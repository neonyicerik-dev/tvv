<?php
// NeonTV - Kitaplığım: İzleme geçmişi + Daha sonra izle
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/supabase.php';
$tab = pgEnum($_GET['tab'] ?? '', ['later', 'history', 'lists'], 'later');
$listId = isUuid(trim($_GET['id'] ?? '')) ? trim($_GET['id']) : '';
$pageTitle = $tab === 'history' ? 'İzleme Geçmişi' : ($tab === 'lists' ? 'Listelerim' : 'Daha Sonra İzle');
$metaDesc  = 'NeonTV kitaplığın.';
?>
<?php include __DIR__ . '/components/header.php'; ?>
<div class="max-w-screen-xl mx-auto px-4 sm:px-6 py-8">
    <div class="flex items-center gap-2 mb-6">
        <a href="?tab=later" class="px-4 py-2 rounded-full text-sm font-medium" style="<?= $tab==='later' ? 'background:rgba(0,245,255,0.12);color:#00f5ff;border:1px solid rgba(0,245,255,0.4)' : 'background:rgba(255,255,255,0.06);color:#9ca3af;border:1px solid rgba(255,255,255,0.1)' ?>"><i class="fa-regular fa-clock mr-1.5"></i>Daha Sonra İzle</a>
        <a href="?tab=history" class="px-4 py-2 rounded-full text-sm font-medium" style="<?= $tab==='history' ? 'background:rgba(0,245,255,0.12);color:#00f5ff;border:1px solid rgba(0,245,255,0.4)' : 'background:rgba(255,255,255,0.06);color:#9ca3af;border:1px solid rgba(255,255,255,0.1)' ?>"><i class="fa-solid fa-clock-rotate-left mr-1.5"></i>Geçmiş</a>
        <a href="?tab=lists" class="px-4 py-2 rounded-full text-sm font-medium" style="<?= $tab==='lists' ? 'background:rgba(0,245,255,0.12);color:#00f5ff;border:1px solid rgba(0,245,255,0.4)' : 'background:rgba(255,255,255,0.06);color:#9ca3af;border:1px solid rgba(255,255,255,0.1)' ?>"><i class="fa-solid fa-list-ul mr-1.5"></i>Listelerim</a>
        <?php if ($tab === 'history'): ?>
        <button id="clear-history" class="ml-auto text-xs text-gray-500 hover:text-red-400"><i class="fa-solid fa-trash mr-1"></i>Geçmişi temizle</button>
        <?php endif; ?>
    </div>
    <div id="lib-msg" class="text-gray-500 text-sm py-10 text-center">Yükleniyor...</div>
    <div id="lib-grid" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5"></div>
</div>
<script>
window.addEventListener('load', async function () {
    const TAB = '<?= $tab ?>', BASE = '<?= APP_URL ?>';
    const msg = document.getElementById('lib-msg'), grid = document.getElementById('lib-grid');
    const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
    const fmt = s => { s = Math.floor(s || 0); const h = Math.floor(s/3600), m = Math.floor(s%3600/60), x = s%60; return (h ? h + ':' + String(m).padStart(2,'0') : m) + ':' + String(x).padStart(2,'0'); };
    async function tok() { try { const { data } = await sbClient.auth.getSession(); if (data.session) return data.session.access_token; } catch (e) {} try { return localStorage.getItem('sb_access_token'); } catch (e) { return null; } }
    const t = await tok();
    const LIST_ID = '<?= $listId ?>';
    if (!t && !(TAB === 'lists' && LIST_ID)) { msg.innerHTML = 'Bu sayfa için <a class="text-cyan-400 underline" href="' + BASE + '/auth.php">giriş yapmalısın</a>.'; return; }
    const hdr = t ? { 'Authorization': 'Bearer ' + t, 'X-Access-Token': t } : {};
    const tq = t ? '&token=' + encodeURIComponent(t) : '';
    const card = v => '<a href="' + BASE + '/video.php?id=' + esc(v.id) + '" class="block rounded-2xl overflow-hidden" style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.06)"><div class="relative" style="aspect-ratio:16/9;background:#13131f"><img src="' + esc(v.thumbnail_url) + '" class="w-full h-full object-cover" loading="lazy">' + (v.duration ? '<span class="absolute bottom-2 right-2 text-[10px] font-bold px-1.5 py-0.5 rounded" style="background:rgba(0,0,0,.8)">' + fmt(v.duration) + '</span>' : '') + '</div><div class="p-3"><h3 class="text-sm font-semibold text-white">' + esc(v.title) + '</h3><p class="text-xs text-gray-500 mt-1">' + esc(v.views) + ' görüntülenme</p></div></a>';
    async function post(body) { return (await fetch(BASE + '/api/user_playlists.php?x=1' + tq, { method: 'POST', headers: Object.assign({ 'Content-Type': 'application/json' }, hdr), body: JSON.stringify(body) })).json(); }
    if (TAB === 'lists') {
        try {
            if (LIST_ID) {
                const j = await (await fetch(BASE + '/api/user_playlists.php?id=' + LIST_ID + tq, { headers: hdr })).json();
                if (!j.success) { msg.textContent = j.message || 'Liste açılamadı.'; return; }
                const d = j.data; msg.remove();
                let head = '<div class="col-span-full flex items-center gap-3 flex-wrap"><h2 class="text-lg font-bold text-white">' + esc(d.playlist.title) + '</h2>';
                if (d.playlist.owner) head += '<label class="text-xs text-gray-400 flex items-center gap-1.5"><input type="checkbox" id="vis" class="accent-cyan-400"' + (d.playlist.is_public ? ' checked' : '') + '> Herkese açık</label><button id="del" class="text-xs text-red-400">Listeyi sil</button>';
                grid.innerHTML = head + '</div>' + (d.items.length ? d.items.map(card).join('') : '<p class="text-gray-500 text-sm col-span-full">Bu listede video yok.</p>');
                document.getElementById('vis')?.addEventListener('change', e => post({ action: 'visibility', playlist_id: LIST_ID, is_public: e.target.checked }));
                document.getElementById('del')?.addEventListener('click', async () => { if (confirm('Liste silinsin mi?')) { await post({ action: 'delete', playlist_id: LIST_ID }); location.href = '?tab=lists'; } });
                return;
            }
            const j = await (await fetch(BASE + '/api/user_playlists.php?x=1' + tq, { headers: hdr })).json();
            const L = (j.data && j.data.lists) || []; msg.remove();
            grid.innerHTML = '<form id="newl" class="col-span-full flex gap-2"><input id="nt" maxlength="80" placeholder="Yeni liste adı" class="bg-black/30 border border-gray-800 rounded-xl py-2 px-3 text-white text-sm"><button class="px-4 rounded-xl text-sm font-bold text-black" style="background:#00f5ff">Oluştur</button></form>' +
                L.map(l => '<a href="?tab=lists&id=' + esc(l.id) + '" class="block rounded-2xl p-4 text-white hover:text-cyan-400" style="background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08)"><i class="fa-solid fa-list-ul mr-2 text-cyan-400"></i>' + esc(l.title) + '<span class="block text-xs text-gray-500 mt-1">' + l.count + ' video · ' + (l.is_public ? 'herkese açık' : 'gizli') + '</span></a>').join('');
            document.getElementById('newl').onsubmit = async e => { e.preventDefault(); const v = document.getElementById('nt').value.trim(); if (v) { await post({ action: 'create', title: v }); location.reload(); } };
        } catch (e) { msg.textContent = 'Liste yüklenemedi.'; }
        return;
    }
    document.getElementById('clear-history')?.addEventListener('click', async () => {
        if (!confirm('Tüm izleme geçmişi silinsin mi?')) return;
        await fetch(BASE + '/api/history.php?all=1&token=' + encodeURIComponent(t), { method: 'DELETE', headers: hdr });
        location.reload();
    });
    try {
        const r = await fetch(BASE + '/api/library.php?tab=' + TAB + '&token=' + encodeURIComponent(t), { headers: hdr });
        const j = await r.json();
        const items = (j.data && j.data.items) || [];
        if (!items.length) { msg.textContent = TAB === 'history' ? 'Henüz izlediğin video yok.' : 'Listen boş. Video sayfasındaki "Sonra İzle" butonuyla ekleyebilirsin.'; return; }
        msg.remove();
        grid.innerHTML = items.map(v => {
            const pct = (v.duration > 0 && v.position > 0) ? Math.min(100, Math.round(v.position / v.duration * 100)) : 0;
            return '<a href="' + BASE + '/video.php?id=' + esc(v.id) + '" class="block rounded-2xl overflow-hidden" style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.06)">' +
              '<div class="relative" style="aspect-ratio:16/9;background:#13131f"><img src="' + esc(v.thumbnail_url) + '" class="w-full h-full object-cover" loading="lazy">' +
              (v.duration ? '<span class="absolute bottom-2 right-2 text-[10px] font-bold px-1.5 py-0.5 rounded" style="background:rgba(0,0,0,.8)">' + fmt(v.duration) + '</span>' : '') +
              (pct ? '<div class="absolute bottom-0 left-0 h-1" style="width:' + pct + '%;background:#00f5ff"></div>' : '') + '</div>' +
              '<div class="p-3"><h3 class="text-sm font-semibold text-white" style="display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden">' + esc(v.title) + '</h3>' +
              '<p class="text-xs text-gray-500 mt-1">' + (pct ? '%' + pct + ' izlendi · ' : '') + esc(v.views) + ' görüntülenme</p></div></a>';
        }).join('');
    } catch (e) { msg.textContent = 'Liste yüklenemedi.'; }
});
</script>
<?php include __DIR__ . '/components/footer.php'; ?>
