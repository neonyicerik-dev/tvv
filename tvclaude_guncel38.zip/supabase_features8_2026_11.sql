-- ============================================================
-- NeonTV – Özellikler 8 (Kasım 2026)
--  • Premium profil teması + avatar çerçevesi (user_themes)
--  • Videoda "kalkacak" tarihi (videos.expires_at)
--  • Giriş cihazı kayıtları / şüpheli giriş uyarısı (login_events)
--  • Aranan kelime günlüğü (search_log) – istatistik panosu için
-- Tüm yeni tablolar: RLS açık, anon/authenticated erişimi kapalı, yalnızca service_role.
-- ============================================================

-- ---- Premium tema + çerçeve ----
CREATE TABLE IF NOT EXISTS public.user_themes (
    user_id    uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    theme      text,
    frame      text,
    updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.user_themes ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.user_themes FROM anon, authenticated;
GRANT ALL ON public.user_themes TO service_role;

-- ---- Videonun kalkacağı tarih (CDN geçici klasörü vb.) ----
ALTER TABLE public.videos ADD COLUMN IF NOT EXISTS expires_at timestamptz;
CREATE INDEX IF NOT EXISTS videos_expires_at_idx ON public.videos (expires_at) WHERE expires_at IS NOT NULL;

-- ---- Giriş olayları (yeni cihaz uyarısı için, kişisel veri içermez: yalnızca hash) ----
CREATE TABLE IF NOT EXISTS public.login_events (
    id         bigserial PRIMARY KEY,
    user_id    uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    ip_hash    text NOT NULL,
    ua_hash    text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS login_events_user_idx ON public.login_events (user_id, created_at DESC);
ALTER TABLE public.login_events ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.login_events FROM anon, authenticated;
GRANT ALL ON public.login_events TO service_role;
GRANT USAGE, SELECT ON SEQUENCE public.login_events_id_seq TO service_role;

-- ---- Aranan kelimeler (istatistik panosu) ----
CREATE TABLE IF NOT EXISTS public.search_log (
    id         bigserial PRIMARY KEY,
    q          text NOT NULL,
    results    integer,
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS search_log_created_idx ON public.search_log (created_at DESC);
ALTER TABLE public.search_log ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.search_log FROM anon, authenticated;
GRANT ALL ON public.search_log TO service_role;
GRANT USAGE, SELECT ON SEQUENCE public.search_log_id_seq TO service_role;

-- 90 günden eski arama ve 180 günden eski giriş kayıtlarını temizleyen yardımcı (isteğe bağlı cron)
CREATE OR REPLACE FUNCTION public.cleanup_features8()
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
    DELETE FROM public.search_log   WHERE created_at < now() - INTERVAL '90 days';
    DELETE FROM public.login_events WHERE created_at < now() - INTERVAL '180 days';
END; $$;
REVOKE ALL ON FUNCTION public.cleanup_features8() FROM public, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.cleanup_features8() TO service_role;
