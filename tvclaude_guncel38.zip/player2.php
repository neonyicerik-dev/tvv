<?php
// ============================================================
// NeonTV - Video İzleme Sayfası (PlayerJS Player)
// Bu dosya video.php'nin kopyasıdır; player.js yerine player/playerjs.js kullanır
// ============================================================
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/supabase.php';

if (isMaintenanceMode() && !isAdminLoggedIn()) {
    die('<!DOCTYPE html><html><head><meta charset="utf-8"><title>Bakım Modu</title><style>body{background:#070711;color:#fff;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;text-align:center;padding:20px;}h1{color:#00f5ff;}</style></head><body><div><h1>Bakım Modu</h1><p>' . htmlspecialchars(getMaintenanceMessage()) . '</p></div></body></html>');
}

// Zamanlanmış videoları yayınla
publishScheduledVideos();

$videoId = trim($_GET['id'] ?? '');
if (!$videoId || !preg_match('/^[0-9a-f\-]{36}$/', $videoId)) {
    header('Location: ' . APP_URL . '/index.php');
    exit;
}

$db    = new Supabase();
$videoRes = $db->select('videos', 'id=eq.' . $videoId . '&status=eq.published&select=*,channels(*)');
$video = $videoRes['data'][0] ?? null;

if (!$video) {
    http_response_code(404);
    header('Location: ' . APP_URL . '/index.php');
    exit;
}

// Subtitle
$subtitle = $db->first('subtitles', 'video_id=eq.' . $videoId . '&language=eq.tr');

// Chapters
$chaptersRes = $db->select('chapters', 'video_id=eq.' . $videoId . '&order=start_time.asc', true);
$chapters    = $chaptersRes['data'] ?? [];

// İlgili videolar
$related = $db->select('videos',
    'status=eq.published&id=neq.' . $videoId . '&order=views.desc&limit=8'
);
$relatedVideos = $related['data'] ?? [];

// Yorumları çek ve ağaç yapısı oluştur (Nested Comments)
$commentsRes = $db->select('comments',
    'video_id=eq.' . $videoId . '&order=created_at.asc&select=*,profiles(username,avatar_url)'
);
$commentsRaw = $commentsRes['data'] ?? [];
$commentTree = [];
foreach ($commentsRaw as $c) {
    if (!$c['parent_id']) $commentTree[$c['id']] = ['comment' => $c, 'replies' => []];
}
foreach ($commentsRaw as $c) {
    if ($c['parent_id'] && isset($commentTree[$c['parent_id']])) {
        $commentTree[$c['parent_id']]['replies'][] = $c;
    }
}
// Kök yorumları yeniden eskiye sırala
usort($commentTree, fn($a, $b) => strtotime($b['comment']['created_at']) - strtotime($a['comment']['created_at']));


$pageTitle = $video['title'];
$metaDesc  = truncate($video['description'] ?? 'NeonTV videosunu izleyin.', 160);
$ogImage   = $video['thumbnail_url'] ?? '';
?>
<?php include __DIR__ . '/components/header.php'; ?>


<div class="max-w-screen-2xl mx-auto px-4 sm:px-6 py-6" id="video-page">
    <div class="flex flex-col xl:flex-row gap-6">

        <!-- ===== SOL: VİDEO OYNATICI + BİLGİ ===== -->
        <div class="flex-1 min-w-0" id="main-col">

            <!-- Video Player -->
            <div id="player-container" style="aspect-ratio:16/9;"></div>

            <!-- #9 Zoom indicator -->
            <div id="zoom-indicator">1.0×</div>

            <!-- ===== VİDEO BİLGİLERİ ===== -->
            <div class="mt-4">
                <h1 class="text-xl sm:text-2xl font-bold text-white leading-tight" id="video-title">
                    <?= e($video['title']) ?>
                </h1>

                <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mt-3">
                    <!-- İstatistikler -->
                    <div class="flex items-center gap-5 text-sm text-gray-500">
                        <span class="flex items-center gap-1.5">
                            <i class="fa-solid fa-eye text-gray-600"></i>
                            <span id="view-count"><?= formatNumber((int)($video['views'] ?? 0)) ?></span> izlenme
                        </span>
                        <span class="flex items-center gap-1.5">
                            <i class="fa-regular fa-clock text-gray-600"></i>
                            <?= timeAgo($video['created_at']) ?>
                        </span>
                        <?php if (!empty($video['duration'])): ?>
                        <span class="flex items-center gap-1.5">
                            <i class="fa-solid fa-film text-gray-600"></i>
                            <?= formatDuration((int)$video['duration']) ?>
                        </span>
                        <?php endif; ?>
                    </div>

                    <!-- Aksiyon Butonları -->
                    <div class="flex items-center gap-2 flex-wrap">
                        <!-- Beğeni -->
                        <button id="like-btn" data-video-id="<?= e($videoId) ?>"
                                class="flex items-center gap-2 px-4 py-2 rounded-full font-semibold text-sm transition-all duration-300 hover:scale-105"
                                style="background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.12);">
                            <i class="fa-regular fa-heart text-sm" id="like-icon"></i>
                            <span id="like-count"><?= formatNumber((int)($video['likes_count'] ?? 0)) ?></span>
                            <span class="hidden sm:inline text-gray-400">Beğen</span>
                        </button>

                        <!-- Paylaş -->
                        <button id="share-btn"
                                class="flex items-center gap-2 px-4 py-2 rounded-full text-sm text-gray-400 hover:text-white transition-all duration-300 hover:scale-105"
                                style="background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.12);"
                                onclick="shareVideo()">
                            <i class="fa-solid fa-share-nodes text-sm"></i>
                            <span class="hidden sm:inline">Paylaş</span>
                        </button>


                        <?php if ($subtitle): ?>
                        <!-- Altyazı badge -->
                        <span class="flex items-center gap-1.5 px-3 py-2 rounded-full text-xs font-semibold"
                              style="background:rgba(0,245,255,0.08);border:1px solid rgba(0,245,255,0.2);color:#00f5ff;">
                            <i class="fa-solid fa-closed-captioning text-xs"></i>
                            Altyazı
                        </span>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Kanal Bilgisi -->
                <?php if (!empty($video['channels'])): ?>
                <div class="mt-5 p-4 rounded-xl flex items-center justify-between" style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.06);">
                    <a href="<?= APP_URL ?>/channel?id=<?= e($video['channels']['id']) ?>" class="flex items-center gap-4 group min-w-0">
                        <div class="w-12 h-12 rounded-full overflow-hidden bg-gray-800 flex items-center justify-center text-xl font-bold border-2 border-transparent group-hover:border-cyan-400 transition-colors shrink-0">
                            <?php if (!empty($video['channels']['avatar_url'])): ?>
                                <img src="<?= e($video['channels']['avatar_url']) ?>" class="w-full h-full object-cover">
                            <?php else: ?>
                                <?= strtoupper(substr($video['channels']['name'], 0, 1)) ?>
                            <?php endif; ?>
                        </div>
                        <div class="min-w-0">
                            <h3 class="font-bold text-white text-lg group-hover:text-cyan-400 transition-colors truncate"><?= e($video['channels']['name']) ?></h3>
                            <p class="text-xs text-gray-500">Resmi Kanal</p>
                        </div>
                    </a>
                    <button id="subscribe-btn" data-channel-id="<?= e($video['channels']['id']) ?>"
                            class="shrink-0 ml-4 px-5 py-2 rounded-full font-bold text-sm text-black bg-white hover:bg-cyan-400 transition-colors">
                        <i class="fa-solid fa-bell mr-1"></i>Abone Ol
                    </button>
                </div>
                <?php endif; ?>

                <!-- Divider -->
                <div class="my-4" style="border-top:1px solid rgba(255,255,255,0.06);"></div>

                <!-- Tags -->
                <?php if (!empty($video['tags'])): ?>
                <div class="flex flex-wrap gap-2 mb-4">
                    <?php foreach ((array)$video['tags'] as $tag): ?>
                    <span class="px-3 py-1 rounded-full text-xs font-medium"
                          style="background:rgba(191,0,255,0.08);color:#bf00ff;border:1px solid rgba(191,0,255,0.2);">
                        #<?= e($tag) ?>
                    </span>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>

                <!-- Açıklama -->
                <?php if (!empty($video['description'])): ?>
                <div id="description-block" class="rounded-xl overflow-hidden"
                     style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.06);">
                    <div class="p-4">
                        <p class="text-gray-300 text-sm leading-relaxed whitespace-pre-line" id="video-description"
                           style="max-height: 100px; overflow: hidden;" id="desc-text">
                            <?php
                                $descSafe = e($video['description']);
                                $descWithLinks = preg_replace_callback('/#([\wıİğĞüÜşŞöÖçÇ]+)/u', function($m) {
                                    $word = $m[1];
                                    return '<a href="' . APP_URL . '/search.php?q=%23' . urlencode($word) . '" class="hover:underline transition-colors" style="color: #00f5ff; font-weight: 500;">#' . $word . '</a>';
                                }, $descSafe);
                                echo $descWithLinks;
                            ?>
                        </p>
                    </div>
                    <button onclick="toggleDesc(this)"
                            class="w-full text-center py-2 text-xs text-gray-600 hover:text-cyan-400 transition-colors"
                            style="border-top:1px solid rgba(255,255,255,0.04);"
                            data-expanded="false">
                        <i class="fa-solid fa-chevron-down text-[10px] mr-1"></i>Devamını Göster
                    </button>
                </div>
                <?php endif; ?>
            </div>

            <!-- ===== YORUMLAR ===== -->
            <div class="mt-8" id="comments-section">
                <h2 class="text-lg font-bold text-white mb-5 flex items-center gap-2">
                    <i class="fa-solid fa-comments text-base" style="color:#bf00ff;"></i>
                    Yorumlar
                    <span class="text-sm font-normal text-gray-500 ml-1"><?= (int)($video['comments_count'] ?? 0) ?></span>
                </h2>

                <!-- Yorum Formu -->
                <div id="comment-form-area" class="mb-6">
                    <!-- Giriş yapılmadıysa -->
                    <div id="comment-login-prompt" class="rounded-xl p-4 flex items-center gap-4"
                         style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.08);">
                        <div class="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0"
                             style="background:rgba(255,255,255,0.06);">
                            <i class="fa-solid fa-lock text-gray-600 text-sm"></i>
                        </div>
                        <div>
                            <p class="text-gray-300 text-sm font-medium">Yorum yapmak için giriş yapın</p>
                            <a href="<?= APP_URL ?>/auth.php" class="text-neon-cyan text-sm hover:underline">Giriş Yap / Kayıt Ol</a>
                        </div>
                    </div>

                    <!-- Giriş yapıldıysa -->
                    <form id="comment-form" class="hidden" onsubmit="submitComment(event)">
                        <div class="flex gap-3">
                            <div class="w-9 h-9 rounded-full flex-shrink-0 flex items-center justify-center text-xs font-bold mt-0.5"
                                 style="background:linear-gradient(135deg,#00f5ff,#bf00ff);color:#000;" id="comment-user-avatar">
                                U
                            </div>
                            <div class="flex-1">
                                <textarea
                                    id="comment-input"
                                    placeholder="Düşüncelerinizi paylaşın..."
                                    rows="3"
                                    maxlength="2000"
                                    class="w-full px-4 py-3 rounded-xl text-sm text-white placeholder-gray-600 resize-none outline-none transition-all duration-200"
                                    style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);"
                                    onfocus="this.style.borderColor='rgba(0,245,255,0.4)'"
                                    onblur="this.style.borderColor='rgba(255,255,255,0.1)'"
                                ></textarea>
                                <div class="flex items-center justify-between mt-2">
                                    <span class="text-xs text-gray-700" id="comment-char-count">0 / 2000</span>
                                    <div class="flex gap-2">
                                        <button type="button" onclick="cancelReply()" id="cancel-reply-btn"
                                                class="hidden px-4 py-1.5 rounded-lg text-xs text-gray-500 hover:text-white transition-colors"
                                                style="background:rgba(255,255,255,0.06);">
                                            Yanıtı İptal Et
                                        </button>
                                        <button type="button" onclick="document.getElementById('comment-input').value='';updateCharCount()"
                                                class="px-4 py-1.5 rounded-lg text-xs text-gray-500 hover:text-white transition-colors"
                                                style="background:rgba(255,255,255,0.06);">
                                            Temizle
                                        </button>
                                        <button type="submit" id="comment-submit-btn"
                                                class="flex items-center gap-2 px-5 py-1.5 rounded-lg text-xs font-semibold text-black transition-all duration-200 hover:scale-105"
                                                style="background:linear-gradient(135deg,#00f5ff,#bf00ff);">
                                            <i class="fa-solid fa-paper-plane text-xs"></i>
                                            Gönder
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>

                <div id="comments-list" class="space-y-6">
                    <?php if (empty($commentTree)): ?>
                    <div class="text-center py-8 text-gray-600" id="no-comments-msg">
                        <i class="fa-regular fa-comment-dots text-3xl mb-2 block opacity-40"></i>
                        Henüz yorum yok. İlk yorumu siz yapın!
                    </div>
                    <?php else: ?>
                    <?php foreach ($commentTree as $item): $comment = $item['comment']; ?>
                    <div class="comment-thread" id="thread-<?= e($comment['id']) ?>">
                        <!-- Root Comment -->
                        <div class="flex gap-3 comment-item" id="comment-<?= e($comment['id']) ?>">
                            <?php if (!empty($comment['profiles']['avatar_url'])): ?>
                            <img src="<?= e($comment['profiles']['avatar_url']) ?>" alt="Avatar" class="w-10 h-10 rounded-full object-cover flex-shrink-0 border border-gray-700">
                            <?php else: ?>
                            <div class="w-10 h-10 rounded-full flex-shrink-0 flex items-center justify-center text-sm font-bold"
                                 style="background:linear-gradient(135deg,#bf00ff,#ff007a);color:#fff;">
                                <?= strtoupper(substr($comment['profiles']['username'] ?? 'U', 0, 1)) ?>
                            </div>
                            <?php endif; ?>
                            <div class="flex-1 min-w-0">
                                <div class="flex items-center gap-2 mb-1">
                                    <span class="text-sm font-bold text-white"><?= e($comment['profiles']['username'] ?? 'Kullanıcı') ?></span>
                                    <span class="text-xs text-gray-600"><?= timeAgo($comment['created_at']) ?></span>
                                </div>
                                <p class="text-gray-300 text-sm leading-relaxed"><?= e($comment['content']) ?></p>
                                <button onclick="replyTo('<?= e($comment['id']) ?>', '<?= e($comment['profiles']['username']) ?>')" class="text-xs text-gray-500 hover:text-cyan-400 mt-2 font-semibold transition-colors">
                                    Yanıtla
                                </button>
                            </div>
                        </div>

                        <!-- Replies -->
                        <?php if (!empty($item['replies'])): ?>
                        <div class="ml-10 mt-4 space-y-4 border-l-2 border-gray-800 pl-4">
                            <?php foreach ($item['replies'] as $reply): ?>
                            <div class="flex gap-3 comment-item" id="comment-<?= e($reply['id']) ?>">
                                <?php if (!empty($reply['profiles']['avatar_url'])): ?>
                                <img src="<?= e($reply['profiles']['avatar_url']) ?>" alt="Avatar" class="w-8 h-8 rounded-full object-cover flex-shrink-0 border border-gray-700">
                                <?php else: ?>
                                <div class="w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center text-xs font-bold"
                                     style="background:linear-gradient(135deg,#00f5ff,#bf00ff);color:#000;">
                                    <?= strtoupper(substr($reply['profiles']['username'] ?? 'U', 0, 1)) ?>
                                </div>
                                <?php endif; ?>
                                <div class="flex-1 min-w-0">
                                    <div class="flex items-center gap-2 mb-1">
                                        <span class="text-sm font-bold text-white"><?= e($reply['profiles']['username'] ?? 'Kullanıcı') ?></span>
                                        <span class="text-xs text-gray-600"><?= timeAgo($reply['created_at']) ?></span>
                                    </div>
                                    <p class="text-gray-300 text-sm leading-relaxed"><?= e($reply['content']) ?></p>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- ===== SAĞ: İLGİLİ VİDEOLAR ===== -->
        <div class="xl:w-96 flex-shrink-0" id="related-sidebar">
            <h3 class="text-base font-semibold text-white mb-4 flex items-center gap-2">
                <i class="fa-solid fa-list-ul text-neon-cyan text-sm"></i>
                İlgili Videolar
            </h3>

            <?php if (empty($relatedVideos)): ?>
            <p class="text-gray-600 text-sm">Başka video bulunamadı.</p>
            <?php else: ?>
            <div class="space-y-3" id="related-videos-list">
                <?php foreach ($relatedVideos as $rv): ?>
                <div class="group rounded-xl p-2 transition-all duration-200 hover:bg-white/[0.04]">
                    <a href="<?= APP_URL ?>/video.php?id=<?= e($rv['id']) ?>"
                       class="flex gap-3"
                       id="related-<?= e($rv['id']) ?>">
                        <div class="relative flex-shrink-0 w-32 rounded-lg overflow-hidden" style="aspect-ratio:16/9;background:#0d0d1a;">
                            <img src="<?= e($rv['thumbnail_url'] ?? 'https://placehold.co/320x180/070711/00f5ff?text=NeonTV') ?>"
                                 alt="<?= e($rv['title']) ?>"
                                 class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                                 loading="lazy">
                            <?php if (!empty($rv['duration'])): ?>
                            <div class="absolute bottom-1 right-1 text-[10px] font-bold px-1.5 py-0.5 rounded"
                                 style="background:rgba(0,0,0,0.8);color:#fff;">
                                <?= formatDuration((int)$rv['duration']) ?>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="flex-1 min-w-0">
                            <p class="text-sm font-medium text-gray-200 leading-snug group-hover:text-cyan-400 transition-colors"
                               style="display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;">
                                <?= e($rv['title']) ?>
                            </p>
                            <p class="text-xs text-gray-600 mt-1.5 flex items-center gap-1">
                                <i class="fa-solid fa-eye text-[10px]"></i><?= formatNumber((int)($rv['views'] ?? 0)) ?>
                                <span class="mx-0.5">·</span>
                                <?= timeAgo($rv['created_at']) ?>
                            </p>
                        </div>
                    </a>
                    <!-- #15 Kuyruğa Ekle -->
                    <button onclick="addToQueue('<?= e($rv['id']) ?>', '<?= e(addslashes($rv['title'])) ?>', '<?= e($rv['thumbnail_url'] ?? '') ?>', this)"
                            class="mt-1.5 w-full text-left text-xs text-gray-600 hover:text-cyan-400 transition-colors px-1 flex items-center gap-1"
                            id="queue-btn-<?= e($rv['id']) ?>">
                        <i class="fa-solid fa-circle-plus text-[10px]"></i>
                        <span>Kuyruğa Ekle</span>
                    </button>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <!-- #30 Queue Panel -->
            <div id="queue-panel" class="hidden mt-4">
                <div class="flex items-center justify-between px-4 py-3" style="border-bottom:1px solid rgba(255,255,255,0.06);">
                    <h4 class="text-sm font-bold text-white flex items-center gap-2">
                        <i class="fa-solid fa-layer-group text-neon-cyan text-xs"></i>
                        Sıra <span id="queue-count" class="text-xs text-gray-500 font-normal"></span>
                    </h4>
                    <button onclick="clearQueue()" class="text-xs text-gray-600 hover:text-red-400 transition-colors">
                        <i class="fa-solid fa-trash-can text-[10px] mr-1"></i>Temizle
                    </button>
                </div>
                <div id="queue-list" class="divide-y divide-white/[0.04]"></div>
            </div>
        </div>

    </div>
</div>

<!-- ===== MINI PLAYER (playerjs.js tarafından oluşturulur) ===== -->
<div id="mini-player" class="hidden"></div>
</div>

<!-- #10 Screenshot Toast (playerjs.js tarafından oluşturulur) -->
<div id="screenshot-toast"></div>






<!-- ===== HIDDEN DATA ===== -->
<script>
const VIDEO_ID        = '<?= e($videoId) ?>';
const VIDEO_URL       = '<?= e($video['video_url']) ?>';
const VIDEO_THUMBNAIL = '<?= e($video['thumbnail_url'] ?? '') ?>';
const HAS_SUBTITLE    = <?= $subtitle ? 'true' : 'false' ?>;
const SUBTITLE_SRC    = <?= $subtitle ? "'data:text/vtt;charset=utf-8;base64," . base64_encode($subtitle['content']) . "'" : 'null' ?>;
const NEXT_VIDEO_ID   = '<?= !empty($relatedVideos[0]) ? e($relatedVideos[0]['id']) : '' ?>';
const NEXT_VIDEO_TITLE= '<?= !empty($relatedVideos[0]) ? e(addslashes($relatedVideos[0]['title'])) : '' ?>';
const APP_URL_JS      = '<?= APP_URL ?>';
const VIDEO_TITLE     = '<?= e(addslashes($video['title'])) ?>';
const VIDEO_PAGE_URL  = window.location.href;

// #12 Chapters verisi
window._chapters = <?= json_encode(array_values($chapters)) ?>;

// #15 Kuyruk fonksiyonları - Güncel (thumbnail destekli)
function addToQueue(videoId, title, thumb, btn) {
    const queue = JSON.parse(localStorage.getItem('neontv_queue') || '[]');
    if (queue.find(q => q.id === videoId)) {
        if (btn) { btn.innerHTML = '<i class="fa-solid fa-check text-[10px]"></i><span>Eklendi</span>'; btn.style.color = '#6b7280'; }
        return;
    }
    queue.push({ id: videoId, title: title, thumb: thumb });
    localStorage.setItem('neontv_queue', JSON.stringify(queue));
    if (btn) {
        btn.innerHTML = '<i class="fa-solid fa-check text-[10px] text-cyan-400"></i><span class="text-cyan-400">Kuyruğa Eklendi!</span>';
        setTimeout(() => { btn.innerHTML = '<i class="fa-solid fa-circle-plus text-[10px]"></i><span>Kuyruğa Ekle</span>'; btn.style.color = ''; }, 2000);
    }
    renderQueuePanel();
}

function clearQueue() {
    localStorage.removeItem('neontv_queue');
    renderQueuePanel();
}

function removeFromQueue(videoId) {
    const queue = JSON.parse(localStorage.getItem('neontv_queue') || '[]').filter(q => q.id !== videoId);
    localStorage.setItem('neontv_queue', JSON.stringify(queue));
    renderQueuePanel();
}

function renderQueuePanel() {
    const panel = document.getElementById('queue-panel');
    const list  = document.getElementById('queue-list');
    const count = document.getElementById('queue-count');
    if (!panel || !list) return;

    const queue = JSON.parse(localStorage.getItem('neontv_queue') || '[]');
    if (!queue.length) { panel.classList.add('hidden'); return; }

    panel.classList.remove('hidden');
    if (count) count.textContent = `(${queue.length})`;

    list.innerHTML = queue.map((item, i) => `
        <div class="queue-item" data-id="${item.id}">
            <span class="text-xs text-gray-600 font-mono w-4 text-center">${i + 1}</span>
            <img src="${item.thumb || 'https://placehold.co/64x36/070711/00f5ff?text=N'}"
                 style="width:56px;height:32px;object-fit:cover;border-radius:6px;flex-shrink:0;background:#0d0d1a;">
            <a href="${APP_URL_JS}/video.php?id=${item.id}" class="flex-1 min-w-0 text-xs text-gray-300 hover:text-cyan-400 transition-colors"
               style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${item.title}</a>
            <button onclick="removeFromQueue('${item.id}')" class="text-gray-600 hover:text-red-400 transition-colors flex-shrink-0">
                <i class="fa-solid fa-xmark text-[10px]"></i>
            </button>
        </div>
    `).join('');
}

document.addEventListener('DOMContentLoaded', () => renderQueuePanel());

// #12 Chapter verileri window._chapters'ta mevcut; playerjs.js tarafından kullanılır

// Görüntülenme sayısını artır
fetch('<?= APP_URL ?>/api/views.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ video_id: VIDEO_ID })
});

// Video süresi algılama ve kaydetme
<?php if (empty($video['duration'])): ?>
document.getElementById('main-video')?.addEventListener('loadedmetadata', async function() {
    const dur = Math.round(this.duration);
    if (dur > 0) {
        // Toplam süreyi göster
        const totalTimeEl = document.getElementById('total-time');
        // Süreyi DB'ye kaydet
        try {
            await fetch('<?= APP_URL ?>/api/videos.php?id=<?= e($videoId) ?>', {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ duration: dur })
            });
        } catch(e) {}
    }
});
<?php endif; ?>

// Subscribe butonu
document.getElementById('subscribe-btn')?.addEventListener('click', async function() {
    const token = getAuthToken();
    if (!token) {
        window.location.href = '<?= APP_URL ?>/auth';
        return;
    }
    const btn = this;
    const channelId = btn.dataset.channelId;
    const isSubscribed = btn.dataset.subscribed === 'true';
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin mr-1"></i>İşleniyor...';
    
    try {
        const res = await fetch('<?= APP_URL ?>/api/channels.php?subscribe=' + channelId + '&token=' + token, {
            method: 'POST',
            headers: { 'Authorization': 'Bearer ' + token, 'Content-Type': 'application/json' }
        });
        const data = await res.json();
        if (data.subscribed) {
            btn.innerHTML = '<i class="fa-solid fa-check mr-1"></i>Abone Olundu';
            btn.style.background = '#00f5ff';
            btn.style.color = '#000';
            btn.dataset.subscribed = 'true';
        } else {
            btn.innerHTML = '<i class="fa-solid fa-bell mr-1"></i>Abone Ol';
            btn.style.background = '';
            btn.style.color = '';
            btn.dataset.subscribed = 'false';
        }
    } catch(e) {
        btn.innerHTML = '<i class="fa-solid fa-bell mr-1"></i>Abone Ol';
    }
    btn.disabled = false;
});

// Açıklama toggle
function toggleDesc(btn) {
    const desc = document.getElementById('video-description');
    const expanded = btn.dataset.expanded === 'true';
    if (expanded) {
        desc.style.maxHeight = '100px';
        desc.style.overflow = 'hidden';
        btn.innerHTML = '<i class="fa-solid fa-chevron-down text-[10px] mr-1"></i>Devamını Göster';
        btn.dataset.expanded = 'false';
    } else {
        desc.style.maxHeight = 'none';
        desc.style.overflow = 'visible';
        btn.innerHTML = '<i class="fa-solid fa-chevron-up text-[10px] mr-1"></i>Daha Az Göster';
        btn.dataset.expanded = 'true';
    }
}

// Yorum karakter sayacı
function updateCharCount() {
    const input = document.getElementById('comment-input');
    const counter = document.getElementById('comment-char-count');
    if (counter) counter.textContent = (input?.value?.length || 0) + ' / 2000';
}
document.getElementById('comment-input')?.addEventListener('input', updateCharCount);
</script>

<script src="<?= APP_URL ?>/playerjs.js"></script>

<script>
// ============================================================
// Yorum & Beğeni İşlemleri
// ============================================================

// Auth durumuna göre form göster/gizle
document.addEventListener('DOMContentLoaded', () => {
    (async function() {
        if (typeof sbClient !== 'undefined') {
            const { data: { session } } = await sbClient.auth.getSession();
            if (session) {
                document.getElementById('comment-login-prompt')?.classList.add('hidden');
                document.getElementById('comment-form')?.classList.remove('hidden');
                const user  = session.user;
                const uname = user.user_metadata?.username || user.email?.split('@')[0] || 'U';
                const avatarUrl = user.user_metadata?.avatar_url;
                const el    = document.getElementById('comment-user-avatar');
                if (el) {
                    if (avatarUrl) {
                        el.outerHTML = `<img src="${avatarUrl}" id="comment-user-avatar" alt="Avatar" class="w-9 h-9 rounded-full object-cover flex-shrink-0 border border-gray-700 mt-0.5">`;
                    } else {
                        el.textContent = uname.charAt(0).toUpperCase();
                    }
                }
                checkLikeStatus(session.access_token);
                checkSubscribeStatus(session.access_token);
            }
        }
    })();
});

async function deleteComment(id) {
    const token = getAuthToken();
    try {
        const res = await fetch(`<?= APP_URL ?>/api/comments.php?id=${id}&token=${token}`, {
            method: 'DELETE',
            headers: { 'Authorization': 'Bearer ' + token }
        });
        const data = await res.json();
        if (data.success) {
            window.location.reload();
        }
    } catch(e) {}
}

async function checkLikeStatus(token) {
    try {
        const res = await fetch('<?= APP_URL ?>/api/likes.php?video_id=<?= $video['id'] ?? '' ?>&token=' + token, {
            method: 'GET',
            headers: { 'Authorization': 'Bearer ' + token }
        });
        const data = await res.json();
        if (data.liked) setLiked(true);
    } catch(e) {}
}

async function checkSubscribeStatus(token) {
    const btn = document.getElementById('subscribe-btn');
    if (!btn) return;
    const channelId = btn.dataset.channelId;
    if (!channelId) return;
    try {
        // Subscriptions tablosundan direkt okuma yapmak için likes mantığına benzer bir GET endpoint'i lazım,
        // veya abone ol butonuna tıklandığında toggle olduğu için şu anlık basitçe çalışır.
        // İdealde api/channels.php'ye GET ?check_subscribe=ID eklenebilir.
        const res = await fetch(`<?= APP_URL ?>/api/channels.php?check_subscribe=${channelId}&token=${token}`, {
            headers: { 'Authorization': 'Bearer ' + token }
        });
        const data = await res.json();
        if (data.subscribed) {
            btn.innerHTML = '<i class="fa-solid fa-check mr-1"></i>Abone Olundu';
            btn.style.background = '#00f5ff';
            btn.style.color = '#000';
            btn.dataset.subscribed = 'true';
        }
    } catch(e) {}
}

let isLiked = false;
document.getElementById('like-btn')?.addEventListener('click', async function() {
    const token = getAuthToken();
    if (!token) { window.location.href = '<?= APP_URL ?>/auth.php'; return; }

    const method = isLiked ? 'DELETE' : 'POST';
    try {
        const res  = await fetch('<?= APP_URL ?>/api/likes.php?token=' + token, {
            method,
            headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
            body: JSON.stringify({ video_id: VIDEO_ID, token: token })
        });
        const data = await res.json();
        if (data.success) {
            isLiked = !isLiked;
            setLiked(isLiked);
            const vRes  = await fetch(`<?= APP_URL ?>/api/videos.php?id=${VIDEO_ID}`);
            const vData = await vRes.json();
            if (vData.data) document.getElementById('like-count').textContent = formatNum(vData.data.likes_count || 0);
        }
    } catch(e) {}
});

function setLiked(liked) {
    isLiked = liked;
    const btn  = document.getElementById('like-btn');
    const icon = document.getElementById('like-icon');
    if (liked) {
        icon.className = 'fa-solid fa-heart text-sm text-red-400';
        btn.style.borderColor = 'rgba(255,0,122,0.5)';
        btn.style.background  = 'rgba(255,0,122,0.1)';
    } else {
        icon.className = 'fa-regular fa-heart text-sm';
        btn.style.borderColor = 'rgba(255,255,255,0.12)';
        btn.style.background  = 'rgba(255,255,255,0.06)';
    }
}

let replyParentId = null;

function replyTo(commentId, username) {
    replyParentId = commentId;
    const input = document.getElementById('comment-input');
    input.value = `@${username} `;
    input.focus();
    document.getElementById('cancel-reply-btn').classList.remove('hidden');
    
    // Scroll to form
    document.getElementById('comment-form-area').scrollIntoView({behavior: 'smooth', block: 'center'});
}

function cancelReply() {
    replyParentId = null;
    document.getElementById('comment-input').value = '';
    document.getElementById('cancel-reply-btn').classList.add('hidden');
    updateCharCount();
}

async function submitComment(e) {
    e.preventDefault();
    const token   = getAuthToken();
    let content = document.getElementById('comment-input').value.trim();
    if (!content) return;

    const btn = document.getElementById('comment-submit-btn');
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin text-xs"></i> Gönderiliyor';

    try {
        const payload = { video_id: VIDEO_ID, content: content, token: token };
        if (replyParentId) payload.parent_id = replyParentId;

        const res  = await fetch('<?= APP_URL ?>/api/comments.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
            body: JSON.stringify(payload)
        });
        
        let data;
        try {
            data = await res.json();
        } catch (e) {
            throw new Error(`Geçersiz JSON yanıtı. Status: ${res.status}`);
        }

        if (data.success) {
            cancelReply();
            document.getElementById('no-comments-msg')?.remove();

            const c = data.data;
            const prof = c.profiles || {};
            const isReply = !!c.parent_id;
            
            const timeAgo = 'Şimdi';
            
            let avatarHtml = '';
            if (prof.avatar_url) {
                avatarHtml = `<img src="${escHtml(prof.avatar_url)}" alt="Avatar" class="${isReply ? 'w-8 h-8' : 'w-10 h-10'} rounded-full object-cover flex-shrink-0 border border-gray-700">`;
            } else {
                const initial = (prof.username || 'U').charAt(0).toUpperCase();
                avatarHtml = `<div class="${isReply ? 'w-8 h-8 text-xs' : 'w-10 h-10 text-sm'} rounded-full flex-shrink-0 flex items-center justify-center font-bold" style="background:linear-gradient(135deg,#00f5ff,#bf00ff);color:#000;">${initial}</div>`;
            }

            const commentHtml = `
            <div class="flex gap-3 comment-item" id="comment-${escHtml(c.id)}">
                ${avatarHtml}
                <div class="flex-1 min-w-0">
                    <div class="flex items-center gap-2 mb-1">
                        <span class="text-sm font-bold text-white">${escHtml(prof.username)}</span>
                        <span class="text-xs text-gray-600">${timeAgo}</span>
                    </div>
                    <p class="text-gray-300 text-sm leading-relaxed">${escHtml(c.content)}</p>
                    ${!isReply ? `<button onclick="replyTo('${escHtml(c.id)}', '${escHtml(prof.username)}')" class="text-xs text-gray-500 hover:text-cyan-400 mt-2 font-semibold transition-colors">Yanıtla</button>` : ''}
                </div>
            </div>`;

            if (isReply) {
                const thread = document.getElementById('thread-' + c.parent_id);
                if (thread) {
                    let repliesContainer = thread.querySelector('.ml-10.mt-4');
                    if (!repliesContainer) {
                        repliesContainer = document.createElement('div');
                        repliesContainer.className = 'ml-10 mt-4 space-y-4 border-l-2 border-gray-800 pl-4';
                        thread.appendChild(repliesContainer);
                    }
                    repliesContainer.insertAdjacentHTML('beforeend', commentHtml);
                }
            } else {
                const newThreadHtml = `<div class="comment-thread" id="thread-${escHtml(c.id)}">${commentHtml}</div>`;
                document.getElementById('comments-list').insertAdjacentHTML('afterbegin', newThreadHtml);
            }
        } else {
            alert(data.message || 'Bir hata oluştu');
        }
    } catch(err) {
        alert('Bağlantı hatası: ' + err.message);
    }

    btn.disabled = false;
    btn.innerHTML = '<i class="fa-solid fa-paper-plane text-xs"></i> Gönder';
}

function shareVideo() {
    if (navigator.share) {
        navigator.share({ title: '<?= e($video['title']) ?>', url: window.location.href });
    } else {
        navigator.clipboard.writeText(window.location.href);
        const btn = document.getElementById('share-btn');
        const orig = btn.innerHTML;
        btn.innerHTML = '<i class="fa-solid fa-check text-sm"></i><span class="hidden sm:inline">Kopyalandı!</span>';
        btn.style.color = '#00f5ff';
        setTimeout(() => { btn.innerHTML = orig; btn.style.color = ''; }, 2000);
    }
}

function escHtml(t) {
    return t.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function formatNum(n) {
    if (n >= 1e6) return (n/1e6).toFixed(1)+'M';
    if (n >= 1e3) return (n/1e3).toFixed(1)+'K';
    return String(n);
}
</script>

<?php include __DIR__ . '/components/footer.php'; ?>
