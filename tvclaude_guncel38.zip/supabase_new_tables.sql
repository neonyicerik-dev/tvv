-- ============================================================
-- NeonTV - YENİ TABLOLAR (Supabase SQL Editor'da çalıştırın)
-- Bu dosyayı: Supabase Dashboard > SQL Editor > New Query
-- ============================================================

-- ---- profiles ----
CREATE TABLE IF NOT EXISTS public.profiles (
    id          UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    username    TEXT,
    avatar_url  TEXT DEFAULT '',
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- Yeni kullanıcı kaydolunca otomatik profil oluştur
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
    INSERT INTO public.profiles (id, username, avatar_url)
    VALUES (
        NEW.id,
        COALESCE(NEW.raw_user_meta_data->>'username', split_part(NEW.email, '@', 1)),
        COALESCE(NEW.raw_user_meta_data->>'avatar_url', '')
    )
    ON CONFLICT (id) DO UPDATE SET
        username   = COALESCE(EXCLUDED.username, profiles.username),
        avatar_url = COALESCE(EXCLUDED.avatar_url, profiles.avatar_url);
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Mevcut kullanıcılara profil oluştur (eğer yoksa)
INSERT INTO public.profiles (id, username)
SELECT id, split_part(email, '@', 1)
FROM auth.users
ON CONFLICT (id) DO NOTHING;

-- ---- likes ----
CREATE TABLE IF NOT EXISTS public.likes (
    id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    video_id   UUID NOT NULL REFERENCES public.videos(id) ON DELETE CASCADE,
    user_id    UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE (video_id, user_id)
);

-- likes_count otomatik güncelleme
CREATE OR REPLACE FUNCTION public.update_likes_count()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
    IF (TG_OP = 'INSERT') THEN
        UPDATE public.videos SET likes_count = likes_count + 1 WHERE id = NEW.video_id;
    ELSIF (TG_OP = 'DELETE') THEN
        UPDATE public.videos SET likes_count = GREATEST(0, likes_count - 1) WHERE id = OLD.video_id;
    END IF;
    RETURN NULL;
END;
$$;

DROP TRIGGER IF EXISTS trigger_update_likes_count ON public.likes;
CREATE TRIGGER trigger_update_likes_count
    AFTER INSERT OR DELETE ON public.likes
    FOR EACH ROW EXECUTE FUNCTION public.update_likes_count();

-- ---- comments ----
CREATE TABLE IF NOT EXISTS public.comments (
    id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    video_id   UUID NOT NULL REFERENCES public.videos(id) ON DELETE CASCADE,
    user_id    UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    parent_id  UUID REFERENCES public.comments(id) ON DELETE CASCADE,
    content    TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- comments_count otomatik güncelleme
CREATE OR REPLACE FUNCTION public.update_comments_count()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
    IF (TG_OP = 'INSERT') THEN
        UPDATE public.videos SET comments_count = comments_count + 1 WHERE id = NEW.video_id;
    ELSIF (TG_OP = 'DELETE') THEN
        UPDATE public.videos SET comments_count = GREATEST(0, comments_count - 1) WHERE id = OLD.video_id;
    END IF;
    RETURN NULL;
END;
$$;

DROP TRIGGER IF EXISTS trigger_update_comments_count ON public.comments;
CREATE TRIGGER trigger_update_comments_count
    AFTER INSERT OR DELETE ON public.comments
    FOR EACH ROW EXECUTE FUNCTION public.update_comments_count();

-- ---- subscriptions ----
CREATE TABLE IF NOT EXISTS public.subscriptions (
    id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    channel_id UUID NOT NULL REFERENCES public.channels(id) ON DELETE CASCADE,
    user_id    UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE (channel_id, user_id)
);

-- ---- views_log ----
CREATE TABLE IF NOT EXISTS public.views_log (
    id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    video_id   UUID NOT NULL REFERENCES public.videos(id) ON DELETE CASCADE,
    user_ip    TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ---- videos tablosuna eksik sütunlar ekle (varsa hata vermez) ----
ALTER TABLE public.videos ADD COLUMN IF NOT EXISTS likes_count    BIGINT DEFAULT 0;
ALTER TABLE public.videos ADD COLUMN IF NOT EXISTS comments_count BIGINT DEFAULT 0;
ALTER TABLE public.videos ADD COLUMN IF NOT EXISTS duration       INTEGER DEFAULT 0;

-- ============================================================
-- RLS Politikaları
-- ============================================================

-- profiles
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "profiles_public_read" ON public.profiles;
DROP POLICY IF EXISTS "profiles_own_write"   ON public.profiles;
CREATE POLICY "profiles_public_read" ON public.profiles FOR SELECT USING (true);
CREATE POLICY "profiles_own_write"   ON public.profiles FOR ALL   USING (auth.uid() = id);

-- likes
ALTER TABLE public.likes ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "likes_public_read" ON public.likes;
DROP POLICY IF EXISTS "likes_own_write"   ON public.likes;
CREATE POLICY "likes_public_read" ON public.likes FOR SELECT USING (true);
CREATE POLICY "likes_own_write"   ON public.likes FOR ALL    USING (auth.uid() = user_id);

-- comments
ALTER TABLE public.comments ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "comments_public_read" ON public.comments;
DROP POLICY IF EXISTS "comments_auth_insert" ON public.comments;
DROP POLICY IF EXISTS "comments_own_delete"  ON public.comments;
CREATE POLICY "comments_public_read" ON public.comments FOR SELECT USING (true);
CREATE POLICY "comments_auth_insert" ON public.comments FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "comments_own_delete"  ON public.comments FOR DELETE USING (auth.uid() = user_id);

-- subscriptions
ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "subs_public_read" ON public.subscriptions;
DROP POLICY IF EXISTS "subs_own_write"   ON public.subscriptions;
CREATE POLICY "subs_public_read" ON public.subscriptions FOR SELECT USING (true);
CREATE POLICY "subs_own_write"   ON public.subscriptions FOR ALL    USING (auth.uid() = user_id);

-- views_log
ALTER TABLE public.views_log ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "views_insert_all" ON public.views_log;
DROP POLICY IF EXISTS "views_select_all" ON public.views_log;
CREATE POLICY "views_insert_all" ON public.views_log FOR INSERT WITH CHECK (true);
CREATE POLICY "views_select_all" ON public.views_log FOR SELECT USING (true);
