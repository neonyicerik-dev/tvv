ALTER TABLE videos ADD COLUMN IF NOT EXISTS preview_clip_url TEXT;
