<?php
require_once __DIR__ . '/includes/config.php';

$ccUrl = 'https://api.cloudconvert.com/v2/jobs';
$videoUrl = 'https://res.cloudinary.com/demo/video/upload/dog.mp4'; // sample video
$jobPayload = [
    'tasks' => [
        'import-video' => [
            'operation' => 'import/url',
            'url'       => $videoUrl,
            'filename'  => 'input_video.mp4',
        ],
        'convert-audio' => [
            'operation'     => 'convert',
            'input'         => 'import-video',
            'output_format' => 'mp3',
            'engine'        => 'ffmpeg',
            'audio_codec'   => 'mp3',
            'audio_bitrate' => 32,
            'trim_from'     => 0,
            'trim_to'       => 300,
        ],
        'export-audio' => [
            'operation'              => 'export/url',
            'input'                  => 'convert-audio',
            'inline'                 => false,
            'archive_multiple_files' => false,
        ]
    ]
];

$ch = curl_init($ccUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($jobPayload));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Authorization: Bearer ' . CLOUDCONVERT_API_KEY,
    'Content-Type: application/json'
]);

$ccResponse = curl_exec($ch);
$ccHttpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: $ccHttpCode\n";
echo "Response: $ccResponse\n";

if ($ccHttpCode === 201) {
    $ccData = json_decode($ccResponse, true);
    $jobId = $ccData['data']['id'] ?? '';
    if ($jobId) {
        echo "Job ID: $jobId\n";
        // Poll status
        $statusUrl = "https://api.cloudconvert.com/v2/jobs/$jobId";
        for ($i=0; $i<10; $i++) {
            sleep(3);
            $ch2 = curl_init($statusUrl);
            curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch2, CURLOPT_HTTPHEADER, [
                'Authorization: Bearer ' . CLOUDCONVERT_API_KEY
            ]);
            $sRes = curl_exec($ch2);
            curl_close($ch2);
            $sData = json_decode($sRes, true);
            $status = $sData['data']['status'] ?? 'unknown';
            echo "Status: $status\n";
            if ($status === 'error' || $status === 'finished') {
                echo "Final response: $sRes\n";
                break;
            }
        }
    }
}
