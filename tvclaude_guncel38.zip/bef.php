<?php
// NeonTV - Eski domain yönlendirme bilgi sayfası
// Eski hostingdeki .htaccess, istekleri buraya gönderir: bef.php?url=/eski/yol&h=eski-domain&...(özgün sorgu)
// "Devam et" ile aynı adres bu sitede açılır. Veritabanı gerektirmez.
require_once __DIR__ . '/includes/config.php';
header('X-Robots-Tag: noindex, nofollow');
header('Referrer-Policy: no-referrer');

// Hedef yol: yalnızca bu siteye ait göreli yol (açık yönlendirme / "//evil.com" / şema engellenir)
$path = (string)($_GET['url'] ?? '/');
$path = preg_replace('/[\x00-\x1F\x7F\\\\]/', '', $path);
$path = '/' . ltrim($path, '/');
if (strlen($path) > 2000 || str_starts_with($path, '//') || preg_match('#^/[a-z][a-z0-9+.\-]*:#i', $path) || preg_match('#^/bef\.php#i', $path)) $path = '/';
// Özgün sorgu parametreleri (url ve h hariç) hedefe aktarılır
$rest = $_GET; unset($rest['url'], $rest['h']);
$target = rtrim(APP_URL, '/') . $path;
if ($rest) $target .= (str_contains($path, '?') ? '&' : '?') . http_build_query($rest);

$old = strtolower(trim((string)($_GET['h'] ?? '')));
$old = preg_match('/^[a-z0-9.\-]{3,100}$/', $old) ? $old : '';
$e = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
?><!DOCTYPE html>
<html lang="tr"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>NeonTV taşındı</title>
<style>
*{box-sizing:border-box}body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px;background:#070711;color:#fff;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;
background-image:radial-gradient(60% 50% at 15% 10%,rgba(0,245,255,.14),transparent),radial-gradient(55% 50% at 90% 90%,rgba(191,0,255,.16),transparent)}
.card{max-width:460px;width:100%;padding:30px 26px;border-radius:24px;text-align:center;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.12);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);box-shadow:0 20px 60px rgba(0,0,0,.5)}
.logo{font-size:30px;font-weight:900;letter-spacing:.5px;background:linear-gradient(135deg,#00f5ff,#bf00ff);-webkit-background-clip:text;background-clip:text;color:transparent}
h1{font-size:20px;margin:14px 0 8px}p{color:#cbd5e1;font-size:14.5px;line-height:1.6;margin:8px 0}
.ok{display:inline-block;margin-top:6px;padding:4px 12px;border-radius:99px;font-size:12px;font-weight:700;color:#7dffb0;background:rgba(57,255,20,.1);border:1px solid rgba(57,255,20,.3)}
.dest{margin:16px 0 4px;padding:10px 12px;border-radius:12px;font-size:12px;color:#9ca3af;background:rgba(0,0,0,.35);word-break:break-all;text-align:left}
.btn{display:block;margin-top:18px;padding:14px;border-radius:14px;font-weight:800;font-size:16px;text-decoration:none;color:#00121a;background:linear-gradient(135deg,#7df9ff,#a78bfa);box-shadow:0 8px 28px rgba(0,245,255,.25)}
.btn:hover{filter:brightness(1.08)}
</style></head><body>
<main class="card">
  <div class="logo">NeonTV</div>
  <h1>Alan adımız değişti 🚀</h1>
  <p><?php if ($old): ?><b><?= $e($old) ?></b> adresinden geldiniz. <?php endif; ?>NeonTV artık yeni sunucusunda ve yeni alan adında yayında. Site <b>şimdi daha hızlı</b>; bunun dışında <b>her şey aynı kaldı</b>: hesabınız, videolar, listeler ve ayarlarınız olduğu gibi duruyor.</p>
  <span class="ok">✓ Verileriniz korundu</span>
  <div class="dest">Açılacak adres:<br><?= $e($target) ?></div>
  <a class="btn" href="<?= $e($target) ?>" rel="noopener">Devam et</a>
  <p style="font-size:12px;color:#6b7280;margin-top:14px">Yer imlerinizi yeni adrese güncellemeyi unutmayın.</p>
</main>
</body></html>
