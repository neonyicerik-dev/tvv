<?php
// NeonTV - Son Yorumlar (sayfalı; ilk/son sayfa butonlu)
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/helpers.php';
$pageTitle = 'Son Yorumlar'; $metaDesc = 'NeonTV\'deki en son yorumlar.';
?>
<?php include __DIR__ . '/components/header.php'; ?>
<div class="max-w-screen-md mx-auto px-4 sm:px-6 py-8">
    <div class="flex items-center gap-3 mb-5 flex-wrap">
        <h1 class="text-xl font-bold text-white"><i class="fa-regular fa-comments text-cyan-400 mr-2"></i>Son Yorumlar</h1>
        <div class="ml-auto flex gap-2 text-xs" id="lc-tabs">
            <button type="button" data-scope="all" class="lc-tab px-3 py-1.5 rounded-full font-semibold">Tümü</button>
            <button type="button" data-scope="following" class="lc-tab px-3 py-1.5 rounded-full font-semibold">Takip ettiklerim</button>
        </div>
    </div>
    <div id="lc-msg" class="text-gray-500 text-sm py-10 text-center">Yükleniyor...</div>
    <div id="lc-list" class="space-y-2"></div>
    <nav id="lc-pager" class="flex items-center justify-center gap-1.5 mt-6 flex-wrap" aria-label="Sayfalama"></nav>
</div>
<style>.lc-tab{background:rgba(255,255,255,.06);color:#d1d5db;border:1px solid rgba(255,255,255,.1)}.lc-tab.on{background:rgba(0,245,255,.18);color:#00f5ff;border-color:rgba(0,245,255,.5)}
.lc-pg{min-width:36px;height:36px;padding:0 10px;border-radius:10px;background:rgba(255,255,255,.06);color:#d1d5db;border:1px solid rgba(255,255,255,.1);font-size:13px;font-weight:600}
.lc-pg:hover:not(:disabled){color:#000;background:#67e8f9}.lc-pg.on{background:linear-gradient(135deg,#00f5ff,#bf00ff);color:#000;border-color:transparent}.lc-pg:disabled{opacity:.35;cursor:not-allowed}</style>
<script>
window.addEventListener('load', async function () {
    const BASE = <?= json_encode(APP_URL) ?>, PER = 15;
    const $ = id => document.getElementById(id), msg = $('lc-msg'), box = $('lc-list'), pager = $('lc-pager');
    const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
    const qs = new URLSearchParams(location.search);
    let scope = qs.get('scope') === 'following' ? 'following' : 'all', page = Math.max(1, parseInt(qs.get('page') || '1', 10) || 1), tok = null;
    try { const { data } = await sbClient.auth.getSession(); tok = data.session ? data.session.access_token : null; } catch (e) {}

    function tabs() { document.querySelectorAll('.lc-tab').forEach(b => b.classList.toggle('on', b.dataset.scope === scope)); }
    async function load(push) {
        tabs(); msg.style.display = 'block'; msg.textContent = 'Yükleniyor...'; box.innerHTML = ''; pager.innerHTML = '';
        if (scope === 'following' && !tok) { msg.innerHTML = 'Takip ettiklerinin yorumlarını görmek için <a class="text-cyan-400 underline" href="' + BASE + '/auth.php">giriş yap</a>.'; return; }
        try {
            const url = BASE + '/api/latest_comments.php?scope=' + scope + '&per=' + PER + '&page=' + page + (tok && scope === 'following' ? '&token=' + encodeURIComponent(tok) : '');
            const r = await fetch(url, { headers: tok ? { 'Authorization': 'Bearer ' + tok, 'X-Access-Token': tok } : {} });
            const j = await r.json(); if (!j.success) { msg.textContent = j.message || 'Yüklenemedi.'; return; }
            const d = j.data; page = d.page;
            if (push) history.replaceState(null, '', '?scope=' + scope + '&page=' + page);
            if (!d.items.length) { msg.textContent = scope === 'following' ? 'Takip ettiklerinden henüz yorum yok.' : 'Henüz yorum yok.'; return; }
            msg.style.display = 'none';
            box.innerHTML = d.items.map(c => {
                const href = BASE + '/video.php?id=' + encodeURIComponent(c.video_id) + '#comment-' + encodeURIComponent(c.id);
                const av = c.avatar_url ? '<img src="' + esc(c.avatar_url) + '" alt="" class="w-full h-full object-cover">' : esc((c.username || 'U').charAt(0).toUpperCase());
                return '<a href="' + esc(href) + '" class="flex gap-3 p-3 rounded-xl hover:bg-white/5 transition-colors" style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.08)">' +
                    '<span class="w-10 h-10 rounded-full overflow-hidden shrink-0 flex items-center justify-center font-bold text-sm" style="background:linear-gradient(135deg,#bf00ff,#ff007a);color:#fff">' + av + '</span>' +
                    '<span class="min-w-0 flex-1"><span class="flex items-center gap-2 text-xs text-gray-500"><b class="text-white text-sm">' + esc(c.username) + '</b>' + (c.is_reply ? '<span class="text-cyan-400">yanıt</span>' : '') + '<span>' + esc(c.ago) + '</span></span>' +
                    (c.gif ? '<img src="' + esc(c.gif) + '" alt="GIF" loading="lazy" class="rounded-lg mt-1" style="max-height:64px;max-width:120px;display:block">' : '') + (c.content ? '<span class="block text-sm text-gray-200 mt-0.5 break-words">' + esc(c.content) + '</span>' : '') +
                    '<span class="block text-xs text-gray-500 mt-1 truncate"><i class="fa-solid fa-play text-[9px] mr-1 text-cyan-400"></i>' + esc(c.video_title) + '</span></span>' +
                    (c.thumb ? '<img src="' + esc(c.thumb) + '" alt="" loading="lazy" class="hidden sm:block w-24 h-14 rounded-lg object-cover shrink-0">' : '') + '</a>';
            }).join('');
            drawPager(d.page, d.pages);
        } catch (e) { msg.textContent = 'Bağlantı hatası.'; }
    }
    function drawPager(cur, total) {
        if (total <= 1) return;
        const btn = (label, p, dis, on, aria) => '<button type="button" class="lc-pg' + (on ? ' on' : '') + '" data-p="' + p + '"' + (dis ? ' disabled' : '') + (aria ? ' aria-label="' + aria + '" title="' + aria + '"' : '') + '>' + label + '</button>';
        let h = btn('«', 1, cur === 1, false, 'En başa git') + btn('‹', cur - 1, cur === 1, false, 'Önceki');
        const from = Math.max(1, Math.min(cur - 2, total - 4)), to = Math.min(total, from + 4);
        for (let i = from; i <= to; i++) h += btn(i, i, false, i === cur);
        h += btn('›', cur + 1, cur === total, false, 'Sonraki') + btn('»', total, cur === total, false, 'Sona git');
        h += '<span class="text-xs text-gray-500 ml-2">' + cur + ' / ' + total + '</span>';
        pager.innerHTML = h;
    }
    pager.addEventListener('click', e => { const b = e.target.closest('.lc-pg'); if (!b || b.disabled) return; page = parseInt(b.dataset.p, 10); load(true); window.scrollTo({ top: 0, behavior: 'smooth' }); });
    $('lc-tabs').addEventListener('click', e => { const b = e.target.closest('.lc-tab'); if (!b) return; scope = b.dataset.scope; page = 1; load(true); });
    load(false);
});
</script>
<?php include __DIR__ . '/components/footer.php'; ?>
