-- ============================================================
-- NeonTV - Yeni özellikler (geçmiş, sonra izle, playlist,
-- reklam günlük istatistik, premium erken erişim)
-- Supabase > SQL Editor'da bir kez çalıştırın. Güvenle tekrar çalıştırılabilir.
-- Tüm tablolar yalnızca service_role (PHP sunucusu) tarafından erişilir.
-- ============================================================

-- 1) İzleme geçmişi
CREATE TABLE IF NOT EXISTS public.watch_history (
    user_id          uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    video_id         uuid NOT NULL REFERENCES public.videos(id) ON DELETE CASCADE,
    position_seconds int  NOT NULL DEFAULT 0 CHECK (position_seconds >= 0),
    duration_seconds int  NOT NULL DEFAULT 0 CHECK (duration_seconds >= 0),
    watched_at       timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, video_id)
);
CREATE INDEX IF NOT EXISTS watch_history_user_time_idx ON public.watch_history (user_id, watched_at DESC);
ALTER TABLE public.watch_history ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.watch_history FROM anon, authenticated;
GRANT ALL ON public.watch_history TO service_role;

-- 2) Daha sonra izle
CREATE TABLE IF NOT EXISTS public.watch_later (
    user_id    uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    video_id   uuid NOT NULL REFERENCES public.videos(id) ON DELETE CASCADE,
    created_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, video_id)
);
CREATE INDEX IF NOT EXISTS watch_later_user_idx ON public.watch_later (user_id, created_at DESC);
ALTER TABLE public.watch_later ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.watch_later FROM anon, authenticated;
GRANT ALL ON public.watch_later TO service_role;

-- 3) Kanal oynatma listeleri
CREATE TABLE IF NOT EXISTS public.playlists (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    channel_id  uuid NOT NULL REFERENCES public.channels(id) ON DELETE CASCADE,
    title       text NOT NULL CHECK (char_length(title) BETWEEN 1 AND 120),
    description text DEFAULT '',
    created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS playlists_channel_idx ON public.playlists (channel_id);
ALTER TABLE public.playlists ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.playlists FROM anon, authenticated;
GRANT ALL ON public.playlists TO service_role;

CREATE TABLE IF NOT EXISTS public.playlist_videos (
    playlist_id uuid NOT NULL REFERENCES public.playlists(id) ON DELETE CASCADE,
    video_id    uuid NOT NULL REFERENCES public.videos(id) ON DELETE CASCADE,
    position    int  NOT NULL DEFAULT 0,
    PRIMARY KEY (playlist_id, video_id)
);
ALTER TABLE public.playlist_videos ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.playlist_videos FROM anon, authenticated;
GRANT ALL ON public.playlist_videos TO service_role;

-- 4) Reklam günlük istatistikleri
CREATE TABLE IF NOT EXISTS public.ad_stats_daily (
    ad_id       uuid NOT NULL REFERENCES public.ads(id) ON DELETE CASCADE,
    day         date NOT NULL DEFAULT (now() AT TIME ZONE 'utc')::date,
    impressions bigint NOT NULL DEFAULT 0,
    clicks      bigint NOT NULL DEFAULT 0,
    PRIMARY KEY (ad_id, day)
);
ALTER TABLE public.ad_stats_daily ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.ad_stats_daily FROM anon, authenticated;
GRANT ALL ON public.ad_stats_daily TO service_role;

CREATE OR REPLACE FUNCTION public.increment_ad_stat(p_ad_id uuid, p_stat text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
    IF p_stat = 'impressions' THEN
        UPDATE public.ads SET impressions = impressions + 1 WHERE id = p_ad_id;
        INSERT INTO public.ad_stats_daily (ad_id, day, impressions, clicks)
        VALUES (p_ad_id, (now() AT TIME ZONE 'utc')::date, 1, 0)
        ON CONFLICT (ad_id, day) DO UPDATE SET impressions = public.ad_stats_daily.impressions + 1;
    ELSIF p_stat = 'clicks' THEN
        UPDATE public.ads SET clicks = clicks + 1 WHERE id = p_ad_id;
        INSERT INTO public.ad_stats_daily (ad_id, day, impressions, clicks)
        VALUES (p_ad_id, (now() AT TIME ZONE 'utc')::date, 0, 1)
        ON CONFLICT (ad_id, day) DO UPDATE SET clicks = public.ad_stats_daily.clicks + 1;
    END IF;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.increment_ad_stat(uuid, text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.increment_ad_stat(uuid, text) TO service_role;

-- 5) Premium erken erişim: bu tarihe kadar yalnızca premium üyeler izler
ALTER TABLE public.videos ADD COLUMN IF NOT EXISTS premium_only_until timestamptz;
