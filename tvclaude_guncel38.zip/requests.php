<?php
// NeonTV - Video İstek Panosu
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/helpers.php';
$pageTitle = 'Video İstek Panosu'; $metaDesc = 'Görmek istediğin videoları iste, diğer isteklere oy ver.';
?>
<?php include __DIR__ . '/components/header.php'; ?>
<div class="max-w-screen-md mx-auto px-4 sm:px-6 py-8">
    <h1 class="text-xl font-bold text-white mb-1"><i class="fa-solid fa-inbox text-cyan-400 mr-2"></i>Video İstek Panosu</h1>
    <p class="text-sm text-gray-500 mb-5">Görmek istediğin bir video, kanal veya tür varsa yaz. En çok oy alanlar öncelikli değerlendirilir.</p>

    <form id="rq-form" class="rounded-2xl p-4 mb-6 space-y-2" style="background:#13131f;border:1px solid rgba(255,255,255,0.08)">
        <input id="rq-title" maxlength="120" required placeholder="İstediğin video / konu (örn. Türkçe altyazılı ... )" class="w-full px-3 py-2.5 rounded-xl text-sm text-white outline-none" style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1)">
        <textarea id="rq-desc" maxlength="600" rows="2" placeholder="Açıklama (isteğe bağlı)" class="w-full px-3 py-2.5 rounded-xl text-sm text-white outline-none resize-none" style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1)"></textarea>
        <div class="flex items-center gap-3"><button class="px-5 py-2 rounded-xl text-sm font-bold text-black" style="background:linear-gradient(135deg,#00f5ff,#bf00ff)">İstek Gönder</button><span id="rq-note" class="text-xs text-gray-500"></span></div>
    </form>

    <div class="flex items-center gap-2 mb-3 text-xs">
        <button data-s="votes" class="rq-sort px-3 py-1.5 rounded-full font-semibold">En çok oy</button>
        <button data-s="new" class="rq-sort px-3 py-1.5 rounded-full font-semibold">En yeni</button>
        <select id="rq-status" class="ml-auto px-3 py-1.5 rounded-lg text-xs text-gray-200 bg-white/5 border border-white/10">
            <option value="">Reddedilenler hariç hepsi</option><option value="open">Açık</option><option value="planned">Planlandı</option><option value="done">Yapıldı</option>
        </select>
    </div>
    <div id="rq-list" class="space-y-3"><p class="text-center text-gray-500 py-8 text-sm">Yükleniyor...</p></div>
</div>
<script>
window.addEventListener('load', async function () {
    const BASE = '<?= APP_URL ?>', list = document.getElementById('rq-list'), note = document.getElementById('rq-note');
    const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
    let t = null; try { const { data } = await sbClient.auth.getSession(); t = data.session ? data.session.access_token : null; } catch (e) {}
    if (!t) { try { t = localStorage.getItem('sb_access_token'); } catch (e) {} }
    const h = t ? { 'Authorization': 'Bearer ' + t, 'X-Access-Token': t, 'Content-Type': 'application/json' } : { 'Content-Type': 'application/json' };
    const q = t ? '&token=' + encodeURIComponent(t) : '';
    let sort = 'votes';
    const ST = { open: ['Açık', '#00f5ff'], planned: ['Planlandı', '#fbbf24'], done: ['Yapıldı ✓', '#22c55e'], rejected: ['Reddedildi', '#ff4d6d'] };
    function paintSort() { document.querySelectorAll('.rq-sort').forEach(b => { const on = b.dataset.s === sort; b.style.background = on ? 'rgba(0,245,255,0.18)' : 'rgba(255,255,255,0.06)'; b.style.color = on ? '#00f5ff' : '#9ca3af'; }); }
    async function load() {
        paintSort();
        const st = document.getElementById('rq-status').value;
        const j = await (await fetch(BASE + '/api/requests.php?sort=' + sort + (st ? '&status=' + st : '') + q, { headers: h })).json();
        const items = (j.data && j.data.items) || [];
        if (!items.length) { list.innerHTML = '<p class="text-center text-gray-500 py-8 text-sm">Henüz istek yok. İlk isteği sen yaz!</p>'; return; }
        list.innerHTML = items.map(r => {
            const s = ST[r.status] || ST.open, canVote = r.status === 'open' || r.status === 'planned';
            return '<div class="flex gap-3 p-4 rounded-2xl" style="background:#13131f;border:1px solid rgba(255,255,255,0.08)">' +
                '<button data-id="' + esc(r.id) + '" class="rq-vote shrink-0 w-14 py-2 rounded-xl text-center ' + (canVote ? '' : 'opacity-50 cursor-not-allowed') + '" style="background:' + (r.voted ? 'rgba(0,245,255,0.2)' : 'rgba(255,255,255,0.06)') + ';color:' + (r.voted ? '#00f5ff' : '#d1d5db') + '"><i class="fa-solid fa-chevron-up text-xs block"></i><b class="text-base">' + r.votes + '</b></button>' +
                '<div class="min-w-0 flex-1"><div class="flex items-center gap-2 flex-wrap"><h3 class="text-white font-semibold text-sm">' + esc(r.title) + '</h3><span class="text-[10px] font-bold px-2 py-0.5 rounded-full" style="color:' + s[1] + ';border:1px solid ' + s[1] + '55">' + s[0] + '</span></div>' +
                (r.description ? '<p class="text-xs text-gray-400 mt-1 whitespace-pre-wrap">' + esc(r.description) + '</p>' : '') +
                (r.admin_note ? '<p class="text-xs mt-1" style="color:#fbbf24">Yönetici notu: ' + esc(r.admin_note) + '</p>' : '') +
                '<p class="text-[10px] text-gray-600 mt-1">' + esc(r.username) + ' · ' + esc(String(r.created_at).slice(0, 10)) + (r.mine && r.status === 'open' ? ' · <button data-id="' + esc(r.id) + '" class="rq-del text-red-400 hover:underline">sil</button>' : '') + '</p></div></div>';
        }).join('');
    }
    document.querySelectorAll('.rq-sort').forEach(b => b.onclick = () => { sort = b.dataset.s; load(); });
    document.getElementById('rq-status').onchange = load;
    list.addEventListener('click', async e => {
        const v = e.target.closest('.rq-vote'), d = e.target.closest('.rq-del');
        if (!t) { if (v || d) location.href = BASE + '/auth.php'; return; }
        if (v) {
            const j = await (await fetch(BASE + '/api/requests.php?token=' + encodeURIComponent(t), { method: 'POST', headers: h, body: JSON.stringify({ vote: v.dataset.id }) })).json();
            if (!j.success) { alert(j.message || 'Oy verilemedi'); return; } load();
        } else if (d && confirm('İstek silinsin mi?')) {
            await fetch(BASE + '/api/requests.php?id=' + encodeURIComponent(d.dataset.id) + '&token=' + encodeURIComponent(t), { method: 'DELETE', headers: h }); load();
        }
    });
    document.getElementById('rq-form').addEventListener('submit', async e => {
        e.preventDefault();
        if (!t) { location.href = BASE + '/auth.php'; return; }
        note.textContent = 'Gönderiliyor...';
        const j = await (await fetch(BASE + '/api/requests.php?token=' + encodeURIComponent(t), { method: 'POST', headers: h, body: JSON.stringify({ title: document.getElementById('rq-title').value, description: document.getElementById('rq-desc').value }) })).json();
        note.textContent = j.message || '';
        if (j.success) { document.getElementById('rq-title').value = ''; document.getElementById('rq-desc').value = ''; load(); }
    });
    load();
});
</script>
<?php include __DIR__ . '/components/footer.php'; ?>
