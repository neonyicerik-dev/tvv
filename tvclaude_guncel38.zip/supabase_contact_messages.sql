-- ============================================================
-- İletişim formu mesajları (Supabase SQL Editor'da bir kez çalıştırın)
-- Yalnızca PHP (service key) yazar/okur; anon ve authenticated erişemez.
-- ============================================================
CREATE TABLE IF NOT EXISTS public.contact_messages (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    topic      text NOT NULL DEFAULT 'Diğer',
    name       text NOT NULL,
    email      text NOT NULL,
    message    text NOT NULL,
    ip_hash    text,
    is_read    boolean NOT NULL DEFAULT false,
    created_at timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT contact_name_len    CHECK (char_length(name) BETWEEN 1 AND 80),
    CONSTRAINT contact_email_len   CHECK (char_length(email) BETWEEN 5 AND 120),
    CONSTRAINT contact_message_len CHECK (char_length(message) BETWEEN 5 AND 3000)
);
CREATE INDEX IF NOT EXISTS idx_contact_created ON public.contact_messages (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_contact_ip_time ON public.contact_messages (ip_hash, created_at DESC);
ALTER TABLE public.contact_messages ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.contact_messages FROM anon, authenticated;
GRANT ALL ON public.contact_messages TO service_role;
