<?php
// ============================================================
// NeonTV - Admin: İletişim Mesajları
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../includes/store.php';

requireAdmin(['moderator', 'superadmin']);

$db = new Supabase();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken(input('csrf_token'))) {
        setFlash('error', 'Güvenlik doğrulaması başarısız.');
        redirect(APP_URL . '/admin/messages.php');
    }
    $action = input('action');
    $id     = trim(input('id'));

    if ($action === 'mark_read' || $action === 'mark_unread') {
        requireUuid($id, 'Mesaj ID');
        $db->update('contact_messages', ['is_read' => ($action === 'mark_read')], 'id=eq.' . urlencode($id), true);
    } elseif ($action === 'mark_all_read') {
        $db->update('contact_messages', ['is_read' => true], 'is_read=eq.false', true);
        setFlash('success', 'Tüm mesajlar okundu olarak işaretlendi.');
    } elseif ($action === 'delete') {
        requireUuid($id, 'Mesaj ID');
        $db->delete('contact_messages', 'id=eq.' . urlencode($id), true);
        logActivity('contact_delete', 'contact_message', $id);
        setFlash('success', 'Mesaj silindi.');
    }
    redirect(APP_URL . '/admin/messages.php' . (isset($_GET['filter']) ? '?filter=' . urlencode($_GET['filter']) : ''));
}

$filter = ($_GET['filter'] ?? '') === 'unread' ? 'unread' : 'all';
$page   = max(1, (int)($_GET['page'] ?? 1));
$per    = 20;
$q      = 'order=created_at.desc&limit=' . $per . '&offset=' . (($page - 1) * $per);
if ($filter === 'unread') $q .= '&is_read=eq.false';
$res      = $db->select('contact_messages', $q . '&select=*', true);
$messages = is_array($res['data'] ?? null) ? $res['data'] : [];

$unreadRes = $db->select('contact_messages', 'is_read=eq.false&select=id', true);
$unread    = is_array($unreadRes['data'] ?? null) ? count($unreadRes['data']) : 0;

$pageTitle = 'Mesajlar';
?>
<!DOCTYPE html>
<html lang="tr" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mesajlar | NeonTV Admin</title>
    <meta name="robots" content="noindex,nofollow">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body { font-family: 'Outfit', sans-serif; background: #070711; color: #fff; }
        ::-webkit-scrollbar { width:6px; } ::-webkit-scrollbar-track { background:#0d0d1a; } ::-webkit-scrollbar-thumb { background:#1e1e3a; border-radius:3px; }
    </style>
</head>
<body class="min-h-screen lg:flex">

<?php include __DIR__ . '/sidebar.php'; ?>

<div class="flex-1 flex flex-col min-w-0 overflow-x-hidden">
    <header class="flex items-center justify-between px-4 sm:px-6 py-4 sticky top-0 z-20"
            style="background:rgba(7,7,17,0.9);backdrop-filter:blur(20px);border-bottom:1px solid rgba(255,255,255,0.06);">
        <div class="flex items-center gap-3">
            <button onclick="openSidebar()" class="lg:hidden p-2 rounded-xl text-gray-400 hover:text-white transition-colors" style="background:rgba(255,255,255,0.06);">
                <i class="fa-solid fa-bars text-sm"></i>
            </button>
            <div>
                <h1 class="text-lg sm:text-xl font-bold text-white">İletişim Mesajları</h1>
                <p class="text-xs text-gray-500"><?= $unread ?> okunmamış mesaj</p>
            </div>
        </div>
        <div class="flex items-center gap-2">
            <a href="?filter=<?= $filter === 'unread' ? 'all' : 'unread' ?>"
               class="px-3 py-2 rounded-xl text-xs sm:text-sm font-semibold"
               style="background:rgba(0,245,255,0.06);border:1px solid rgba(0,245,255,0.25);color:#00f5ff;">
                <?= $filter === 'unread' ? 'Tümünü Göster' : 'Sadece Okunmamış' ?>
            </a>
            <?php if ($unread > 0): ?>
            <form method="POST" class="inline">
                <?= csrfField() ?>
                <input type="hidden" name="action" value="mark_all_read">
                <button class="px-3 py-2 rounded-xl text-xs sm:text-sm font-semibold text-black" style="background:linear-gradient(135deg,#00f5ff,#bf00ff);">Hepsini Okundu Yap</button>
            </form>
            <?php endif; ?>
        </div>
    </header>

    <main class="flex-1 p-4 sm:p-6">
        <div class="max-w-4xl mx-auto space-y-4">
            <?= renderFlash() ?>

            <?php if (empty($messages)): ?>
            <div class="text-center py-16 text-gray-600">
                <i class="fa-regular fa-envelope-open text-4xl mb-3 block opacity-40"></i>
                Henüz mesaj yok.
            </div>
            <?php endif; ?>

            <?php foreach ($messages as $m): $isRead = !empty($m['is_read']); ?>
            <div class="rounded-2xl p-4 sm:p-5" style="background:#13131f;border:1px solid <?= $isRead ? 'rgba(255,255,255,0.06)' : 'rgba(0,245,255,0.35)' ?>;">
                <div class="flex flex-wrap items-start justify-between gap-2 mb-3">
                    <div class="min-w-0">
                        <div class="flex items-center gap-2 flex-wrap">
                            <?php if (!$isRead): ?><span class="w-2 h-2 rounded-full" style="background:#00f5ff;box-shadow:0 0 8px #00f5ff;"></span><?php endif; ?>
                            <span class="font-bold text-white"><?= e($m['name']) ?></span>
                            <span class="text-xs px-2 py-0.5 rounded-full" style="background:rgba(191,0,255,0.12);color:#d67bff;border:1px solid rgba(191,0,255,0.25);"><?= e($m['topic']) ?></span>
                        </div>
                        <a href="mailto:<?= e($m['email']) ?>?subject=<?= rawurlencode('Re: ' . $m['topic']) ?>" class="text-sm text-cyan-400 hover:underline break-all"><?= e($m['email']) ?></a>
                    </div>
                    <span class="text-xs text-gray-500"><?= e(date('d.m.Y H:i', strtotime($m['created_at']))) ?></span>
                </div>
                <p class="text-sm text-gray-300 leading-relaxed whitespace-pre-wrap break-words"><?= e($m['message']) ?></p>
                <div class="flex items-center gap-2 mt-4">
                    <a href="mailto:<?= e($m['email']) ?>?subject=<?= rawurlencode('Re: ' . $m['topic']) ?>"
                       class="px-3 py-1.5 rounded-lg text-xs font-semibold text-black" style="background:linear-gradient(135deg,#00f5ff,#bf00ff);">
                        <i class="fa-solid fa-reply mr-1"></i>Yanıtla
                    </a>
                    <form method="POST" class="inline">
                        <?= csrfField() ?>
                        <input type="hidden" name="action" value="<?= $isRead ? 'mark_unread' : 'mark_read' ?>">
                        <input type="hidden" name="id" value="<?= e($m['id']) ?>">
                        <button class="px-3 py-1.5 rounded-lg text-xs font-semibold text-gray-300" style="background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);">
                            <?= $isRead ? 'Okunmadı yap' : 'Okundu yap' ?>
                        </button>
                    </form>
                    <form method="POST" class="inline" onsubmit="return confirm('Bu mesaj silinsin mi?');">
                        <?= csrfField() ?>
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="id" value="<?= e($m['id']) ?>">
                        <button class="px-3 py-1.5 rounded-lg text-xs font-semibold text-red-400" style="background:rgba(255,0,60,0.06);border:1px solid rgba(255,0,60,0.25);">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </form>
                </div>
            </div>
            <?php endforeach; ?>

            <div class="flex justify-between pt-2 text-sm">
                <?php if ($page > 1): ?><a class="text-cyan-400" href="?filter=<?= $filter ?>&page=<?= $page - 1 ?>">&larr; Önceki</a><?php else: ?><span></span><?php endif; ?>
                <?php if (count($messages) === $per): ?><a class="text-cyan-400" href="?filter=<?= $filter ?>&page=<?= $page + 1 ?>">Sonraki &rarr;</a><?php endif; ?>
            </div>
        </div>
    </main>
</div>
</body>
</html>
