<?php
// ============================================================
// NeonTV - Admin Ayarlar (Settings)
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
requireAdmin('superadmin');

require_once __DIR__ . '/../includes/store.php';
$settings    = loadSettingsCompat();
$settingsOld = $settings;

$saved   = false;
$saveErr = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $settings['subtitle_system_prompt']     = trim($_POST['subtitle_system_prompt'] ?? '');
    $settings['ai_title_system_prompt']     = trim($_POST['ai_title_system_prompt'] ?? '');
    $settings['ai_channel_desc_system_prompt']= trim($_POST['ai_channel_desc_system_prompt'] ?? '');
    $settings['ai_chapter_system_prompt']   = trim($_POST['ai_chapter_system_prompt'] ?? '');
    $settings['subtitle_language']          = in_array($_POST['subtitle_language'] ?? 'tr', ['tr', 'en']) ? $_POST['subtitle_language'] : 'tr';
    $settings['subtitle_temperature']       = max(0, min(1, (float)($_POST['subtitle_temperature'] ?? 0.2)));
    $settings['title_temperature']          = max(0, min(1, (float)($_POST['title_temperature'] ?? 0.7)));
    $settings['channel_desc_temperature']   = max(0, min(1, (float)($_POST['channel_desc_temperature'] ?? 0.7)));
    $settings['maintenance_mode']           = isset($_POST['maintenance_mode']) && $_POST['maintenance_mode'] === 'on';
    $settings['maintenance_message']        = trim($_POST['maintenance_message'] ?? 'Sitemiz şu an bakımda. Kısa süre içinde geri döneceğiz.');
    $settings['allow_download']             = isset($_POST['allow_download']) && $_POST['allow_download'] === 'on';
    // +18 Uyaı Ayarları
    $settings['age_warning_enabled']        = isset($_POST['age_warning_enabled']) && $_POST['age_warning_enabled'] === 'on';
    $settings['age_warning_title']          = trim($_POST['age_warning_title'] ?? '+18 İçerik Uyaısı');
    $settings['age_warning_text']           = trim($_POST['age_warning_text']  ?? 'Bu site 18 yaş ve üzeri yetişkinlere yönelik içerikler barındırmaktadır.');
    $settings['age_warning_btn_yes']        = trim($_POST['age_warning_btn_yes']?? '18 Yaşındayım, Devam Et');
    $settings['age_warning_btn_no']         = trim($_POST['age_warning_btn_no'] ?? 'Hayır, Çık');
    $settings['age_warning_redirect']       = trim($_POST['age_warning_redirect']?? 'https://www.google.com');


    $json = json_encode($settings, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    if (saveSettingsDiff($settingsOld, $settings)) {
        $saved = true;
    } else {
        $saveErr = 'Ayarlar veritabanına kaydedilemedi. site_settings tablosunu kontrol edin.';
    }
}

// Varsayılan promptlar
$defaultSubtitlePrompt = 'Bu ses kaydını dinle ve Türkçe altyazı (VTT formatında) oluştur. Sadece geçerli bir WebVTT içeriği döndür. Başında \'WEBVTT\' olsun, sonra boş bir satır ve zaman damgaları (00:00:00.000 --> 00:00:05.000) ile metinler gelsin. Yabancı dilde konuşuluyorsa doğrudan Türkçeye çevir. İngilizce hiçbir kelime veya cümle bulunmasın, hepsi Türkçeye çevrilsin.';
$defaultTitlePrompt    = 'Sen bir video platformu için içerik yöneticisisin. Türkçe yaz. SEO uyumlu, dikkat çekici başlıklar ve açıklamalar oluştur.';
$defaultChannelDescPrompt = 'Sen bir video platformu için kanal yöneticisisin. Türkçe yaz. Verilen kanal videolarını analiz ederek kanalı en iyi tanımlayan, SEO uyumlu, ilgi çekici bir kanal açıklaması oluştur. Açıklama 2-4 cümle uzunluğunda olsun.';
$defaultChapterPrompt     = "Aşağıdaki WebVTT altyazı içeriğini analiz et ve videoyu anlamlı bölümlere (chapters) ayır. Her bölüm için bir başlık ve o bölümün başladığı saniyeyi belirle. Bölüm sayısı konuya göre 3-10 arasında olsun. SADECE JSON formatında yanıt ver, başka hiçbir şey yazma:\n[{\"title\": \"Bölüm Adı\", \"start_time\": 0}]";
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ayarlar | NeonTV Admin</title>
    <meta name="robots" content="noindex,nofollow">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body { font-family: 'Outfit', sans-serif; background: #070711; color: #fff; }
        .panel {
            background: #0f0f1e;
            border: 1px solid rgba(255,255,255,0.07);
            border-radius: 1rem;
            overflow: hidden;
        }
        .panel-header {
            padding: 1rem 1.25rem;
            border-bottom: 1px solid rgba(255,255,255,0.06);
        }
        .input-field {
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(255,255,255,0.1);
            width: 100%;
            transition: all 0.2s;
            color: #fff;
        }
        .input-field:focus {
            border-color: rgba(0,245,255,0.5);
            box-shadow: 0 0 0 3px rgba(0,245,255,0.08);
            outline: none;
        }
        .input-field::placeholder { color: rgba(255,255,255,0.2); }
        .section-label {
            display: block;
            font-size: 0.7rem;
            font-weight: 600;
            color: #9ca3af;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            margin-bottom: 0.5rem;
        }
        .badge {
            display: inline-flex;
            align-items: center;
            gap: 0.3rem;
            padding: 0.2rem 0.6rem;
            border-radius: 9999px;
            font-size: 0.65rem;
            font-weight: 600;
        }
        .slider-track {
            -webkit-appearance: none;
            appearance: none;
            height: 4px;
            border-radius: 2px;
            background: rgba(255,255,255,0.1);
            outline: none;
            width: 100%;
        }
        .slider-track::-webkit-slider-thumb {
            -webkit-appearance: none;
            width: 16px; height: 16px;
            border-radius: 50%;
            background: linear-gradient(135deg,#00f5ff,#bf00ff);
            cursor: pointer;
            box-shadow: 0 0 8px rgba(0,245,255,0.4);
        }
        .tab-btn {
            padding: 0.5rem 1rem;
            border-radius: 0.6rem;
            font-size: 0.8rem;
            font-weight: 600;
            transition: all 0.2s;
            cursor: pointer;
            border: 1px solid transparent;
        }
        .tab-btn.active {
            background: linear-gradient(135deg,rgba(0,245,255,0.15),rgba(191,0,255,0.1));
            border-color: rgba(0,245,255,0.3);
            color: #00f5ff;
        }
        .tab-btn:not(.active) {
            color: #6b7280;
        }
        .tab-btn:not(.active):hover {
            color: #fff;
            background: rgba(255,255,255,0.06);
        }
        .tab-panel { display: none; }
        .tab-panel.active { display: block; }
    </style>
</head>
<body class="min-h-screen lg:flex">

<?php include __DIR__ . '/sidebar.php'; ?>

<div class="flex-1 flex flex-col min-w-0 overflow-x-hidden">

    <!-- Top Bar -->
    <header class="flex items-center justify-between px-4 sm:px-6 py-4 sticky top-0 z-20"
            style="background:rgba(7,7,17,0.95);backdrop-filter:blur(24px);border-bottom:1px solid rgba(255,255,255,0.06);">
        <div class="flex items-center gap-3">
            <button onclick="openSidebar()" class="lg:hidden p-2 rounded-xl text-gray-400 hover:text-white transition-colors"
                    style="background:rgba(255,255,255,0.06);">
                <i class="fa-solid fa-bars text-sm"></i>
            </button>
            <div>
                <h1 class="text-lg sm:text-xl font-bold text-white">Ayarlar</h1>
                <p class="text-xs text-gray-500 hidden sm:block">Platform ve AI yapılandırması</p>
            </div>
        </div>
        <a href="<?= APP_URL ?>/admin/index.php"
           class="flex items-center gap-2 px-3 py-2 rounded-xl text-xs text-gray-400 hover:text-white transition-all"
           style="background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);">
            <i class="fa-solid fa-arrow-left text-xs"></i>
            <span class="hidden sm:inline">Dashboard</span>
        </a>
    </header>

    <main class="flex-1 p-4 sm:p-6 overflow-auto">
        <div class="max-w-3xl mx-auto space-y-6">

            <?php if ($saved): ?>
            <div class="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium"
                 style="background:rgba(0,245,255,0.08);border:1px solid rgba(0,245,255,0.25);color:#00f5ff;"
                 id="save-success-msg">
                <i class="fa-solid fa-circle-check"></i>
                Ayarlar başarıyla kaydedildi!
                <button onclick="this.parentElement.remove()" class="ml-auto text-gray-500 hover:text-white">
                    <i class="fa-solid fa-xmark text-xs"></i>
                </button>
            </div>
            <?php endif; ?>

            <?php if ($saveErr): ?>
            <div class="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium"
                 style="background:rgba(255,0,122,0.08);border:1px solid rgba(255,0,122,0.25);color:#ff007a;">
                <i class="fa-solid fa-triangle-exclamation"></i>
                <?= e($saveErr) ?>
            </div>
            <?php endif; ?>

            <!-- Tabs -->
            <div class="flex items-center gap-2 p-1 rounded-xl" style="background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08);">
                <button class="tab-btn active" onclick="showTab('ai', this)" id="tab-ai">
                    <i class="fa-solid fa-robot mr-1.5"></i>AI Ayarları
                </button>
                <button class="tab-btn" onclick="showTab('general', this)" id="tab-general">
                    <i class="fa-solid fa-sliders mr-1.5"></i>Genel
                </button>
                <button class="tab-btn" onclick="showTab('info', this)" id="tab-info">
                    <i class="fa-solid fa-circle-info mr-1.5"></i>Bilgiler
                </button>
            </div>

            <form method="POST" autocomplete="off">

                <!-- ===== TAB: AI Ayarları ===== -->
                <div class="tab-panel active space-y-5" id="panel-ai">

                    <!-- Altyazı Sistemi Prompt -->
                    <div class="panel">
                        <div class="panel-header flex items-center justify-between">
                            <div class="flex items-center gap-2">
                                <div class="w-8 h-8 rounded-lg flex items-center justify-center"
                                     style="background:rgba(0,245,255,0.1);">
                                    <i class="fa-solid fa-closed-captioning text-xs" style="color:#00f5ff;"></i>
                                </div>
                                <div>
                                    <h2 class="font-bold text-white text-sm">Altyazı AI Sistem Promptu</h2>
                                    <p class="text-xs text-gray-600">Ses dosyasından altyazı oluştururken AI'ya verilen talimat</p>
                                </div>
                            </div>
                            <span class="badge" style="background:rgba(0,245,255,0.1);color:#00f5ff;border:1px solid rgba(0,245,255,0.2);">
                                <i class="fa-solid fa-microchip"></i>Gemini
                            </span>
                        </div>
                        <div class="p-5 space-y-4">
                            <div>
                                <label class="section-label">Sistem Promptu (System Prompt)</label>
                                <textarea name="subtitle_system_prompt" id="subtitle_system_prompt" rows="8"
                                          placeholder="<?= htmlspecialchars($defaultSubtitlePrompt) ?>"
                                          class="input-field px-4 py-3 rounded-xl text-sm resize-none"
                                ><?= e($settings['subtitle_system_prompt'] ?? '') ?></textarea>
                                <p class="text-xs text-gray-600 mt-1.5">
                                    Boş bırakırsanız varsayılan prompt kullanılır. Prompt, sesi analiz edip WebVTT altyazısı oluşturan AI modelini yönlendirir.
                                </p>
                            </div>

                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                <div>
                                    <label class="section-label">Altyazı Dili</label>
                                    <select name="subtitle_language"
                                            class="input-field px-4 py-2.5 rounded-xl text-sm">
                                        <option value="tr" <?= ($settings['subtitle_language'] ?? 'tr') === 'tr' ? 'selected' : '' ?>>🇹🇷 Türkçe (tr)</option>
                                        <option value="en" <?= ($settings['subtitle_language'] ?? 'tr') === 'en' ? 'selected' : '' ?>>🇬🇧 İngilizce (en)</option>
                                    </select>
                                </div>
                                <div>
                                    <label class="section-label">
                                        Temperature: <span id="sub-temp-val"><?= $settings['subtitle_temperature'] ?? 0.2 ?></span>
                                    </label>
                                    <input type="range" name="subtitle_temperature" min="0" max="1" step="0.05"
                                           value="<?= $settings['subtitle_temperature'] ?? 0.2 ?>"
                                           class="slider-track"
                                           oninput="document.getElementById('sub-temp-val').textContent=this.value">
                                    <div class="flex justify-between text-[10px] text-gray-700 mt-1">
                                        <span>Deterministik (0)</span>
                                        <span>Yaratıcı (1)</span>
                                    </div>
                                </div>
                            </div>

                            <div class="p-3 rounded-xl" style="background:rgba(0,245,255,0.04);border:1px solid rgba(0,245,255,0.1);">
                                <p class="text-xs text-gray-500 flex items-start gap-2">
                                    <i class="fa-solid fa-lightbulb text-cyan-500 mt-0.5 flex-shrink-0"></i>
                                    <span><strong class="text-gray-300">İpucu:</strong> Altyazı oluşturma için düşük temperature (0.1–0.3) değerleri daha tutarlı ve doğru sonuçlar verir. Yüksek değerler yaratıcı ama hatalı çeviriler üretebilir.</span>
                                </p>
                            </div>

                            <div class="flex gap-2">
                                <button type="button" onclick="resetSubtitlePrompt()"
                                        class="px-4 py-2 rounded-xl text-xs text-gray-500 hover:text-white transition-all"
                                        style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);">
                                    <i class="fa-solid fa-rotate-left mr-1"></i>Varsayılana Sıfırla
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Başlık & Açıklama AI Promptu -->
                    <div class="panel">
                        <div class="panel-header flex items-center justify-between">
                            <div class="flex items-center gap-2">
                                <div class="w-8 h-8 rounded-lg flex items-center justify-center"
                                     style="background:rgba(191,0,255,0.1);">
                                    <i class="fa-solid fa-wand-magic-sparkles text-xs" style="color:#bf00ff;"></i>
                                </div>
                                <div>
                                    <h2 class="font-bold text-white text-sm">Başlık & Açıklama AI Promptu</h2>
                                    <p class="text-xs text-gray-600">Video başlığı ve açıklaması oluştururken AI'ya verilen talimat</p>
                                </div>
                            </div>
                            <span class="badge" style="background:rgba(191,0,255,0.1);color:#bf00ff;border:1px solid rgba(191,0,255,0.2);">
                                <i class="fa-solid fa-microchip"></i>Gemini
                            </span>
                        </div>
                        <div class="p-5 space-y-4">
                            <div>
                                <label class="section-label">Sistem Promptu (System Prompt)</label>
                                <textarea name="ai_title_system_prompt" id="ai_title_system_prompt" rows="6"
                                          placeholder="<?= htmlspecialchars($defaultTitlePrompt) ?>"
                                          class="input-field px-4 py-3 rounded-xl text-sm resize-none"
                                ><?= e($settings['ai_title_system_prompt'] ?? '') ?></textarea>
                                <p class="text-xs text-gray-600 mt-1.5">
                                    AI'nın ne tür bir asistan olduğunu, hangi dilde yazdığını ve nasıl başlıklar üretmesi gerektiğini buraya yazın.
                                </p>
                            </div>

                            <div>
                                <label class="section-label">
                                    Temperature: <span id="title-temp-val"><?= $settings['title_temperature'] ?? 0.7 ?></span>
                                </label>
                                <input type="range" name="title_temperature" min="0" max="1" step="0.05"
                                       value="<?= $settings['title_temperature'] ?? 0.7 ?>"
                                       class="slider-track"
                                       oninput="document.getElementById('title-temp-val').textContent=this.value">
                                <div class="flex justify-between text-[10px] text-gray-700 mt-1">
                                    <span>Deterministik (0)</span>
                                    <span>Yaratıcı (1)</span>
                                </div>
                            </div>

                            <div class="p-3 rounded-xl" style="background:rgba(191,0,255,0.04);border:1px solid rgba(191,0,255,0.1);">
                                <p class="text-xs text-gray-500 flex items-start gap-2">
                                    <i class="fa-solid fa-lightbulb text-purple-400 mt-0.5 flex-shrink-0"></i>
                                    <span><strong class="text-gray-300">İpucu:</strong> Başlık oluşturma için orta-yüksek temperature (0.6–0.8) önerilir. Bu, AI'nın daha ilgi çekici ve çeşitli başlıklar üretmesini sağlar.</span>
                                </p>
                            </div>

                            <div class="flex gap-2">
                                <button type="button" onclick="resetTitlePrompt()"
                                        class="px-4 py-2 rounded-xl text-xs text-gray-500 hover:text-white transition-all"
                                        style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);">
                                    <i class="fa-solid fa-rotate-left mr-1"></i>Varsayılana Sıfırla
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Kanal Açıklaması AI Promptu -->
                    <div class="panel">
                        <div class="panel-header flex items-center justify-between">
                            <div class="flex items-center gap-2">
                                <div class="w-8 h-8 rounded-lg flex items-center justify-center"
                                     style="background:rgba(255,165,0,0.1);">
                                    <i class="fa-solid fa-building-user text-xs" style="color:#ffa500;"></i>
                                </div>
                                <div>
                                    <h2 class="font-bold text-white text-sm">Kanal Açıklaması AI Promptu</h2>
                                    <p class="text-xs text-gray-600">Videoları analiz edip kanal açıklaması oluştururken AI'ya verilen talimat</p>
                                </div>
                            </div>
                            <span class="badge" style="background:rgba(191,0,255,0.1);color:#bf00ff;border:1px solid rgba(191,0,255,0.2);">
                                <i class="fa-solid fa-microchip"></i>Gemini
                            </span>
                        </div>
                        <div class="p-5 space-y-4">
                            <div>
                                <label class="section-label">Sistem Promptu (System Prompt)</label>
                                <textarea name="ai_channel_desc_system_prompt" id="ai_channel_desc_system_prompt" rows="6"
                                          placeholder="<?= htmlspecialchars($defaultChannelDescPrompt) ?>"
                                          class="input-field px-4 py-3 rounded-xl text-sm resize-none"
                                ><?= e($settings['ai_channel_desc_system_prompt'] ?? '') ?></textarea>
                            </div>

                            <div>
                                <label class="section-label">
                                    Temperature: <span id="channel-temp-val"><?= $settings['channel_desc_temperature'] ?? 0.7 ?></span>
                                </label>
                                <input type="range" name="channel_desc_temperature" min="0" max="1" step="0.05"
                                       value="<?= $settings['channel_desc_temperature'] ?? 0.7 ?>"
                                       class="slider-track"
                                       oninput="document.getElementById('channel-temp-val').textContent=this.value">
                            </div>

                            <div class="flex gap-2">
                                <button type="button" onclick="resetChannelDescPrompt()"
                                        class="px-4 py-2 rounded-xl text-xs text-gray-500 hover:text-white transition-all"
                                        style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);">
                                    <i class="fa-solid fa-rotate-left mr-1"></i>Varsayılana Sıfırla
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Bölüm (Chapter) AI Promptu -->
                    <div class="panel">
                        <div class="panel-header flex items-center justify-between">
                            <div class="flex items-center gap-2">
                                <div class="w-8 h-8 rounded-lg flex items-center justify-center"
                                     style="background:rgba(0,255,127,0.1);">
                                    <i class="fa-solid fa-list-ol text-xs" style="color:#00ff7f;"></i>
                                </div>
                                <div>
                                    <h2 class="font-bold text-white text-sm">Bölüm (Chapter) AI Promptu</h2>
                                    <p class="text-xs text-gray-600">Altyazıdan otomatik bölümler çıkarırken AI'ya verilen talimat</p>
                                </div>
                            </div>
                            <span class="badge" style="background:rgba(0,255,127,0.1);color:#00ff7f;border:1px solid rgba(0,255,127,0.2);">
                                <i class="fa-solid fa-microchip"></i>Gemini
                            </span>
                        </div>
                        <div class="p-5 space-y-4">
                            <div>
                                <label class="section-label">Sistem Promptu (System Prompt)</label>
                                <textarea name="ai_chapter_system_prompt" id="ai_chapter_system_prompt" rows="6"
                                          placeholder="<?= htmlspecialchars($defaultChapterPrompt) ?>"
                                          class="input-field px-4 py-3 rounded-xl text-sm resize-none"
                                ><?= e($settings['ai_chapter_system_prompt'] ?? '') ?></textarea>
                                <p class="text-xs text-gray-600 mt-1.5">
                                    <strong>ÖNEMLİ:</strong> Modelin düzgün çalışması için "SADECE JSON formatında yanıt ver" komutu bulunmalıdır.
                                </p>
                            </div>

                            <div class="flex gap-2">
                                <button type="button" onclick="resetChapterPrompt()"
                                        class="px-4 py-2 rounded-xl text-xs text-gray-500 hover:text-white transition-all"
                                        style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);">
                                    <i class="fa-solid fa-rotate-left mr-1"></i>Varsayılana Sıfırla
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- ===== TAB: Genel ===== -->
                <div class="tab-panel space-y-5" id="panel-general">
                    <div class="panel">
                        <div class="panel-header">
                            <h2 class="font-bold text-white text-sm flex items-center gap-2">
                                <i class="fa-solid fa-gear text-xs text-gray-400"></i>
                                Genel Ayarlar
                            </h2>
                        </div>
                        <div class="p-5 space-y-4">
                            <div class="p-4 rounded-xl" style="background:rgba(255,215,0,0.05);border:1px solid rgba(255,215,0,0.15);">
                                <p class="text-sm text-gray-300 flex items-start gap-2">
                                    <i class="fa-solid fa-triangle-exclamation text-yellow-500 mt-0.5 flex-shrink-0"></i>
                                    <span>Cloudinary, Supabase ve Gemini yapılandırması <strong class="text-white">includes/config.php</strong> dosyasından yönetilmektedir. Güvenlik açısından bu dosyaları sunucu üzerinde doğrudan düzenleyin.</span>
                                </p>
                            </div>

                            <!-- İndirme İzni -->
                            <div class="p-4 rounded-xl space-y-4" style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.1);">
                                <div class="flex items-center justify-between">
                                    <div>
                                        <h3 class="font-bold text-white text-sm">Videoları İndirme İzni</h3>
                                        <p class="text-xs text-gray-500">Kullanıcıların videoyu izleme sayfasından indirmesine izin verin.</p>
                                    </div>
                                    <label class="relative inline-flex items-center cursor-pointer">
                                        <input type="checkbox" name="allow_download" class="sr-only peer"
                                            <?= !empty($settings['allow_download']) ? 'checked' : '' ?>>
                                        <div class="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-cyan-400"></div>
                                    </label>
                                </div>
                            </div>

                            <!-- Bakım Modu -->
                            <div class="p-4 rounded-xl space-y-4" style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.1);">
                                <div class="flex items-center justify-between">
                                    <div>
                                        <h3 class="font-bold text-white text-sm">Bakım Modu</h3>
                                        <p class="text-xs text-gray-500 mt-0.5">Sistemi geçici olarak ziyaretçilere kapatın. Adminler giriş yapıp kullanmaya devam edebilir.</p>
                                    </div>
                                    <label class="relative inline-flex items-center cursor-pointer">
                                        <input type="checkbox" name="maintenance_mode" class="sr-only peer" <?= !empty($settings['maintenance_mode']) ? 'checked' : '' ?>>
                                        <div class="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-red-500"></div>
                                    </label>
                                </div>
                                <div>
                                    <label class="section-label">Bakım Mesajı</label>
                                    <textarea name="maintenance_message" rows="2"
                                              class="input-field px-4 py-2 rounded-xl text-sm resize-none"
                                              placeholder="Sitemiz şu an bakımda..."
                                    ><?= e($settings['maintenance_message'] ?? 'Sitemiz şu an bakımda. Kısa süre içinde geri döneceğiz.') ?></textarea>
                                </div>
                            </div>

                            <!-- +18 Yaş Uyaısı -->
                            <div class="p-4 rounded-xl space-y-4" style="background:rgba(255,0,122,0.03);border:1px solid rgba(255,0,122,0.15);">
                                <div class="flex items-center justify-between">
                                    <div>
                                        <h3 class="font-bold text-white text-sm flex items-center gap-2">
                                            <i class="fa-solid fa-shield-halved" style="color:#ff007a;"></i>
                                            +18 Yaş Doğrulama Modalı
                                        </h3>
                                        <p class="text-xs text-gray-500 mt-0.5">Siteye girince +18 uyaı modalı göster. Kullanıcı bir kez onayladıktan sonra bir daha görünmez.</p>
                                    </div>
                                    <label class="relative inline-flex items-center cursor-pointer">
                                        <input type="checkbox" name="age_warning_enabled" class="sr-only peer" <?= !empty($settings['age_warning_enabled']) ? 'checked' : '' ?>>
                                        <div class="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-pink-600"></div>
                                    </label>
                                </div>
                                <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                    <div>
                                        <label class="section-label">Modal Başlığı</label>
                                        <input type="text" name="age_warning_title"
                                               value="<?= e($settings['age_warning_title'] ?? '+18 İçerik Uyaısı') ?>"
                                               class="input-field w-full px-4 py-2 rounded-xl text-sm">
                                    </div>
                                    <div>
                                        <label class="section-label">Reddetme Yönlendirme URL</label>
                                        <input type="text" name="age_warning_redirect"
                                               value="<?= e($settings['age_warning_redirect'] ?? 'https://www.google.com') ?>"
                                               class="input-field w-full px-4 py-2 rounded-xl text-sm" placeholder="https://..">
                                    </div>
                                </div>
                                <div>
                                    <label class="section-label">Açıklama Metni</label>
                                    <textarea name="age_warning_text" rows="2"
                                              class="input-field px-4 py-2 rounded-xl text-sm resize-none w-full"
                                    ><?= e($settings['age_warning_text'] ?? 'Bu site 18 yaş ve üzeri yetişkinlere yönelik içerikler barındırmaktadır.') ?></textarea>
                                </div>
                                <div class="grid grid-cols-2 gap-3">
                                    <div>
                                        <label class="section-label">Onay Butonu Metni</label>
                                        <input type="text" name="age_warning_btn_yes"
                                               value="<?= e($settings['age_warning_btn_yes'] ?? '18 Yaşındayım, Devam Et') ?>"
                                               class="input-field w-full px-4 py-2 rounded-xl text-sm">
                                    </div>
                                    <div>
                                        <label class="section-label">Red Butonu Metni</label>
                                        <input type="text" name="age_warning_btn_no"
                                               value="<?= e($settings['age_warning_btn_no'] ?? 'Hayır, Çık') ?>"
                                               class="input-field w-full px-4 py-2 rounded-xl text-sm">
                                    </div>
                                </div>
                            </div>

                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                                <div class="p-3 rounded-xl" style="background:rgba(255,255,255,0.03);">
                                    <p class="text-gray-500 text-xs mb-1">APP_NAME</p>
                                    <p class="font-bold text-white"><?= e(APP_NAME) ?></p>
                                </div>
                                <div class="p-3 rounded-xl" style="background:rgba(255,255,255,0.03);">
                                    <p class="text-gray-500 text-xs mb-1">APP_URL</p>
                                    <p class="font-bold text-white truncate"><?= e(APP_URL) ?></p>
                                </div>
                                <div class="p-3 rounded-xl" style="background:rgba(255,255,255,0.03);">
                                    <p class="text-gray-500 text-xs mb-1">VIDEOS_PER_PAGE</p>
                                    <p class="font-bold text-white"><?= VIDEOS_PER_PAGE ?></p>
                                </div>
                                <div class="p-3 rounded-xl" style="background:rgba(255,255,255,0.03);">
                                    <p class="text-gray-500 text-xs mb-1">MAX_VIDEO_SIZE</p>
                                    <p class="font-bold text-white"><?= round(MAX_VIDEO_SIZE/1024/1024) ?> MB</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- ===== TAB: Bilgiler ===== -->
                <div class="tab-panel space-y-5" id="panel-info">
                    <div class="panel">
                        <div class="panel-header">
                            <h2 class="font-bold text-white text-sm flex items-center gap-2">
                                <i class="fa-solid fa-circle-info text-xs" style="color:#00f5ff;"></i>
                                API & Servis Durumu
                            </h2>
                        </div>
                        <div class="p-5 space-y-3">
                            <div class="flex items-center justify-between p-3 rounded-xl" style="background:rgba(0,245,255,0.04);border:1px solid rgba(0,245,255,0.1);">
                                <div class="flex items-center gap-3">
                                    <i class="fa-solid fa-robot" style="color:#00f5ff;"></i>
                                    <div>
                                        <p class="text-sm font-semibold text-white">Google Gemini AI</p>
                                        <p class="text-xs text-gray-600">Model: <?= e(GEMINI_MODEL) ?></p>
                                    </div>
                                </div>
                                <span class="badge" style="background:rgba(0,245,255,0.1);color:#00f5ff;">
                                    <span class="w-1.5 h-1.5 rounded-full bg-cyan-400 inline-block"></span>
                                    Yapılandırıldı
                                </span>
                            </div>
                            <div class="flex items-center justify-between p-3 rounded-xl" style="background:rgba(191,0,255,0.04);border:1px solid rgba(191,0,255,0.1);">
                                <div class="flex items-center gap-3">
                                    <i class="fa-solid fa-cloud" style="color:#bf00ff;"></i>
                                    <div>
                                        <p class="text-sm font-semibold text-white">Cloudinary CDN</p>
                                        <p class="text-xs text-gray-600">Cloud: <?= e(CLOUDINARY_CLOUD_NAME) ?></p>
                                    </div>
                                </div>
                                <span class="badge" style="background:rgba(191,0,255,0.1);color:#bf00ff;">
                                    <span class="w-1.5 h-1.5 rounded-full bg-purple-400 inline-block"></span>
                                    Yapılandırıldı
                                </span>
                            </div>
                            <div class="flex items-center justify-between p-3 rounded-xl" style="background:rgba(255,215,0,0.04);border:1px solid rgba(255,215,0,0.1);">
                                <div class="flex items-center gap-3">
                                    <i class="fa-solid fa-database" style="color:#ffd700;"></i>
                                    <div>
                                        <p class="text-sm font-semibold text-white">Supabase</p>
                                        <p class="text-xs text-gray-600 truncate max-w-xs"><?= e(substr(SUPABASE_URL, 0, 40)) ?>...</p>
                                    </div>
                                </div>
                                <span class="badge" style="background:rgba(255,215,0,0.1);color:#ffd700;">
                                    <span class="w-1.5 h-1.5 rounded-full bg-yellow-400 inline-block"></span>
                                    Yapılandırıldı
                                </span>
                            </div>
                        </div>
                    </div>

                    <div class="panel">
                        <div class="panel-header">
                            <h2 class="font-bold text-white text-sm flex items-center gap-2">
                                <i class="fa-solid fa-keyboard text-xs text-gray-400"></i>
                                Oynatıcı Klavye Kısayolları
                            </h2>
                        </div>
                        <div class="p-5 grid grid-cols-2 sm:grid-cols-3 gap-2">
                            <?php
                            $shortcuts = [
                                'Space / K' => 'Oynat / Durdur',
                                'F'         => 'Tam Ekran',
                                'M'         => 'Sesi Kapat/Aç',
                                '→'         => '+5 saniye',
                                '←'         => '-5 saniye',
                                'C'         => 'Altyazıyı Aç/Kapat',
                            ];
                            foreach ($shortcuts as $key => $desc): ?>
                            <div class="flex items-center gap-2 p-2 rounded-lg" style="background:rgba(255,255,255,0.03);">
                                <kbd class="px-2 py-0.5 rounded text-[10px] font-mono font-bold text-white"
                                     style="background:rgba(0,245,255,0.15);border:1px solid rgba(0,245,255,0.3);"><?= $key ?></kbd>
                                <span class="text-xs text-gray-400"><?= $desc ?></span>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>

                <!-- Save Button (AI ve Genel tablar için) -->
                <div class="flex items-center justify-end gap-3" id="save-area">
                    <button type="reset" class="px-5 py-2.5 rounded-xl text-sm text-gray-500 hover:text-white transition-all"
                            style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);">
                        <i class="fa-solid fa-xmark mr-1.5"></i>İptal
                    </button>
                    <button type="submit" id="save-btn"
                            class="flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-bold text-black transition-all hover:scale-105 hover:shadow-lg"
                            style="background:linear-gradient(135deg,#00f5ff,#bf00ff);box-shadow:0 0 20px rgba(0,245,255,0.2);">
                        <i class="fa-solid fa-floppy-disk"></i>
                        Ayarları Kaydet
                    </button>
                </div>
            </form>

        </div>
    </main>
</div>

<script>
const DEFAULT_SUBTITLE_PROMPT = <?= json_encode($defaultSubtitlePrompt) ?>;
const DEFAULT_TITLE_PROMPT    = <?= json_encode($defaultTitlePrompt) ?>;
const DEFAULT_CHANNEL_DESC_PROMPT = <?= json_encode($defaultChannelDescPrompt) ?>;
const DEFAULT_CHAPTER_PROMPT  = <?= json_encode($defaultChapterPrompt) ?>;

function resetSubtitlePrompt() {
    document.getElementById('subtitle_system_prompt').value = DEFAULT_SUBTITLE_PROMPT;
}
function resetTitlePrompt() {
    document.getElementById('ai_title_system_prompt').value = DEFAULT_TITLE_PROMPT;
}
function resetChannelDescPrompt() {
    document.getElementById('ai_channel_desc_system_prompt').value = DEFAULT_CHANNEL_DESC_PROMPT;
}
function resetChapterPrompt() {
    document.getElementById('ai_chapter_system_prompt').value = DEFAULT_CHAPTER_PROMPT;
}

function showTab(name, btn) {
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.getElementById('panel-' + name).classList.add('active');
    btn.classList.add('active');

    // Save area visibility
    const saveArea = document.getElementById('save-area');
    if (name === 'info') {
        saveArea.style.display = 'none';
    } else {
        saveArea.style.display = 'flex';
    }
}

// Auto-dismiss success
setTimeout(() => {
    const msg = document.getElementById('save-success-msg');
    if (msg) { msg.style.opacity = '0'; msg.style.transition = 'opacity 0.5s'; setTimeout(() => msg.remove(), 500); }
}, 3000);
</script>

</body>
</html>
