<?php
// Ortak admin sayfa başlığı. Kullanım: $adminTitle, $adminSub tanımla, sonra include.
?><!DOCTYPE html>
<html lang="tr" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($adminTitle) ?> | NeonTV Admin</title>
    <meta name="robots" content="noindex,nofollow">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
      body { font-family: 'Outfit', sans-serif; background: #070711; color: #fff; }
      @media print { #admin-sidebar, header, .no-print { display:none !important; } body { background:#fff; color:#000; } .print-card { background:#fff !important; border:1px solid #ccc !important; color:#000 !important; } .print-card * { color:#000 !important; } }
    </style>
</head>
<body class="min-h-screen lg:flex">
<?php include __DIR__ . '/sidebar.php'; ?>
<div class="flex-1 flex flex-col min-w-0 overflow-x-hidden">
    <header class="flex items-center gap-3 px-4 sm:px-6 py-4 sticky top-0 z-20"
            style="background:rgba(7,7,17,0.9);backdrop-filter:blur(20px);border-bottom:1px solid rgba(255,255,255,0.06);">
        <button onclick="openSidebar()" class="lg:hidden p-2 rounded-xl text-gray-400 hover:text-white" style="background:rgba(255,255,255,0.06);">
            <i class="fa-solid fa-bars text-sm"></i>
        </button>
        <div>
            <h1 class="text-lg sm:text-xl font-bold text-white"><?= e($adminTitle) ?></h1>
            <p class="text-xs text-gray-500"><?= e($adminSub ?? '') ?></p>
        </div>
    </header>
    <main class="flex-1 p-4 sm:p-6">
        <div class="max-w-5xl mx-auto space-y-4">
            <?= renderFlash() ?>
