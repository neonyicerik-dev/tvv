<?php
// ============================================================
// NeonTV - Admin: Kanal Oynatma Listeleri
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/store.php';

requireAdmin(['editor', 'moderator', 'superadmin']);
$db = new Supabase();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken(input('csrf_token'))) { setFlash('error', 'Güvenlik doğrulaması başarısız.'); redirect(APP_URL . '/admin/playlists.php'); }
    $a = input('action');
    if ($a === 'create') {
        $ch = trim(input('channel_id')); requireUuid($ch, 'Kanal');
        $title = mb_substr(trim(input('title')), 0, 120);
        if ($title === '') { setFlash('error', 'Başlık gerekli.'); redirect(APP_URL . '/admin/playlists.php'); }
        $db->insert('playlists', ['channel_id' => $ch, 'title' => $title, 'description' => mb_substr(trim(input('description')), 0, 500)], true);
        setFlash('success', 'Liste oluşturuldu.');
    } elseif ($a === 'delete') {
        $id = trim(input('id')); requireUuid($id, 'Liste');
        $db->delete('playlists', 'id=eq.' . $id, true);
        setFlash('success', 'Liste silindi.');
    } elseif ($a === 'add_video') {
        $id = trim(input('id')); $vid = trim(input('video_id'));
        requireUuid($id, 'Liste'); requireUuid($vid, 'Video');
        $cnt = $db->count('playlist_videos', 'playlist_id=eq.' . $id, true);
        $db->insert('playlist_videos', ['playlist_id' => $id, 'video_id' => $vid, 'position' => $cnt], true);
        setFlash('success', 'Video listeye eklendi.');
    } elseif ($a === 'remove_video') {
        $id = trim(input('id')); $vid = trim(input('video_id'));
        requireUuid($id, 'Liste'); requireUuid($vid, 'Video');
        $db->delete('playlist_videos', 'playlist_id=eq.' . $id . '&video_id=eq.' . $vid, true);
    }
    redirect(APP_URL . '/admin/playlists.php');
}

$channels = $db->select('channels', 'select=id,name&order=name.asc&limit=300', true)['data'] ?? [];
$chName = array_column($channels, 'name', 'id');
$videos = $db->select('videos', 'select=id,title,channel_id&order=created_at.desc&limit=500', true)['data'] ?? [];
$vTitle = array_column($videos, 'title', 'id');
$lists  = $db->select('playlists', 'order=created_at.desc&limit=200', true)['data'] ?? [];
$items  = [];
foreach (($db->select('playlist_videos', 'order=position.asc&limit=5000', true)['data'] ?? []) as $r) $items[$r['playlist_id']][] = $r['video_id'];

$adminTitle = 'Oynatma Listeleri';
$adminSub   = 'Kanal sayfasındaki "Oynatma listeleri" sekmesi';
include __DIR__ . '/_top.php';
$inp = 'bg-black/30 border border-gray-800 rounded-xl py-2.5 px-3 text-white text-sm focus:outline-none focus:border-cyan-500';
?>
<form method="POST" class="rounded-2xl p-5 grid sm:grid-cols-4 gap-3" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
    <?= csrfField() ?><input type="hidden" name="action" value="create">
    <select name="channel_id" required class="<?= $inp ?>"><option value="">Kanal seç</option><?php foreach ($channels as $c): ?><option value="<?= e($c['id']) ?>"><?= e($c['name']) ?></option><?php endforeach; ?></select>
    <input name="title" required maxlength="120" placeholder="Liste adı" class="<?= $inp ?>">
    <input name="description" maxlength="500" placeholder="Açıklama (isteğe bağlı)" class="<?= $inp ?>">
    <button class="px-4 py-2.5 rounded-xl font-bold text-black" style="background:linear-gradient(135deg,#00f5ff,#bf00ff);">Liste Oluştur</button>
</form>

<?php foreach ($lists as $l): $vs = $items[$l['id']] ?? []; ?>
<div class="rounded-2xl p-5" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
    <div class="flex items-center gap-3 mb-3">
        <div class="flex-1 min-w-0"><p class="font-bold text-white truncate"><?= e($l['title']) ?></p><p class="text-xs text-gray-500"><?= e($chName[$l['channel_id']] ?? '') ?> · <?= count($vs) ?> video</p></div>
        <form method="POST" onsubmit="return confirm('Liste silinsin mi?')"><?= csrfField() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= e($l['id']) ?>"><button class="text-red-400 text-sm"><i class="fa-solid fa-trash"></i></button></form>
    </div>
    <ul class="text-sm text-gray-300 space-y-1 mb-3">
        <?php foreach ($vs as $vid): ?>
        <li class="flex items-center gap-2"><span class="flex-1 truncate"><?= e($vTitle[$vid] ?? $vid) ?></span>
            <form method="POST"><?= csrfField() ?><input type="hidden" name="action" value="remove_video"><input type="hidden" name="id" value="<?= e($l['id']) ?>"><input type="hidden" name="video_id" value="<?= e($vid) ?>"><button class="text-gray-500 hover:text-red-400 text-xs"><i class="fa-solid fa-xmark"></i></button></form></li>
        <?php endforeach; ?>
    </ul>
    <form method="POST" class="flex gap-2"><?= csrfField() ?><input type="hidden" name="action" value="add_video"><input type="hidden" name="id" value="<?= e($l['id']) ?>">
        <select name="video_id" required class="<?= $inp ?> flex-1 min-w-0"><option value="">Video ekle…</option>
            <?php foreach ($videos as $v): if (in_array($v['id'], $vs, true)) continue; ?><option value="<?= e($v['id']) ?>"><?= e(mb_substr($v['title'], 0, 70)) ?></option><?php endforeach; ?></select>
        <button class="px-4 rounded-xl text-sm font-semibold text-black" style="background:#00f5ff">Ekle</button></form>
</div>
<?php endforeach; if (!$lists): ?><p class="text-center text-gray-500 py-8">Henüz oynatma listesi yok.</p><?php endif; ?>
<?php include __DIR__ . '/_bottom.php'; ?>
