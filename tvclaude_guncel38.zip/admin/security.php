<?php
// ============================================================
// NeonTV - Admin Güvenlik & IP Yönetimi
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/ip_log.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../includes/store.php';
require_once __DIR__ . '/../includes/supabase.php';
requireAdmin('superadmin');

$msg = ''; $msgType = 'success';

// CSRF doğrulama (tüm POST'lar için)
$csrfOk = ($_SERVER['REQUEST_METHOD'] === 'POST')
    ? verifyCsrfToken(trim($_POST['csrf_token'] ?? ''))
    : true;

// === IP Engelle ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['block_ip'])) {
    if (!$csrfOk) {
        $msg = 'Güvenlik hatası.'; $msgType = 'error';
    } else {
    $ip     = trim($_POST['block_ip']);
    $reason = trim($_POST['block_reason'] ?? '');
    if (filter_var($ip, FILTER_VALIDATE_IP)) {
        if (blockIp($ip, $reason)) {
            logActivity('ip_block', 'ip', $ip, [], ['ip' => $ip, 'reason' => $reason], $reason);
            $msg = $ip . ' adresi engellendi.'; $msgType = 'success';
        } else {
            $msg = 'Bu IP zaten engellenmiş.'; $msgType = 'warning';
        }
    } else {
        $msg = 'Geçersiz IP adresi.'; $msgType = 'error';
    }
    }
}

// === IP Engel Kaldır ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['unblock_ip'])) {
    if (!$csrfOk) {
        $msg = 'Güvenlik hatası.'; $msgType = 'error';
    } else {
    $ip = trim($_POST['unblock_ip']);
    if (unblockIp($ip)) {
        logActivity('ip_unblock', 'ip', $ip, [], [], $ip . ' engeli kaldırıldı');
        $msg = $ip . ' engelinden kaldırıldı.'; $msgType = 'success';
    }
    }
}

// === Log Temizle (DB) ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['clear_visits'])) {
    if (!$csrfOk) {
        $msg = 'Güvenlik hatası.'; $msgType = 'error';
    } else {
        $db  = new Supabase();
        $db->rpc('cleanup_old_data', [], true);
        $msg = 'Ziyaret logu temizlendi (30 günden eski).'; $msgType = 'success';
    }
}

// Veri yükle
$period    = (int)($_GET['period'] ?? 24);
$period    = in_array($period, [1,6,24,48,168]) ? $period : 24;
$visits    = array_values(getRecentVisits($period));
$ipSummary = getIpSummary($visits);
$countries = getCountryStats($visits);
$sources   = getTrafficSources($visits);
$blocked   = readBlockedIps();

// En çok ziyaret edilen sayfalar
$pageCounts = [];
foreach ($visits as $v) {
    $p = parse_url($v['page'] ?? '', PHP_URL_PATH) ?: '/';
    if (!isset($pageCounts[$p])) $pageCounts[$p] = 0;
    $pageCounts[$p]++;
}
arsort($pageCounts);

$activeTab = $_GET['tab'] ?? 'visitors';
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Güvenlik & IP | NeonTV Admin</title>
    <meta name="robots" content="noindex,nofollow">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body { font-family: 'Outfit', sans-serif; background: #070711; color: #fff; }
        .panel { background: #0f0f1e; border: 1px solid rgba(255,255,255,0.07); border-radius: 1rem; overflow: hidden; }
        .panel-header { padding: 1rem 1.25rem; border-bottom: 1px solid rgba(255,255,255,0.06); display:flex; align-items:center; justify-content:space-between; }
        .tab-btn { padding: 0.5rem 1rem; border-radius: 0.6rem; font-size: 0.8rem; font-weight: 600; transition: all 0.2s; cursor: pointer; }
        .tab-btn.active { background: linear-gradient(135deg,rgba(0,245,255,0.15),rgba(191,0,255,0.1)); border: 1px solid rgba(0,245,255,0.3); color: #00f5ff; }
        .tab-btn:not(.active) { color: #6b7280; border: 1px solid transparent; }
        .tab-btn:not(.active):hover { color: #fff; background: rgba(255,255,255,0.06); }
        .tab-content { display: none; }
        .tab-content.active { display: block; }
        .row { border-bottom: 1px solid rgba(255,255,255,0.04); transition: background 0.15s; }
        .row:hover { background: rgba(255,255,255,0.025); }
        .row:last-child { border-bottom: none; }
        .badge { display: inline-flex; align-items: center; gap: 4px; padding: 2px 10px; border-radius: 9999px; font-size: 11px; font-weight: 600; }
        .input-field { background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); color: #fff; transition: all 0.2s; }
        .input-field:focus { border-color: rgba(0,245,255,0.5); outline: none; }
        .progress-bar { height: 6px; border-radius: 3px; background: rgba(255,255,255,0.06); overflow: hidden; }
        .progress-fill { height: 100%; border-radius: 3px; transition: width 0.6s ease; }
        .stat-mini { background: #0f0f1e; border: 1px solid rgba(255,255,255,0.07); border-radius: 0.75rem; padding: 1rem; }
        .btn-block { background: rgba(255,68,68,0.1); border: 1px solid rgba(255,68,68,0.3); color: #ff4444; font-size: 11px; padding: 4px 10px; border-radius: 8px; cursor: pointer; transition: all 0.2s; }
        .btn-block:hover { background: rgba(255,68,68,0.2); }
        .btn-unblock { background: rgba(0,255,127,0.1); border: 1px solid rgba(0,255,127,0.3); color: #00ff7f; font-size: 11px; padding: 4px 10px; border-radius: 8px; cursor: pointer; transition: all 0.2s; }
        .btn-unblock:hover { background: rgba(0,255,127,0.2); }
        .flag { font-size: 1.1rem; }
    </style>
</head>
<body class="min-h-screen lg:flex">

<?php include __DIR__ . '/sidebar.php'; ?>

<div class="flex-1 flex flex-col min-w-0 overflow-x-hidden">

    <!-- Top Bar -->
    <header class="flex items-center justify-between px-4 sm:px-6 py-4 sticky top-0 z-20"
            style="background:rgba(7,7,17,0.95);backdrop-filter:blur(24px);border-bottom:1px solid rgba(255,255,255,0.06);">
        <div class="flex items-center gap-3">
            <button onclick="openSidebar()" class="lg:hidden p-2 rounded-xl text-gray-400"
                    style="background:rgba(255,255,255,0.06);"><i class="fa-solid fa-bars text-sm"></i></button>
            <div>
                <h1 class="text-lg sm:text-xl font-bold text-white flex items-center gap-2">
                    <i class="fa-solid fa-shield-halved text-sm" style="color:#ff007a;"></i>
                    Güvenlik & IP
                </h1>
                <p class="text-xs text-gray-500 hidden sm:block">Ziyaretçi analizi, coğrafi dağılım, trafik kaynakları</p>
            </div>
        </div>
        <!-- Dönem Seçici -->
        <form method="GET" class="flex items-center gap-2">
            <input type="hidden" name="tab" value="<?= e($activeTab) ?>">
            <select name="period" onchange="this.form.submit()"
                    class="input-field px-3 py-1.5 rounded-xl text-xs">
                <option value="1"   <?= $period===1  ?'selected':''?>>Son 1 Saat</option>
                <option value="6"   <?= $period===6  ?'selected':''?>>Son 6 Saat</option>
                <option value="24"  <?= $period===24 ?'selected':''?>>Son 24 Saat</option>
                <option value="48"  <?= $period===48 ?'selected':''?>>Son 48 Saat</option>
                <option value="168" <?= $period===168?'selected':''?>>Son 7 Gün</option>
            </select>
        </form>
    </header>

    <main class="flex-1 p-4 sm:p-6 space-y-5 overflow-auto">

        <?php if ($msg): ?>
        <div class="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium"
             style="background:rgba(<?= $msgType==='success'?'0,245,255':($msgType==='error'?'255,68,68':'255,215,0') ?>,0.08);
                    border:1px solid rgba(<?= $msgType==='success'?'0,245,255':($msgType==='error'?'255,68,68':'255,215,0') ?>,0.25);
                    color:<?= $msgType==='success'?'#00f5ff':($msgType==='error'?'#ff4444':'#ffd700') ?>;">
            <i class="fa-solid fa-<?= $msgType==='success'?'circle-check':($msgType==='error'?'circle-xmark':'triangle-exclamation') ?>"></i>
            <?= e($msg) ?>
        </div>
        <?php endif; ?>

        <!-- Özet Kartlar -->
        <div class="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div class="stat-mini">
                <p class="text-xs text-gray-500 mb-1">Toplam Ziyaret</p>
                <p class="text-2xl font-bold text-white"><?= count($visits) ?></p>
                <p class="text-[10px] text-gray-600 mt-1">Son <?= $period ?> saat</p>
            </div>
            <div class="stat-mini">
                <p class="text-xs text-gray-500 mb-1">Tekil IP</p>
                <p class="text-2xl font-bold" style="color:#00f5ff;"><?= count($ipSummary) ?></p>
                <p class="text-[10px] text-gray-600 mt-1"><?= count($countries) ?> farklı ülke</p>
            </div>
            <div class="stat-mini">
                <p class="text-xs text-gray-500 mb-1">Engellenmiş IP</p>
                <p class="text-2xl font-bold" style="color:#ff007a;"><?= count($blocked) ?></p>
                <p class="text-[10px] text-gray-600 mt-1">aktif engel</p>
            </div>
            <div class="stat-mini">
                <p class="text-xs text-gray-500 mb-1">Trafik Kaynağı</p>
                <p class="text-2xl font-bold" style="color:#bf00ff;"><?= count($sources) ?></p>
                <p class="text-[10px] text-gray-600 mt-1">farklı kaynak</p>
            </div>
        </div>

        <!-- Sekmeler -->
        <div class="flex items-center gap-1.5 p-1 rounded-xl flex-wrap"
             style="background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08);">
            <?php
            $tabs = [
                'visitors' => ['icon' => 'fa-users',      'label' => 'Ziyaretçiler'],
                'geo'      => ['icon' => 'fa-globe',       'label' => 'Coğrafi Dağılım'],
                'sources'  => ['icon' => 'fa-share-nodes', 'label' => 'Trafik Kaynakları'],
                'blocked'  => ['icon' => 'fa-ban',         'label' => 'Engellenmiş IPs'],
                'block_new'=> ['icon' => 'fa-plus',        'label' => 'IP Engelle'],
            ];
            foreach ($tabs as $key => $t): ?>
            <button class="tab-btn <?= $activeTab===$key?'active':'' ?>"
                    onclick="switchTab('<?= $key ?>')" id="tab-btn-<?= $key ?>">
                <i class="fa-solid <?= $t['icon'] ?> mr-1.5 text-xs"></i><?= $t['label'] ?>
                <?php if ($key==='blocked' && count($blocked)>0): ?>
                <span class="ml-1 px-1.5 py-0.5 rounded-full text-[10px] font-bold"
                      style="background:#ff007a;color:#fff;"><?= count($blocked) ?></span>
                <?php endif; ?>
            </button>
            <?php endforeach; ?>
        </div>

        <!-- TAB: Ziyaretçiler -->
        <div class="tab-content <?= $activeTab==='visitors'?'active':'' ?>" id="tab-visitors">
            <div class="panel">
                <div class="panel-header">
                    <h2 class="font-bold text-white text-sm flex items-center gap-2">
                        <i class="fa-solid fa-users text-xs" style="color:#00f5ff;"></i>
                        IP Ziyaretçi Listesi
                    </h2>
                    <?php if (!empty($visits)): ?>
                    <form method="POST">
                        <button name="clear_visits" value="1" type="submit"
                                onclick="return confirm('Ziyaret logu temizlensin mi?')"
                                class="text-xs text-gray-500 hover:text-red-400 transition-colors flex items-center gap-1">
                            <i class="fa-solid fa-trash text-[10px]"></i> Temizle
                        </button>
                    </form>
                    <?php endif; ?>
                </div>
                <?php if (empty($ipSummary)): ?>
                <div class="text-center py-14 text-gray-600">
                    <i class="fa-solid fa-users text-4xl mb-3 block opacity-20"></i>
                    Bu dönemde ziyaret kaydı yok
                </div>
                <?php else: ?>
                <div class="overflow-x-auto">
                    <table class="w-full text-sm">
                        <thead>
                            <tr style="border-bottom:1px solid rgba(255,255,255,0.06);">
                                <th class="text-left px-4 py-2.5 text-xs text-gray-500 font-semibold uppercase">IP Adresi</th>
                                <th class="text-left px-4 py-2.5 text-xs text-gray-500 font-semibold uppercase hidden sm:table-cell">Konum</th>
                                <th class="text-center px-4 py-2.5 text-xs text-gray-500 font-semibold uppercase">Ziyaret</th>
                                <th class="text-left px-4 py-2.5 text-xs text-gray-500 font-semibold uppercase hidden md:table-cell">Son Görülme</th>
                                <th class="text-center px-4 py-2.5 text-xs text-gray-500 font-semibold uppercase">İşlem</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                        $blockedIpList = array_map(fn($e) => is_array($e) ? ($e['ip']??'') : $e, $blocked);
                        foreach (array_slice($ipSummary, 0, 100) as $v):
                            $isBlk = false; // ziyaretçiler yalnızca hash olarak tutulur, IP ile eşleştirilemez
                        ?>
                        <tr class="row">
                            <td class="px-4 py-3">
                                <div class="flex items-center gap-2">
                                    <?php if ($isBlk): ?>
                                    <span class="w-2 h-2 rounded-full bg-red-500 flex-shrink-0"></span>
                                    <?php else: ?>
                                    <span class="w-2 h-2 rounded-full bg-green-500 flex-shrink-0"></span>
                                    <?php endif; ?>
                                    <span class="font-mono text-xs text-white"><?= e(substr($v['ip_hash'] ?? '', 0, 12)) ?>…</span>
                                </div>
                                <?php if (!empty($v['isp'])): ?>
                                <p class="text-[10px] text-gray-600 ml-4 mt-0.5 truncate max-w-[160px]"><?= e($v['isp']) ?></p>
                                <?php endif; ?>
                            </td>
                            <td class="px-4 py-3 hidden sm:table-cell">
                                <div class="flex items-center gap-1.5">
                                    <span><?= !empty($v['country']) ? '🌍' : '' ?></span>
                                    <div>
                                        <p class="text-xs text-gray-300"><?= e($v['country'] ?: 'Bilinmeyen') ?></p>
                                        <?php if (!empty($v['city'])): ?>
                                        <p class="text-[10px] text-gray-600"><?= e($v['city']) ?></p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </td>
                            <td class="px-4 py-3 text-center">
                                <span class="font-bold text-white"><?= $v['count'] ?></span>
                            </td>
                            <td class="px-4 py-3 hidden md:table-cell text-xs text-gray-500">
                                <?= timeAgo($v['last_seen'] ?? '') ?>
                            </td>
                            <td class="px-4 py-3 text-center">
                                <span class="text-[10px] text-gray-600" title="Gizlilik için IP'ler hashlenir; engellemek için yukarıdaki IP kutusunu kullanın">hash</span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- TAB: Coğrafi Dağılım -->
        <div class="tab-content <?= $activeTab==='geo'?'active':'' ?>" id="tab-geo">
            <div class="panel">
                <div class="panel-header">
                    <h2 class="font-bold text-white text-sm flex items-center gap-2">
                        <i class="fa-solid fa-globe text-xs" style="color:#00f5ff;"></i>
                        Ülke Bazlı Dağılım
                    </h2>
                    <span class="text-xs text-gray-600"><?= count($countries) ?> ülke</span>
                </div>
                <?php if (empty($countries)): ?>
                <div class="text-center py-14 text-gray-600">
                    <i class="fa-solid fa-globe text-4xl mb-3 block opacity-20"></i>Veri yok
                </div>
                <?php else: ?>
                <div class="p-4 space-y-3">
                    <?php
                    $maxCount = $countries[0]['count'] ?? 1;
                    $countryFlags = ['TR'=>'🇹🇷','US'=>'🇺🇸','DE'=>'🇩🇪','GB'=>'🇬🇧','FR'=>'🇫🇷','NL'=>'🇳🇱','RU'=>'🇷🇺','CN'=>'🇨🇳','JP'=>'🇯🇵','KR'=>'🇰🇷','IT'=>'🇮🇹','ES'=>'🇪🇸','PL'=>'🇵🇱','UA'=>'🇺🇦','AZ'=>'🇦🇿','SY'=>'🇸🇾','IR'=>'🇮🇷','SA'=>'🇸🇦'];
                    foreach ($countries as $c):
                        $pct  = $maxCount > 0 ? round($c['count']/$maxCount*100) : 0;
                        $flag = $countryFlags[$c['code']] ?? '🌍';
                    ?>
                    <div>
                        <div class="flex items-center justify-between mb-1.5">
                            <div class="flex items-center gap-2">
                                <span class="text-lg leading-none"><?= $flag ?></span>
                                <span class="text-sm text-white font-medium"><?= e($c['country']) ?></span>
                                <span class="text-xs text-gray-600">(<?= e($c['code']) ?>)</span>
                            </div>
                            <div class="flex items-center gap-2">
                                <span class="font-bold text-white text-sm"><?= $c['count'] ?></span>
                                <span class="text-xs text-gray-600"><?= round($c['count']/max(1,count($visits))*100) ?>%</span>
                            </div>
                        </div>
                        <div class="progress-bar">
                            <div class="progress-fill" style="width:<?= $pct ?>%;background:linear-gradient(90deg,#00f5ff,#bf00ff);"></div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>

            <!-- En çok ziyaret edilen sayfalar -->
            <div class="panel mt-4">
                <div class="panel-header">
                    <h2 class="font-bold text-white text-sm flex items-center gap-2">
                        <i class="fa-solid fa-file-lines text-xs" style="color:#bf00ff;"></i>
                        En Çok Ziyaret Edilen Sayfalar
                    </h2>
                </div>
                <?php if (empty($pageCounts)): ?>
                <div class="text-center py-10 text-gray-600">Veri yok</div>
                <?php else: ?>
                <div class="p-4 space-y-2">
                    <?php
                    $maxPg = max($pageCounts) ?: 1;
                    $i = 0;
                    foreach (array_slice($pageCounts, 0, 10, true) as $pg => $cnt):
                        $i++;
                        $pct = round($cnt/$maxPg*100);
                    ?>
                    <div>
                        <div class="flex items-center justify-between mb-1">
                            <span class="text-xs text-gray-300 font-mono truncate max-w-[70%]"><?= e($pg) ?></span>
                            <span class="text-xs font-bold text-white"><?= $cnt ?></span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress-fill" style="width:<?= $pct ?>%;background:linear-gradient(90deg,#bf00ff,#ff007a);"></div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- TAB: Trafik Kaynakları -->
        <div class="tab-content <?= $activeTab==='sources'?'active':'' ?>" id="tab-sources">
            <div class="panel">
                <div class="panel-header">
                    <h2 class="font-bold text-white text-sm flex items-center gap-2">
                        <i class="fa-solid fa-share-nodes text-xs" style="color:#ffd700;"></i>
                        Trafik Kaynakları
                    </h2>
                    <span class="text-xs text-gray-600"><?= count($sources) ?> kaynak</span>
                </div>
                <?php if (empty($sources)): ?>
                <div class="text-center py-14 text-gray-600">
                    <i class="fa-solid fa-share-nodes text-4xl mb-3 block opacity-20"></i>Veri yok
                </div>
                <?php else: ?>
                <div class="p-4 space-y-3">
                    <?php
                    $maxSrc = max($sources) ?: 1;
                    $srcIcons = [
                        'Direkt'      => ['icon'=>'fa-link',     'color'=>'#00f5ff'],
                        'google.com'  => ['icon'=>'fa-google',   'color'=>'#ea4335'],
                        'twitter.com' => ['icon'=>'fa-x-twitter','color'=>'#fff'],
                        't.co'        => ['icon'=>'fa-x-twitter','color'=>'#fff'],
                        'facebook.com'=> ['icon'=>'fa-facebook', 'color'=>'#1877f2'],
                        'instagram.com'=> ['icon'=>'fa-instagram','color'=>'#e1306c'],
                        'youtube.com' => ['icon'=>'fa-youtube',  'color'=>'#ff0000'],
                        'telegram.org'=> ['icon'=>'fa-telegram', 'color'=>'#26a5e4'],
                        'reddit.com'  => ['icon'=>'fa-reddit',   'color'=>'#ff4500'],
                        't.me'        => ['icon'=>'fa-telegram', 'color'=>'#26a5e4'],
                    ];
                    $totalVisitsCnt = count($visits) ?: 1;
                    foreach ($sources as $src => $cnt):
                        $pct = round($cnt/$maxSrc*100);
                        $pctOfTotal = round($cnt/$totalVisitsCnt*100);
                        $iconData = $srcIcons[$src] ?? ['icon'=>'fa-globe','color'=>'#9ca3af'];
                    ?>
                    <div class="p-3 rounded-xl" style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.07);">
                        <div class="flex items-center justify-between mb-2">
                            <div class="flex items-center gap-2.5">
                                <div class="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
                                     style="background:<?= $iconData['color'] ?>18;border:1px solid <?= $iconData['color'] ?>30;">
                                    <i class="fa-brands <?= $iconData['icon'] ?> text-sm" style="color:<?= $iconData['color'] ?>;"></i>
                                </div>
                                <div>
                                    <p class="text-sm font-semibold text-white"><?= e($src) ?></p>
                                    <p class="text-[10px] text-gray-600"><?= $pctOfTotal ?>% toplam trafik</p>
                                </div>
                            </div>
                            <span class="text-xl font-bold text-white"><?= $cnt ?></span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress-fill" style="width:<?= $pct ?>%;background:<?= $iconData['color'] ?>;opacity:0.7;"></div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- TAB: Engellenmiş IPs -->
        <div class="tab-content <?= $activeTab==='blocked'?'active':'' ?>" id="tab-blocked">
            <div class="panel">
                <div class="panel-header">
                    <h2 class="font-bold text-white text-sm flex items-center gap-2">
                        <i class="fa-solid fa-ban text-xs" style="color:#ff007a;"></i>
                        Engellenmiş IP Listesi
                    </h2>
                    <span class="badge" style="background:rgba(255,0,122,0.1);color:#ff007a;">
                        <?= count($blocked) ?> engel
                    </span>
                </div>
                <?php if (empty($blocked)): ?>
                <div class="text-center py-14 text-gray-600">
                    <i class="fa-solid fa-shield-check text-4xl mb-3 block opacity-20"></i>
                    Engellenmiş IP yok
                </div>
                <?php else: ?>
                <div>
                    <?php foreach ($blocked as $b):
                        $bIp  = is_array($b) ? ($b['ip']        ?? '-') : $b;
                        $bRsn = is_array($b) ? ($b['reason']    ?? '') : '';
                        $bBy  = is_array($b) ? ($b['blocked_by']?? '') : '';
                        $bAt  = is_array($b) ? ($b['blocked_at']?? '') : '';
                    ?>
                    <div class="row px-4 py-3 flex items-center gap-4">
                        <div class="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
                             style="background:rgba(255,0,122,0.1);border:1px solid rgba(255,0,122,0.2);">
                            <i class="fa-solid fa-ban text-xs" style="color:#ff007a;"></i>
                        </div>
                        <div class="flex-1 min-w-0">
                            <p class="font-mono font-bold text-white text-sm"><?= e($bIp) ?></p>
                            <div class="flex items-center gap-3 text-xs text-gray-500 mt-0.5 flex-wrap">
                                <?php if ($bRsn): ?>
                                <span><?= e($bRsn) ?></span>
                                <?php endif; ?>
                                <?php if ($bBy): ?>
                                <span><i class="fa-solid fa-user text-[10px]"></i> <?= e($bBy) ?></span>
                                <?php endif; ?>
                                <?php if ($bAt): ?>
                                <span><i class="fa-regular fa-clock text-[10px]"></i> <?= timeAgo($bAt) ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <form method="POST">
                            <input type="hidden" name="unblock_ip" value="<?= e($bIp) ?>">
                            <button type="submit" class="btn-unblock">
                                <i class="fa-solid fa-unlock mr-1"></i>Kaldır
                            </button>
                        </form>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- TAB: IP Engelle -->
        <div class="tab-content <?= $activeTab==='block_new'?'active':'' ?>" id="tab-block_new">
            <div class="panel max-w-lg">
                <div class="panel-header">
                    <h2 class="font-bold text-white text-sm flex items-center gap-2">
                        <i class="fa-solid fa-shield-halved text-xs" style="color:#ff007a;"></i>
                        Yeni IP Engelle
                    </h2>
                </div>
                <form method="POST" class="p-5 space-y-4">
                    <div>
                        <label class="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">
                            IP Adresi (IPv4 / IPv6 / CIDR)
                        </label>
                        <input type="text" name="block_ip" id="block_ip_input" placeholder="örn: 1.2.3.4 veya 192.168.0.0/24"
                               class="input-field w-full px-4 py-2.5 rounded-xl text-sm font-mono" required>
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">
                            Engel Sebebi (isteğe bağlı)
                        </label>
                        <input type="text" name="block_reason" placeholder="örn: Spam, brute force..."
                               class="input-field w-full px-4 py-2.5 rounded-xl text-sm">
                    </div>
                    <div class="p-3 rounded-xl text-xs" style="background:rgba(255,0,122,0.05);border:1px solid rgba(255,0,122,0.15);color:#ff9ca3;">
                        <i class="fa-solid fa-triangle-exclamation mr-1.5"></i>
                        Engellenen IP, siteye erişemez ve 403 hatası alır. CIDR ile ağ aralığı da engellenebilir.
                    </div>
                    <button type="submit"
                            class="flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-bold text-black"
                            style="background:linear-gradient(135deg,#ff007a,#bf00ff);">
                        <i class="fa-solid fa-ban"></i>
                        IP'yi Engelle
                    </button>
                </form>
            </div>
        </div>

    </main>
</div>

<script>
function switchTab(name) {
    document.querySelectorAll('.tab-content').forEach(el => el.classList.remove('active'));
    document.querySelectorAll('.tab-btn').forEach(el => el.classList.remove('active'));
    document.getElementById('tab-' + name).classList.add('active');
    document.getElementById('tab-btn-' + name).classList.add('active');
    // URL güncelle
    const url = new URL(window.location);
    url.searchParams.set('tab', name);
    history.replaceState(null, '', url);
}
</script>
</body>
</html>
