<?php
// ============================================================
// NeonTV - Admin Çıkış
// G4: Session + Cookie tam temizleme
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/activity_log.php';

if (isAdminLoggedIn()) {
    logActivity('logout', 'admin', $_SESSION['admin_username'] ?? '');
}
adminLogout();

header('Location: ' . APP_URL . '/admin/login.php');
exit;
