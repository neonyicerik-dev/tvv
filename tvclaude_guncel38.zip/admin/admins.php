<?php
// ============================================================
// NeonTV - Admin Yönetimi (Sadece Superadmin)
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/store.php';
require_once __DIR__ . '/../includes/activity_log.php';
requireAdmin('superadmin');

$msg = '';
$msgType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken(input('csrf_token'))) {
        $msg = 'Güvenlik hatası. Sayfayı yenileyin.'; $msgType = 'error';
    } elseif (($_POST['action'] ?? '') === 'add') {
        $username = trim($_POST['username'] ?? '');
        $password = trim($_POST['password'] ?? '');
        $role     = pgEnum($_POST['role'] ?? '', ['superadmin', 'moderator', 'editor'], 'editor');

        if (!$username || !$password) {
            $msg = 'Kullanıcı adı ve şifre zorunludur.'; $msgType = 'error';
        } elseif (!validatePassword($password)) {
            $msg = 'Şifre en az 6 karakter olmalı.'; $msgType = 'error';
        } elseif ($username === ADMIN_USERNAME || Store::findAdmin($username)) {
            $msg = 'Bu kullanıcı adı zaten mevcut.'; $msgType = 'error';
        } else {
            $id = 'adm_' . bin2hex(random_bytes(7));
            $ok = Store::createAdmin($id, $username, password_hash($password, PASSWORD_BCRYPT), $role);
            if ($ok) {
                logActivity('admin_create', 'admin', $id, [], ['username' => $username, 'role' => $role]);
                $msg = 'Yeni admin eklendi.'; $msgType = 'success';
            } else {
                $msg = 'Admin oluşturulamadı.'; $msgType = 'error';
            }
        }
    } elseif (($_POST['action'] ?? '') === 'delete') {
        $id = trim($_POST['id'] ?? '');
        if ($id) {
            $ok = Store::deleteAdmin($id);
            if ($ok) {
                logActivity('admin_delete', 'admin', $id);
                $msg = 'Admin silindi.'; $msgType = 'success';
            } else {
                $msg = 'Silinemedi.'; $msgType = 'error';
            }
        }
    }
}
$admins = Store::admins();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adminler | NeonTV</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body { font-family: 'Outfit', sans-serif; background: #070711; color: #fff; }
        .table-row { transition: background 0.15s; }
        .table-row:hover { background: rgba(255,255,255,0.03); }
    </style>
</head>
<body class="min-h-screen lg:flex">

<?php include __DIR__ . '/sidebar.php'; ?>

<div class="flex-1 flex flex-col min-w-0 overflow-x-hidden">
    <header class="flex items-center justify-between px-4 sm:px-6 py-4 sticky top-0 z-20"
            style="background:rgba(7,7,17,0.9);backdrop-filter:blur(20px);border-bottom:1px solid rgba(255,255,255,0.06);">
        <div class="flex items-center gap-3">
            <button onclick="openSidebar()" class="lg:hidden p-2 rounded-xl text-gray-400 hover:text-white" style="background:rgba(255,255,255,0.06);">
                <i class="fa-solid fa-bars"></i>
            </button>
            <div>
                <h1 class="text-lg sm:text-xl font-bold text-white">Yöneticiler</h1>
                <p class="text-xs text-gray-500">Sistem yetkililerini yönetin</p>
            </div>
        </div>
        <button onclick="document.getElementById('add-modal').classList.remove('hidden')"
           class="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold text-black"
           style="background:linear-gradient(135deg,#00f5ff,#bf00ff);">
            <i class="fa-solid fa-plus"></i><span class="hidden sm:inline">Yeni Admin</span>
        </button>
    </header>

    <main class="flex-1 p-4 sm:p-6 overflow-auto">
        <div class="max-w-4xl mx-auto space-y-6">

            <?php if ($msg): ?>
            <div class="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium"
                 style="<?= $msgType === 'success' ? 'background:rgba(0,245,255,0.08);border:1px solid rgba(0,245,255,0.25);color:#00f5ff;' : 'background:rgba(255,0,122,0.08);border:1px solid rgba(255,0,122,0.25);color:#ff007a;' ?>">
                <i class="fa-solid <?= $msgType === 'success' ? 'fa-check' : 'fa-triangle-exclamation' ?>"></i>
                <?= $msg ?>
            </div>
            <?php endif; ?>

            <div class="rounded-2xl overflow-hidden" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
                <table class="w-full min-w-[600px]">
                    <thead>
                        <tr style="border-bottom:1px solid rgba(255,255,255,0.06);">
                            <th class="text-left px-5 py-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Kullanıcı Adı</th>
                            <th class="text-left px-5 py-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Rol</th>
                            <th class="text-left px-5 py-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Eklenme</th>
                            <th class="text-right px-5 py-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">İşlem</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Config Admin -->
                        <tr class="table-row" style="border-bottom:1px solid rgba(255,255,255,0.03);">
                            <td class="px-5 py-4">
                                <div class="flex items-center gap-3">
                                    <div class="w-10 h-10 rounded-full flex items-center justify-center bg-purple-500/10 text-purple-400">
                                        <i class="fa-solid fa-crown"></i>
                                    </div>
                                    <span class="font-bold"><?= e(ADMIN_USERNAME) ?></span>
                                </div>
                            </td>
                            <td class="px-5 py-4">
                                <span class="px-2.5 py-1 rounded-full text-[11px] font-medium bg-purple-500/10 text-purple-400 border border-purple-500/20">
                                    Sistem Kurucusu
                                </span>
                            </td>
                            <td class="px-5 py-4 text-xs text-gray-500">-</td>
                            <td class="px-5 py-4 text-right text-xs text-gray-600">Yapılandırma Dosyasından</td>
                        </tr>
                        <!-- Ekli Adminler (DB) -->
                        <?php foreach ($admins as $admin): ?>
                        <tr class="table-row" style="border-bottom:1px solid rgba(255,255,255,0.03);">
                            <td class="px-5 py-4">
                                <div class="flex items-center gap-3">
                                    <div class="w-10 h-10 rounded-full flex items-center justify-center bg-white/5 text-gray-400">
                                        <i class="fa-solid fa-user"></i>
                                    </div>
                                    <span class="font-bold text-white"><?= e($admin['username']) ?></span>
                                </div>
                            </td>
                            <td class="px-5 py-4">
                                <?php if($admin['role'] === 'superadmin'): ?>
                                <span class="px-2.5 py-1 rounded-full text-[11px] font-medium bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">Superadmin</span>
                                <?php elseif($admin['role'] === 'moderator'): ?>
                                <span class="px-2.5 py-1 rounded-full text-[11px] font-medium bg-yellow-500/10 text-yellow-400 border border-yellow-500/20">Moderatör</span>
                                <?php else: ?>
                                <span class="px-2.5 py-1 rounded-full text-[11px] font-medium bg-gray-500/10 text-gray-400 border border-gray-500/20">Editör</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-5 py-4 text-xs text-gray-500"><?= date('d.m.Y', strtotime($admin['created_at'])) ?></td>
                            <td class="px-5 py-4 text-right">
                                <form method="POST" onsubmit="return confirm('Silmek istediğinize emin misiniz?');">
                                    <?= csrfField() ?>
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="id" value="<?= e($admin['id']) ?>">
                                    <button type="submit" class="p-2 rounded-lg text-red-400 hover:bg-red-400/10 transition-colors">
                                        <i class="fa-solid fa-trash-can"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</div>

<!-- Add Modal -->
<div id="add-modal" class="fixed inset-0 z-50 hidden flex items-center justify-center px-4" style="background:rgba(0,0,0,0.8);backdrop-filter:blur(4px);">
    <div class="w-full max-w-md rounded-2xl p-6" style="background:#13131f;border:1px solid rgba(255,255,255,0.1);">
        <div class="flex justify-between items-center mb-5">
            <h3 class="text-lg font-bold text-white">Yeni Yönetici Ekle</h3>
            <button onclick="document.getElementById('add-modal').classList.add('hidden')" class="text-gray-500 hover:text-white">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>
        <form method="POST">
            <input type="hidden" name="action" value="add">
            <div class="space-y-4">
                <div>
                    <label class="block text-xs text-gray-400 mb-1">Kullanıcı Adı</label>
                    <input type="text" name="username" required class="w-full px-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white outline-none focus:border-cyan-400">
                </div>
                <div>
                    <label class="block text-xs text-gray-400 mb-1">Şifre</label>
                    <input type="password" name="password" required class="w-full px-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white outline-none focus:border-cyan-400">
                </div>
                <div>
                    <label class="block text-xs text-gray-400 mb-1">Yetki Rolü</label>
                    <select name="role" class="w-full px-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white outline-none focus:border-cyan-400 [&>option]:bg-gray-900">
                        <option value="editor">Editör (Sadece İçerik Yönetimi)</option>
                        <option value="moderator">Moderatör (İçerik + Yorum Yönetimi)</option>
                        <option value="superadmin">Superadmin (Tam Yetki)</option>
                    </select>
                </div>
                <button type="submit" class="w-full py-3 mt-2 rounded-xl text-black font-bold" style="background:linear-gradient(135deg,#00f5ff,#00c8d4);">Ekle</button>
            </div>
        </form>
    </div>
</div>

<script>
    if (window.history.replaceState) {
        window.history.replaceState(null, null, window.location.href);
    }
</script>
</body>
</html>
