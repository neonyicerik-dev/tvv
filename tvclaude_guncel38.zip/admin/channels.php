<?php
// ============================================================
// NeonTV - Admin Kanallar
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
requireAdmin();

$db = new Supabase();
$res = $db->select('channels', 'order=created_at.desc', true);
$channels = $res['data'] ?? [];
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kanallar | NeonTV Admin</title>
    <meta name="robots" content="noindex,nofollow">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body { font-family: 'Outfit', sans-serif; background: #070711; color: #fff; }
        .input-field {
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(255,255,255,0.1);
            width: 100%; transition: all 0.2s; color: #fff;
        }
        .input-field:focus { border-color: rgba(0,245,255,0.5); outline: none; }
        .modal {
            position: fixed; inset: 0; background: rgba(0,0,0,0.8); backdrop-filter: blur(5px);
            z-index: 50; display: none; align-items: center; justify-content: center;
        }
        .modal.active { display: flex; }
        .modal-content {
            background: #13131f; border: 1px solid rgba(255,255,255,0.1); border-radius: 1rem; width: 100%; max-width: 500px;
        }
    </style>
</head>
<body class="min-h-screen lg:flex">

<?php include __DIR__ . '/sidebar.php'; ?>

<div class="flex-1 flex flex-col min-w-0 overflow-x-hidden">

    <header class="flex items-center justify-between px-4 sm:px-6 py-4 sticky top-0 z-20"
            style="background:rgba(7,7,17,0.9);backdrop-filter:blur(20px);border-bottom:1px solid rgba(255,255,255,0.06);">
        <div class="flex items-center gap-3">
            <button onclick="openSidebar()" class="lg:hidden p-2 rounded-xl text-gray-400 hover:text-white"
                    style="background:rgba(255,255,255,0.06);"><i class="fa-solid fa-bars text-sm"></i></button>
            <h1 class="text-xl font-bold text-white">Kanallar</h1>
        </div>
        <button onclick="openModal()" class="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold text-black"
                style="background:linear-gradient(135deg,#00f5ff,#bf00ff);">
            <i class="fa-solid fa-plus"></i> Yeni Kanal
        </button>
    </header>

    <main class="flex-1 p-4 sm:p-6 overflow-auto">
        <?php if (empty($channels)): ?>
            <div class="text-center py-12 text-gray-500">
                <i class="fa-solid fa-users-slash text-4xl mb-3 block opacity-50"></i>
                Henüz kanal oluşturulmamış. Yeni kanal ekleyerek videolara yazar/kanal atayabilirsiniz.
            </div>
        <?php else: ?>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                <?php foreach ($channels as $c): ?>
                <div class="rounded-2xl overflow-hidden relative group" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
                    <!-- Cover -->
                    <div class="h-24 w-full bg-gray-800 relative">
                        <?php if(!empty($c['cover_url'])): ?>
                            <img src="<?= e($c['cover_url']) ?>" class="w-full h-full object-cover">
                        <?php else: ?>
                            <div class="w-full h-full" style="background:linear-gradient(135deg,rgba(0,245,255,0.2),rgba(191,0,255,0.2));"></div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Avatar -->
                    <div class="absolute top-16 left-4 w-14 h-14 rounded-full border-4 border-[#13131f] overflow-hidden bg-gray-700 flex items-center justify-center text-xl font-bold text-white">
                        <?php if(!empty($c['avatar_url'])): ?>
                            <img src="<?= e($c['avatar_url']) ?>" class="w-full h-full object-cover">
                        <?php else: ?>
                            <?= strtoupper(substr($c['name'], 0, 1)) ?>
                        <?php endif; ?>
                    </div>

                    <!-- Actions -->
                    <div class="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button onclick="editChannel(<?= htmlspecialchars(json_encode($c), ENT_QUOTES, 'UTF-8') ?>)" class="w-8 h-8 rounded-lg flex items-center justify-center text-xs text-white" style="background:rgba(0,0,0,0.6);backdrop-filter:blur(4px);"><i class="fa-solid fa-pen"></i></button>
                        <button onclick="deleteChannel('<?= e($c['id']) ?>')" class="w-8 h-8 rounded-lg flex items-center justify-center text-xs text-red-400" style="background:rgba(0,0,0,0.6);backdrop-filter:blur(4px);"><i class="fa-solid fa-trash"></i></button>
                    </div>

                    <!-- Info -->
                    <div class="pt-8 px-4 pb-4">
                        <h3 class="font-bold text-white text-base truncate"><?= e($c['name']) ?></h3>
                        <p class="text-xs text-gray-500 mt-1 line-clamp-2"><?= e($c['description'] ?: 'Açıklama yok') ?></p>
                        <a href="<?= APP_URL ?>/channel.php?id=<?= e($c['id']) ?>" target="_blank" class="mt-4 block text-center py-1.5 rounded-lg text-xs font-semibold text-cyan-400" style="background:rgba(0,245,255,0.1);">Kanalı Görüntüle</a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </main>
</div>

<!-- Modal -->
<div id="channel-modal" class="modal">
    <div class="modal-content p-6">
        <div class="flex items-center justify-between mb-4">
            <h2 id="modal-title" class="text-lg font-bold text-white">Yeni Kanal Ekle</h2>
            <button onclick="closeModal()" class="text-gray-500 hover:text-white"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <form id="channel-form" onsubmit="saveChannel(event)">
            <input type="hidden" id="channel-id" value="">
            <div class="space-y-4">
                <div>
                    <label class="block text-xs font-semibold text-gray-400 mb-1">Kanal Adı *</label>
                    <input type="text" id="channel-name" required class="input-field px-3 py-2 rounded-lg text-sm">
                </div>
                <div>
                    <div class="flex justify-between items-center mb-1">
                        <label class="block text-xs font-semibold text-gray-400">Açıklama</label>
                        <button type="button" id="ai-desc-btn" onclick="generateChannelDesc()" class="text-[10px] bg-indigo-500/20 text-indigo-400 hover:text-indigo-300 px-2 py-1 rounded hidden">
                            <i class="fa-solid fa-wand-magic-sparkles"></i> AI ile Oluştur
                        </button>
                    </div>
                    <textarea id="channel-desc" rows="3" class="input-field px-3 py-2 rounded-lg text-sm resize-none"></textarea>
                </div>
                <div>
                    <label class="block text-xs font-semibold text-gray-400 mb-1">Avatar URL veya Bilgisayardan Yükle</label>
                    <div class="flex gap-2 mb-2">
                        <input type="url" id="channel-avatar" placeholder="https://..." class="input-field px-3 py-2 rounded-lg text-sm flex-1">
                        <label class="px-3 py-2 rounded-lg text-xs font-bold bg-gray-700 hover:bg-gray-600 text-white cursor-pointer flex-shrink-0 flex items-center justify-center">
                            <i class="fa-solid fa-upload mr-1"></i> Dosya Seç
                            <input type="file" id="channel-avatar-file" class="hidden" accept="image/*" onchange="uploadImageToCld(this, 'channel-avatar')">
                        </label>
                    </div>
                    <div id="channel-avatar-status" class="text-[10px] text-cyan-400 hidden"><i class="fa-solid fa-spinner fa-spin"></i> Yükleniyor...</div>
                </div>
                <div>
                    <label class="block text-xs font-semibold text-gray-400 mb-1">Kapak Fotoğrafı URL veya Bilgisayardan Yükle</label>
                    <div class="flex gap-2 mb-2">
                        <input type="url" id="channel-cover" placeholder="https://..." class="input-field px-3 py-2 rounded-lg text-sm flex-1">
                        <label class="px-3 py-2 rounded-lg text-xs font-bold bg-gray-700 hover:bg-gray-600 text-white cursor-pointer flex-shrink-0 flex items-center justify-center">
                            <i class="fa-solid fa-upload mr-1"></i> Dosya Seç
                            <input type="file" id="channel-cover-file" class="hidden" accept="image/*" onchange="uploadImageToCld(this, 'channel-cover')">
                        </label>
                    </div>
                    <div id="channel-cover-status" class="text-[10px] text-cyan-400 hidden"><i class="fa-solid fa-spinner fa-spin"></i> Yükleniyor...</div>
                </div>
                <button type="submit" id="save-btn" class="w-full py-2.5 rounded-xl text-sm font-bold text-black mt-2" style="background:linear-gradient(135deg,#00f5ff,#bf00ff);">Kaydet</button>
            </div>
        </form>
    </div>
</div>

<script>
const API_URL = '<?= APP_URL ?>/api/channels.php';
const APP_URL_JS = '<?= APP_URL ?>';

async function generateChannelDesc() {
    const id = document.getElementById('channel-id').value;
    if (!id) return;
    
    const btn = document.getElementById('ai-desc-btn');
    const oldHtml = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Oluşturuluyor...';
    
    try {
        const res = await fetch(APP_URL_JS + '/api/ai.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ action: 'generate_channel_desc', channel_id: id })
        });
        const data = await res.json();
        
        if (data.success) {
            document.getElementById('channel-desc').value = data.data.description;
        } else {
            alert('AI Hatası: ' + (data.message || 'Bilinmeyen hata'));
        }
    } catch (e) {
        alert('Bağlantı hatası.');
    }
    
    btn.disabled = false;
    btn.innerHTML = oldHtml;
}

async function uploadImageToCld(input, targetInputId) {
    const file = input.files[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) { alert('Maksimum 5MB yüklenebilir.'); return; }
    
    const statusEl = document.getElementById(targetInputId + '-status');
    statusEl.classList.remove('hidden');
    document.getElementById('save-btn').disabled = true;
    
    try {
        const sigRes  = await fetch(APP_URL_JS + '/api/upload_sign.php?type=image&folder=neontv/channels', {
            credentials: 'same-origin'
        });
        const sigData = await sigRes.json();
        
        if (!sigRes.ok) {
            alert('İmza alınamadı: ' + (sigData.message || 'Yetkisiz'));
            statusEl.classList.add('hidden');
            document.getElementById('save-btn').disabled = false;
            return;
        }
        
        const fd = new FormData();
        fd.append('file', file);
        fd.append('timestamp', sigData.timestamp);
        fd.append('signature', sigData.signature);
        fd.append('api_key', sigData.api_key);
        fd.append('folder', 'neontv/channels');
        
        const cldUrl = 'https://api.cloudinary.com/v1_1/<?= CLOUDINARY_CLOUD_NAME ?>/image/upload';
        
        const res = await fetch(cldUrl, { method: 'POST', body: fd });
        const data = await res.json();
        
        if (data.secure_url) {
            document.getElementById(targetInputId).value = data.secure_url;
        } else {
            alert('Yükleme hatası: ' + (data.error?.message || 'Bilinmeyen hata'));
        }
    } catch(e) {
        alert('Bağlantı hatası: ' + e.message);
    }
    statusEl.classList.add('hidden');
    document.getElementById('save-btn').disabled = false;
    input.value = ''; // reset
}

function openModal() {
    document.getElementById('channel-id').value = '';
    document.getElementById('channel-form').reset();
    document.getElementById('modal-title').textContent = 'Yeni Kanal Ekle';
    document.getElementById('ai-desc-btn').classList.add('hidden');
    document.getElementById('channel-modal').classList.add('active');
}
function closeModal() {
    document.getElementById('channel-modal').classList.remove('active');
}
function editChannel(c) {
    document.getElementById('channel-id').value = c.id;
    document.getElementById('channel-name').value = c.name;
    document.getElementById('channel-desc').value = c.description || '';
    document.getElementById('channel-avatar').value = c.avatar_url || '';
    document.getElementById('channel-cover').value = c.cover_url || '';
    document.getElementById('modal-title').textContent = 'Kanalı Düzenle';
    document.getElementById('ai-desc-btn').classList.remove('hidden');
    document.getElementById('channel-modal').classList.add('active');
}

async function saveChannel(e) {
    e.preventDefault();
    const id = document.getElementById('channel-id').value;
    const payload = {
        name: document.getElementById('channel-name').value,
        description: document.getElementById('channel-desc').value,
        avatar_url: document.getElementById('channel-avatar').value,
        cover_url: document.getElementById('channel-cover').value
    };
    
    const btn = document.getElementById('save-btn');
    btn.disabled = true; btn.textContent = 'Kaydediliyor...';
    
    try {
        const res = await fetch(API_URL + (id ? '?id=' + id : ''), {
            method: id ? 'PATCH' : 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(payload)
        });
        const data = await res.json();
        if(data.success) {
            window.location.reload();
        } else {
            alert(data.message || 'Hata oluştu');
        }
    } catch(err) { alert('Bağlantı hatası'); }
    btn.disabled = false; btn.textContent = 'Kaydet';
}

async function deleteChannel(id) {
    if(!confirm('Bu kanalı silmek istediğinize emin misiniz? (Bağlı videoların kanalı boş kalacaktır)')) return;
    try {
        const res = await fetch(API_URL + '?id=' + id, { method: 'DELETE' });
        const data = await res.json();
        if(data.success) window.location.reload();
        else alert(data.message);
    } catch(err) { alert('Hata'); }
}
</script>
</body>
</html>
