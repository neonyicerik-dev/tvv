<?php
// ============================================================
// NeonTV - Admin Video Yükleme / Düzenleme (Responsive)
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/cloudinary.php';
requireAdmin();

$db   = new Supabase();
$cld  = new Cloudinary();

// Düzenleme modu
$editId   = trim($_GET['edit'] ?? '');
$editData = null;
if ($editId) {
    $editData = $db->first('videos', 'id=eq.' . $editId, true);
}

$pageTitle = $editData ? 'Video Duzenle' : 'Video Yukle';

// Kanalları çek
$channelsRes = $db->select('channels', 'order=name.asc', true);
$channelsList = $channelsRes['data'] ?? [];

// Ayarları yükle
require_once __DIR__ . '/../includes/store.php';
$siteSettings = loadSettingsCompat();
$defaultSystemPrompt = $siteSettings['ai_title_system_prompt'] ?? 'Sen bir video platformu için içerik yöneticisisin. Türkçe yaz. SEO uyumlu, dikkat çekici başlıklar ve açıklamalar oluştur.';

// Cloudinary upload URL'leri
$uploadUrl  = $cld->getUploadUrl('video');
$imageUpUrl = $cld->getUploadUrl('image');
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle) ?> | NeonTV Admin</title>
    <meta name="robots" content="noindex,nofollow">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body { font-family: 'Outfit', sans-serif; background: #070711; color: #fff; }
        .input-field {
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(255,255,255,0.1);
            transition: all 0.2s;
            width: 100%;
        }
        .input-field:focus {
            border-color: rgba(0,245,255,0.5);
            box-shadow: 0 0 0 3px rgba(0,245,255,0.08);
            outline: none;
        }
        .progress-bar { transition: width 0.3s ease; }
        .drop-zone { transition: all 0.3s; }
        .drop-zone.dragover {
            border-color: rgba(0,245,255,0.6) !important;
            background: rgba(0,245,255,0.05) !important;
        }
        #chunk-log { max-height: 120px; overflow-y: auto; font-size: 11px; }
        .neon-btn {
            background: linear-gradient(135deg, #00f5ff, #bf00ff);
            color: #000;
            font-weight: 700;
            transition: all 0.3s;
        }
        .neon-btn:hover { transform: scale(1.02); box-shadow: 0 0 25px rgba(0,245,255,0.3); }
        .neon-btn:disabled { opacity: 0.5; transform: none; cursor: not-allowed; }
    </style>
</head>
<body class="min-h-screen lg:flex">

<?php include __DIR__ . '/sidebar.php'; ?>

<div class="flex-1 flex flex-col min-w-0 overflow-x-hidden">

    <!-- ===== TOP BAR ===== -->
    <header class="flex items-center gap-3 px-4 sm:px-6 py-4 sticky top-0 z-20"
            style="background:rgba(7,7,17,0.9);backdrop-filter:blur(20px);border-bottom:1px solid rgba(255,255,255,0.06);">
        <!-- Hamburger -->
        <button onclick="openSidebar()" class="lg:hidden p-2 rounded-xl text-gray-400 hover:text-white transition-colors"
                style="background:rgba(255,255,255,0.06);">
            <i class="fa-solid fa-bars text-sm"></i>
        </button>
        <a href="<?= APP_URL ?>/admin/videos.php" class="text-gray-500 hover:text-white transition-colors">
            <i class="fa-solid fa-arrow-left"></i>
        </a>
        <div class="min-w-0">
            <h1 class="text-lg sm:text-xl font-bold text-white truncate"><?= e($pageTitle) ?></h1>
            <p class="text-xs text-gray-500 hidden sm:block">Cloudinary CDN + Supabase</p>
        </div>
    </header>

    <!-- ===== ANA İÇERİK ===== -->
    <main class="flex-1 p-4 sm:p-6 overflow-auto">
        <div class="max-w-4xl mx-auto">
            <form id="upload-form" onsubmit="return false;" autocomplete="off">

                <!-- Grid: mobilde tek sütun, büyük ekranda iki sütun -->
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">

                    <!-- ===== SOL SÜTUN ===== -->
                    <div class="space-y-4 sm:space-y-5">

                        <!-- Başlık -->
                        <div class="rounded-2xl p-4 sm:p-5" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
                            <label class="block text-xs font-semibold text-gray-400 mb-2 uppercase tracking-wider">
                                <i class="fa-solid fa-heading mr-1"></i>Video Basligi *
                            </label>
                            <input type="text" id="video-title" name="title"
                                   value="<?= e($editData['title'] ?? '') ?>"
                                   placeholder="Dikkat cekici bir baslik girin"
                                   maxlength="200" required
                                   class="input-field px-4 py-3 rounded-xl text-sm text-white placeholder-gray-600">
                        </div>

                        <!-- Açıklama -->
                        <div class="rounded-2xl p-4 sm:p-5" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
                            <label class="block text-xs font-semibold text-gray-400 mb-2 uppercase tracking-wider">
                                <i class="fa-solid fa-align-left mr-1"></i>Aciklama
                            </label>
                            <textarea id="video-description" name="description"
                                      placeholder="Video aciklamasini girin..."
                                      rows="5" maxlength="5000"
                                      class="input-field px-4 py-3 rounded-xl text-sm text-white placeholder-gray-600 resize-none"><?= e($editData['description'] ?? '') ?></textarea>
                        </div>

                        <!-- Etiketler -->
                        <div class="rounded-2xl p-4 sm:p-5" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
                            <label class="block text-xs font-semibold text-gray-400 mb-2 uppercase tracking-wider">
                                <i class="fa-solid fa-tags mr-1"></i>Etiketler
                            </label>
                            <input type="text" id="video-tags" name="tags"
                                   value="<?= e(implode(', ', $editData['tags'] ?? [])) ?>"
                                   placeholder="Örn: Müzik, Eğlence, Vlog (Virgülle ayırın)"
                                   class="input-field px-4 py-3 rounded-xl text-sm text-white placeholder-gray-600">
                        </div>

                        <!-- Kanal Seçimi -->
                        <div class="rounded-2xl p-4 sm:p-5" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
                            <label class="block text-xs font-semibold text-gray-400 mb-2 uppercase tracking-wider">
                                <i class="fa-solid fa-user-circle mr-1"></i>Kanal Seçimi
                            </label>
                            <select id="video-channel" name="channel_id" class="input-field px-4 py-3 rounded-xl text-sm text-white">
                                <option value="">(Bağımsız Video)</option>
                                <?php foreach($channelsList as $c): ?>
                                    <option value="<?= e($c['id']) ?>" <?= ($editData && $editData['channel_id'] === $c['id']) ? 'selected' : '' ?>>
                                        <?= e($c['name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <!-- AI İçerik Oluşturucu -->
                        <div class="rounded-2xl p-4 sm:p-5" style="background:#13131f;border:1px solid rgba(191,0,255,0.2);">
                            <div class="flex items-center gap-2 mb-4">
                                <div class="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0" style="background:rgba(191,0,255,0.15);">
                                    <i class="fa-solid fa-robot text-xs" style="color:#bf00ff;"></i>
                                </div>
                                <h3 class="text-sm font-bold text-white">AI ile Icerik Olustur</h3>
                                <span class="text-[10px] px-2 py-0.5 rounded-full font-medium flex-shrink-0" style="background:rgba(191,0,255,0.15);color:#bf00ff;">Gemini</span>
                            </div>
                            <div class="space-y-3">
                                <div>
                                    <label class="block text-xs text-gray-500 mb-1.5">Konu / Video hakkinda kisa bilgi (Istege Bagli)</label>
                                    <input type="text" id="ai-topic"
                                           placeholder="Bos birakirsaniz video dosyasi analiz edilir"
                                           class="input-field px-3 py-2.5 rounded-lg text-sm text-white placeholder-gray-600">
                                </div>
                                <div>
                                    <label class="block text-xs text-gray-500 mb-1.5">
                                        System Prompt
                                        <span class="text-gray-700">(Ayarlardan otomatik yüklendi)</span>
                                    </label>
                                    <textarea id="ai-system-prompt" rows="3"
                                              placeholder="Orn: Sen egitim platformu icin icerik yazarsin. Turkce yaz."
                                              class="input-field px-3 py-2.5 rounded-lg text-sm text-white placeholder-gray-600 resize-none"><?= htmlspecialchars($defaultSystemPrompt) ?></textarea>
                                </div>
                                <button type="button" id="ai-generate-btn" onclick="generateWithAI()"
                                        class="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-semibold text-white transition-all duration-200"
                                        style="background:linear-gradient(135deg,rgba(191,0,255,0.3),rgba(0,245,255,0.15));border:1px solid rgba(191,0,255,0.4);">
                                    <i class="fa-solid fa-wand-magic-sparkles text-xs"></i>
                                    Baslik + Aciklama Olustur
                                </button>
                                <!-- AI Sonuç -->
                                <div id="ai-result" class="hidden">
                                    <div class="rounded-xl p-3 text-xs text-gray-400" style="background:rgba(191,0,255,0.05);border:1px solid rgba(191,0,255,0.15);">
                                        <p id="ai-result-text" style="white-space:pre-wrap;"></p>
                                    </div>
                                    <div class="flex gap-2 mt-2">
                                        <button type="button" onclick="applyAiResult()"
                                                class="flex-1 py-2 rounded-lg text-xs font-semibold text-black"
                                                style="background:linear-gradient(135deg,#00f5ff,#bf00ff);">
                                            <i class="fa-solid fa-check mr-1"></i>Formlara Uygula
                                        </button>
                                        <button type="button" onclick="document.getElementById('ai-result').classList.add('hidden')"
                                                class="px-3 py-2 rounded-lg text-xs text-gray-500 hover:text-white transition-colors"
                                                style="background:rgba(255,255,255,0.06);">
                                            <i class="fa-solid fa-xmark"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Yayın Durumu -->
                        <div class="rounded-2xl p-4 sm:p-5" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
                            <label class="block text-xs font-semibold text-gray-400 mb-3 uppercase tracking-wider">
                                <i class="fa-solid fa-circle-dot mr-1"></i>Yayin Durumu
                            </label>
                            <div class="flex flex-col gap-3">
                                <div class="flex gap-3">
                                    <label class="flex-1 flex items-center gap-2 sm:gap-3 p-3 rounded-xl cursor-pointer"
                                           style="background:rgba(0,245,255,0.05);border:1px solid rgba(0,245,255,0.2);">
                                        <input type="radio" name="status" value="published" onchange="toggleScheduledDate()"
                                               <?= (!$editData || $editData['status'] === 'published') ? 'checked' : '' ?>
                                               class="accent-cyan-400 flex-shrink-0">
                                        <div>
                                            <p class="text-sm font-medium text-white">Yayinla</p>
                                            <p class="text-xs text-gray-600">Hemen gorunur</p>
                                        </div>
                                    </label>
                                    <label class="flex-1 flex items-center gap-2 sm:gap-3 p-3 rounded-xl cursor-pointer"
                                           style="background:rgba(251,191,36,0.05);border:1px solid rgba(251,191,36,0.2);">
                                        <input type="radio" name="status" value="scheduled" onchange="toggleScheduledDate()"
                                               <?= ($editData && $editData['status'] === 'scheduled') ? 'checked' : '' ?>
                                               class="accent-yellow-400 flex-shrink-0">
                                        <div>
                                            <p class="text-sm font-medium text-white">Zamanla</p>
                                            <p class="text-xs text-gray-600">İleri tarihte</p>
                                        </div>
                                    </label>
                                    <label class="flex-1 flex items-center gap-2 sm:gap-3 p-3 rounded-xl cursor-pointer"
                                           style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.1);">
                                        <input type="radio" name="status" value="draft" onchange="toggleScheduledDate()"
                                               <?= ($editData && $editData['status'] === 'draft') ? 'checked' : '' ?>
                                               class="accent-gray-400 flex-shrink-0">
                                        <div>
                                            <p class="text-sm font-medium text-gray-300">Taslak</p>
                                            <p class="text-xs text-gray-600">Gizli kalir</p>
                                        </div>
                                    </label>
                                </div>
                                <div id="scheduled-date-wrap" class="<?= ($editData && $editData['status'] === 'scheduled') ? 'block' : 'hidden' ?> mt-2">
                                    <label class="block text-xs font-semibold text-gray-400 mb-2 uppercase tracking-wider">
                                        <i class="fa-solid fa-calendar-days mr-1"></i>Yayın Tarihi
                                    </label>
                                    <input type="datetime-local" id="scheduled-at"
                                           value="<?= ($editData && !empty($editData['scheduled_at'])) ? date('Y-m-d\TH:i', strtotime($editData['scheduled_at'])) : '' ?>"
                                           class="w-full px-4 py-3 rounded-xl text-sm text-white placeholder-gray-600 outline-none transition-all"
                                           style="background:rgba(255,255,255,0.05);border:1px solid rgba(251,191,36,0.3);color-scheme:dark;">
                                </div>
                                <div class="mt-4">
                                    <label class="block text-xs font-semibold text-gray-400 mb-2 uppercase tracking-wider">
                                        <i class="fa-solid fa-hourglass-half mr-1"></i>Kaldırılma Tarihi <span class="normal-case text-gray-600">(geçici CDN videosu için, isteğe bağlı)</span>
                                    </label>
                                    <input type="datetime-local" id="expires-at" data-had="<?= !empty($editData['expires_at']) ? '1' : '0' ?>"
                                           value="<?= ($editData && !empty($editData['expires_at'])) ? date('Y-m-d\TH:i', strtotime($editData['expires_at'])) : '' ?>"
                                           class="w-full px-4 py-3 rounded-xl text-sm text-white outline-none"
                                           style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,107,107,0.3);color-scheme:dark;">
                                    <p class="text-[11px] text-gray-600 mt-1">Doluysa kartlarda ve video sayfasında “yakında kalkacak” uyarısı gösterilir (14 gün kala).</p>
                                </div>
                                <div class="mt-4">
                                    <label class="block text-xs font-semibold text-gray-400 mb-2 uppercase tracking-wider"><i class="fa-solid fa-forward-step mr-1"></i>Giriş bitişi <span class="normal-case text-gray-600">(saniye, "Girişi atla" butonu için, isteğe bağlı)</span></label>
                                    <input type="number" min="0" max="3600" id="intro-end" data-had="<?= !empty($editData['intro_end']) ? '1' : '0' ?>" value="<?= (int)($editData['intro_end'] ?? 0) ?: '' ?>" placeholder="örn. 45"
                                           class="w-full px-4 py-3 rounded-xl text-sm text-white outline-none" style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.12);">
                                </div>


                            </div>
                        </div>
                    </div>

                    <!-- ===== SAĞ SÜTUN ===== -->
                    <div class="space-y-4 sm:space-y-5">

                        <!-- Thumbnail -->
                        <div class="rounded-2xl p-4 sm:p-5" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
                            <div class="flex flex-wrap items-center justify-between mb-3 gap-2">
                                <label class="block text-xs font-semibold text-gray-400 uppercase tracking-wider">
                                    <i class="fa-regular fa-image mr-1"></i>Thumbnail (Kapak Gorseli)
                                </label>
                                <div class="flex gap-2">
                                    <button type="button" onclick="openAiThumbModal()" class="text-[10px] px-2 py-1 rounded-lg font-bold text-black" style="background:linear-gradient(135deg,#00f5ff,#bf00ff);">
                                        <i class="fa-solid fa-wand-magic-sparkles mr-1"></i>AI ile Üret
                                    </button>
                                    <button type="button" id="auto-thumb-btn" onclick="captureBestMoment()" class="text-[10px] px-2 py-1 rounded-lg font-bold text-black" style="background:linear-gradient(135deg,#00f5ff,#bf00ff);">
                                        <i class="fa-solid fa-camera mr-1"></i>En Güzel Anı Yakala
                                    </button>
                                </div>
                            </div>
                            <div id="thumb-preview" class="relative rounded-xl overflow-hidden mb-3"
                                 style="aspect-ratio:16/9;background:#0d0d1a;<?= $editData && $editData['thumbnail_url'] ? '' : 'display:none;' ?>">
                                <img id="thumb-preview-img" src="<?= e($editData['thumbnail_url'] ?? '') ?>"
                                     class="w-full h-full object-cover">
                                <button type="button" onclick="clearThumbnail()"
                                        class="absolute top-2 right-2 w-7 h-7 rounded-full flex items-center justify-center text-xs"
                                        style="background:rgba(0,0,0,0.7);color:#fff;">
                                    <i class="fa-solid fa-xmark"></i>
                                </button>
                            </div>
                            <div id="thumb-drop-zone"
                                 class="drop-zone rounded-xl border-2 border-dashed flex flex-col items-center justify-center gap-2 cursor-pointer p-5 sm:p-6 text-center"
                                 style="border-color:rgba(255,255,255,0.15);<?= $editData && $editData['thumbnail_url'] ? 'display:none;' : '' ?>"
                                 onclick="document.getElementById('thumb-file').click()"
                                 ondragover="event.preventDefault();this.classList.add('dragover')"
                                 ondragleave="this.classList.remove('dragover')"
                                 ondrop="handleThumbDrop(event)">
                                <i class="fa-solid fa-image text-2xl text-gray-700"></i>
                                <p class="text-sm text-gray-500">Thumbnail surukleyin veya tiklayin</p>
                                <p class="text-xs text-gray-700">JPG, PNG, WebP · Maks 5MB</p>
                            </div>
                            <input type="file" id="thumb-file" accept="image/*" class="hidden" onchange="handleThumbFile(this)">
                            <input type="hidden" id="thumb-url" name="thumbnail_url" value="<?= e($editData['thumbnail_url'] ?? '') ?>">
                            <div id="thumb-upload-status" class="hidden mt-3">
                                <div class="flex items-center gap-2 text-xs text-gray-400">
                                    <i class="fa-solid fa-spinner fa-spin" style="color:#00f5ff;"></i>
                                    <span id="thumb-upload-text">Yukleniyor...</span>
                                </div>
                                <div class="mt-1.5 h-1 rounded-full overflow-hidden" style="background:rgba(255,255,255,0.1);">
                                    <div id="thumb-progress-bar" class="progress-bar h-full rounded-full"
                                         style="background:linear-gradient(90deg,#00f5ff,#bf00ff);width:0%;"></div>
                                </div>
                            </div>
                        </div>

                        <!-- MP4 URL ile Yükleme -->
                        <div class="rounded-2xl p-4 sm:p-5" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
                            <label class="block text-xs font-semibold text-gray-400 mb-2 uppercase tracking-wider">
                                <i class="fa-solid fa-link mr-1"></i>MP4 URL ile Yükle (Alternatif)
                            </label>
                            <div class="flex gap-2">
                                <input type="url" id="video-url-input"
                                       placeholder="https://ornek.com/video.mp4"
                                       class="input-field px-3 py-2.5 rounded-lg text-sm text-white placeholder-gray-600 flex-1">
                                <button type="button" onclick="useVideoUrl()"
                                        class="px-4 py-2.5 rounded-lg text-xs font-bold text-black flex-shrink-0"
                                        style="background:linear-gradient(135deg,#00f5ff,#bf00ff);">
                                    <i class="fa-solid fa-check"></i> Kullan
                                </button>
                            </div>
                            <p class="text-xs text-gray-700 mt-1.5">Cloudinary yerine direkt bir URL kullanmak istiyorsanız</p>
                        </div>

                        <!-- Video Yükleme -->
                        <div class="rounded-2xl p-4 sm:p-5" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
                            <label class="block text-xs font-semibold text-gray-400 mb-3 uppercase tracking-wider">
                                <i class="fa-solid fa-film mr-1"></i>Video Dosyasi
                                <?php if (!$editData): ?><span class="text-red-400">*</span><?php endif; ?>
                            </label>

                            <?php if ($editData && $editData['video_url']): ?>
                            <div class="flex items-center gap-2 p-3 rounded-xl mb-3 text-xs"
                                 style="background:rgba(0,245,255,0.05);border:1px solid rgba(0,245,255,0.15);">
                                <i class="fa-solid fa-circle-check" style="color:#00f5ff;"></i>
                                <span class="text-gray-400 flex-1 truncate">Mevcut video yuklu</span>
                                <button type="button" onclick="document.getElementById('change-video-area').classList.toggle('hidden')"
                                        class="text-gray-500 hover:text-white">Degistir</button>
                            </div>
                            <div id="change-video-area" class="hidden">
                            <?php endif; ?>

                            <div id="video-drop-zone"
                                 class="drop-zone rounded-xl border-2 border-dashed flex flex-col items-center justify-center gap-3 cursor-pointer p-6 sm:p-8 text-center"
                                 style="border-color:rgba(255,255,255,0.15);min-height:140px;"
                                 onclick="document.getElementById('video-file').click()"
                                 ondragover="event.preventDefault();this.classList.add('dragover')"
                                 ondragleave="this.classList.remove('dragover')"
                                 ondrop="handleVideoDrop(event)">
                                <div class="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl flex items-center justify-center"
                                     style="background:rgba(0,245,255,0.05);">
                                    <i class="fa-solid fa-cloud-arrow-up text-xl sm:text-2xl" style="color:rgba(0,245,255,0.6);"></i>
                                </div>
                                <div>
                                    <p class="text-sm font-medium text-gray-300">Video dosyasini surukleyin</p>
                                    <p class="text-xs text-gray-600 mt-1">veya secmek icin tiklayin</p>
                                </div>
                                <p class="text-xs text-gray-700">MP4, WebM, MOV · Maks 500MB · 1MB parcalar halinde yuklenir</p>
                            </div>
                            <input type="file" id="video-file" accept="video/*" class="hidden" onchange="handleVideoFile(this)">
                            <input type="hidden" id="video-url" name="video_url" value="<?= e($editData['video_url'] ?? '') ?>">
                            <input type="hidden" id="cloudinary-public-id" name="cloudinary_public_id" value="<?= e($editData['cloudinary_public_id'] ?? '') ?>">
                            <input type="hidden" id="video-duration" name="duration" value="<?= e($editData['duration'] ?? '0') ?>">

                            <?php if ($editData && $editData['video_url']): ?>
                            </div>
                            <?php endif; ?>

                            <!-- Seçilen video bilgisi -->
                            <div id="video-selected-info" class="hidden mt-3 p-3 rounded-xl"
                                 style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.08);">
                                <div class="flex items-center justify-between gap-2">
                                    <div class="flex items-center gap-2 min-w-0">
                                        <i class="fa-solid fa-file-video flex-shrink-0" style="color:#00f5ff;"></i>
                                        <span id="video-file-name" class="text-sm text-gray-300 truncate"></span>
                                    </div>
                                    <span id="video-file-size" class="text-xs text-gray-600 flex-shrink-0"></span>
                                </div>
                            </div>

                            <!-- Yükleme İlerlemesi -->
                            <div id="upload-progress-area" class="hidden mt-4 space-y-3">
                                <div>
                                    <div class="flex justify-between text-xs text-gray-500 mb-1.5">
                                        <span id="upload-status-text">Hazirlaniyor...</span>
                                        <span id="upload-percent">0%</span>
                                    </div>
                                    <div class="h-2 rounded-full overflow-hidden" style="background:rgba(255,255,255,0.08);">
                                        <div id="upload-progress-bar" class="progress-bar h-full rounded-full"
                                             style="background:linear-gradient(90deg,#00f5ff,#bf00ff);width:0%;"></div>
                                    </div>
                                </div>
                                <div id="chunk-log" class="rounded-lg p-2 font-mono text-gray-600"
                                     style="background:rgba(0,0,0,0.3);"></div>
                            </div>
                        </div>

                        <!-- Otomatik Altyazı -->
                        <div class="rounded-2xl p-4 sm:p-5" style="background:#13131f;border:1px solid rgba(0,245,255,0.1);">
                            <label class="flex items-center gap-3 cursor-pointer">
                                <div class="relative">
                                    <input type="checkbox" id="auto-subtitle-check" class="sr-only">
                                    <div id="toggle-track" class="w-11 h-6 rounded-full transition-colors duration-200" style="background:rgba(255,255,255,0.1);"></div>
                                    <div id="toggle-thumb" class="absolute top-1 left-1 w-4 h-4 rounded-full bg-gray-400 transition-transform duration-200"></div>
                                </div>
                                <div>
                                    <p class="text-sm font-semibold text-white">Otomatik Altyazı Oluştur</p>
                                    <p class="text-xs text-gray-500">Video kaydedildikten sonra AI altyazı oluşturur</p>
                                </div>
                                <span class="ml-auto text-[10px] px-2 py-0.5 rounded-full font-medium" style="background:rgba(0,245,255,0.1);color:#00f5ff;">Gemini AI</span>
                            </label>
                        </div>

                        <!-- #12 Bölüm Yönetimi (sadece düzenleme modunda) -->
                        <?php if ($editData): ?>
                        <div class="rounded-2xl p-4 sm:p-5" style="background:#13131f;border:1px solid rgba(191,0,255,0.2);">
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center gap-2">
                                    <div class="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0" style="background:rgba(191,0,255,0.15);">
                                        <i class="fa-solid fa-list-ul text-xs" style="color:#bf00ff;"></i>
                                    </div>
                                    <h3 class="text-sm font-bold text-white">Bölüm Yönetimi</h3>
                                </div>
                                <!-- #20 AI ile Bölüm Oluştur -->
                                <button type="button" id="ai-chapters-btn" onclick="generateChaptersWithAI()"
                                        class="text-[10px] px-2 py-1 rounded-lg font-bold text-white flex items-center gap-1"
                                        style="background:linear-gradient(135deg,rgba(191,0,255,0.4),rgba(0,245,255,0.2));border:1px solid rgba(191,0,255,0.3);">
                                    <i class="fa-solid fa-wand-magic-sparkles"></i> AI ile Oluştur
                                </button>
                            </div>

                            <!-- Bölüm listesi -->
                            <div id="chapters-list" class="space-y-2 mb-3 max-h-48 overflow-y-auto"></div>

                            <!-- Yeni Bölüm Formu -->
                            <div class="flex gap-2 mt-2">
                                <input type="text" id="chapter-title-input" placeholder="Bölüm başlığı"
                                       class="input-field flex-1 px-3 py-2 rounded-lg text-xs text-white placeholder-gray-600">
                                <input type="number" id="chapter-time-input" placeholder="Sn" min="0"
                                       class="input-field w-20 px-3 py-2 rounded-lg text-xs text-white placeholder-gray-600">
                                <button type="button" onclick="addChapter()"
                                        class="px-3 py-2 rounded-lg text-xs font-bold text-black flex-shrink-0"
                                        style="background:linear-gradient(135deg,#00f5ff,#bf00ff);">
                                    <i class="fa-solid fa-plus"></i>
                                </button>
                            </div>
                            <p class="text-xs text-gray-700 mt-1.5">Saniye cinsinden girin (ör: 120 = 2:00)</p>
                        </div>
                        <?php endif; ?>

                        <!-- Kaydet -->
                        <button type="button" id="save-btn" onclick="saveVideo()"
                                class="neon-btn w-full py-3 sm:py-4 rounded-2xl text-sm flex items-center justify-center gap-2">
                            <i class="fa-solid fa-<?= $editData ? 'floppy-disk' : 'cloud-arrow-up' ?>"></i>
                            <?= $editData ? 'Degisiklikleri Kaydet' : 'Videoyu Yukle ve Kaydet' ?>
                        </button>

                        <div id="save-status" class="hidden px-4 py-3 rounded-xl text-sm border"></div>
                    </div>
                </div>
            </form>
        </div>
    </main>
</div>

<!-- ===== AI THUMBNAIL MODAL ===== -->
<div id="ai-thumb-modal" class="fixed inset-0 z-50 hidden flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
    <div class="bg-[#13131f] border border-white/10 rounded-2xl p-6 w-full max-w-3xl shadow-2xl animate-fade-in flex flex-col max-h-[90vh]">
        <h3 class="text-lg font-bold text-white mb-4"><i class="fa-solid fa-wand-magic-sparkles text-cyan-400 mr-2"></i>AI Thumbnail Üretici</h3>
        
        <div class="mb-4">
            <label class="block text-xs text-gray-400 mb-2">Görsel Açıklaması (Prompt)</label>
            <div class="flex gap-2">
                <input type="text" id="ai-thumb-prompt" placeholder="Örn: Siberpunk neon ışıklı bir şehirde uçan araba..." 
                       class="flex-1 input-field px-4 py-2.5 rounded-xl text-sm text-white">
                <button type="button" onclick="generateAiThumbnails()" id="ai-thumb-generate-btn"
                        class="px-5 py-2.5 rounded-xl font-bold text-black whitespace-nowrap"
                        style="background:linear-gradient(135deg,#00f5ff,#bf00ff);">
                    Üret (3 Seçenek)
                </button>
            </div>
        </div>

        <!-- Sonuçlar -->
        <div id="ai-thumb-results" class="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4 overflow-y-auto min-h-[150px]">
            <!-- Görseller buraya gelecek -->
        </div>

        <div class="mt-auto flex justify-end gap-2 pt-4 border-t border-white/10">
            <button type="button" onclick="closeAiThumbModal()" 
                    class="px-5 py-2 rounded-xl text-sm text-white bg-white/5 border border-white/10 hover:bg-white/10">
                Kapat
            </button>
        </div>
    </div>
</div>

<script>
const EDIT_ID        = '<?= e($editId) ?>';
const CLOUDINARY_URL = '<?= e($uploadUrl) ?>';
const CLD_IMAGE_URL  = '<?= e($imageUpUrl) ?>';
const APP_URL_JS     = '<?= APP_URL ?>';
let aiGeneratedData  = null;
let selectedVideoFile = null;

/* ---- Toggle Switch ---- */
const autoSubCheck = document.getElementById('auto-subtitle-check');
const toggleTrack  = document.getElementById('toggle-track');
const toggleThumb  = document.getElementById('toggle-thumb');

if (autoSubCheck) {
    autoSubCheck.addEventListener('change', function() {
        if (this.checked) {
            toggleTrack.style.background = 'linear-gradient(135deg,#00f5ff,#bf00ff)';
            toggleThumb.style.transform = 'translateX(20px)';
            toggleThumb.style.background = '#fff';
        } else {
            toggleTrack.style.background = 'rgba(255,255,255,0.1)';
            toggleThumb.style.transform = 'translateX(0)';
            toggleThumb.style.background = '#9ca3af';
        }
    });
    // Toggle'a tıklaınca checkbox değiştir
    toggleTrack.parentElement.parentElement.addEventListener('click', function(e) {
        if (e.target.tagName !== 'INPUT') {
            autoSubCheck.checked = !autoSubCheck.checked;
            autoSubCheck.dispatchEvent(new Event('change'));
        }
    });
}

/* ---- MP4 URL Kullan ---- */
function useVideoUrl() {
    const url = document.getElementById('video-url-input').value.trim();
    if (!url) { alert('Lütfen geçerli bir URL girin.'); return; }
    document.getElementById('video-url').value = url;
    document.getElementById('video-file-name').textContent = url.split('/').pop() || 'Harici Video';
    document.getElementById('video-file-size').textContent = 'URL';
    document.getElementById('video-selected-info').classList.remove('hidden');
    document.getElementById('video-drop-zone').style.opacity = '0.5';
    
    // Extract duration
    const tempVideo = document.createElement('video');
    tempVideo.src = url;
    tempVideo.addEventListener('loadedmetadata', () => {
        document.getElementById('video-duration').value = Math.round(tempVideo.duration);
    });
    
    showSaveStatus('MP4 URL ayarlandı. Kaydedebilirsiniz.', 'success');
}

/* ---- Video Dosyası Seçimi ---- */
function handleVideoDrop(e) {
    e.preventDefault();
    e.currentTarget.classList.remove('dragover');
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
        processVideoFile(e.dataTransfer.files[0]);
    }
}
function handleVideoFile(input) {
    if (input.files && input.files[0]) {
        processVideoFile(input.files[0]);
    }
}
function processVideoFile(file) {
    if (file.size > 500 * 1024 * 1024) {
        alert('HATA: Video dosyası en fazla 500MB olabilir.');
        return;
    }
    selectedVideoFile = file;
    document.getElementById('video-file-name').textContent = file.name;
    document.getElementById('video-file-size').textContent = (file.size / (1024 * 1024)).toFixed(2) + ' MB';
    document.getElementById('video-selected-info').classList.remove('hidden');
    document.getElementById('video-drop-zone').style.opacity = '0.5';
    document.getElementById('video-url').value = '';
    
    // Extract duration
    const tempVideo = document.createElement('video');
    tempVideo.src = URL.createObjectURL(file);
    tempVideo.addEventListener('loadedmetadata', () => {
        document.getElementById('video-duration').value = Math.round(tempVideo.duration);
    });
}

/* ---- AI - Video dosyasını analiz ederek başlık oluştur ---- */
async function generateWithAI() {
    const topic     = document.getElementById('ai-topic').value.trim();
    const btn       = document.getElementById('ai-generate-btn');
    const videoFile = selectedVideoFile;
    const videoUrl  = document.getElementById('video-url').value;

    if (!topic && !videoFile && !videoUrl) { 
        alert('Lütfen bir konu girin veya video dosyası seçin.'); 
        return; 
    }
    
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin text-xs"></i> Olusturuluyor...';
    
    try {
        let imageBase64 = '';

        if (videoFile) {
            // Videonun ilk karesini veya ortasını yakala (Gemini'ye resim olarak gönder)
            imageBase64 = await new Promise((resolve) => {
                const vid = document.createElement('video');
                vid.src = URL.createObjectURL(videoFile);
                vid.crossOrigin = 'anonymous';
                vid.addEventListener('loadeddata', () => { vid.currentTime = Math.max(0, vid.duration * 0.5); });
                vid.addEventListener('seeked', () => {
                    const canvas = document.createElement('canvas');
                    canvas.width = vid.videoWidth || 1280;
                    canvas.height = vid.videoHeight || 720;
                    const ctx = canvas.getContext('2d');
                    ctx.drawImage(vid, 0, 0, canvas.width, canvas.height);
                    resolve(canvas.toDataURL('image/jpeg', 0.8).split(',')[1]);
                });
                vid.addEventListener('error', () => resolve(''));
            });
        }

        let fileName = '';
        if (videoFile) fileName = videoFile.name;
        else if (videoUrl) fileName = videoUrl.split('/').pop();

        const res = await fetch(APP_URL_JS + '/api/ai.php', {
            method: 'POST', 
            headers: {'Content-Type':'application/json'},
            body: JSON.stringify({ 
                topic, 
                system_prompt: '', // Backend otomatik settings.json'dan alacak
                image_base64: imageBase64,
                file_name: fileName,
                action: 'generate_title_desc' 
            })
        });
        
        let data;
        try {
            data = await res.json();
        } catch (err) {
            throw new Error('Sunucudan gecersiz yanit alindi.');
        }

        if (data.success) {
            aiGeneratedData = data.data;
            document.getElementById('ai-result-text').textContent = `Baslik: ${data.data.title}\n\nAciklama: ${data.data.description}`;
            document.getElementById('ai-result').classList.remove('hidden');
        } else {
            alert('AI hatasi: ' + (data.message || 'Bilinmeyen hata'));
        }
    } catch(e) { alert('Baglanti hatasi: ' + e.message); }
    btn.disabled = false;
    btn.innerHTML = '<i class="fa-solid fa-wand-magic-sparkles text-xs"></i> Baslik + Aciklama Olustur';
}

function applyAiResult() {
    if (!aiGeneratedData) return;
    document.getElementById('video-title').value       = aiGeneratedData.title;
    document.getElementById('video-description').value = aiGeneratedData.description;
    document.getElementById('ai-result').classList.add('hidden');
}

/* ---- Otomatik Thumbnail Yakalama ---- */
async function captureBestMoment() {
    if (!selectedVideoFile && !document.getElementById('video-url').value) {
        alert('Lütfen önce bir Video Dosyası seçin.');
        return;
    }
    
    const btn = document.getElementById('auto-thumb-btn');
    const oldHtml = btn.innerHTML;
    btn.disabled = true; btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Yakalanıyor...';

    let videoUrl = document.getElementById('video-url').value;
    if (videoUrl && !selectedVideoFile) {
        let thumbUrl = videoUrl.replace('/upload/', '/upload/so_auto/').replace(/\.[^/.]+$/, ".jpg");
        document.getElementById('thumb-url').value = thumbUrl;
        document.getElementById('thumb-preview-img').src = thumbUrl;
        document.getElementById('thumb-preview').style.display = '';
        document.getElementById('thumb-drop-zone').style.display = 'none';
        btn.disabled = false; btn.innerHTML = oldHtml;
        return;
    }

    const video = document.createElement('video');
    video.src = URL.createObjectURL(selectedVideoFile);
    video.crossOrigin = 'anonymous';
    video.addEventListener('loadeddata', () => { video.currentTime = video.duration * 0.3; });
    video.addEventListener('seeked', async () => {
        const canvas = document.createElement('canvas');
        canvas.width = video.videoWidth; canvas.height = video.videoHeight;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        canvas.toBlob(async (blob) => {
            const file = new File([blob], "thumbnail.jpg", { type: "image/jpeg" });
            await uploadThumbnail(file);
            btn.disabled = false; btn.innerHTML = oldHtml;
        }, 'image/jpeg', 0.85);
    });
    video.addEventListener('error', () => {
        alert('Video okunurken hata oluştu.');
        btn.disabled = false; btn.innerHTML = oldHtml;
    });
}

/* ---- Thumbnail ---- */
function handleThumbDrop(e) {
    e.preventDefault(); e.currentTarget.classList.remove('dragover');
    const f = e.dataTransfer.files[0];
    if (f && f.type.startsWith('image/')) uploadThumbnail(f);
}
function handleThumbFile(input) { if (input.files[0]) uploadThumbnail(input.files[0]); }
async function uploadThumbnail(file) {
    if (file.size > 5 * 1024 * 1024) { alert('HATA: Kapak görseli en fazla 5MB olabilir.'); return; }
    document.getElementById('thumb-upload-status').classList.remove('hidden');
    document.getElementById('thumb-drop-zone').style.display = 'none';

    // credentials: 'same-origin' ile session cookie gönderilir (401 hatasını önler)
    const sigRes  = await fetch(APP_URL_JS + '/api/upload_sign.php?type=image', { credentials: 'same-origin' });
    if (!sigRes.ok) {
        alert('Thumbnail yuklenemedi: Imzalama hatasi (HTTP ' + sigRes.status + '). Lutfen tekrar giris yapin.');
        document.getElementById('thumb-upload-status').classList.add('hidden');
        document.getElementById('thumb-drop-zone').style.display = '';
        return;
    }
    const sigData = await sigRes.json();
    if (!sigData.api_key) {
        alert('Thumbnail yuklenemedi: Cloudinary API key alinamadi. Lutfen config.php dosyasini kontrol edin.');
        document.getElementById('thumb-upload-status').classList.add('hidden');
        document.getElementById('thumb-drop-zone').style.display = '';
        return;
    }

    const fd = new FormData();
    fd.append('file', file); fd.append('timestamp', sigData.timestamp);
    fd.append('signature', sigData.signature); fd.append('api_key', sigData.api_key);
    fd.append('folder', 'neontv/thumbnails');
    const xhr = new XMLHttpRequest();
    xhr.upload.onprogress = e => {
        const p = Math.round(e.loaded / e.total * 100);
        document.getElementById('thumb-progress-bar').style.width = p + '%';
        document.getElementById('thumb-upload-text').textContent = `Yukleniyor... ${p}%`;
    };
    xhr.onload = () => {
        let res;
        try { res = JSON.parse(xhr.responseText); } catch(e) { res = {}; }
        if (res.secure_url) {
            document.getElementById('thumb-url').value = res.secure_url;
            document.getElementById('thumb-preview-img').src = res.secure_url;
            document.getElementById('thumb-preview').style.display = '';
        } else {
            const errMsg = res.error?.message || 'Bilinmeyen hata';
            alert('Thumbnail Cloudinary\'a yuklenemedi: ' + errMsg);
            document.getElementById('thumb-drop-zone').style.display = '';
        }
        document.getElementById('thumb-upload-status').classList.add('hidden');
    };
    xhr.onerror = () => {
        alert('Thumbnail yuklenemedi: Ag baglantisi hatasi.');
        document.getElementById('thumb-upload-status').classList.add('hidden');
        document.getElementById('thumb-drop-zone').style.display = '';
    };
    xhr.open('POST', CLD_IMAGE_URL); xhr.send(fd);
}
function clearThumbnail() {
    document.getElementById('thumb-url').value = '';
    document.getElementById('thumb-preview').style.display = 'none';
    document.getElementById('thumb-drop-zone').style.display = '';
}

/* ---- Video (Chunked) ---- */
async function uploadVideoChunked(file) {
    const CHUNK = 6 * 1024 * 1024;
    const total = Math.ceil(file.size / CHUNK);
    const uid   = 'ntv_' + Date.now() + '_' + Math.random().toString(36).substr(2,9);
    document.getElementById('upload-progress-area').classList.remove('hidden');
    document.getElementById('video-drop-zone').style.pointerEvents = 'none';
    document.getElementById('video-drop-zone').style.opacity = '0.5';
    const log = document.getElementById('chunk-log');
    let cldUrl = null, cldId = null;
    for (let i = 0; i < total; i++) {
        const start = i * CHUNK, end = Math.min(start + CHUNK, file.size);
        const chunk = file.slice(start, end);
        const pct   = Math.round((i / total) * 90);
        document.getElementById('upload-progress-bar').style.width = pct + '%';
        document.getElementById('upload-percent').textContent = pct + '%';
        document.getElementById('upload-status-text').textContent = `Parca ${i+1} / ${total} yukleniyor`;
        log.innerHTML += `<div>> Parca ${i+1}/${total}: ${Math.round((end-start)/1024)}KB gonderiliyor...</div>`;
        log.scrollTop = log.scrollHeight;
        if (i === 0) {
            const sr = await fetch(APP_URL_JS + '/api/upload_sign.php?type=video', { credentials: 'same-origin' });
            window._sig = await sr.json();
        }
        const fd = new FormData();
        fd.append('file', chunk); fd.append('timestamp', window._sig.timestamp);
        fd.append('signature', window._sig.signature); fd.append('api_key', window._sig.api_key);
        fd.append('folder', 'neontv/videos');
        const resp = await fetch(CLOUDINARY_URL, {
            method: 'POST',
            headers: { 'X-Unique-Upload-Id': uid, 'Content-Range': `bytes ${start}-${end-1}/${file.size}` },
            body: fd
        });
        const result = await resp.json();
        if (result.error) throw new Error(result.error.message || 'Cloudinary yukleme hatasi');
        if (result.secure_url) {
            cldUrl = result.secure_url; cldId = result.public_id;
            log.innerHTML += `<div style="color:#00f5ff;">> Yukleme tamamlandi!</div>`;
            log.scrollTop = log.scrollHeight;
        }
    }
    if (!cldUrl) throw new Error('Video URL alinamadi');
    document.getElementById('upload-progress-bar').style.width = '100%';
    document.getElementById('upload-percent').textContent = '100%';
    document.getElementById('upload-status-text').textContent = 'Video yuklendi!';
    document.getElementById('video-url').value = cldUrl;
    document.getElementById('cloudinary-public-id').value = cldId;
    return { url: cldUrl, publicId: cldId };
}

/* ---- Kaydet ---- */
async function saveVideo() {
    const title  = document.getElementById('video-title').value.trim();
    const desc   = document.getElementById('video-description').value.trim();
    const thumb  = document.getElementById('thumb-url').value;
    const status = document.querySelector('input[name="status"]:checked')?.value || 'published';
    const btn    = document.getElementById('save-btn');
    const autoSubtitle = document.getElementById('auto-subtitle-check')?.checked;
    const duration = document.getElementById('video-duration')?.value || 0;

    if (!title) { showSaveStatus('Video basligi zorunludur.', 'error'); return; }
    let videoUrl = document.getElementById('video-url').value;
    let publicId = document.getElementById('cloudinary-public-id').value;
    if (!EDIT_ID && !selectedVideoFile && !videoUrl) {
        showSaveStatus('Lutfen bir video dosyasi secin veya URL girin.', 'error'); return;
    }
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Isleniyor...';
    try {
        if (selectedVideoFile) {
            btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Video yukleniyor...';
            const up = await uploadVideoChunked(selectedVideoFile);
            videoUrl = up.url; publicId = up.publicId;
        }
        btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Kaydediliyor...';
        const channelId = document.getElementById('video-channel').value;
        let previewClipUrl = '';

        // ------ Preview Klip Olustur (sadece yeni video + yerel dosya varsa) ------
        if (!EDIT_ID && selectedVideoFile) {
            try {
                btn.innerHTML = '<i class="fa-solid fa-film fa-spin"></i> Preview klip olusturuluyor...';
                previewClipUrl = await createAndUploadPreviewClip(selectedVideoFile);
            } catch (clipErr) {
                console.warn('Preview klip olusturulamadi:', clipErr.message);
                // Hata olsa bile devam et
            }
        }

        const payload = { 
            title, description: desc, thumbnail_url: thumb, 
            video_url: videoUrl, cloudinary_public_id: publicId, 
            status, channel_id: channelId, duration: parseInt(duration, 10),
            preview_clip_url: previewClipUrl || null, tags: tags
        };
        if (status === 'scheduled') {
            const schedAt = document.getElementById('scheduled-at').value;
            if (!schedAt) { showSaveStatus('Zamanlanmış yayın için tarih gereklidir.', 'error'); return; }
            payload.scheduled_at = new Date(schedAt).toISOString();
        }

                        { const ie = document.getElementById('intro-end'); if (ie) { const n = parseInt(ie.value, 10); if (n > 0) payload.intro_end = n; else if (ie.dataset.had === '1') payload.intro_end = null; } }
        { const ex = document.getElementById('expires-at'); if (ex) { if (ex.value) payload.expires_at = new Date(ex.value).toISOString(); else if (ex.dataset.had === '1') payload.expires_at = null; } }

        const res = await fetch(APP_URL_JS + '/api/videos.php' + (EDIT_ID ? '?id=' + EDIT_ID : ''), {
            method: EDIT_ID ? 'PATCH' : 'POST',
            headers: {'Content-Type':'application/json'},
            body: JSON.stringify(payload)
        });
        const data = await res.json();
        if (data.success) {
            const videoId = data.data?.id || data.data?.[0]?.id || EDIT_ID;
            
            // Otomatik altyazı oluştur
            if (autoSubtitle && videoId && (publicId || videoUrl)) {
                btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Altyazi olusturuluyor...';
                try {
                    const subRes = await fetch(APP_URL_JS + '/api/subtitles.php', {
                        method: 'POST',
                        headers: {'Content-Type':'application/json'},
                        body: JSON.stringify({ video_id: videoId, cloudinary_public_id: publicId, video_url: videoUrl })
                    });
                    const subData = await subRes.json();
                    if (subData.success) {
                        showSaveStatus((EDIT_ID ? 'Degisiklikler kaydedildi' : 'Video yuklendi') + ' ve altyazi olusturuldu!' + (previewClipUrl ? ' Preview klip hazir.' : ''), 'success');
                    } else {
                        showSaveStatus('Video kaydedildi fakat altyazi hatasi: ' + (subData.message || 'Bilinmeyen'), 'error');
                    }
                } catch(e) {
                    showSaveStatus('Video kaydedildi, altyazi olusturulamadi.', 'error');
                }
            } else {
                showSaveStatus(EDIT_ID ? 'Degisiklikler kaydedildi!' : 'Video basariyla yuklendi!' + (previewClipUrl ? ' Preview klip hazir.' : ''), 'success');
            }
            
            if (!EDIT_ID) setTimeout(() => window.location.href = APP_URL_JS + '/admin/videos.php', 2500);
        } else {
            showSaveStatus('Hata: ' + (data.message || 'Bilinmeyen hata'), 'error');
        }
    } catch(err) { showSaveStatus('Hata: ' + err.message, 'error'); }
    btn.disabled = false;
    btn.innerHTML = '<i class="fa-solid fa-' + (EDIT_ID ? 'floppy-disk' : 'cloud-arrow-up') + '"></i> ' + (EDIT_ID ? 'Degisiklikleri Kaydet' : 'Videoyu Yukle ve Kaydet');
}

/* ---- Preview Klip Olustur ve Cloudinary'e Yukle ----
   Algoritma:
   1. Video dosyasindan 4 rastgele zaman noktasi sec
   2. Her noktadan ~3 saniye kadar canvas ile kareye cek (30fps)
   3. MediaRecorder ile WebM video olarak kaydet
   4. Cloudinary'e video olarak yukle, URL'i don
---------------------------------------------------------------- */
async function createAndUploadPreviewClip(file) {
    return new Promise(async (resolve, reject) => {
        const video = document.createElement('video');
        video.src = URL.createObjectURL(file);
        video.muted = true;
        video.crossOrigin = 'anonymous';

        await new Promise(r => { video.addEventListener('loadedmetadata', r, { once: true }); video.load(); });

        const duration   = video.duration;
        if (!duration || duration < 4) { reject(new Error('Video cok kisa')); return; }

        const canvas  = document.createElement('canvas');
        canvas.width  = Math.min(video.videoWidth || 640, 640);
        canvas.height = Math.min(video.videoHeight || 360, 360);
        const ctx     = canvas.getContext('2d');

        // Desteklenen MIME tipi: WebM tercih
        const mimeType = MediaRecorder.isTypeSupported('video/webm;codecs=vp9')
            ? 'video/webm;codecs=vp9'
            : MediaRecorder.isTypeSupported('video/webm')
            ? 'video/webm'
            : 'video/mp4';

        const stream   = canvas.captureStream(25); // 25 fps
        const recorder = new MediaRecorder(stream, { mimeType, videoBitsPerSecond: 800000 });
        const chunks   = [];
        recorder.ondataavailable = e => { if (e.data.size > 0) chunks.push(e.data); };

        // 4 rastgele zaman noktasi: videonun %10 ile %90 arasinda
        const margin   = duration * 0.1;
        const usable   = duration * 0.8;
        const clipSec  = Math.min(3, duration / 4); // her segment max 3 sn
        const points   = [];
        for (let i = 0; i < 4; i++) {
            points.push(margin + (usable / 4) * i + Math.random() * (usable / 8));
        }
        points.sort((a, b) => a - b);

        recorder.start();

        for (const startT of points) {
            video.currentTime = Math.min(startT, duration - clipSec - 0.5);
            await new Promise(r => video.addEventListener('seeked', r, { once: true }));
            await video.play();

            const segEnd = performance.now() + clipSec * 1000;
            await new Promise(r => {
                function drawFrame() {
                    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
                    if (performance.now() < segEnd) requestAnimationFrame(drawFrame);
                    else r();
                }
                requestAnimationFrame(drawFrame);
            });
            video.pause();
        }

        recorder.stop();
        await new Promise(r => { recorder.addEventListener('stop', r, { once: true }); });
        URL.revokeObjectURL(video.src);

        const clipBlob = new Blob(chunks, { type: mimeType });
        const ext      = mimeType.includes('webm') ? 'webm' : 'mp4';
        const clipFile = new File([clipBlob], `preview_${Date.now()}.${ext}`, { type: mimeType });

        // Cloudinary'e yukle
        const sigRes  = await fetch(APP_URL_JS + '/api/upload_sign.php?type=video', { credentials: 'same-origin' });
        if (!sigRes.ok) { reject(new Error('Preview imzalama hatasi')); return; }
        const sig = await sigRes.json();
        if (!sig.api_key) { reject(new Error('Preview API key alinamadi')); return; }

        const fd = new FormData();
        fd.append('file', clipFile);
        fd.append('timestamp', sig.timestamp);
        fd.append('signature', sig.signature);
        fd.append('api_key', sig.api_key);
        fd.append('folder', 'neontv/previews');

        const uploadRes  = await fetch(CLOUDINARY_URL, { method: 'POST', body: fd });
        const uploadData = await uploadRes.json();

        if (uploadData.secure_url) {
            resolve(uploadData.secure_url);
        } else {
            reject(new Error(uploadData.error?.message || 'Preview yuklenemedi'));
        }
    });
}

// ===== AI THUMBNAIL İŞLEMLERİ =====
function openAiThumbModal() {
    document.getElementById('ai-thumb-modal').classList.remove('hidden');
    // Eğer başlık doluysa, prompt olarak öner
    const title = document.getElementById('video-title').value.trim();
    if (title && !document.getElementById('ai-thumb-prompt').value) {
        document.getElementById('ai-thumb-prompt').value = "YouTube thumbnail for a video titled: " + title;
    }
}

function closeAiThumbModal() {
    document.getElementById('ai-thumb-modal').classList.add('hidden');
}

function generateAiThumbnails() {
    const prompt = document.getElementById('ai-thumb-prompt').value.trim();
    if (!prompt) return alert('Lütfen bir prompt girin.');

    const btn = document.getElementById('ai-thumb-generate-btn');
    const resultsContainer = document.getElementById('ai-thumb-results');
    
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin mr-1"></i>Üretiliyor...';
    resultsContainer.innerHTML = '';

    // Pollinations.ai 3 farklı varyasyon (farklı seed'ler)
    const variations = 3;
    let html = '';
    
    for (let i = 0; i < variations; i++) {
        const seed = Math.floor(Math.random() * 1000000);
        // Pollinations URL'si, ekstra parametrelerle (nologo, width, height vb)
        const imageUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=1280&height=720&nologo=true&seed=${seed}`;
        
        html += `
        <div class="relative group rounded-xl overflow-hidden cursor-pointer border-2 border-transparent hover:border-cyan-400 transition-colors"
             onclick="selectAiThumb('${imageUrl}')">
            <img src="${imageUrl}" class="w-full aspect-video object-cover" onload="this.nextElementSibling.style.display='none'" onerror="this.nextElementSibling.innerHTML='Yüklenemedi'">
            <div class="absolute inset-0 flex items-center justify-center bg-black/50 text-xs text-white">Yükleniyor...</div>
            <div class="absolute inset-0 bg-cyan-400/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <span class="bg-black/80 px-3 py-1 rounded-lg text-xs font-bold text-cyan-400">Seç</span>
            </div>
        </div>`;
    }
    
    resultsContainer.innerHTML = html;
    
    btn.disabled = false;
    btn.innerHTML = 'Üret (3 Seçenek)';
}

function selectAiThumb(url) {
    // Seçilen resmi thumbnail alanına set et
    document.getElementById('thumb-url').value = url;
    document.getElementById('thumb-preview-img').src = url;
    document.getElementById('thumb-preview').style.display = 'block';
    document.getElementById('thumb-drop-zone').style.display = 'none';
    
    closeAiThumbModal();
}
</script>

<script>
/* ---- showSaveStatus ---- */
function showSaveStatus(msg, type) {
    const el = document.getElementById('save-status');
    const s  = { success: 'background:rgba(0,245,255,0.08);border-color:rgba(0,245,255,0.25);color:#00f5ff;',
                 error:   'background:rgba(255,0,122,0.08);border-color:rgba(255,0,122,0.25);color:#ff007a;' };
    el.style.cssText = s[type] || s.error;
    el.innerHTML = `<i class="fa-solid fa-${type==='success'?'circle-check':'circle-xmark'} mr-2"></i>${msg}`;
    el.classList.remove('hidden');
    el.scrollIntoView({ behavior:'smooth', block:'nearest' });
}

function toggleScheduledDate() {
    const status = document.querySelector('input[name="status"]:checked')?.value;
    const wrap = document.getElementById('scheduled-date-wrap');
    if (status === 'scheduled') wrap.classList.remove('hidden');
    else wrap.classList.add('hidden');
}

/* ---- #12 Chapters Yönetimi ---- */
const EDIT_VIDEO_ID = '<?= e($editId) ?>';

function formatSeconds(s) {
    s = parseInt(s) || 0;
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    if (h > 0) return `${h}:${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}`;
    return `${m}:${String(sec).padStart(2,'0')}`;
}

async function loadChapters() {
    if (!EDIT_VIDEO_ID) return;
    const res = await fetch(APP_URL_JS + '/api/chapters.php?video_id=' + EDIT_VIDEO_ID);
    const data = await res.json();
    if (data.success) renderChapters(data.data || []);
}

function renderChapters(chapters) {
    const list = document.getElementById('chapters-list');
    if (!list) return;
    if (!chapters.length) {
        list.innerHTML = '<p class="text-xs text-gray-600 text-center py-2">Henüz bölüm yok</p>';
        return;
    }
    list.innerHTML = chapters.map(ch => `
        <div class="flex items-center gap-2 p-2 rounded-lg" style="background:rgba(255,255,255,0.04);">
            <span class="text-xs font-mono text-cyan-400 flex-shrink-0">${formatSeconds(ch.start_time)}</span>
            <span class="text-xs text-gray-300 flex-1 truncate">${ch.title}</span>
            <button onclick="deleteChapter('${ch.id}')" class="text-gray-600 hover:text-red-400 transition-colors flex-shrink-0">
                <i class="fa-solid fa-xmark text-xs"></i>
            </button>
        </div>
    `).join('');
}

async function addChapter() {
    const title = document.getElementById('chapter-title-input').value.trim();
    const time  = parseInt(document.getElementById('chapter-time-input').value) || 0;
    if (!title) { alert('Bölüm başlığı gerekli'); return; }
    if (!EDIT_VIDEO_ID) { alert('Önce videoyu kaydedin'); return; }

    const res  = await fetch(APP_URL_JS + '/api/chapters.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ video_id: EDIT_VIDEO_ID, title, start_time: time })
    });
    const data = await res.json();
    if (data.success) {
        document.getElementById('chapter-title-input').value = '';
        document.getElementById('chapter-time-input').value  = '';
        loadChapters();
    } else {
        alert('Hata: ' + (data.message || 'Bilinmeyen'));
    }
}

async function deleteChapter(id) {
    if (!confirm('Bu bölümü silmek istiyor musunuz?')) return;
    const res  = await fetch(APP_URL_JS + '/api/chapters.php?id=' + id, { method: 'DELETE' });
    const data = await res.json();
    if (data.success) loadChapters();
}

/* ---- #20 AI ile Bölüm Oluştur ---- */
async function generateChaptersWithAI() {
    if (!EDIT_VIDEO_ID) { alert('Önce videoyu kaydedin'); return; }

    const btn = document.getElementById('ai-chapters-btn');
    const oldHtml = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Oluşturuluyor...';

    try {
        // Önce altyazıyı çek
        const subRes  = await fetch(APP_URL_JS + '/api/subtitles.php?video_id=' + EDIT_VIDEO_ID);
        const subData = await subRes.json();
        const subtitleContent = subData.data?.content || '';

        if (!subtitleContent) {
            alert('Bu video için altyazı bulunamadı. Önce altyazı oluşturun.');
            btn.disabled = false; btn.innerHTML = oldHtml;
            return;
        }

        // AI ile bölümler oluştur
        const res  = await fetch(APP_URL_JS + '/api/chapters.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ video_id: EDIT_VIDEO_ID, ai: true, subtitle_content: subtitleContent })
        });
        const data = await res.json();

        if (data.success) {
            loadChapters();
            showSaveStatus(data.message || 'Bölümler oluşturuldu!', 'success');
        } else {
            alert('Hata: ' + (data.message || 'Bilinmeyen'));
        }
    } catch(e) {
        alert('Bağlantı hatası: ' + e.message);
    }

    btn.disabled = false;
    btn.innerHTML = oldHtml;
}

// Sayfa yüklenince bölümleri çek
if (EDIT_VIDEO_ID) loadChapters();
</script>
</body>
</html>
