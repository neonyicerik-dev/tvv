<?php
// NeonTV - Admin: Site duyuru çubuğu
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/store.php';
requireAdmin(['editor', 'superadmin']);

$cur = Store::getSetting('site_announcement');
if (!is_array($cur)) $cur = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken(input('csrf_token'))) { setFlash('error', 'Güvenlik doğrulaması başarısız.'); redirect(APP_URL . '/admin/announcement.php'); }
    $link = trim(input('link'));
    if ($link !== '' && !preg_match('#^(https?://|/)#i', $link)) $link = '';
    $color = in_array(input('color'), ['cyan', 'purple', 'red', 'green', 'yellow'], true) ? input('color') : 'cyan';
    $new = [
        'enabled' => input('enabled') === '1',
        'text'    => mb_substr(trim(input('text')), 0, 200),
        'link'    => mb_substr($link, 0, 300),
        'color'   => $color,
        'ends_at' => trim(input('ends_at')) ? date('c', strtotime(input('ends_at'))) : '',
        // metin/link değişince kapatmış kullanıcılara tekrar göster
        'id'      => (($cur['text'] ?? '') !== mb_substr(trim(input('text')), 0, 200) || ($cur['link'] ?? '') !== $link) ? (string)time() : ($cur['id'] ?? (string)time()),
    ];
    if (Store::setSetting('site_announcement', $new)) setFlash('success', 'Duyuru kaydedildi.');
    else setFlash('error', 'Kaydedilemedi.');
    redirect(APP_URL . '/admin/announcement.php');
}

$adminTitle = 'Duyuru Çubuğu';
$adminSub   = 'Sitenin en üstünde kapatılabilir bir şerit gösterir';
include __DIR__ . '/_top.php';
$inp = 'bg-black/30 border border-gray-800 rounded-xl py-2.5 px-3 text-white text-sm focus:outline-none focus:border-cyan-500 w-full';
?>
<form method="POST" class="rounded-2xl p-5 space-y-4 max-w-2xl" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
    <?= csrfField() ?>
    <label class="flex items-center gap-2 text-sm text-gray-200"><input type="checkbox" name="enabled" value="1" <?= !empty($cur['enabled']) ? 'checked' : '' ?>> Duyuruyu yayında göster</label>
    <div><label class="block text-xs text-gray-400 mb-1">Metin (en fazla 200 karakter)</label><input type="text" name="text" maxlength="200" value="<?= e($cur['text'] ?? '') ?>" class="<?= $inp ?>" placeholder="Örn: Yeni videolar eklendi!"></div>
    <div><label class="block text-xs text-gray-400 mb-1">Bağlantı (isteğe bağlı, https://… veya /sayfa)</label><input type="text" name="link" value="<?= e($cur['link'] ?? '') ?>" class="<?= $inp ?>"></div>
    <div class="grid grid-cols-2 gap-3">
        <div><label class="block text-xs text-gray-400 mb-1">Renk</label>
            <select name="color" class="<?= $inp ?>"><?php foreach (['cyan' => 'Camgöbeği', 'purple' => 'Mor', 'red' => 'Kırmızı', 'green' => 'Yeşil', 'yellow' => 'Sarı'] as $k => $l): ?><option value="<?= $k ?>" <?= ($cur['color'] ?? 'cyan') === $k ? 'selected' : '' ?>><?= $l ?></option><?php endforeach; ?></select></div>
        <div><label class="block text-xs text-gray-400 mb-1">Bitiş (boşsa süresiz)</label><input type="datetime-local" name="ends_at" value="<?= !empty($cur['ends_at']) ? e(date('Y-m-d\TH:i', strtotime($cur['ends_at']))) : '' ?>" class="<?= $inp ?>"></div>
    </div>
    <button class="px-6 py-2.5 rounded-xl font-bold text-black" style="background:linear-gradient(135deg,#00f5ff,#bf00ff);">Kaydet</button>
</form>
<?php include __DIR__ . '/_bottom.php'; ?>
