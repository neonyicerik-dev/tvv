<?php
// ============================================================
// NeonTV - Admin Giriş Sayfası
// G4: Rate limit, session_regenerate_id, şifre uyarısı
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/store.php';

// Zaten giriş yapmışsa dashboard'a yönlendir
if (isAdminLoggedIn()) {
    redirect(APP_URL . '/admin/index.php');
}

$error     = '';
$isBlocked = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = input('username');
    $password = input('password');
    $csrf     = input('csrf_token');

    if (!verifyCsrfToken($csrf)) {
        $error = 'Güvenlik hatası. Lütfen sayfayı yenileyin.';
    } else {
        // G4: Rate limit kontrolü
        $ip     = getClientIp();
        $ratKey = 'login:' . md5($ip . ':' . $username);
        $attempts = Store::countLoginAttempts($ratKey);

        if ($attempts >= 10) {
            $isBlocked = true;
            $error = 'Çok fazla başarısız deneme. 15 dakika sonra tekrar deneyin.';
        } elseif (adminLogin($username, $password)) {
            // G4: session_regenerate_id adminLogin içinde yapılıyor
            redirect(APP_URL . '/admin/index.php');
        } else {
            $remaining = max(0, 10 - ($attempts + 1));
            $error = 'Kullanıcı adı veya şifre hatalı.' . ($remaining > 0 ? " ($remaining deneme hakkı kaldı)" : '');
            sleep(1); // Timing saldırısına karşı
        }
    }
}

// G4: Varsayılan şifre uyarısı
$defaultHashWarning = password_verify('password', ADMIN_PASSWORD_HASH);
?>
<!DOCTYPE html>
<html lang="tr" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Girişi | NeonTV</title>
    <meta name="robots" content="noindex,nofollow">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body { font-family: 'Outfit', sans-serif; background: #070711; }
        .neon-border { box-shadow: 0 0 20px rgba(0,245,255,0.15), inset 0 0 20px rgba(0,245,255,0.02); }
        .shake { animation: shake 0.4s ease; }
        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            20%       { transform: translateX(-6px); }
            40%       { transform: translateX(6px); }
            60%       { transform: translateX(-4px); }
            80%       { transform: translateX(4px); }
        }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center px-4" style="background:radial-gradient(ellipse at center top, rgba(0,245,255,0.05) 0%, #070711 60%);">

    <div class="w-full max-w-sm">

        <?php if ($defaultHashWarning): ?>
        <!-- G4: Varsayılan şifre uyarısı -->
        <div class="flex items-center gap-3 px-4 py-3 rounded-xl mb-4 text-xs"
             style="background:rgba(255,165,0,0.08);border:1px solid rgba(255,165,0,0.3);color:#ffa500;">
            <i class="fa-solid fa-triangle-exclamation flex-shrink-0"></i>
            <span>Güvenlik: config.php'deki varsayılan şifre hâlâ aktif. <strong>Lütfen değiştirin!</strong></span>
        </div>
        <?php endif; ?>

        <!-- Logo -->
        <div class="text-center mb-8">
            <div class="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 neon-border"
                 style="background:rgba(0,245,255,0.05);border:1px solid rgba(0,245,255,0.2);">
                <i class="fa-solid fa-shield-halved text-2xl" style="color:#00f5ff;"></i>
            </div>
            <h1 class="text-2xl font-bold text-white">Admin Paneli</h1>
            <p class="text-gray-500 text-sm mt-1">NeonTV Yönetim Sistemi</p>
        </div>

        <!-- Form Card -->
        <div class="rounded-2xl p-8 shadow-2xl" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">

            <?php if ($error): ?>
            <div class="flex items-center gap-3 px-4 py-3 rounded-xl mb-5 text-sm shake"
                 style="background:rgba(255,0,122,0.1);border:1px solid rgba(255,0,122,0.3);color:#ff007a;">
                <i class="fa-solid fa-triangle-exclamation flex-shrink-0"></i>
                <?= e($error) ?>
            </div>
            <?php endif; ?>

            <form method="POST" action="" id="admin-login-form">
                <?= csrfField() ?>

                <div class="space-y-4">
                    <div>
                        <label for="admin-username" class="block text-xs font-semibold text-gray-400 mb-1.5 uppercase tracking-wider">
                            <i class="fa-solid fa-user mr-1"></i>Kullanıcı Adı
                        </label>
                        <input type="text" name="username" id="admin-username"
                               value="<?= e(input('username')) ?>"
                               required autocomplete="username"
                               <?= $isBlocked ? 'disabled' : '' ?>
                               class="w-full px-4 py-3 rounded-xl text-sm text-white placeholder-gray-600 outline-none transition-all duration-200"
                               style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);"
                               onfocus="this.style.borderColor='rgba(0,245,255,0.5)';this.style.boxShadow='0 0 0 3px rgba(0,245,255,0.08)'"
                               onblur="this.style.borderColor='rgba(255,255,255,0.1)';this.style.boxShadow='none'">
                    </div>

                    <div>
                        <label for="admin-password" class="block text-xs font-semibold text-gray-400 mb-1.5 uppercase tracking-wider">
                            <i class="fa-solid fa-lock mr-1"></i>Şifre
                        </label>
                        <div class="relative">
                            <input type="password" name="password" id="admin-password"
                                   required autocomplete="current-password"
                                   <?= $isBlocked ? 'disabled' : '' ?>
                                   class="w-full px-4 py-3 pr-12 rounded-xl text-sm text-white placeholder-gray-600 outline-none transition-all duration-200"
                                   style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);"
                                   onfocus="this.style.borderColor='rgba(0,245,255,0.5)';this.style.boxShadow='0 0 0 3px rgba(0,245,255,0.08)'"
                                   onblur="this.style.borderColor='rgba(255,255,255,0.1)';this.style.boxShadow='none'">
                            <button type="button"
                                    onclick="const i=document.getElementById('admin-password');i.type=i.type==='password'?'text':'password';this.querySelector('i').className='fa-regular fa-'+(i.type==='password'?'eye':'eye-slash')"
                                    class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300 transition-colors">
                                <i class="fa-regular fa-eye"></i>
                            </button>
                        </div>
                    </div>

                    <button type="submit" id="login-btn"
                            <?= $isBlocked ? 'disabled' : '' ?>
                            class="w-full py-3 rounded-xl font-bold text-black text-sm transition-all duration-300 hover:scale-[1.02] hover:shadow-xl mt-2 flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                            style="background:linear-gradient(135deg,#00f5ff,#bf00ff);box-shadow:0 0 25px rgba(0,245,255,0.25);">
                        <i class="fa-solid fa-right-to-bracket"></i>
                        <?= $isBlocked ? 'Geçici Olarak Kilitlendi' : 'Giriş Yap' ?>
                    </button>
                </div>
            </form>
        </div>

        <a href="<?= APP_URL ?>/index.php" class="flex items-center justify-center gap-2 mt-6 text-sm text-gray-600 hover:text-gray-400 transition-colors">
            <i class="fa-solid fa-arrow-left text-xs"></i>
            Siteye dön
        </a>
    </div>

    <script>
    document.getElementById('admin-login-form').addEventListener('submit', function() {
        const btn = document.getElementById('login-btn');
        if (btn.disabled) return;
        btn.disabled = true;
        btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Kontrol ediliyor...';
    });
    </script>
</body>
</html>
