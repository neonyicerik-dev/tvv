<?php
// ============================================================
// NeonTV - Admin: Kategori Yönetimi
// F1: Kategori sistemi (Videolardaki etiketler ile tam senkronize)
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../includes/store.php';

requireAdmin('superadmin');

$db = new Supabase();

// ---- Videolardaki etiketleri ve sayılarını çek ----
$vidsRes = $db->select('videos', 'select=id,tags', true);
$videoTagsCount = [];
foreach (($vidsRes['data'] ?? []) as $v) {
    $tags = $v['tags'] ?? [];
    if (is_string($tags)) {
        if (str_starts_with($tags, '{') && str_ends_with($tags, '}')) {
            $tags = explode(',', trim($tags, '{}'));
        } else {
            $tags = json_decode($tags, true) ?? [];
        }
    }
    if (is_array($tags)) {
        foreach ($tags as $t) {
            $t = trim(trim($t, '"'));
            if ($t !== '') {
                $videoTagsCount[$t] = ($videoTagsCount[$t] ?? 0) + 1;
            }
        }
    }
}

// Otomatik senkronizasyon: Videolarda olan ama categories tablosunda henüz olmayan kategorileri ekle
$existingCats = Store::getCategories(false);
$existingMap  = [];
foreach ($existingCats as $c) {
    $existingMap[mb_strtolower($c['name'], 'UTF-8')] = $c;
    $existingMap[mb_strtolower($c['slug'], 'UTF-8')] = $c;
}

$autoSynced = 0;
foreach ($videoTagsCount as $tagName => $count) {
    $lower = mb_strtolower($tagName, 'UTF-8');
    if (!isset($existingMap[$lower])) {
        $slug = slugify($tagName);
        if (!$slug) $slug = 'kat-' . substr(md5($tagName), 0, 6);
        $ins = $db->insert('categories', [
            'name'       => $tagName,
            'slug'       => $slug,
            'sort_order' => 0,
            'is_active'  => true,
        ], true);
        if ($ins['status'] < 400) {
            $autoSynced++;
            $existingMap[$lower] = true;
        }
    }
}
if ($autoSynced > 0) {
    Store::clearCache('categories_all');
    Store::clearCache('categories_active');
}

// ---- Aksiyon işle ----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = input('csrf_token');
    if (!verifyCsrfToken($csrf)) {
        setFlash('error', 'Güvenlik hatası. Sayfayı yenileyin.');
        redirect(APP_URL . '/admin/categories.php');
    }

    $action = input('action');

    // Videolardan manuel eşitleme
    if ($action === 'sync_videos') {
        $synced = 0;
        foreach ($videoTagsCount as $tagName => $count) {
            $lower = mb_strtolower($tagName, 'UTF-8');
            if (!isset($existingMap[$lower])) {
                $slug = slugify($tagName) ?: 'kat-' . substr(md5($tagName), 0, 6);
                $ins = $db->insert('categories', [
                    'name'       => $tagName,
                    'slug'       => $slug,
                    'sort_order' => 0,
                    'is_active'  => true,
                ], true);
                if ($ins['status'] < 400) {
                    $synced++;
                }
            }
        }
        Store::clearCache('categories_all');
        Store::clearCache('categories_active');
        setFlash('success', $synced > 0 ? "{$synced} yeni video kategorisi başarıyla eşitlendi." : 'Tüm video kategorileri zaten güncel.');
        redirect(APP_URL . '/admin/categories.php');
    }

    // Yeni kategori oluştur
    if ($action === 'create') {
        $name     = trim(input('name'));
        $slug     = trim(input('slug')) ?: slugify($name);
        $sort     = (int)input('sort_order');
        $isActive = isset($_POST['is_active']);

        if (!$name) {
            setFlash('error', 'Kategori adı zorunlu.');
        } else {
            $r = $db->insert('categories', [
                'name'       => $name,
                'slug'       => $slug,
                'sort_order' => $sort,
                'is_active'  => $isActive,
            ], true);
            if ($r['status'] < 400) {
                Store::clearCache('categories_all');
                Store::clearCache('categories_active');
                logActivity('category_create', 'category', '', [], ['name' => $name]);
                setFlash('success', 'Kategori oluşturuldu.');
            } else {
                setFlash('error', 'Hata: ' . ($r['error'] ?? 'bilinmeyen'));
            }
        }
    }

    // Güncelle
    if ($action === 'edit') {
        $id       = trim(input('id'));
        requireUuid($id, 'Kategori ID');
        $name     = trim(input('name'));
        $slug     = trim(input('slug')) ?: slugify($name);
        $sort     = (int)input('sort_order');
        $isActive = isset($_POST['is_active']);

        $r = $db->update('categories', [
            'name'       => $name,
            'slug'       => $slug,
            'sort_order' => $sort,
            'is_active'  => $isActive,
        ], 'id=eq.' . urlencode($id), true);

        if ($r['status'] < 400) {
            Store::clearCache('categories_all');
            Store::clearCache('categories_active');
            logActivity('category_edit', 'category', $id, [], ['name' => $name]);
            setFlash('success', 'Kategori güncellendi.');
        } else {
            setFlash('error', 'Güncelleme başarısız: ' . ($r['error'] ?? ''));
        }
    }

    // Sil
    if ($action === 'delete') {
        $id = trim(input('id'));
        requireUuid($id, 'Kategori ID');
        $r = $db->delete('categories', 'id=eq.' . urlencode($id), true);
        if ($r['status'] < 400) {
            Store::clearCache('categories_all');
            Store::clearCache('categories_active');
            logActivity('category_delete', 'category', $id);
            setFlash('success', 'Kategori silindi.');
        } else {
            setFlash('error', 'Silinemedi.');
        }
    }

    redirect(APP_URL . '/admin/categories.php');
}

// ---- Güncel kategori listesi ----
$cats = Store::getCategories(false);
$pageTitle = 'Kategoriler';
?>
<!DOCTYPE html>
<html lang="tr" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kategoriler | NeonTV Admin</title>
    <meta name="robots" content="noindex,nofollow">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body { font-family: 'Outfit', sans-serif; background: #070711; color: #fff; }
        ::-webkit-scrollbar { width:6px; } ::-webkit-scrollbar-track { background:#0d0d1a; } ::-webkit-scrollbar-thumb { background:#1e1e3a; border-radius:3px; }
    </style>
</head>
<body class="min-h-screen lg:flex">

<?php include __DIR__ . '/sidebar.php'; ?>

<div class="flex-1 flex flex-col min-w-0 overflow-x-hidden">

    <!-- TOP BAR (Mobil Menü Butonu Dahil) -->
    <header class="flex items-center justify-between px-4 sm:px-6 py-4 sticky top-0 z-20"
            style="background:rgba(7,7,17,0.9);backdrop-filter:blur(20px);border-bottom:1px solid rgba(255,255,255,0.06);">
        <div class="flex items-center gap-3">
            <!-- Hamburger Menü -->
            <button onclick="openSidebar()" class="lg:hidden p-2 rounded-xl text-gray-400 hover:text-white transition-colors"
                    style="background:rgba(255,255,255,0.06);">
                <i class="fa-solid fa-bars text-sm"></i>
            </button>
            <div>
                <h1 class="text-lg sm:text-xl font-bold text-white">Kategori Yönetimi</h1>
                <p class="text-xs text-gray-500">Videolardaki ve platformdaki kategoriler (<?= count($cats) ?> kategori)</p>
            </div>
        </div>
        <div class="flex items-center gap-2">
            <form method="POST" class="inline">
                <?= csrfField() ?>
                <input type="hidden" name="action" value="sync_videos">
                <button type="submit"
                        title="Mevcut videolarda kullanılan tüm etiketleri kategorilere senkronize eder"
                        class="flex items-center gap-1.5 sm:gap-2 px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all hover:bg-cyan-500/10"
                        style="background:rgba(0,245,255,0.06);border:1px solid rgba(0,245,255,0.25);color:#00f5ff;">
                    <i class="fa-solid fa-arrows-rotate"></i>
                    <span class="hidden sm:inline">Videolardan Eşitle</span>
                    <span class="sm:hidden">Eşitle</span>
                </button>
            </form>
            <button onclick="document.getElementById('create-modal').classList.remove('hidden')"
                    class="flex items-center gap-1.5 sm:gap-2 px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold text-black transition-all hover:scale-105"
                    style="background:linear-gradient(135deg,#00f5ff,#bf00ff);">
                <i class="fa-solid fa-plus text-xs"></i>
                <span class="hidden sm:inline">Yeni Kategori</span>
                <span class="sm:hidden">Yeni</span>
            </button>
        </div>
    </header>

    <main class="flex-1 p-4 sm:p-6 overflow-auto">
        <div class="max-w-5xl mx-auto space-y-6">

            <?= renderFlash() ?>

            <!-- Bilgilendirme Kartı -->
            <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between p-4 rounded-2xl gap-3"
                 style="background:rgba(0,245,255,0.03);border:1px solid rgba(0,245,255,0.1);">
                <div class="flex items-center gap-3">
                    <div class="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
                         style="background:rgba(0,245,255,0.1);color:#00f5ff;">
                        <i class="fa-solid fa-film text-sm"></i>
                    </div>
                    <div>
                        <h3 class="text-sm font-semibold text-white">Videolardaki Kategoriler Dahildir</h3>
                        <p class="text-xs text-gray-400">Yayınlanmış videolardaki etiketler otomatik olarak kategori listesine eklenir ve video sayıları gösterilir.</p>
                    </div>
                </div>
                <div class="text-xs px-3 py-1.5 rounded-xl font-mono text-cyan-400 bg-cyan-400/10 border border-cyan-400/20 whitespace-nowrap">
                    <?= count($videoTagsCount) ?> video etiketi algılandı
                </div>
            </div>

            <!-- Kategori Listesi -->
            <div class="rounded-2xl overflow-hidden" style="background:#13131f;border:1px solid rgba(255,255,255,0.06);">
                <div class="overflow-x-auto">
                    <table class="w-full text-sm">
                        <thead>
                            <tr style="background:rgba(0,245,255,0.04);border-bottom:1px solid rgba(255,255,255,0.06);">
                                <th class="px-4 py-3.5 text-left text-gray-400 font-semibold">Kategori Adı</th>
                                <th class="px-4 py-3.5 text-left text-gray-400 font-semibold">Slug (URL)</th>
                                <th class="px-4 py-3.5 text-center text-gray-400 font-semibold">Video Sayısı</th>
                                <th class="px-4 py-3.5 text-center text-gray-400 font-semibold">Sıra</th>
                                <th class="px-4 py-3.5 text-center text-gray-400 font-semibold">Durum</th>
                                <th class="px-4 py-3.5 text-center text-gray-400 font-semibold">İşlem</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y" style="border-color:rgba(255,255,255,0.04);">
                            <?php if (empty($cats)): ?>
                            <tr><td colspan="6" class="px-4 py-8 text-center text-gray-500">Henüz kategori bulunamadı</td></tr>
                            <?php else: ?>
                            <?php foreach ($cats as $cat): 
                                $vCount = $videoTagsCount[$cat['name']] ?? ($videoTagsCount[$cat['slug']] ?? 0);
                            ?>
                            <tr class="hover:bg-white/[0.02] transition-colors">
                                <td class="px-4 py-3.5 font-medium flex items-center gap-2">
                                    <i class="fa-solid fa-hashtag text-cyan-400 text-xs"></i>
                                    <span><?= e($cat['name']) ?></span>
                                    <?php if ($vCount > 0): ?>
                                    <span class="text-[10px] px-1.5 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">Videoda Var</span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-4 py-3.5 text-gray-400 font-mono text-xs"><?= e($cat['slug']) ?></td>
                                <td class="px-4 py-3.5 text-center">
                                    <?php if ($vCount > 0): ?>
                                    <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold"
                                          style="background:rgba(0,245,255,0.1);color:#00f5ff;border:1px solid rgba(0,245,255,0.2);">
                                        <i class="fa-solid fa-play text-[10px]"></i>
                                        <?= $vCount ?> video
                                    </span>
                                    <?php else: ?>
                                    <span class="text-xs text-gray-600">0 video</span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-4 py-3.5 text-center text-gray-400 font-mono text-xs"><?= (int)$cat['sort_order'] ?></td>
                                <td class="px-4 py-3.5 text-center">
                                    <?php if ($cat['is_active']): ?>
                                        <span class="px-2.5 py-1 rounded-full text-xs font-medium" style="background:rgba(0,245,255,0.1);color:#00f5ff;">Aktif</span>
                                    <?php else: ?>
                                        <span class="px-2.5 py-1 rounded-full text-xs font-medium" style="background:rgba(255,255,255,0.05);color:#6b7280;">Pasif</span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-4 py-3.5 text-center">
                                    <div class="flex items-center justify-center gap-2">
                                        <button onclick="openEdit(<?= htmlspecialchars(json_encode($cat), ENT_QUOTES) ?>)"
                                                class="px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all hover:scale-105"
                                                style="background:rgba(251,191,36,0.1);color:#fbbf24;border:1px solid rgba(251,191,36,0.2);">
                                            <i class="fa-solid fa-pen-to-square mr-1"></i>Düzenle
                                        </button>
                                        <button onclick="confirmDelete('<?= e($cat['id']) ?>','<?= e($cat['name']) ?>')"
                                                class="px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all hover:scale-105"
                                                style="background:rgba(255,68,68,0.1);color:#ff4444;border:1px solid rgba(255,68,68,0.2);">
                                            <i class="fa-solid fa-trash mr-1"></i>Sil
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
</div>

<!-- Yeni Kategori Modal -->
<div id="create-modal" class="hidden fixed inset-0 z-50 flex items-center justify-center p-4" style="background:rgba(0,0,0,0.7);backdrop-filter:blur(4px);">
    <div class="w-full max-w-md rounded-2xl p-6" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
        <h2 class="text-lg font-bold mb-5 flex items-center gap-2">
            <i class="fa-solid fa-plus text-cyan-400"></i> Yeni Kategori
        </h2>
        <form method="POST">
            <?= csrfField() ?>
            <input type="hidden" name="action" value="create">
            <div class="space-y-4">
                <div>
                    <label class="block text-xs font-semibold text-gray-400 mb-1.5">Kategori Adı *</label>
                    <input type="text" name="name" required placeholder="örn: Amatör"
                           class="w-full px-4 py-2.5 rounded-xl text-sm text-white bg-white/5 border border-white/10 outline-none focus:border-cyan-500/50">
                </div>
                <div>
                    <label class="block text-xs font-semibold text-gray-400 mb-1.5">Slug (boş bırakırsanız otomatik oluşturulur)</label>
                    <input type="text" name="slug" placeholder="amator"
                           class="w-full px-4 py-2.5 rounded-xl text-sm text-gray-400 bg-white/5 border border-white/10 outline-none focus:border-cyan-500/50 font-mono">
                </div>
                <div class="flex items-center gap-4">
                    <div class="flex-1">
                        <label class="block text-xs font-semibold text-gray-400 mb-1.5">Sıra</label>
                        <input type="number" name="sort_order" value="0" min="0"
                               class="w-full px-4 py-2.5 rounded-xl text-sm text-white bg-white/5 border border-white/10 outline-none focus:border-cyan-500/50">
                    </div>
                    <div class="flex items-center gap-2 mt-5">
                        <input type="checkbox" name="is_active" id="cat-active-new" checked class="w-4 h-4 accent-cyan-400">
                        <label for="cat-active-new" class="text-sm text-gray-300">Aktif</label>
                    </div>
                </div>
            </div>
            <div class="flex gap-3 mt-6">
                <button type="button" onclick="document.getElementById('create-modal').classList.add('hidden')"
                        class="flex-1 py-2.5 rounded-xl text-sm font-semibold bg-white/5 hover:bg-white/10 transition-colors">İptal</button>
                <button type="submit"
                        class="flex-1 py-2.5 rounded-xl text-sm font-bold text-black transition-all hover:scale-[1.02]"
                        style="background:linear-gradient(135deg,#00f5ff,#bf00ff);">Oluştur</button>
            </div>
        </form>
    </div>
</div>

<!-- Düzenle Modal -->
<div id="edit-modal" class="hidden fixed inset-0 z-50 flex items-center justify-center p-4" style="background:rgba(0,0,0,0.7);backdrop-filter:blur(4px);">
    <div class="w-full max-w-md rounded-2xl p-6" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
        <h2 class="text-lg font-bold mb-5 flex items-center gap-2">
            <i class="fa-solid fa-pen-to-square text-amber-400"></i> Kategori Düzenle
        </h2>
        <form method="POST">
            <?= csrfField() ?>
            <input type="hidden" name="action" value="edit">
            <input type="hidden" name="id" id="edit-id">
            <div class="space-y-4">
                <div>
                    <label class="block text-xs font-semibold text-gray-400 mb-1.5">Kategori Adı *</label>
                    <input type="text" name="name" id="edit-name" required
                           class="w-full px-4 py-2.5 rounded-xl text-sm text-white bg-white/5 border border-white/10 outline-none focus:border-cyan-500/50">
                </div>
                <div>
                    <label class="block text-xs font-semibold text-gray-400 mb-1.5">Slug</label>
                    <input type="text" name="slug" id="edit-slug"
                           class="w-full px-4 py-2.5 rounded-xl text-sm text-gray-400 bg-white/5 border border-white/10 outline-none focus:border-cyan-500/50 font-mono">
                </div>
                <div class="flex items-center gap-4">
                    <div class="flex-1">
                        <label class="block text-xs font-semibold text-gray-400 mb-1.5">Sıra</label>
                        <input type="number" name="sort_order" id="edit-sort" min="0"
                               class="w-full px-4 py-2.5 rounded-xl text-sm text-white bg-white/5 border border-white/10 outline-none focus:border-cyan-500/50">
                    </div>
                    <div class="flex items-center gap-2 mt-5">
                        <input type="checkbox" name="is_active" id="edit-active" class="w-4 h-4 accent-cyan-400">
                        <label for="edit-active" class="text-sm text-gray-300">Aktif</label>
                    </div>
                </div>
            </div>
            <div class="flex gap-3 mt-6">
                <button type="button" onclick="document.getElementById('edit-modal').classList.add('hidden')"
                        class="flex-1 py-2.5 rounded-xl text-sm font-semibold bg-white/5 hover:bg-white/10 transition-colors">İptal</button>
                <button type="submit"
                        class="flex-1 py-2.5 rounded-xl text-sm font-bold text-black transition-all hover:scale-[1.02]"
                        style="background:linear-gradient(135deg,#00f5ff,#bf00ff);">Kaydet</button>
            </div>
        </form>
    </div>
</div>

<!-- Sil Onay -->
<div id="delete-modal" class="hidden fixed inset-0 z-50 flex items-center justify-center p-4" style="background:rgba(0,0,0,0.7);backdrop-filter:blur(4px);">
    <div class="w-full max-w-sm rounded-2xl p-6" style="background:#13131f;border:1px solid rgba(255,68,68,0.2);">
        <h2 class="text-lg font-bold mb-2 text-red-400 flex items-center gap-2">
            <i class="fa-solid fa-triangle-exclamation"></i> Kategori Sil
        </h2>
        <p class="text-gray-400 text-sm mb-5"><span id="delete-name" class="text-white font-semibold"></span> silinecek. Bu işlem geri alınamaz.</p>
        <form method="POST" id="delete-form">
            <?= csrfField() ?>
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="id" id="delete-id">
            <div class="flex gap-3">
                <button type="button" onclick="document.getElementById('delete-modal').classList.add('hidden')"
                        class="flex-1 py-2.5 rounded-xl text-sm bg-white/5 hover:bg-white/10 transition-colors">İptal</button>
                <button type="submit"
                        class="flex-1 py-2.5 rounded-xl text-sm font-bold text-white transition-all hover:scale-[1.02]"
                        style="background:#ff4444;">Sil</button>
            </div>
        </form>
    </div>
</div>

<script>
function openEdit(cat) {
    document.getElementById('edit-id').value   = cat.id;
    document.getElementById('edit-name').value = cat.name;
    document.getElementById('edit-slug').value = cat.slug;
    document.getElementById('edit-sort').value = cat.sort_order;
    document.getElementById('edit-active').checked = !!cat.is_active;
    document.getElementById('edit-modal').classList.remove('hidden');
}
function confirmDelete(id, name) {
    document.getElementById('delete-id').value       = id;
    document.getElementById('delete-name').textContent = name;
    document.getElementById('delete-modal').classList.remove('hidden');
}
// Modal dışına tıklayınca kapat
['create-modal','edit-modal','delete-modal'].forEach(id => {
    const el = document.getElementById(id);
    if (el) {
        el.addEventListener('click', function(e) {
            if (e.target === this) this.classList.add('hidden');
        });
    }
});
</script>
</body>
</html>
