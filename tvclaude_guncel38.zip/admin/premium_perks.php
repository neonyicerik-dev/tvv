<?php
// ============================================================
// NeonTV - Admin: Premium Erken Erişim (videoyu belli tarihe kadar yalnızca premiuma aç)
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/store.php';

requireAdmin(['editor', 'moderator', 'superadmin']);
$db = new Supabase();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken(input('csrf_token'))) { setFlash('error', 'Güvenlik doğrulaması başarısız.'); redirect(APP_URL . '/admin/premium_perks.php'); }
    $id = trim(input('id')); requireUuid($id, 'Video');
    $until = trim(input('until'));
    if (input('action') === 'clear' || $until === '') {
        $db->update('videos', ['premium_only_until' => null], 'id=eq.' . $id, true);
        setFlash('success', 'Erken erişim kaldırıldı.');
    } else {
        $ts = strtotime($until);
        if (!$ts || $ts < time()) { setFlash('error', 'Gelecekte bir tarih seçin.'); redirect(APP_URL . '/admin/premium_perks.php'); }
        $r = $db->update('videos', ['premium_only_until' => gmdate('c', $ts)], 'id=eq.' . $id, true);
        setFlash(($r['status'] ?? 500) < 400 ? 'success' : 'error', ($r['status'] ?? 500) < 400 ? 'Erken erişim ayarlandı.' : 'Kaydedilemedi (SQL güncellemesi çalıştırıldı mı?).');
    }
    redirect(APP_URL . '/admin/premium_perks.php');
}

$videos = $db->select('videos', 'select=id,title,premium_only_until,status&order=created_at.desc&limit=100', true)['data'] ?? [];
$adminTitle = 'Premium Erken Erişim';
$adminSub   = 'Seçilen tarihe kadar video yalnızca Premium üyelere açılır';
include __DIR__ . '/_top.php';
?>
<div class="rounded-2xl divide-y divide-white/5" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
<?php foreach ($videos as $v): $act = !empty($v['premium_only_until']) && strtotime($v['premium_only_until']) > time(); ?>
    <form method="POST" class="p-4 flex flex-wrap items-center gap-3">
        <?= csrfField() ?><input type="hidden" name="id" value="<?= e($v['id']) ?>">
        <div class="flex-1 min-w-[200px]"><p class="text-sm text-white truncate"><?= e($v['title']) ?></p>
            <?php if ($act): ?><p class="text-xs" style="color:#ffd76a"><i class="fa-solid fa-crown mr-1"></i><?= e(date('d.m.Y H:i', strtotime($v['premium_only_until']))) ?>'e kadar premium</p><?php endif; ?></div>
        <input type="datetime-local" name="until" class="bg-black/30 border border-gray-800 rounded-xl py-2 px-3 text-white text-sm">
        <button name="action" value="set" class="px-4 py-2 rounded-xl text-sm font-semibold text-black" style="background:#ffd76a">Ayarla</button>
        <?php if ($act): ?><button name="action" value="clear" class="px-3 py-2 rounded-xl text-sm text-gray-400 hover:text-red-400">Kaldır</button><?php endif; ?>
    </form>
<?php endforeach; ?>
</div>
<?php include __DIR__ . '/_bottom.php'; ?>
