<?php
// ============================================================
// NeonTV - Admin Araçlar Sayfası
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
requireAdmin();

$db = new Supabase();
$pageTitle = 'Araçlar';

?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Araçlar | NeonTV Admin</title>
    <meta name="robots" content="noindex,nofollow">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body { font-family: 'Outfit', sans-serif; background: #070711; color: #fff; }
        .input-field {
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(255,255,255,0.1);
            transition: all 0.2s;
            width: 100%;
        }
        .input-field:focus {
            border-color: rgba(0,245,255,0.5);
            box-shadow: 0 0 0 3px rgba(0,245,255,0.08);
            outline: none;
        }
        .neon-btn {
            background: linear-gradient(135deg, #00f5ff, #bf00ff);
            color: #000;
            font-weight: 700;
            transition: all 0.3s;
        }
        .neon-btn:hover { transform: scale(1.02); box-shadow: 0 0 25px rgba(0,245,255,0.3); }
        .neon-btn:disabled { opacity: 0.5; transform: none; cursor: not-allowed; }
        .tool-card {
            background: #13131f;
            border: 1px solid rgba(255,255,255,0.08);
            border-radius: 1rem;
            padding: 1.5rem;
        }
    </style>
</head>
<body class="min-h-screen lg:flex">

<?php include __DIR__ . '/sidebar.php'; ?>

<div class="flex-1 flex flex-col min-w-0 overflow-x-hidden">

    <!-- ===== TOP BAR ===== -->
    <header class="flex items-center gap-3 px-4 sm:px-6 py-4 sticky top-0 z-20"
            style="background:rgba(7,7,17,0.9);backdrop-filter:blur(20px);border-bottom:1px solid rgba(255,255,255,0.06);">
        <button onclick="openSidebar()" class="lg:hidden p-2 rounded-xl text-gray-400 hover:text-white transition-colors"
                style="background:rgba(255,255,255,0.06);">
            <i class="fa-solid fa-bars text-sm"></i>
        </button>
        <div class="min-w-0">
            <h1 class="text-lg sm:text-xl font-bold text-white truncate"><?= e($pageTitle) ?></h1>
            <p class="text-xs text-gray-500 hidden sm:block">Video ve Metin Araçları</p>
        </div>
    </header>

    <!-- ===== ANA İÇERİK ===== -->
    <main class="flex-1 p-4 sm:p-6 overflow-auto">
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 max-w-7xl mx-auto">
            
            <!-- Video Araçları -->
            <div class="space-y-6">
                
                <!-- Video Boyut Düşürücü -->
                <div class="tool-card" style="border-color:rgba(0,245,255,0.2);">
                    <div class="flex items-center gap-3 mb-4">
                        <div class="w-10 h-10 rounded-xl flex items-center justify-center" style="background:rgba(0,245,255,0.1);">
                            <i class="fa-solid fa-compress text-lg" style="color:#00f5ff;"></i>
                        </div>
                        <div>
                            <h2 class="text-lg font-bold text-white">Video Boyut Düşürücü</h2>
                            <p class="text-xs text-gray-500">Cloudinary üzerindeki videoların çözünürlüğünü ve kalitesini düşürerek link oluştur</p>
                        </div>
                    </div>
                    
                    <div class="space-y-4">
                        <div>
                            <label class="block text-xs font-semibold text-gray-400 mb-2">Cloudinary Public ID</label>
                            <input type="text" id="compress-id" placeholder="neontv/videos/ornek_id" 
                                   class="input-field px-4 py-2.5 rounded-xl text-sm text-white placeholder-gray-600">
                        </div>
                        
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="block text-xs font-semibold text-gray-400 mb-2">Çözünürlük</label>
                                <select id="compress-res" class="input-field px-4 py-2.5 rounded-xl text-sm text-white">
                                    <option value="auto">Otomatik</option>
                                    <option value="720">720p (HD)</option>
                                    <option value="480">480p (SD)</option>
                                    <option value="360">360p</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-xs font-semibold text-gray-400 mb-2">Kalite</label>
                                <select id="compress-quality" class="input-field px-4 py-2.5 rounded-xl text-sm text-white">
                                    <option value="auto">Otomatik</option>
                                    <option value="auto:eco">Ekonomik (Düşük Boyut)</option>
                                    <option value="auto:low">Düşük</option>
                                </select>
                            </div>
                        </div>
                        
                        <button onclick="generateCompressedLink()" class="w-full py-3 rounded-xl text-sm font-bold text-black" style="background:linear-gradient(135deg,#00f5ff,#00c8d4);">
                            Sıkıştırılmış Link Oluştur
                        </button>
                        
                        <div id="compress-result" class="hidden mt-4 p-4 rounded-xl" style="background:rgba(255,255,255,0.05);border:1px solid rgba(0,245,255,0.3);">
                            <p class="text-xs text-gray-400 mb-2">Sıkıştırılmış Video Linki:</p>
                            <div class="flex gap-2">
                                <input type="text" id="compress-link" readonly class="input-field flex-1 px-3 py-2 rounded-lg text-xs text-white" onclick="this.select()">
                                <a id="compress-download" href="#" target="_blank" class="px-4 py-2 rounded-lg text-xs font-bold text-white flex items-center justify-center" style="background:#00f5ff;color:#000;">
                                    <i class="fa-solid fa-download"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Metin Araçları -->
            <div class="space-y-6">
                
                <!-- AI Yazım Hatası Düzeltme -->
                <div class="tool-card" style="border-color:rgba(191,0,255,0.2);">
                    <div class="flex items-center gap-3 mb-4">
                        <div class="w-10 h-10 rounded-xl flex items-center justify-center" style="background:rgba(191,0,255,0.1);">
                            <i class="fa-solid fa-spell-check text-lg" style="color:#bf00ff;"></i>
                        </div>
                        <div class="flex-1">
                            <h2 class="text-lg font-bold text-white flex items-center gap-2">
                                AI Yazım Hatası Düzeltme
                                <span class="text-[10px] px-2 py-0.5 rounded-full font-medium" style="background:rgba(191,0,255,0.15);color:#bf00ff;">Gemini</span>
                            </h2>
                            <p class="text-xs text-gray-500">Video açıklamalarındaki yazım yanlışlarını düzeltin</p>
                        </div>
                    </div>
                    
                    <div class="space-y-4">
                        <div>
                            <label class="block text-xs font-semibold text-gray-400 mb-2">Bozuk / Hatalı Metin</label>
                            <textarea id="spell-input" rows="5" placeholder="Düzeltilecek metni buraya yapıştırın..." 
                                      class="input-field px-4 py-3 rounded-xl text-sm text-white placeholder-gray-600 resize-none"></textarea>
                        </div>
                        
                        <button id="spell-btn" onclick="fixSpelling()" class="w-full py-3 rounded-xl text-sm font-bold text-black" style="background:linear-gradient(135deg,#bf00ff,#ff007a);">
                            <i class="fa-solid fa-wand-magic-sparkles mr-2"></i>Metni Düzelt
                        </button>
                        
                        <div id="spell-result" class="hidden mt-4">
                            <label class="block text-xs font-semibold text-gray-400 mb-2">Düzeltilmiş Metin</label>
                            <div class="relative">
                                <textarea id="spell-output" rows="5" readonly
                                          class="input-field px-4 py-3 rounded-xl text-sm text-white resize-none" style="border-color:rgba(191,0,255,0.4);"></textarea>
                                <button onclick="copySpellText()" class="absolute top-2 right-2 p-2 rounded-lg bg-gray-800 hover:bg-gray-700 text-gray-300 transition-colors" title="Kopyala">
                                    <i class="fa-regular fa-copy"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </main>
</div>

<script>
const CLOUD_NAME = '<?= e(CLOUDINARY_CLOUD_NAME) ?>';
const APP_URL_JS = '<?= APP_URL ?>';

// Video Boyut Düşürücü
function generateCompressedLink() {
    const pubId = document.getElementById('compress-id').value.trim();
    if (!pubId) { alert('Lütfen Cloudinary Public ID girin.'); return; }
    
    const res = document.getElementById('compress-res').value;
    const quality = document.getElementById('compress-quality').value;
    
    let transform = [];
    if (res !== 'auto') transform.push(`h_${res},c_limit`);
    if (quality !== 'auto') transform.push(`q_${quality}`);
    transform.push('f_auto'); // Otomatik format (webm vb.)
    
    const transformStr = transform.join(',');
    const url = `https://res.cloudinary.com/${CLOUD_NAME}/video/upload/${transformStr}/${pubId}.mp4`;
    
    document.getElementById('compress-link').value = url;
    document.getElementById('compress-download').href = url;
    document.getElementById('compress-result').classList.remove('hidden');
}

// AI Yazım Hatası Düzeltici
async function fixSpelling() {
    const text = document.getElementById('spell-input').value.trim();
    if (!text) { alert('Lütfen bir metin girin.'); return; }
    
    const btn = document.getElementById('spell-btn');
    const oldHtml = btn.innerHTML;
    
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin mr-2"></i>Düzeltiliyor...';
    document.getElementById('spell-result').classList.add('hidden');
    
    try {
        const res = await fetch(APP_URL_JS + '/api/ai.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'fix_spelling', text: text })
        });
        
        const data = await res.json();
        
        if (data.success && data.data && data.data.corrected_text) {
            document.getElementById('spell-output').value = data.data.corrected_text;
            document.getElementById('spell-result').classList.remove('hidden');
        } else {
            alert('Hata: ' + (data.message || 'Metin düzeltilemedi.'));
        }
    } catch (e) {
        alert('Bağlantı hatası: ' + e.message);
    }
    
    btn.disabled = false;
    btn.innerHTML = oldHtml;
}

function copySpellText() {
    const text = document.getElementById('spell-output').value;
    navigator.clipboard.writeText(text).then(() => {
        alert('Düzeltilmiş metin kopyalandı!');
    });
}
</script>

</body>
</html>
