<?php
// NeonTV - Admin: NeTvYZ kullanım paneli
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/store.php';
require_once __DIR__ . '/../includes/gemini.php';
requireAdmin('superadmin');
$db = new Supabase();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken(input('csrf_token'))) { setFlash('error', 'Güvenlik doğrulaması başarısız.'); redirect(APP_URL . '/admin/ai_usage.php'); }
    if (input('action') === 'test') {
        $t0 = microtime(true);
        $r = geminiCall(['contents' => [['role' => 'user', 'parts' => [['text' => 'Sadece "evet" yaz.']]]],
            'generationConfig' => ['maxOutputTokens' => 64] + (str_contains(GEMINI_MODEL, '2.5-flash') ? ['thinkingConfig' => ['thinkingBudget' => 0]] : [])], null, 20);
        $_SESSION['ai_test'] = ['ok' => $r['http'] === 200 && $r['text'] !== '', 'http' => $r['http'], 'err' => $r['err'], 'finish' => $r['finish'], 'block' => $r['block'] ?? '', 'text' => $r['text'], 'ms' => (int)round((microtime(true) - $t0) * 1000), 'at' => date('d.m.Y H:i:s')];
        redirect(APP_URL . '/admin/ai_usage.php');
    }
    if (input('action') === 'clear_summaries') { $db->delete('video_summaries', 'video_id=not.is.null', true); setFlash('success', 'Özet önbelleği temizlendi.'); }
    redirect(APP_URL . '/admin/ai_usage.php');
}

$test = $_SESSION['ai_test'] ?? null; unset($_SESSION['ai_test']);
$since = gmdate('c', time() - 30 * 86400);
$r = $db->select('ai_chat_messages', 'select=id,user_id,role,content,refused,rating,created_at&created_at=gte.' . urlencode($since) . '&order=created_at.desc&limit=2000', true);
$lastMsgs = array_slice(is_array($r['data'] ?? null) ? $r['data'] : [], 0, 24);
$msgs = is_array($r['data'] ?? null) ? $r['data'] : [];
$q = 0; $bot = 0; $ref = 0; $up = 0; $down = 0; $users = []; $perDay = []; $words = []; $bad = []; $recent = [];
$stop = array_flip(['bir','bu','ve','ile','için','mi','mı','mu','mü','de','da','ne','var','ben','bana','bir','daha','çok','gibi','video','videolar','öner','önerir','misin','musun']);
foreach ($msgs as $m) {
    $d = substr($m['created_at'], 0, 10);
    if ($m['role'] === 'user') {
        $q++; $users[$m['user_id']] = 1; $perDay[$d] = ($perDay[$d] ?? 0) + 1;
        foreach (preg_split('/[^\p{L}\p{N}]+/u', mb_strtolower($m['content']), -1, PREG_SPLIT_NO_EMPTY) as $w) {
            if (mb_strlen($w) < 3 || isset($stop[$w])) continue; $words[$w] = ($words[$w] ?? 0) + 1;
        }
        if (count($recent) < 25) $recent[] = $m;
    } else {
        $bot++; if (!empty($m['refused'])) $ref++;
        if ((int)$m['rating'] === 1) $up++;
        if ((int)$m['rating'] === -1) { $down++; if (count($bad) < 15) $bad[] = $m; }
    }
}
arsort($words); $words = array_slice($words, 0, 15, true);
ksort($perDay);
$sum = $db->count('video_summaries', '', true);

$adminTitle = 'NeTvYZ Kullanımı';
$adminSub   = 'Son 30 gün · yapay zeka sohbet istatistikleri';
include __DIR__ . '/_top.php';
$e = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
?>
<div class="p-4 rounded-xl mb-6" style="background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08)">
    <div class="flex flex-wrap items-center gap-3">
        <h3 class="font-bold text-white">Gemini bağlantısı</h3>
        <span class="text-xs text-gray-400">Model: <?= $e(GEMINI_MODEL) ?> · Anahtar: …<?= $e(substr(GEMINI_API_KEY, -4)) ?></span>
        <form method="post" class="ml-auto"><input type="hidden" name="csrf_token" value="<?= $e(generateCsrfToken()) ?>"><input type="hidden" name="action" value="test">
            <button class="px-3 py-1.5 rounded-lg text-sm text-white" style="background:rgba(0,245,255,0.2)">Şimdi test et</button></form>
    </div>
    <?php if ($test): ?>
    <div class="mt-3 text-sm" style="color:<?= $test['ok'] ? '#4ade80' : '#ff5f7a' ?>">
        <?= $test['ok'] ? '✅ Gemini yanıt veriyor' : '❌ Gemini yanıt vermedi' ?> · <?= (int)$test['ms'] ?> ms · HTTP <?= (int)$test['http'] ?> · <?= $e($test['at']) ?>
        <div class="text-xs text-gray-300 mt-1">Yanıt: “<?= $e($test['text']) ?>” <?php if ($test['finish']): ?>· finish: <?= $e($test['finish']) ?><?php endif; ?> <?php if ($test['block']): ?>· engel: <?= $e($test['block']) ?><?php endif; ?> <?php if ($test['err']): ?>· hata: <?= $e($test['err']) ?><?php endif; ?></div>
    </div>
    <?php else: ?><p class="text-xs text-gray-500 mt-2">“Şimdi test et” ile Gemini'ye canlı bir istek gönderilir ve sonucu burada görürsün.</p><?php endif; ?>
</div>
<div class="grid grid-cols-2 md:grid-cols-5 gap-3 mb-6">
<?php foreach ([['Soru', $q], ['Kullanıcı', count($users)], ['Reddedilen', $ref], ['👍', $up], ['👎', $down]] as $c): ?>
    <div class="p-4 rounded-xl" style="background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08)">
        <div class="text-xs text-gray-400"><?= $c[0] ?></div><div class="text-2xl font-bold text-white"><?= (int)$c[1] ?></div>
    </div>
<?php endforeach; ?>
</div>
<div class="grid md:grid-cols-2 gap-6">
    <div class="p-4 rounded-xl" style="background:rgba(255,255,255,0.04)">
        <h3 class="font-bold text-white mb-2">Günlük soru</h3>
        <?php foreach ($perDay as $d => $n): ?><div class="flex items-center gap-2 text-xs text-gray-300"><span class="w-20"><?= $e($d) ?></span><div style="height:8px;background:#bf00ff;width:<?= min(100, $n * 100 / max($perDay)) ?>%;border-radius:4px"></div><span><?= $n ?></span></div><?php endforeach; ?>
        <?php if (!$perDay): ?><p class="text-sm text-gray-500">Veri yok.</p><?php endif; ?>
    </div>
    <div class="p-4 rounded-xl" style="background:rgba(255,255,255,0.04)">
        <h3 class="font-bold text-white mb-2">Sık geçen kelimeler</h3>
        <?php foreach ($words as $w => $n): ?><span class="inline-block text-xs px-2 py-1 m-1 rounded-full text-gray-200" style="background:rgba(191,0,255,0.15)"><?= $e($w) ?> · <?= $n ?></span><?php endforeach; ?>
    </div>
    <div class="p-4 rounded-xl" style="background:rgba(255,255,255,0.04)">
        <h3 class="font-bold text-white mb-2">Son sorular</h3>
        <?php foreach ($recent as $m): ?><p class="text-xs text-gray-300 py-1 border-b border-white/5"><span class="text-gray-500"><?= $e(substr($m['created_at'], 5, 11)) ?></span> <?= $e(mb_substr($m['content'], 0, 140)) ?></p><?php endforeach; ?>
    </div>
    <div class="p-4 rounded-xl" style="background:rgba(255,255,255,0.04)">
        <h3 class="font-bold text-white mb-2">👎 alan yanıtlar</h3>
        <?php foreach ($bad as $m): ?><p class="text-xs text-gray-300 py-1 border-b border-white/5"><?= $e(mb_substr($m['content'], 0, 160)) ?></p><?php endforeach; ?>
        <?php if (!$bad): ?><p class="text-sm text-gray-500">Yok.</p><?php endif; ?>
    </div>
</div>
<div class="p-4 rounded-xl mt-6" style="background:rgba(255,255,255,0.04)">
    <h3 class="font-bold text-white mb-2">Son sohbet kayıtları (Gemini'nin gerçek yanıtları)</h3>
    <?php foreach ($lastMsgs as $m): ?>
    <p class="text-xs py-1 border-b border-white/5 <?= $m['role'] === 'bot' ? 'text-cyan-200' : 'text-gray-300' ?>">
        <span class="text-gray-500"><?= $e(substr($m['created_at'], 5, 11)) ?></span>
        <b><?= $m['role'] === 'bot' ? 'NeTvYZ' : 'Kullanıcı' ?></b><?= !empty($m['refused']) ? ' <span style="color:#ff5f7a">[reddedildi]</span>' : '' ?>: <?= $e(mb_substr($m['content'], 0, 220)) ?>
    </p>
    <?php endforeach; if (!$lastMsgs): ?><p class="text-sm text-gray-500">Kayıt yok.</p><?php endif; ?>
</div>
<form method="post" class="mt-6 flex items-center gap-3">
    <input type="hidden" name="csrf_token" value="<?= $e(generateCsrfToken()) ?>"><input type="hidden" name="action" value="clear_summaries">
    <span class="text-sm text-gray-400">Önbellekte <?= (int)$sum ?> altyazı özeti var.</span>
    <button class="px-3 py-1.5 rounded-lg text-sm text-white" style="background:rgba(255,0,60,0.3)" onclick="return confirm('Özet önbelleği silinsin mi?')">Önbelleği temizle</button>
</form>
<?php include __DIR__ . '/_bottom.php'; ?>
