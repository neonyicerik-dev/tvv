<?php
// NeonTV - Admin: Sunucu sağlık sayfası (disk, PHP, Supabase gecikmesi, hata sayısı, yazma izinleri)
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
requireAdmin('superadmin');
$root = dirname(__DIR__);
$e = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');

// Supabase gecikmesi: 3 hafif sorgu
$db = new Supabase(); $lat = []; $dbOk = true; $dbErr = '';
for ($i = 0; $i < 3; $i++) {
    $t = microtime(true); $r = $db->select('site_settings', 'select=key&limit=1', true);
    $lat[] = (int)round((microtime(true) - $t) * 1000);
    if (($r['status'] ?? 0) !== 200) { $dbOk = false; $dbErr = (string)($r['error'] ?? 'bilinmiyor'); }
}
$latAvg = (int)round(array_sum($lat) / max(1, count($lat)));

// Disk
$free = @disk_free_space($root) ?: 0; $total = @disk_total_space($root) ?: 0; $usedPct = $total ? (int)round(($total - $free) / $total * 100) : 0;
// Önbellek
$cn = 0; $cb = 0; foreach (glob($root . '/logs/cache/*') ?: [] as $f) { if (is_file($f)) { $cn++; $cb += filesize($f); } }
// Son 24 saat hata
$err24 = 0; $ef = $root . '/logs/app_errors.log';
if (is_file($ef) && filesize($ef) < 5 * 1048576) foreach (file($ef, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $ln) { $j = json_decode($ln, true); if (is_array($j) && !empty($j['t']) && strtotime($j['t']) > time() - 86400) $err24++; }
$slow24 = 0; $sf = function_exists('neonSlowLogPath') ? neonSlowLogPath() : '';
if ($sf && is_file($sf) && filesize($sf) < 6 * 1048576) foreach (file($sf, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $ln) { $j = json_decode($ln, true); if (is_array($j) && !empty($j['t']) && strtotime($j['t']) > time() - 86400) $slow24++; }
$op = function_exists('opcache_get_status') ? @opcache_get_status(false) : null;
$fmt = function (int $b) { $u = ['B','KB','MB','GB','TB']; $i = 0; $v = $b; while ($v >= 1024 && $i < 4) { $v /= 1024; $i++; } return round($v, $i ? 1 : 0) . ' ' . $u[$i]; };

$checks = [];
$add = function (string $name, string $val, string $lvl = 'ok', string $hint = '') use (&$checks) { $checks[] = [$name, $val, $lvl, $hint]; };
$add('Supabase bağlantısı', $dbOk ? 'Çalışıyor' : 'HATA: ' . $dbErr, $dbOk ? 'ok' : 'bad', $dbOk ? '' : 'includes/secrets.php içindeki SUPABASE_URL / anahtarları kontrol edin.');
$add('Supabase gecikmesi', implode(' / ', $lat) . ' ms (ort. ' . $latAvg . ')', $latAvg > 400 ? 'bad' : ($latAvg > 150 ? 'warn' : 'ok'), $latAvg > 150 ? 'Yüksek: Supabase bölgesini sunucuya yakın seçin.' : '');
$add('Disk', $fmt((int)$free) . ' boş / ' . $fmt((int)$total) . ' (%' . $usedPct . ' dolu)', $usedPct >= 92 ? 'bad' : ($usedPct >= 80 ? 'warn' : 'ok'));
$add('Çevrimiçi (son 5 dk)', (string)nvOnlineCount(300), 'ok');
$add('Son 24 saat hata', (string)$err24, $err24 > 50 ? 'bad' : ($err24 > 0 ? 'warn' : 'ok'), 'Ayrıntı: Hata Günlüğü');
$add('Son 24 saat yavaş istek', (string)$slow24, $slow24 > 100 ? 'warn' : 'ok', 'Ayrıntı: Yavaş İstekler');
$add('PHP', PHP_VERSION . ' · bellek sınırı ' . ini_get('memory_limit') . ' · max_execution_time ' . ini_get('max_execution_time'), 'ok');
$add('OPcache', $op && !empty($op['opcache_enabled']) ? 'Açık (' . (int)round($op['opcache_statistics']['opcache_hit_rate'] ?? 0) . '% isabet)' : 'KAPALI', $op && !empty($op['opcache_enabled']) ? 'ok' : 'warn', 'Kapalıysa php.ini: opcache.enable=1');
foreach (['curl', 'gd', 'mbstring', 'openssl'] as $x) $add('PHP uzantısı: ' . $x, extension_loaded($x) ? 'Yüklü' : 'EKSİK', extension_loaded($x) ? 'ok' : 'bad');
foreach (['logs', 'logs/cache', 'assets/profiles'] as $d) {
    $p = $root . '/' . $d; if (!is_dir($p)) @mkdir($p, 0755, true);
    $add('Yazma izni: ' . $d, is_writable($p) ? 'Yazılabilir' : 'YAZILAMIYOR', is_writable($p) ? 'ok' : 'bad', is_writable($p) ? '' : 'chown -R www-data:www-data ' . $d);
}
$add('Önbellek', $cn . ' dosya · ' . $fmt($cb), 'ok');
$add('Yapay zekâ modeli', GEMINI_MODEL, 'ok');

$adminTitle = 'Sunucu Sağlığı'; $adminSub = date('d.m.Y H:i:s');
include __DIR__ . '/_top.php';
$col = ['ok' => '#39ff14', 'warn' => '#ffd76a', 'bad' => '#ff4d6d'];
?>
<div class="rounded-xl overflow-hidden" style="background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08)">
<?php foreach ($checks as [$n, $v, $l, $h]): ?>
  <div class="flex items-start gap-3 px-4 py-3 border-b border-white/5 text-sm">
    <span class="mt-1.5 w-2.5 h-2.5 rounded-full shrink-0" style="background:<?= $col[$l] ?>"></span>
    <div class="min-w-0"><div class="text-white font-semibold"><?= $e($n) ?></div><div class="text-gray-300 break-words"><?= $e($v) ?></div><?php if ($h): ?><div class="text-xs text-gray-500 mt-0.5"><?= $e($h) ?></div><?php endif; ?></div>
  </div>
<?php endforeach; ?>
</div>
<?php include __DIR__ . '/_bottom.php'; ?>
