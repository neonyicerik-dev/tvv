<?php
// NeonTV - Admin: İstatistik paneli (30 gün izlenme/kullanıcı/yorum/AI, hata, popüler video, aranan kelimeler, saatlik dağılım)
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
requireAdmin('superadmin');
$db = new Supabase();
$N = 30; $since = gmdate('Y-m-d', time() - ($N - 1) * 86400);
$days = [];
for ($i = 0; $i < $N; $i++) $days[gmdate('Y-m-d', strtotime($since) + $i * 86400)] = ['v' => 0, 'ip' => [], 'u' => 0, 'c' => 0, 'a' => 0, 'e' => 0];
$rows = fn($t, $sel) => (function () use ($db, $t, $sel, $since) { $r = $db->select($t, 'created_at=gte.' . $since . 'T00:00:00Z&select=' . $sel . '&limit=50000', true)['data'] ?? []; return is_array($r) ? $r : []; })();

$hours = array_fill(0, 24, 0); $vidCount = [];
$weekAgo = time() - 7 * 86400;
foreach ($rows('views_log', 'created_at,user_ip,video_id') as $r) {
    $d = substr($r['created_at'], 0, 10); $ts = strtotime($r['created_at']);
    if (isset($days[$d])) { $days[$d]['v']++; if (!empty($r['user_ip'])) $days[$d]['ip'][$r['user_ip']] = 1; }
    if ($ts >= $weekAgo) { $hours[(int)(new DateTime('@' . $ts))->setTimezone(new DateTimeZone('Europe/Istanbul'))->format('G')]++; $vidCount[$r['video_id']] = ($vidCount[$r['video_id']] ?? 0) + 1; }
}
foreach ($rows('profiles', 'created_at') as $r) { $d = substr($r['created_at'], 0, 10); if (isset($days[$d])) $days[$d]['u']++; }
foreach ($rows('comments', 'created_at') as $r) { $d = substr($r['created_at'], 0, 10); if (isset($days[$d])) $days[$d]['c']++; }
$aiRows = $db->select('ai_chat_messages', 'role=eq.user&created_at=gte.' . $since . 'T00:00:00Z&select=created_at&limit=50000', true)['data'] ?? [];
foreach (is_array($aiRows) ? $aiRows : [] as $r) { $d = substr($r['created_at'], 0, 10); if (isset($days[$d])) $days[$d]['a']++; }

// Hata günlüğü (logs/app_errors.log, son 30 gün)
$errTotal = 0; $errTop = [];
$f = dirname(__DIR__) . '/logs/app_errors.log';
if (is_file($f) && filesize($f) < 5 * 1048576) {
    foreach (file($f, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $ln) {
        $j = json_decode($ln, true); if (!is_array($j) || empty($j['t'])) continue;
        $d = substr($j['t'], 0, 10); if (!isset($days[$d])) continue;
        $days[$d]['e']++; $errTotal++;
        $k = mb_substr(($j['lv'] ?? '') . ' · ' . ($j['at'] ?? ''), 0, 90); $errTop[$k] = ($errTop[$k] ?? 0) + 1;
    }
}
arsort($errTop); $errTop = array_slice($errTop, 0, 8, true);

arsort($vidCount); $vidCount = array_slice($vidCount, 0, 10, true);
$titles = [];
if ($vidCount) { $r = $db->select('videos', 'id=in.(' . implode(',', array_map('rawurlencode', array_keys($vidCount))) . ')&select=id,title', true)['data'] ?? []; foreach ($r as $v) $titles[$v['id']] = $v['title']; }

$sl = $db->select('search_log', 'created_at=gte.' . $since . 'T00:00:00Z&select=q,results&limit=20000', true)['data'] ?? [];
$sq = []; $sz = [];
foreach (is_array($sl) ? $sl : [] as $r) { $q = (string)$r['q']; $sq[$q] = ($sq[$q] ?? 0) + 1; if ((int)$r['results'] === 0) $sz[$q] = ($sz[$q] ?? 0) + 1; }
arsort($sq); arsort($sz); $sq = array_slice($sq, 0, 15, true); $sz = array_slice($sz, 0, 10, true);

$pv = array_sum(array_column($days, 'v')); $ae = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
$adminTitle = 'İstatistikler'; $adminSub = 'Son 30 gün';
include __DIR__ . '/_top.php';
$card = 'p-4 rounded-xl'; $cs = 'background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08)';
?>
<div class="grid grid-cols-2 md:grid-cols-5 gap-3 mb-6">
<?php foreach ([['İzlenme', $pv], ['Yeni üye', array_sum(array_column($days, 'u'))], ['Yorum', array_sum(array_column($days, 'c'))], ['AI sorusu', array_sum(array_column($days, 'a'))], ['Hata kaydı', $errTotal]] as $c): ?>
    <div class="<?= $card ?>" style="<?= $cs ?>"><div class="text-xs text-gray-400"><?= $c[0] ?></div><div class="text-2xl font-bold text-white"><?= (int)$c[1] ?></div></div>
<?php endforeach; ?>
</div>
<div class="grid lg:grid-cols-2 gap-6 mb-6">
    <div class="<?= $card ?>" style="<?= $cs ?>"><h3 class="font-bold text-white mb-2">Günlük izlenme ve tekil izleyici</h3><canvas id="c1" height="150"></canvas></div>
    <div class="<?= $card ?>" style="<?= $cs ?>"><h3 class="font-bold text-white mb-2">Üye / yorum / AI sorusu</h3><canvas id="c2" height="150"></canvas></div>
    <div class="<?= $card ?>" style="<?= $cs ?>"><h3 class="font-bold text-white mb-2">Hata sayısı (günlük)</h3><canvas id="c3" height="150"></canvas></div>
    <div class="<?= $card ?>" style="<?= $cs ?>"><h3 class="font-bold text-white mb-2">Saatlik izlenme (son 7 gün, TSİ)</h3><canvas id="c4" height="150"></canvas></div>
</div>
<div class="grid lg:grid-cols-2 gap-6">
    <div class="<?= $card ?>" style="<?= $cs ?>"><h3 class="font-bold text-white mb-2">En çok izlenen (7 gün)</h3>
        <?php foreach ($vidCount as $id => $n): ?><div class="flex justify-between text-sm py-1 text-gray-300"><span class="truncate pr-3"><?= $ae($titles[$id] ?? $id) ?></span><span class="text-cyan-400"><?= (int)$n ?></span></div><?php endforeach; if (!$vidCount) echo '<p class="text-sm text-gray-500">Veri yok.</p>'; ?></div>
    <div class="<?= $card ?>" style="<?= $cs ?>"><h3 class="font-bold text-white mb-2">En çok aranan</h3>
        <?php foreach ($sq as $q => $n): ?><div class="flex justify-between text-sm py-1 text-gray-300"><span class="truncate pr-3"><?= $ae($q) ?></span><span class="text-cyan-400"><?= (int)$n ?></span></div><?php endforeach; if (!$sq) echo '<p class="text-sm text-gray-500">Henüz arama kaydı yok (SQL çalıştırıldı mı?).</p>'; ?></div>
    <div class="<?= $card ?>" style="<?= $cs ?>"><h3 class="font-bold text-white mb-2">Sonuç bulunamayan aramalar</h3>
        <?php foreach ($sz as $q => $n): ?><div class="flex justify-between text-sm py-1 text-gray-300"><span class="truncate pr-3"><?= $ae($q) ?></span><span class="text-pink-400"><?= (int)$n ?></span></div><?php endforeach; if (!$sz) echo '<p class="text-sm text-gray-500">Yok.</p>'; ?></div>
    <div class="<?= $card ?>" style="<?= $cs ?>"><h3 class="font-bold text-white mb-2">En sık hatalar</h3>
        <?php foreach ($errTop as $k => $n): ?><div class="flex justify-between text-sm py-1 text-gray-300"><span class="truncate pr-3"><?= $ae($k) ?></span><span class="text-pink-400"><?= (int)$n ?></span></div><?php endforeach; if (!$errTop) echo '<p class="text-sm text-gray-500">Hata kaydı yok 🎉</p>'; ?></div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<script>
const L = <?= json_encode(array_map(fn($d) => substr($d, 5), array_keys($days))) ?>;
const mk = (id, type, labels, sets) => new Chart(document.getElementById(id), { type, data: { labels, datasets: sets }, options: { responsive: true, plugins: { legend: { labels: { color: '#9ca3af' } } }, scales: { x: { ticks: { color: '#6b7280' }, grid: { color: 'rgba(255,255,255,.05)' } }, y: { beginAtZero: true, ticks: { color: '#6b7280' }, grid: { color: 'rgba(255,255,255,.05)' } } } } });
const ds = (label, data, color) => ({ label, data, borderColor: color, backgroundColor: color + '55', tension: .3, borderWidth: 2 });
mk('c1', 'line', L, [ds('İzlenme', <?= json_encode(array_column($days, 'v')) ?>, '#00f5ff'), ds('Tekil izleyici', <?= json_encode(array_map(fn($d) => count($d['ip']), array_values($days))) ?>, '#bf00ff')]);
mk('c2', 'line', L, [ds('Üye', <?= json_encode(array_column($days, 'u')) ?>, '#39ff14'), ds('Yorum', <?= json_encode(array_column($days, 'c')) ?>, '#ffd76a'), ds('AI', <?= json_encode(array_column($days, 'a')) ?>, '#ff007a')]);
mk('c3', 'bar', L, [ds('Hata', <?= json_encode(array_column($days, 'e')) ?>, '#ff5f7a')]);
mk('c4', 'bar', [...Array(24).keys()].map(h => h + ':00'), [ds('İzlenme', <?= json_encode(array_values($hours)) ?>, '#00f5ff')]);
</script>
<?php include __DIR__ . '/_bottom.php'; ?>
