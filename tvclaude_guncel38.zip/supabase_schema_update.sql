-- ============================================================
-- NeonTV - Yeni Özellikler İçin Supabase SQL Güncellemesi
-- Supabase SQL Editor'a yapıştırın ve çalıştırın
-- ============================================================

-- ============================================================
-- CHANNELS TABLE (Admin managed content creators)
-- ============================================================
CREATE TABLE IF NOT EXISTS public.channels (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT DEFAULT '',
    avatar_url TEXT,
    cover_url TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- RLS for Channels
ALTER TABLE public.channels ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public_read_channels" ON public.channels FOR SELECT USING (true);
CREATE POLICY "service_role_manage_channels" ON public.channels USING (true) WITH CHECK (true);

-- ============================================================
-- ALTER VIDEOS AND COMMENTS FOR NEW FEATURES
-- ============================================================
ALTER TABLE public.videos ADD COLUMN IF NOT EXISTS channel_id UUID REFERENCES public.channels(id) ON DELETE SET NULL;
ALTER TABLE public.comments ADD COLUMN IF NOT EXISTS parent_id UUID REFERENCES public.comments(id) ON DELETE CASCADE;

CREATE INDEX IF NOT EXISTS idx_videos_channel_id ON public.videos(channel_id);
CREATE INDEX IF NOT EXISTS idx_comments_parent_id ON public.comments(parent_id);
