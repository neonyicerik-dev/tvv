-- NeonTV features6: izleyici ısı çizgisi (en çok izlenen anlar). Tekrar çalıştırılabilir, RLS güvenli.
CREATE TABLE IF NOT EXISTS public.video_replay_heat (
    video_id uuid NOT NULL REFERENCES public.videos(id) ON DELETE CASCADE,
    bucket   smallint NOT NULL CHECK (bucket BETWEEN 0 AND 99),
    hits     bigint NOT NULL DEFAULT 0,
    PRIMARY KEY (video_id, bucket)
);
ALTER TABLE public.video_replay_heat ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.video_replay_heat FROM anon, authenticated;
GRANT ALL ON public.video_replay_heat TO service_role;

CREATE OR REPLACE FUNCTION public.add_replay_hits(p_video uuid, p_hits int[])
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE i int; n int;
BEGIN
    IF p_hits IS NULL THEN RETURN; END IF;
    FOR i IN 1..LEAST(100, COALESCE(array_length(p_hits, 1), 0)) LOOP
        n := LEAST(3, GREATEST(0, COALESCE(p_hits[i], 0)));
        IF n > 0 THEN
            INSERT INTO public.video_replay_heat (video_id, bucket, hits) VALUES (p_video, i - 1, n)
            ON CONFLICT (video_id, bucket) DO UPDATE SET hits = public.video_replay_heat.hits + EXCLUDED.hits;
        END IF;
    END LOOP;
END $$;
REVOKE ALL ON FUNCTION public.add_replay_hits(uuid, int[]) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.add_replay_hits(uuid, int[]) TO service_role;
