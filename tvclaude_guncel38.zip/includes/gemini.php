<?php
// ============================================================
// NeonTV - Gemini çağrı yardımcısı (normal ve akışlı/streaming)
// ============================================================
require_once __DIR__ . '/config.php';

/** Günlüklerde API anahtarını gizle */
function geminiRedact(string $s): string {
    if (defined('GEMINI_API_KEY') && GEMINI_API_KEY !== '') $s = str_replace(GEMINI_API_KEY, '***', $s);
    return preg_replace('/([?&]key=)[^&\s"\']+/i', '$1***', $s);
}

/** Başarısız Gemini çağrısını (curl hatası, HTTP kodu, Google hata gövdesi) sunucu günlüğüne yazar; anahtar yazılmaz */
function geminiLogFailure(string $where, $ch, $response, int $http): void {
    $err = curl_error($ch); $errno = curl_errno($ch);
    if ($http === 200 && !$err) return;
    $body = is_string($response) ? substr(preg_replace('/\s+/', ' ', $response), 0, 400) : '';
    $msg = geminiRedact('[Gemini] ' . $where . ' HTTP ' . $http . ($errno ? ' curl#' . $errno . ' ' . $err : '') . ($body !== '' ? ' ' . $body : ''));
    error_log($msg);
    if (function_exists('neonLogError')) neonLogError('WARNING', $msg, __FILE__, __LINE__);
}

/**
 * @param array         $payload  Gemini isteği
 * @param callable|null $onDelta  Akışlı modda her metin parçası için çağrılır (function(string $text))
 * @return array ['text'=>string, 'finish'=>string, 'http'=>int, 'err'=>string]
 */
function geminiCall(array $payload, ?callable $onDelta = null, int $timeout = 40): array {
    $stream = $onDelta !== null;
    $url = GEMINI_API_BASE . GEMINI_MODEL . ($stream ? ':streamGenerateContent?alt=sse&key=' : ':generateContent?key=') . GEMINI_API_KEY;
    $ch = curl_init();
    $text = ''; $finish = ''; $block = ''; $buf = ''; $rawHead = '';

    $opts = [
        CURLOPT_URL            => $url,
        CURLOPT_POST           => true,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_TIMEOUT        => $timeout,
        CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
    ];
    if (defined('CA_BUNDLE_PATH') && CA_BUNDLE_PATH !== '' && file_exists(CA_BUNDLE_PATH)) $opts[CURLOPT_CAINFO] = CA_BUNDLE_PATH;
    elseif (file_exists(__DIR__ . '/cacert.pem')) $opts[CURLOPT_CAINFO] = __DIR__ . '/cacert.pem';

    $handle = function (array $j) use (&$text, &$finish, &$block, $onDelta) {
        if (!empty($j['promptFeedback']['blockReason'])) $block = (string)$j['promptFeedback']['blockReason'];
        $cand = $j['candidates'][0] ?? null;
        if (!$cand) return;
        foreach (($cand['content']['parts'] ?? []) as $p) {
            if (!empty($p['thought'])) continue;
            if (isset($p['text']) && $p['text'] !== '') { $text .= $p['text']; if ($onDelta) $onDelta($p['text']); }
        }
        if (!empty($cand['finishReason'])) $finish = $cand['finishReason'];
    };

    if ($stream) {
        $opts[CURLOPT_WRITEFUNCTION] = function ($c, $chunk) use (&$buf, &$rawHead, $handle) {
            if (strlen($rawHead) < 600) $rawHead .= $chunk;
            $buf .= $chunk;
            while (($pos = strpos($buf, "\n")) !== false) {
                $line = rtrim(substr($buf, 0, $pos), "\r");
                $buf  = substr($buf, $pos + 1);
                if (strncmp($line, 'data:', 5) === 0) {
                    $j = json_decode(trim(substr($line, 5)), true);
                    if (is_array($j)) $handle($j);
                }
            }
            return strlen($chunk);
        };
        curl_setopt_array($ch, $opts);
        curl_exec($ch);
    } else {
        $opts[CURLOPT_RETURNTRANSFER] = true;
        curl_setopt_array($ch, $opts);
        $raw = curl_exec($ch);
        $rawHead = is_string($raw) ? substr($raw, 0, 600) : '';
        $j = is_string($raw) ? json_decode($raw, true) : null;
        if (is_array($j)) $handle($j);
    }
    $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = curl_error($ch);
    $errno = curl_errno($ch);
    curl_close($ch);
    if ($http !== 200 || $err) {
        $m = geminiRedact('[Gemini] HTTP ' . $http . ' curl#' . $errno . ' ' . ($err ?: substr(preg_replace('/\s+/', ' ', (string)$rawHead), 0, 400)));
        error_log($m);
        if (function_exists('neonLogError')) neonLogError('WARNING', $m, __FILE__, __LINE__);
    }
    if ($http === 200 && $text === '' && function_exists('neonLogError')) neonLogError('WARNING', '[Gemini] boş yanıt finish=' . $finish . ' block=' . $block . ' raw=' . substr(preg_replace('/\s+/', ' ', $rawHead), 0, 300), __FILE__, __LINE__);
    return ['text' => $text, 'finish' => $finish, 'block' => $block, 'http' => $http, 'err' => $err];
}

/** Yetişkin platformu için güvenlik ayarları (cinsel içerik engeli yok, nefret/taciz yüksek eşik) */
function geminiSafety(): array {
    return [
        ['category' => 'HARM_CATEGORY_SEXUALLY_EXPLICIT', 'threshold' => 'BLOCK_NONE'],
        ['category' => 'HARM_CATEGORY_HATE_SPEECH',       'threshold' => 'BLOCK_ONLY_HIGH'],
        ['category' => 'HARM_CATEGORY_HARASSMENT',        'threshold' => 'BLOCK_ONLY_HIGH'],
        ['category' => 'HARM_CATEGORY_DANGEROUS_CONTENT', 'threshold' => 'BLOCK_ONLY_HIGH'],
    ];
}
