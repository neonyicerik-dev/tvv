<?php
// ============================================================
// NeonTV - Yardımcı Fonksiyonlar
// ============================================================
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/ip_log.php';

// --------------------------------------------------------
// G3: Güvenli PostgREST Yardımcıları
// --------------------------------------------------------

/** UUID formatını doğrular */
function isUuid(string $v): bool {
    return (bool) preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i', $v);
}

/**
 * UUID doğrular; başarısız olursa JSON hata döndürür ve çıkar.
 */
function requireUuid(string $v, string $label = 'ID'): string {
    if (!isUuid($v)) {
        http_response_code(400);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['success' => false, 'message' => $label . ' geçersiz format'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    return $v;
}

/**
 * PostgREST eşitlik filtresi için güvenli parametre üretir.
 * Sadece alfanümerik + noktalama karakterlerine izin verir.
 * Kullanım: $db->select('table', pgEq('status', $status) . '&...')
 */
function pgEq(string $col, string $val): string {
    // Sütun adı: sadece [a-z0-9_] karakterleri
    if (!preg_match('/^[a-z0-9_]+$/i', $col)) {
        error_log('[pgEq] Geçersiz sütun adı: ' . $col);
        return '';
    }
    return $col . '=eq.' . rawurlencode($val);
}

/** PostgREST ilike filtresi için güvenli parametre üretir */
function pgLike(string $col, string $val): string {
    if (!preg_match('/^[a-z0-9_]+$/i', $col)) return '';
    // % ve _ kaçış karakterleri (LIKE injection'a karşı)
    $escaped = str_replace(['%', '_', '*'], ['\%', '\_', '\*'], $val);
    return $col . '.ilike.*' . rawurlencode($escaped) . '*';
}

/** İzin verilen değerler listesinden güvenli seçim */
function pgEnum(string $val, array $allowed, string $default = ''): string {
    return in_array($val, $allowed, true) ? $val : $default;
}

// --------------------------------------------------------
// Admin Kimlik Doğrulama (G4 güncellemeleri)
// --------------------------------------------------------
function isAdminLoggedIn(): bool {
    return isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
}

function getAdminRole(): string {
    return $_SESSION['admin_role'] ?? 'editor'; // Güvenli varsayılan
}

/**
 * Rol hiyerarşisi: superadmin > moderator > editor
 * $requiredRole: string veya string[] (izin verilen roller)
 */
function requireAdmin($requiredRole = null): void {
    if (!isAdminLoggedIn()) {
        $isAjax = !empty($_SERVER['HTTP_X_REQUESTED_WITH'])
            || str_contains($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json')
            || str_contains($_SERVER['CONTENT_TYPE'] ?? '', 'application/json');

        if ($isAjax) {
            http_response_code(401);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['success' => false, 'message' => 'Oturum süresi doldu'], JSON_UNESCAPED_UNICODE);
            exit;
        }
        header('Location: ' . APP_URL . '/admin/login.php');
        exit;
    }

    if ($requiredRole === null) return;

    $currentRole  = getAdminRole();
    $allowedRoles = is_array($requiredRole) ? $requiredRole : [$requiredRole];

    if ($currentRole === 'superadmin') return;

    if (!in_array($currentRole, $allowedRoles, true)) {
        $isAjax = !empty($_SERVER['HTTP_X_REQUESTED_WITH'])
            || str_contains($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json');

        if ($isAjax) {
            http_response_code(403);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['success' => false, 'message' => 'Yetersiz yetki'], JSON_UNESCAPED_UNICODE);
            exit;
        }
        header('Location: ' . APP_URL . '/admin/index.php?error=yetersiz_yetki');
        exit;
    }
}

/** Mevcut admin rolünün gereken rolü karşılayıp karşılamadığını kontrol eder (redirect olmadan) */
function canAccess($requiredRole): bool {
    if (!isAdminLoggedIn()) return false;
    $currentRole  = getAdminRole();
    if ($currentRole === 'superadmin') return true;
    $allowedRoles = is_array($requiredRole) ? $requiredRole : [$requiredRole];
    return in_array($currentRole, $allowedRoles, true);
}

/** Rol etiketi Türkçe adını döndürür */
function getRoleLabel(string $role): string {
    return match($role) {
        'superadmin' => 'Süper Admin',
        'moderator'  => 'Moderatör',
        'editor'     => 'Editör',
        default      => ucfirst($role),
    };
}

/** Rol rengi (CSS hex) */
function getRoleColor(string $role): string {
    return match($role) {
        'superadmin' => '#00f5ff',
        'moderator'  => '#fbbf24',
        'editor'     => '#a78bfa',
        default      => '#9ca3af',
    };
}

/**
 * G4: Giriş – rate limit + session ID yenileme
 */
function adminLogin(string $username, string $password): bool {
    require_once __DIR__ . '/store.php';
    $ip     = getClientIp();
    $ratKey = 'login:' . md5($ip . ':' . $username);

    // Son 15 dakikada 10'dan fazla deneme → engelle
    if (Store::countLoginAttempts($ratKey) >= 10) {
        return false;
    }

    // Önce DB'deki admin tablosunu dene
    $admin = Store::findAdmin($username);
    if ($admin && password_verify($password, $admin['password_hash'])) {
        // Başarılı: denemeleri temizle
        Store::clearLoginAttempts($ratKey);
        // G4: Eski session'ı sonlandır, yeni ID al
        session_regenerate_id(true);
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_username']  = $username;
        $_SESSION['admin_role']      = $admin['role'] ?? 'editor';
        $_SESSION['admin_login_at']  = time();
        $_SESSION['admin_last_activity'] = time();
        Store::updateAdminLastLogin($username);
        return true;
    }

    // Fallback: config.php superadmin
    if ($username === ADMIN_USERNAME && password_verify($password, ADMIN_PASSWORD_HASH)) {
        Store::clearLoginAttempts($ratKey);
        session_regenerate_id(true);
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_username']  = $username;
        $_SESSION['admin_role']      = 'superadmin';
        $_SESSION['admin_login_at']  = time();
        $_SESSION['admin_last_activity'] = time();
        return true;
    }

    // Başarısız: dene kaydı ekle
    Store::recordLoginAttempt($ratKey);
    // Zamanlı gecikme (timing attack'a karşı dummy hash)
    password_verify($password, '$2y$12$dummyhashforetimingprotection12');
    return false;
}

function adminLogout(): void {
    // G4: Session tamamen temizle + çerezi sıfırla
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(),
            '',
            time() - 3600,
            $params['path'],
            $params['domain'],
            $params['secure'],
            $params['httponly']
        );
    }
    session_destroy();
}

// --------------------------------------------------------
// Bakım Modu Kontrolü (Store ile)
// --------------------------------------------------------
function isMaintenanceMode(): bool {
    static $cached = null;
    if ($cached !== null) return $cached;
    try {
        require_once __DIR__ . '/store.php';
        $cached = Store::isMaintenanceMode();
    } catch (\Throwable $e) {
        $cached = false;
    }
    return $cached;
}

function getMaintenanceMessage(): string {
    try {
        require_once __DIR__ . '/store.php';
        $msg = Store::getSetting('maintenance_message');
        if (is_string($msg)) return $msg;
    } catch (\Throwable $e) {
        // hata
    }
    return 'Site bakımda. Lütfen daha sonra tekrar deneyin.';
}

// --------------------------------------------------------
// Zamanlanmış Videoları Yayınla (cron-like PHP tetikleyici)
// --------------------------------------------------------
function publishScheduledVideos(): void {
    static $ran = false;
    if ($ran) return;
    $ran = true;
    $lockFile = sys_get_temp_dir() . '/neontv_sched.lock';
    if (file_exists($lockFile) && (time() - filemtime($lockFile)) < 60) return;
    @touch($lockFile);
    // Sayfa gönderildikten sonra çalışır: ziyaretçi beklemez
    register_shutdown_function(function () {
        ignore_user_abort(true);
        if (function_exists('fastcgi_finish_request')) { @fastcgi_finish_request(); }
        else { while (ob_get_level() > 0) @ob_end_flush(); @flush(); }
        try {
            require_once __DIR__ . '/supabase.php';
            $db  = new Supabase();
            $now = date('c');
            $res = $db->select('videos',
                'status=eq.scheduled&scheduled_at=lte.' . urlencode($now) . '&select=id',
                true
            );
            foreach ($res['data'] ?? [] as $v) {
                $db->update('videos', ['status' => 'published'], 'id=eq.' . $v['id'], true);
            }
        } catch (\Throwable $e) {
            // Sessizce geç
        }
    });
}

// --------------------------------------------------------
// Bearer Token (kullanıcı API isteklerinden)
// --------------------------------------------------------
function getBearerToken(): ?string {
    $auth = '';
    if (function_exists('getallheaders')) {
        $h = getallheaders();
        $auth = $h['Authorization'] ?? $h['authorization'] ?? '';
    }
    if (!$auth) {
        $auth = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
    }
    if (preg_match('/Bearer\s+(.+)$/i', $auth, $m)) {
        return trim($m[1]);
    }
    // Bazı ücretsiz sunucular Authorization başlığını siler. Yedek yollar:
    $alt = $_SERVER['HTTP_X_ACCESS_TOKEN'] ?? '';
    if (!$alt && !empty($_GET['token']) && is_string($_GET['token'])) $alt = $_GET['token'];
    if (!$alt && !empty($_POST['token']) && is_string($_POST['token'])) $alt = $_POST['token'];
    if (!$alt) {
        $raw = file_get_contents('php://input');
        if ($raw && $raw[0] === '{') {
            $j = json_decode($raw, true);
            if (is_array($j) && !empty($j['token']) && is_string($j['token'])) $alt = $j['token'];
        }
    }
    $alt = trim((string)$alt);
    if ($alt !== '' && $alt !== 'null' && $alt !== 'undefined') return $alt;
    return null;
}

// --------------------------------------------------------
// Origin kontrolü: protokolden bağımsız, yalnızca host karşılaştırır (wildcard yok).
// İzinli: isteğin kendi host'u + ALLOWED_HOSTS listesi (tam eşleşme).
// --------------------------------------------------------
function isAllowedOrigin(string $origin): bool {
    $host = strtolower((string)parse_url($origin, PHP_URL_HOST));
    $port = parse_url($origin, PHP_URL_PORT);
    if ($host === '') return false;
    $self = strtolower((string)($_SERVER['HTTP_HOST'] ?? ''));
    $selfHost = strtolower((string)preg_replace('/:\d+$/', '', $self));
    if ($host === $selfHost) return true;
    if ($port && $host . ':' . $port === $self) return true;
    return defined('ALLOWED_HOSTS') && in_array($host, ALLOWED_HOSTS, true);
}

// --------------------------------------------------------
// JSON API Response
// --------------------------------------------------------
function jsonResponse(array $data, int $status = 200): void {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    // G8: CORS'u kısıtla – sadece aynı origin ya da trusted
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    if ($origin !== '' && isAllowedOrigin($origin)) {
        header('Access-Control-Allow-Origin: ' . $origin);
        header('Vary: Origin');
    }
    header('Access-Control-Allow-Methods: GET, POST, DELETE, PATCH, OPTIONS');
    header('Access-Control-Allow-Headers: Authorization, Content-Type, X-CSRF-Token, X-Access-Token');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function jsonSuccess(array $data = [], string $message = 'Basarili'): void {
    jsonResponse(['success' => true, 'message' => $message, 'data' => $data]);
}

function jsonError(string $message, int $status = 400): void {
    jsonResponse(['success' => false, 'message' => $message], $status);
}

// --------------------------------------------------------
// Zaman Formatlama (Türkçe)
// --------------------------------------------------------
function timeAgo($datetime): string {
    $time = is_string($datetime) ? strtotime($datetime) : $datetime->getTimestamp();
    $diff = time() - $time;

    if ($diff < 60)        return 'Az önce';
    if ($diff < 3600)      return floor($diff / 60) . ' dakika önce';
    if ($diff < 86400)     return floor($diff / 3600) . ' saat önce';
    if ($diff < 2592000)   return floor($diff / 86400) . ' gün önce';
    if ($diff < 31536000)  return floor($diff / 2592000) . ' ay önce';
    return floor($diff / 31536000) . ' yıl önce';
}

// --------------------------------------------------------
// Sayı Formatlama (1.2K, 3.4M)
// --------------------------------------------------------
function formatNumber(int $n): string {
    if ($n >= 1_000_000) return round($n / 1_000_000, 1) . 'M';
    if ($n >= 1_000)     return round($n / 1_000, 1) . 'K';
    return (string) $n;
}

// --------------------------------------------------------
// Süre Formatlama (saniye → HH:MM:SS)
// --------------------------------------------------------
function formatDuration(int $seconds): string {
    $h = floor($seconds / 3600);
    $m = floor(($seconds % 3600) / 60);
    $s = $seconds % 60;

    if ($h > 0) {
        return sprintf('%d:%02d:%02d', $h, $m, $s);
    }
    return sprintf('%d:%02d', $m, $s);
}

// --------------------------------------------------------
// Metin Kısaltma
// --------------------------------------------------------
function truncate(string $text, int $length = 120, string $suffix = '...'): string {
    if (mb_strlen($text) <= $length) return $text;
    return mb_substr($text, 0, $length - mb_strlen($suffix)) . $suffix;
}

// --------------------------------------------------------
// Güvenli HTML Çıktısı (XSS önlemi)
// --------------------------------------------------------
function e($text): string {
    return htmlspecialchars((string)($text ?? ''), ENT_QUOTES | ENT_HTML5, 'UTF-8');
}

// --------------------------------------------------------
// URL Slug Oluşturma
// --------------------------------------------------------
function slugify(string $text): string {
    $text = mb_strtolower($text, 'UTF-8');
    $tr   = ['ş', 'ı', 'ğ', 'ü', 'ö', 'ç', 'Ş', 'İ', 'Ğ', 'Ü', 'Ö', 'Ç'];
    $en   = ['s', 'i', 'g', 'u', 'o', 'c', 's', 'i', 'g', 'u', 'o', 'c'];
    $text = str_replace($tr, $en, $text);
    $text = preg_replace('/[^a-z0-9\s-]/', '', $text);
    $text = preg_replace('/[\s-]+/', '-', trim($text));
    return $text;
}

// --------------------------------------------------------
// CSRF Token
// --------------------------------------------------------
function generateCsrfToken(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verifyCsrfToken(string $token): bool {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

function csrfField(): string {
    return '<input type="hidden" name="csrf_token" value="' . e(generateCsrfToken()) . '">';
}

/**
 * G4: API isteklerinde X-CSRF-Token başlığını doğrula
 */
function verifyCsrfHeader(): bool {
    $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    return verifyCsrfToken($token);
}

// --------------------------------------------------------
// Request Input Helper
// --------------------------------------------------------
function input(string $key, string $default = '', string $method = 'POST'): string {
    $data = $method === 'GET' ? $_GET : $_POST;
    return trim($data[$key] ?? $default);
}

function inputJson(): ?array {
    $raw = file_get_contents('php://input');
    if (!$raw) return null;
    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : null;
}

// --------------------------------------------------------
// Pagination Helper
// --------------------------------------------------------
function paginate(int $total, int $perPage, int $current): array {
    $totalPages = max(1, (int) ceil($total / $perPage));
    $current    = max(1, min($current, $totalPages));
    $offset     = ($current - 1) * $perPage;

    return [
        'total'       => $total,
        'per_page'    => $perPage,
        'current'     => $current,
        'total_pages' => $totalPages,
        'offset'      => $offset,
        'has_prev'    => $current > 1,
        'has_next'    => $current < $totalPages,
    ];
}

// --------------------------------------------------------
// Validation Helpers
// --------------------------------------------------------
function validateEmail(string $email): bool {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function validatePassword(string $password): bool {
    return strlen($password) >= 6;
}

// --------------------------------------------------------
// Redirect Helper
// --------------------------------------------------------
function redirect(string $url, bool $permanent = false): void {
    header('Location: ' . $url, true, $permanent ? 301 : 302);
    exit;
}

// --------------------------------------------------------
// Flash Mesajları
// --------------------------------------------------------
function setFlash(string $type, string $message): void {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function getFlash(): ?array {
    $flash = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $flash;
}

function renderFlash(): string {
    $flash = getFlash();
    if (!$flash) return '';

    $colors = [
        'success' => 'bg-green-500/20 border-green-500/50 text-green-400',
        'error'   => 'bg-red-500/20 border-red-500/50 text-red-400',
        'info'    => 'bg-cyan-500/20 border-cyan-500/50 text-cyan-400',
        'warning' => 'bg-yellow-500/20 border-yellow-500/50 text-yellow-400',
    ];
    $cls = $colors[$flash['type']] ?? $colors['info'];

    return '<div class="flash-message border rounded-lg px-4 py-3 mb-4 ' . $cls . '">' . e($flash['message']) . '</div>';
}


// --------------------------------------------------------
// Yorum metni: @etiket, zaman damgası (1:23) ve GIF ([gif:URL]) dönüşümü
// --------------------------------------------------------
function commentGifRe(): string { return '#\[gif:(https://media\d*\.giphy\.com/[A-Za-z0-9_/.\-]+\.(?:gif|webp))\]#'; }

/** Geçersiz [gif:...] etiketlerini temizler; en fazla 1 GIF bırakır */
function sanitizeCommentContent(string $c): string {
    $n = 0;
    $c = preg_replace_callback('/\[gif:([^\]]*)\]/u', function ($m) use (&$n) {
        if ($n >= 1 || !preg_match(commentGifRe(), $m[0])) return '';
        $n++; return $m[0];
    }, $c);
    return trim($c);
}

function renderCommentText(string $text): string {
    $safe = e($text);
    $safe = preg_replace_callback('/(?<![\d:\/])(?:(\d{1,2}):)?([0-5]?\d):([0-5]\d)(?![\d:])/', function ($m) {
        $sec = ($m[1] !== '' ? (int)$m[1] * 3600 : 0) + (int)$m[2] * 60 + (int)$m[3];
        return '<a href="#t=' . $sec . '" class="ts-link text-cyan-400 hover:underline font-semibold" data-t="' . $sec . '">' . $m[0] . '</a>';
    }, $safe);
    $safe = preg_replace('/@([a-zA-Z0-9_.-]+)/u', '<a href="' . APP_URL . '/search.php?q=%40$1" class="text-cyan-400 hover:underline font-semibold">@$1</a>', $safe);
    $safe = preg_replace(commentGifRe(), '<img src="$1" alt="GIF" class="cgif" loading="lazy">', $safe);
    return $safe;
}
