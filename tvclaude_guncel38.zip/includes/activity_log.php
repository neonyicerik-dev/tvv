<?php
// ============================================================
// NeonTV - Moderatör Aktivite Log Sistemi
// G1: JSON dosyası yerine Store (Supabase) kullanır
// ============================================================

/**
 * Aktivite kaydet
 */
function logActivity(string $action, string $targetType, string $targetId = '', array $oldData = [], array $newData = [], string $note = ''): void {
    require_once __DIR__ . '/store.php';

    $admin = $_SESSION['admin_username'] ?? 'system';
    $role  = $_SESSION['admin_role']    ?? 'unknown';

    $details = [];
    if ($targetId)    $details['target_id']  = $targetId;
    if ($role)        $details['role']       = $role;
    if ($oldData)     $details['old_data']   = $oldData;
    if ($newData)     $details['new_data']   = $newData;
    if ($note)        $details['note']       = $note;

    // target = "targetType:targetId" formatında
    $target = $targetType . ($targetId ? ':' . $targetId : '');

    Store::logActivity($action, $target, $details, $admin);
}

/**
 * Logları oku
 */
function readActivityLog(int $limit = 100, int $offset = 0): array {
    require_once __DIR__ . '/store.php';
    return Store::getActivityLog($limit, $offset);
}

/**
 * Belirli bir log kaydını ID ile bul
 */
function findActivityById(string $id): ?array {
    require_once __DIR__ . '/store.php';
    require_once __DIR__ . '/supabase.php';

    $db  = new Supabase();
    $res = $db->first('activity_log', 'id=eq.' . urlencode($id), true);
    return $res ?: null;
}

/**
 * Tüm logları temizle (service role)
 */
function clearActivityLog(): bool {
    require_once __DIR__ . '/supabase.php';
    $db  = new Supabase();
    $r   = $db->delete('activity_log', 'id=gte.0', true); // tümünü sil
    return ($r['status'] < 400);
}

/**
 * Aksiyon etiketlerini Türkçe göster
 */
function actionLabel(string $action): string {
    $map = [
        'video_delete'        => 'Video Silindi',
        'video_edit'          => 'Video Düzenlendi',
        'video_status_change' => 'Video Durumu Değiştirildi',
        'video_create'        => 'Video Eklendi',
        'video_duplicate'     => 'Video Kopyalandı',
        'video_bulk_ai_title' => 'Toplu AI Başlık',
        'video_bulk_status'   => 'Toplu Durum Değişikliği',
        'video_bulk_delete'   => 'Toplu Silme',
        'video_bulk_edit'     => 'Toplu Video Düzenleme',
        'comment_delete'      => 'Yorum Silindi',
        'comment_approve'     => 'Yorum Onaylandı',
        'channel_edit'        => 'Kanal Düzenlendi',
        'channel_delete'      => 'Kanal Silindi',
        'channel_create'      => 'Kanal Oluşturuldu',
        'ip_block'            => 'IP Engellendi',
        'ip_unblock'          => 'IP Engeli Kaldırıldı',
        'settings_update'     => 'Ayarlar Güncellendi',
        'admin_create'        => 'Admin Eklendi',
        'admin_delete'        => 'Admin Silindi',
        'category_create'     => 'Kategori Oluşturuldu',
        'category_edit'       => 'Kategori Düzenlendi',
        'category_delete'     => 'Kategori Silindi',
        'ad_create'           => 'Reklam Oluşturuldu',
        'ad_edit'             => 'Reklam Düzenlendi',
        'ad_delete'           => 'Reklam Silindi',
        'popup_create'        => 'Popup Oluşturuldu',
        'popup_edit'          => 'Popup Düzenlendi',
        'popup_delete'        => 'Popup Silindi',
        'user_premium_grant'  => 'Premium Verildi',
        'user_premium_revoke' => 'Premium İptal',
    ];
    return $map[$action] ?? $action;
}

/**
 * Aksiyon rengini döndür
 */
function actionColor(string $action): string {
    if (str_contains($action, 'delete'))  return '#ff4444';
    if (str_contains($action, 'block'))   return '#ff007a';
    if (str_contains($action, 'revoke'))  return '#ff007a';
    if (str_contains($action, 'create') || str_contains($action, 'approve') || str_contains($action, 'grant')) return '#00f5ff';
    if (str_contains($action, 'edit') || str_contains($action, 'update'))   return '#ffd700';
    if (str_contains($action, 'unblock')) return '#00ff7f';
    return '#9ca3af';
}

/**
 * Hedef tipini Türkçe göster
 */
function targetTypeLabel(string $type): string {
    $map = [
        'video'    => 'Video',
        'comment'  => 'Yorum',
        'channel'  => 'Kanal',
        'ip'       => 'IP Adresi',
        'settings' => 'Ayarlar',
        'admin'    => 'Admin',
        'category' => 'Kategori',
        'ad'       => 'Reklam',
        'popup'    => 'Popup',
        'user'     => 'Kullanıcı',
    ];
    // "video:uuid" formatından tip çıkar
    $parts = explode(':', $type, 2);
    return $map[$parts[0]] ?? ($parts[0] ?: $type);
}
