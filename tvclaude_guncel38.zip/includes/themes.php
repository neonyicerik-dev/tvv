<?php
// NeonTV – Premium profil temaları ve çerçeveleri tanımı (gen_themes.py ile üretilir; CSS: assets/css/themes.css)
function nvThemes(): array {
    return [
        "aurora" => ['name' => "Kuzey Işıkları", 'desc' => "Dans eden yeşil-mor ışık perdeleri", 'icon' => "fa-wand-magic-sparkles", 'colors' => ["#00ffa3", "#00b8ff", "#a855f7"]],
        "neon" => ['name' => "Neon Şehir", 'desc' => "Kayan ızgara ve neon gün batımı", 'icon' => "fa-city", 'colors' => ["#00f5ff", "#ff2bd6", "#7b2ff7"]],
        "gece" => ['name' => "Yıldızlı Gece", 'desc' => "Göz kırpan yıldızlar", 'icon' => "fa-moon", 'colors' => ["#bcd4ff", "#7aa2ff", "#ffffff"]],
        "magma" => ['name' => "Magma", 'desc' => "Akan lav ve yükselen kıvılcımlar", 'icon' => "fa-fire", 'colors' => ["#ff3d00", "#ff9100", "#ffd166"]],
        "okyanus" => ['name' => "Derin Okyanus", 'desc' => "Dalgalanan mavi ve kabarcıklar", 'icon' => "fa-water", 'colors' => ["#00b4d8", "#0077b6", "#90e0ef"]],
        "sakura" => ['name' => "Sakura", 'desc' => "Süzülen kiraz çiçeği yaprakları", 'icon' => "fa-spa", 'colors' => ["#ff9ecb", "#ffd1e8", "#ffffff"]],
        "matrix" => ['name' => "Siber Yağmur", 'desc' => "Yeşil kod yağmuru", 'icon' => "fa-terminal", 'colors' => ["#00ff6a", "#00c853", "#b9ffd5"]],
        "altin" => ['name' => "Altın Lüks", 'desc' => "Parlayan altın ışıltısı", 'icon' => "fa-crown", 'colors' => ["#ffd76a", "#ffb300", "#fff1b8"]],
        "buz" => ['name' => "Buz Kristali", 'desc' => "Soğuk ışıltı ve yağan kar", 'icon' => "fa-snowflake", 'colors' => ["#8be9ff", "#c7f0ff", "#5aa9ff"]],
        "gunbatimi" => ['name' => "Gün Batımı", 'desc' => "Turuncudan mora yavaş geçiş", 'icon' => "fa-sun", 'colors' => ["#ff7e5f", "#feb47b", "#c13cff"]],
        "elektrik" => ['name' => "Elektrik Fırtınası", 'desc' => "Çakan şimşek ve yağmur", 'icon' => "fa-bolt", 'colors' => ["#7df9ff", "#4aa3ff", "#ffffff"]],
        "ormanbocegi" => ['name' => "Ateşböceği Ormanı", 'desc' => "Karanlıkta uçuşan ateşböcekleri", 'icon' => "fa-tree", 'colors' => ["#d4ff3a", "#4ade80", "#a3e635"]],
        "galaksi" => ['name' => "Galaksi", 'desc' => "Dönen nebula ve yıldızlar", 'icon' => "fa-meteor", 'colors' => ["#7b2ff7", "#f107a3", "#00d4ff"]],
        "kanay" => ['name' => "Kan Ayı", 'desc' => "Nabız gibi atan kızıl ay", 'icon' => "fa-circle", 'colors' => ["#ff1f4b", "#ff6b6b", "#ffb3bf"]],
        "retro" => ['name' => "Retrowave", 'desc' => "Synthwave güneşi ve ızgara", 'icon' => "fa-compact-disc", 'colors' => ["#ff3ea5", "#ffd319", "#7b2ff7"]],
        "zehir" => ['name' => "Zehir", 'desc' => "Toksik yeşil-mor plazma", 'icon' => "fa-skull-crossbones", 'colors' => ["#9dff00", "#b100ff", "#00ffa8"]],
        "gokkusagi" => ['name' => "Gökkuşağı", 'desc' => "Sürekli renk değiştiren akış", 'icon' => "fa-rainbow", 'colors' => ["#ff0055", "#00ff95", "#7a5cff"]],
        "gulaltin" => ['name' => "Gül Altın", 'desc' => "Pembe-altın zarif ışıltı", 'icon' => "fa-gem", 'colors' => ["#f4cdb0", "#e8a6a0", "#fff0e6"]],
        "duman" => ['name' => "Karanlık Duman", 'desc' => "Süzülen gri sis ve kül", 'icon' => "fa-cloud", 'colors' => ["#9aa0a6", "#cfd2d6", "#ffffff"]],
        "plazma" => ['name' => "Plazma", 'desc' => "Akışkan neon plazma", 'icon' => "fa-atom", 'colors' => ["#ff0080", "#7928ca", "#00dfd8"]],
        "siber" => ['name' => "Siber Sokak", 'desc' => "Neon tabelalar ve tarama çizgileri", 'icon' => "fa-robot", 'colors' => ["#00f0ff", "#ff2a6d", "#d1f7ff"]],
        "kristal" => ['name' => "Kristal Prizma", 'desc' => "Dönen ışık huzmeleri", 'icon' => "fa-diamond", 'colors' => ["#9be7ff", "#c4a1ff", "#ffffff"]],
        "dalga" => ['name' => "Sonsuz Dalga", 'desc' => "Birbirine karışan akıcı dalgalar", 'icon' => "fa-wave-square", 'colors' => ["#2de2e6", "#3a86ff", "#b8f2ff"]],
        "bokeh" => ['name' => "Bokeh Geceleri", 'desc' => "Süzülen sıcak şehir ışıkları", 'icon' => "fa-lightbulb", 'colors' => ["#ffb86b", "#ff6b9d", "#ffe29a"]],
        "lav" => ['name' => "Lav Lambası", 'desc' => "Erimiş renk damlaları", 'icon' => "fa-fire-flame-curved", 'colors' => ["#ff4fd8", "#ff9a3c", "#8a5cff"]],
        "cennet" => ['name' => "Tropik Akşam", 'desc' => "Turuncu-pembe dalgalar ve parıltı", 'icon' => "fa-umbrella-beach", 'colors' => ["#ff9966", "#ff5e62", "#ffd0a1"]],
        "hologram" => ['name' => "Hologram", 'desc' => "Parıldayan tarama ışığı", 'icon' => "fa-cube", 'colors' => ["#7fffd4", "#7aa2ff", "#ff9bf5"]],
        "yildiztozu" => ['name' => "Yıldız Tozu", 'desc' => "Altın tozlar yağıyor", 'icon' => "fa-star", 'colors' => ["#ffe27a", "#ffb3f0", "#ffffff"]],
        "neonkenar" => ['name' => "Neon Kenar", 'desc' => "Kenarlarda dönen ışık", 'icon' => "fa-border-all", 'colors' => ["#00f5ff", "#bf00ff", "#ff2bd6"]],
        "bulut" => ['name' => "Bulutların Üstü", 'desc' => "Yumuşak pastel bulutlar", 'icon' => "fa-cloud-sun", 'colors' => ["#a0c4ff", "#ffc6ff", "#fdffb6"]],
        "volkan" => ['name' => "Volkan", 'desc' => "Yoğun kor ve akan lav", 'icon' => "fa-mountain", 'colors' => ["#ff5a1f", "#ffb000", "#fff0b0"]],
        "zumrut" => ['name' => "Zümrüt Rüya", 'desc' => "Yeşil ışık perdesi ve ışık topları", 'icon' => "fa-leaf", 'colors' => ["#2bffb0", "#00c2a8", "#b6ffdf"]],
        "yagmurlu" => ['name' => "Yağmurlu Gece", 'desc' => "Cama vuran yağmur ve uzak şimşek", 'icon' => "fa-cloud-showers-heavy", 'colors' => ["#7aa2ff", "#4aa3ff", "#cfe3ff"]],
        "sonbahar" => ['name' => "Sonbahar", 'desc' => "Savrulan turuncu yapraklar", 'icon' => "fa-leaf", 'colors' => ["#ff8a3d", "#ffc371", "#d2691e"]],
        "kisgecesi" => ['name' => "Kış Gecesi", 'desc' => "Usulca yağan kar ve soğuk ışık", 'icon' => "fa-snowman", 'colors' => ["#cfe8ff", "#8ec5ff", "#ffffff"]],
        "disko" => ['name' => "Disko", 'desc' => "Dönen renkli ışıklar", 'icon' => "fa-record-vinyl", 'colors' => ["#ff2bd6", "#00f5ff", "#ffe600"]],
        "gunes" => ['name' => "Güneş Işığı", 'desc' => "Sıcak ışık huzmeleri", 'icon' => "fa-certificate", 'colors' => ["#ffd76a", "#ffb347", "#fff3c4"]],
        "sihir" => ['name' => "Sihirli Orman", 'desc' => "Ateşböceği ışıkları ve sis", 'icon' => "fa-hat-wizard", 'colors' => ["#9d7bff", "#4ade80", "#e0c3ff"]],
        "tokyo" => ['name' => "Tokyo Gecesi", 'desc' => "Neon yağmur ve tarama çizgileri", 'icon' => "fa-torii-gate", 'colors' => ["#ff2a6d", "#05d9e8", "#d1f7ff"]],
        "col" => ['name' => "Çöl Akşamı", 'desc' => "Kum rengi dalgalar ve sıcak gökyüzü", 'icon' => "fa-mountain-sun", 'colors' => ["#ffb36b", "#ff7a5c", "#ffe0b3"]],
        "ruya" => ['name' => "Rüya", 'desc' => "Pastel ışık topları", 'icon' => "fa-wand-sparkles", 'colors' => ["#ffb3f0", "#b3d4ff", "#fff2b3"]],
        "magara" => ['name' => "Kristal Mağara", 'desc' => "Parlayan kristal ışıkları", 'icon' => "fa-icicles", 'colors' => ["#5ce1ff", "#a78bfa", "#ffffff"]],
        "siyahaltin" => ['name' => "Siyah Altın", 'desc' => "Karanlık lüks ve altın parıltı", 'icon' => "fa-chess-queen", 'colors' => ["#ffd76a", "#b8860b", "#fff1b8"]],
        "kozmos" => ['name' => "Kozmos", 'desc' => "Dönen galaksi kolları", 'icon' => "fa-user-astronaut", 'colors' => ["#8ea2ff", "#ff6ec7", "#59f0ff"]],
    ];
}

/** Geçerli tema/çerçeve anahtarı mı? (boş string = yok) */
function nvValidKey(?string $k): bool { return $k === null || $k === '' || isset(nvThemes()[$k]); }

/** Objeli çerçeveler (SVG süslemeler): key => [name, colors] */
function nvFrameObjs(): array {
    return [
        "kral" => ['name' => "Kara Taç", 'colors' => ["#c9b27a", "#23232b", "#ffcc66"]],
        "tac" => ['name' => "Altın Taç", 'colors' => ["#ffc83d", "#fff2a8", "#ff4d6d"]],
        "melek" => ['name' => "Melek", 'colors' => ["#ffe58a", "#ffffff", "#9bbcf0"]],
        "seytan" => ['name' => "Şeytan", 'colors' => ["#ff3b3b", "#ff9a3c", "#5a0010"]],
        "kedi" => ['name' => "Kedi Kulakları", 'colors' => ["#ff8fb7", "#ffd3e4", "#c2457a"]],
        "tavsan" => ['name' => "Tavşan Kulakları", 'colors' => ["#ffc2d9", "#ffffff", "#e6c9d6"]],
        "karakanat" => ['name' => "Kara Kanat", 'colors' => ["#b86bff", "#3b1766", "#d9b3ff"]],
        "ejder" => ['name' => "Ejder", 'colors' => ["#7cff6b", "#2e7d32", "#c8ff6b"]],
        "alev" => ['name' => "Alev Halkası", 'colors' => ["#ff7a1a", "#ffd166", "#ff3d00"]],
        "yildiz" => ['name' => "Yıldız Yörüngesi", 'colors' => ["#ffd86b", "#ffffff", "#b8860b"]],
        "kalp" => ['name' => "Kalp Yağmuru", 'colors' => ["#ff4d86", "#ff9ec2", "#ffffff"]],
        "cicek" => ['name' => "Çiçek Çelengi", 'colors' => ["#ff9ec7", "#ffffff", "#5fcf80"]],
        "kar" => ['name' => "Kış", 'colors' => ["#bfe9ff", "#ffffff", "#7aa2ff"]],
        "simsek" => ['name' => "Şimşek", 'colors' => ["#7df9ff", "#ffe94d", "#ffffff"]],
        "gezegen" => ['name' => "Gezegen", 'colors' => ["#b9a4ff", "#ffd6a8", "#b5541a"]],
        "ay" => ['name' => "Ay ve Yıldızlar", 'colors' => ["#f2d46b", "#fff7c2", "#f2b705"]],
    ];
}

/** Tüm çerçeveler (önce objeli, sonra halka) */
function nvFrameList(): array {
    $o = []; foreach (nvFrameObjs() as $k => $f) $o[] = ['key' => $k, 'name' => $f['name'], 'group' => 'obj', 'colors' => $f['colors']];
    foreach (nvThemes() as $k => $t) $o[] = ['key' => $k, 'name' => $t['name'], 'group' => 'ring', 'colors' => $t['colors']];
    return $o;
}
function nvValidFrame(?string $k): bool { return $k === null || $k === '' || isset(nvThemes()[$k]) || isset(nvFrameObjs()[$k]); }

/** Çerçeve sarmalayıcı açılışı; çerçeve yoksa boş döner. $size: sm | md | lg */
function nvFrameOpen(?string $key, string $size = 'md'): string {
    if (!$key || !nvValidFrame($key)) return '';
    return '<span class="nvf nvf-' . $key . ' nvf-' . $size . '">';
}
function nvFrameClose(?string $key): string { return ($key && nvValidFrame($key)) ? '</span>' : ''; }
