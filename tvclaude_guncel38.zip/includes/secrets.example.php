<?php
// includes/secrets.example.php -> secrets.php olarak kopyalayın (git'e eklemeyin; Nginx/.htaccess ile erişime kapalıdır).
// PHP-FPM ortam değişkenlerini varsayılanda temizler (clear_env=yes); alternatif: www.conf içinde clear_env = no
// ve env[GEMINI_API_KEY] = ... Bu dosya o yöntem yerine kullanılabilir.
putenv('GEMINI_API_KEY=');
putenv('GIPHY_API_KEY=');
putenv('SUPABASE_SERVICE_KEY=');
putenv('CLOUDCONVERT_API_KEY=');
putenv('ALLOWED_HOSTS=neontvapp.dpdns.org,neontv.qd.je');
