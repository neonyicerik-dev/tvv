<?php
// ============================================================
// NeonTV - IP Takip & Engelleme Sistemi
// G5: IP'ler hashlenir, Store (Supabase) kullanılır
// G1: JSON dosyaları kaldırıldı
// ============================================================

/**
 * G5: Güvenilir proxy'leri dikkate alarak istemci IP'sini döndürür.
 * Tek merkezi fonksiyon – tüm kod bu fonksiyonu kullanmalı.
 */
function getClientIp(): string {
    $remoteAddr = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';

    // TRUSTED_PROXIES tanımlıysa ve REMOTE_ADDR güvenilir proxy ise X-Forwarded-For'u kullan
    if (defined('TRUSTED_PROXIES') && is_array(TRUSTED_PROXIES)) {
        if (ipIsTrusted($remoteAddr)) {
            // CF-Connecting-IP (Cloudflare)
            if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
                $ip = trim($_SERVER['HTTP_CF_CONNECTING_IP']);
                if (filter_var($ip, FILTER_VALIDATE_IP)) return $ip;
            }
            // X-Real-IP
            if (!empty($_SERVER['HTTP_X_REAL_IP'])) {
                $ip = trim($_SERVER['HTTP_X_REAL_IP']);
                if (filter_var($ip, FILTER_VALIDATE_IP)) return $ip;
            }
            // X-Forwarded-For – ilk genel IP adresini al
            if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                $parts = array_map('trim', explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']));
                foreach ($parts as $part) {
                    if (filter_var($part, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                        return $part;
                    }
                }
            }
        }
    }

    return $remoteAddr;
}

/** Geri uyumluluk için eski isim */
function getVisitorIp(): string {
    return getClientIp();
}

/** Bir IP'nin güvenilir proxy listesinde olup olmadığını kontrol eder */
function ipIsTrusted(string $ip): bool {
    if (!defined('TRUSTED_PROXIES')) return false;
    foreach (TRUSTED_PROXIES as $proxy) {
        $proxy = trim($proxy);
        if (!$proxy) continue;
        if ($proxy === $ip) return true;
        if (str_contains($proxy, '/') && ipInCidr($ip, $proxy)) return true;
    }
    return false;
}

/**
 * CIDR kontrolü
 */
function ipInCidr(string $ip, string $cidr): bool {
    [$subnet, $bits] = explode('/', $cidr, 2);
    $ip     = ip2long($ip);
    $subnet = ip2long($subnet);
    if ($ip === false || $subnet === false) return false;
    $mask = -1 << (32 - (int)$bits);
    return ($ip & $mask) === ($subnet & $mask);
}

/**
 * G5: IP'yi HMAC-SHA256 ile hashle
 */
function hashIp(string $ip): string {
    $secret = defined('IP_HASH_SECRET') ? IP_HASH_SECRET : 'neontv_default_secret';
    return hash_hmac('sha256', $ip, $secret);
}

// --------------------------------------------------------
// Engellenen IP'ler (Store tabanlı)
// --------------------------------------------------------

function readBlockedIps(): array {
    require_once __DIR__ . '/store.php';
    return Store::blockedIps();
}

function isIpBlocked(string $ip = ''): bool {
    if (!$ip) $ip = getClientIp();
    require_once __DIR__ . '/store.php';
    return Store::isIpBlocked($ip);
}

function blockIp(string $ip, string $reason = '', string $admin = '', ?string $expiresAt = null): bool {
    require_once __DIR__ . '/store.php';
    return Store::blockIp($ip, $reason, $admin, $expiresAt);
}

function unblockIp(string $ip): bool {
    require_once __DIR__ . '/store.php';
    return Store::unblockIp($ip);
}

// --------------------------------------------------------
// Ziyaret Kaydı (Store tabanlı)
// --------------------------------------------------------

/** Çevrimiçi sayacı: IP özetine göre dosya mtime'ı (veritabanı gerektirmez) */
function nvPresenceTouch(): void {
    $d = dirname(__DIR__) . '/logs/online';
    if (!is_dir($d) && !@mkdir($d, 0755, true)) return;
    $f = $d . '/' . substr(hash('sha256', getClientIp() . '|' . ($_SERVER['HTTP_USER_AGENT'] ?? '')), 0, 24);
    if (!is_file($f) || filemtime($f) < time() - 30) @touch($f);
}
function nvOnlineCount(int $window = 300): int {
    $d = dirname(__DIR__) . '/logs/online'; $n = 0; $now = time();
    foreach (glob($d . '/*') ?: [] as $f) {
        $m = @filemtime($f);
        if ($m !== false && $m >= $now - $window) $n++;
        elseif ($m !== false && $m < $now - 3600) @unlink($f);
    }
    return $n;
}

function logVisit(): void {
    static $logged = false;
    if ($logged) return;
    $logged = true;
    try { nvPresenceTouch(); } catch (\Throwable $e) {}

    // Bot kontrolü
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $botPatterns = ['bot', 'crawl', 'spider', 'slurp', 'fetch', 'curl', 'wget', 'python', 'java/', 'go-http'];
    foreach ($botPatterns as $pat) {
        if (stripos($ua, $pat) !== false) return;
    }

    $ip       = getClientIp();
    $page     = $_SERVER['REQUEST_URI'] ?? '/';
    $referrer = $_SERVER['HTTP_REFERER'] ?? '';

    // Ağır kısım (coğrafi arama + veritabanı kaydı) sayfa gönderildikten SONRA çalışır:
    // ziyaretçi bu işlemleri beklemez.
    register_shutdown_function(function () use ($ip, $page, $referrer, $ua) {
        ignore_user_abort(true);
        if (function_exists('fastcgi_finish_request')) {
            @fastcgi_finish_request();
        } else {
            while (ob_get_level() > 0) @ob_end_flush();
            @flush();
        }
        try {
            $ipHash = hashIp($ip);
            $geo    = getIpGeo($ip);
            require_once __DIR__ . '/store.php';
            Store::logVisit($ipHash, $geo['countryCode'] ?? '', $geo['city'] ?? '', $geo['isp'] ?? '', $page, $referrer, substr($ua, 0, 300));
        } catch (\Throwable $e) { error_log('[logVisit] ' . $e->getMessage()); }
    });
}

function readIpLog(int $hours = 24, int $limit = 500): array {
    require_once __DIR__ . '/store.php';
    return Store::getRecentVisits($hours, $limit);
}

/**
 * IP coğrafi konumunu al (önbellekli – Store tabanlı)
 */
function getIpGeo(string $ip): array {
    // Yerel IP'ler için boş döndür
    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false) {
        return ['country' => 'Yerel', 'city' => 'Localhost', 'countryCode' => 'LO'];
    }

    $ipHash = hashIp($ip);

    require_once __DIR__ . '/store.php';
    $cached = Store::getGeoCache($ipHash);
    if ($cached !== null) return $cached;

    // ip-api.com ücretsiz API (45 req/min)
    $ch = curl_init();
    $opts = [
        CURLOPT_URL            => "http://ip-api.com/json/{$ip}?fields=status,country,countryCode,city,isp",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 3,
        CURLOPT_CONNECTTIMEOUT => 2,
        CURLOPT_SSL_VERIFYPEER => false, // HTTP (plain) endpoint kullanıyoruz
    ];
    curl_setopt_array($ch, $opts);
    $raw  = curl_exec($ch);
    $err  = curl_error($ch);
    curl_close($ch);

    if (!$err && $raw) {
        $data = json_decode($raw, true);
        if (($data['status'] ?? '') === 'success') {
            unset($data['status']);
            Store::setGeoCache($ipHash, $data);
            return $data;
        }
    }

    return [];
}

// --------------------------------------------------------
// İstatistik Yardımcıları (ip_visits kayıtları üzerinde)
// --------------------------------------------------------

function getRecentVisits(int $hours = 24): array {
    require_once __DIR__ . '/store.php';
    return Store::getRecentVisits($hours);
}

function extractReferrerDomain(string $referrer): string {
    if (!$referrer) return 'Direkt';
    $host = parse_url($referrer, PHP_URL_HOST) ?? '';
    $host = preg_replace('/^www\./', '', $host);
    return $host ?: 'Bilinmeyen';
}

function getCountryStats(array $visits): array {
    $stats = [];
    foreach ($visits as $v) {
        $code    = $v['country_code'] ?? '??';
        $country = $code ?: 'Bilinmeyen';
        if (!isset($stats[$country])) $stats[$country] = ['code' => $code, 'count' => 0];
        $stats[$country]['count']++;
    }
    $result = [];
    foreach ($stats as $country => $d) {
        $result[] = ['country' => $country, 'code' => $d['code'], 'count' => $d['count']];
    }
    usort($result, fn($a, $b) => $b['count'] - $a['count']);
    return array_values($result);
}

function getTrafficSources(array $visits): array {
    $sources = [];
    foreach ($visits as $v) {
        $domain = extractReferrerDomain($v['referrer'] ?? '');
        if (!isset($sources[$domain])) $sources[$domain] = 0;
        $sources[$domain]++;
    }
    arsort($sources);
    return $sources;
}

function getIpSummary(array $visits): array {
    // ip_visits artık ip_hash tutuyor – gerçek IP yok
    $ips = [];
    foreach ($visits as $v) {
        $hash = $v['ip_hash'] ?? 'unknown';
        if (!isset($ips[$hash])) {
            $ips[$hash] = [
                'ip_hash'  => $hash,
                'country'  => $v['country_code'] ?? '',
                'city'     => $v['city']          ?? '',
                'isp'      => $v['isp']            ?? '',
                'count'    => 0,
                'last_seen'=> $v['created_at']     ?? '',
                'pages'    => [],
            ];
        }
        $ips[$hash]['count']++;
        $ips[$hash]['pages'][] = $v['page'] ?? '';
    }
    usort($ips, fn($a, $b) => $b['count'] - $a['count']);
    return array_values($ips);
}
