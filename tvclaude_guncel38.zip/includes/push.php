<?php
// ============================================================
// NeonTV - Web Push (VAPID, yüksüz/boş push). Şifreleme gerekmez:
// push gönderilir, service worker (sw.js) api/push.php?action=latest ile bildirimi çeker.
// Özel anahtar: VAPID_PRIVATE_PEM ortam değişkeni ya da otomatik üretilen logs/vapid_private.pem (web'den erişilemez olmalı).
// ============================================================
function nvB64u(string $s): string { return rtrim(strtr(base64_encode($s), '+/', '-_'), '='); }

function nvVapidPem(): ?string {
    $env = getenv('VAPID_PRIVATE_PEM');
    if ($env) return str_replace('\n', "\n", $env);
    $dir = dirname(__DIR__) . '/logs'; $f = $dir . '/vapid_private.pem';
    if (is_file($f)) return (string)file_get_contents($f);
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    $k = openssl_pkey_new(['curve_name' => 'prime256v1', 'private_key_type' => OPENSSL_KEYTYPE_EC]);
    if (!$k || !openssl_pkey_export($k, $pem)) return null;
    if (@file_put_contents($f, $pem, LOCK_EX) === false) return null;
    @chmod($f, 0600);
    if (!is_file($dir . '/.htaccess')) @file_put_contents($dir . '/.htaccess', "Require all denied\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n");
    return $pem;
}

/** Uygulama sunucusu açık anahtarı (base64url, sıkıştırılmamış nokta) */
function nvVapidPublic(): ?string {
    $pem = nvVapidPem(); if (!$pem) return null;
    $d = openssl_pkey_get_details(openssl_pkey_get_private($pem));
    if (!$d || empty($d['ec']['x'])) return null;
    return nvB64u("\x04" . str_pad($d['ec']['x'], 32, "\0", STR_PAD_LEFT) . str_pad($d['ec']['y'], 32, "\0", STR_PAD_LEFT));
}

function nvVapidJwt(string $aud): ?string {
    $pem = nvVapidPem(); if (!$pem) return null;
    $sub = str_starts_with(APP_URL, 'https://') ? APP_URL : 'mailto:noreply@' . (parse_url(APP_URL, PHP_URL_HOST) ?: 'example.com');
    $h = nvB64u(json_encode(['typ' => 'JWT', 'alg' => 'ES256']));
    $c = nvB64u(json_encode(['aud' => $aud, 'exp' => time() + 12 * 3600, 'sub' => $sub]));
    if (!openssl_sign("$h.$c", $der, $pem, OPENSSL_ALGO_SHA256)) return null;
    // DER (r,s) -> ham 64 bayt
    $o = 2 + (ord($der[1]) & 0x80 ? (ord($der[1]) & 0x7f) : 0);
    $rl = ord($der[$o + 1]); $r = substr($der, $o + 2, $rl); $o2 = $o + 2 + $rl;
    $sl = ord($der[$o2 + 1]); $s = substr($der, $o2 + 2, $sl);
    $raw = str_pad(ltrim($r, "\0"), 32, "\0", STR_PAD_LEFT) . str_pad(ltrim($s, "\0"), 32, "\0", STR_PAD_LEFT);
    return "$h.$c." . nvB64u($raw);
}

/** Yalnızca bilinen push servislerine gönderim (SSRF koruması) */
function nvPushEndpointOk(string $u): bool {
    if (strlen($u) > 600 || !preg_match('#^https://([a-z0-9.-]+)/#i', $u, $m)) return false;
    $h = strtolower($m[1]);
    foreach (['fcm.googleapis.com', 'updates.push.services.mozilla.com', 'push.services.mozilla.com', 'push.apple.com', 'notify.windows.com', 'push.microsoft.com'] as $ok) {
        if ($h === $ok || str_ends_with($h, '.' . $ok)) return true;
    }
    return false;
}

/** Kullanıcının tüm abonelik uçlarına boş push gönderir; süresi dolanları siler. */
function nvPushNotify(string $userId): void {
    try {
        if (!isUuid($userId) || !function_exists('openssl_sign')) return;
        $db = new Supabase();
        $subs = $db->select('push_subscriptions', 'user_id=eq.' . $userId . '&select=id,endpoint&limit=5', true)['data'] ?? [];
        $pub = nvVapidPublic(); if (!$pub || !is_array($subs)) return;
        foreach ($subs as $s) {
            $ep = (string)$s['endpoint']; if (!nvPushEndpointOk($ep)) continue;
            $p = parse_url($ep); $jwt = nvVapidJwt($p['scheme'] . '://' . $p['host']); if (!$jwt) continue;
            $ch = curl_init($ep);
            curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_POSTFIELDS => '', CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 5, CURLOPT_CONNECTTIMEOUT => 3,
                CURLOPT_HTTPHEADER => ['TTL: 3600', 'Urgency: normal', 'Content-Length: 0', 'Authorization: vapid t=' . $jwt . ', k=' . $pub]]);
            curl_exec($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
            if ($code === 404 || $code === 410) $db->delete('push_subscriptions', 'id=eq.' . (int)$s['id'], true);
        }
    } catch (\Throwable $e) {}
}

/** Bildirim eklendiğinde (Supabase::insert kancası) yanıt sonrası push gönder */
function nvPushSchedule(string $userId): void {
    static $done = [];
    if (isset($done[$userId]) || !isUuid($userId)) return;
    $done[$userId] = true;
    register_shutdown_function(function () use ($userId) {
        if (function_exists('fastcgi_finish_request')) @fastcgi_finish_request();
        nvPushNotify($userId);
    });
}
