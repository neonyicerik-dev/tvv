<?php
// ============================================================
// NeonTV - Yavaş istek günlüğü
// Eşik (ms) üstünde süren istekleri logs/slow_requests.log dosyasına JSON satırı olarak yazar.
// Eşik: SLOW_REQUEST_MS ortam değişkeni (varsayılan 1500). 0 = kapalı.
// Yanıt gönderildikten sonra yapılan arka plan işleri (fastcgi_finish_request) süreye dahil olabilir.
// ============================================================
if (!defined('SLOW_REQUEST_MS')) define('SLOW_REQUEST_MS', (int)(getenv('SLOW_REQUEST_MS') !== false && getenv('SLOW_REQUEST_MS') !== '' ? getenv('SLOW_REQUEST_MS') : 1500));

function neonSlowLogPath(): string {
    return dirname(__DIR__) . '/logs/slow_requests.log';
}

if (SLOW_REQUEST_MS > 0 && PHP_SAPI !== 'cli') {
    register_shutdown_function(function () {
        try {
            $start = (float)($_SERVER['REQUEST_TIME_FLOAT'] ?? 0);
            if ($start <= 0) return;
            $ms = (int)round((microtime(true) - $start) * 1000);
            if ($ms < SLOW_REQUEST_MS) return;

            $path = (string)parse_url((string)($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH);
            // sorgu dizgisinden yalnızca parametre ADLARI yazılır (token, e-posta vb. değerler asla kaydedilmez)
            $keys = array_keys($_GET ?? []);
            $line = [
                't'   => date('c'),
                'ms'  => $ms,
                'm'   => $_SERVER['REQUEST_METHOD'] ?? 'GET',
                'p'   => mb_substr($path, 0, 160),
                'q'   => array_slice(array_map(fn($k) => mb_substr((string)$k, 0, 30), $keys), 0, 8),
                'mem' => (int)round(memory_get_peak_usage(true) / 1048576),
                'db'  => class_exists('Supabase', false) ? (int)Supabase::$stats['n'] : 0,
                'dbms'=> class_exists('Supabase', false) ? (int)round(Supabase::$stats['ms']) : 0,
                'slowdb' => class_exists('Supabase', false) ? (string)Supabase::$stats['slow'] : '',
            ];
            $file = neonSlowLogPath();
            $dir  = dirname($file);
            if (!is_dir($dir)) @mkdir($dir, 0755, true);
            if (is_file($file) && filesize($file) > 2 * 1048576) @rename($file, $file . '.1'); // basit döndürme
            @file_put_contents($file, json_encode($line, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n", FILE_APPEND | LOCK_EX);
        } catch (\Throwable $e) { /* günlük hatası isteği bozmasın */ }
    });
}
