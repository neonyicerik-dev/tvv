<?php
// ============================================================
// NeonTV - Hata günlüğü (logs/app_errors.log, satır başına bir JSON)
// Admin → Hata Günlüğü sayfasından okunur. 1 MB'ı geçince eski dosya .1'e taşınır.
// ============================================================
if (!function_exists('neonLogError')) {
    function neonLogError(string $level, string $message, string $file = '', int $line = 0): void {
        try {
            $dir = dirname(__DIR__) . '/logs';
            if (!is_dir($dir) && !@mkdir($dir, 0755, true)) return;
            $path = $dir . '/app_errors.log';
            if (@filesize($path) > 1048576) @rename($path, $path . '.1');
            $root = dirname(__DIR__) . '/';
            $row = [
                't'   => date('Y-m-d H:i:s'),
                'lv'  => $level,
                'msg' => mb_substr($message, 0, 500),
                'at'  => ($file !== '' ? str_replace($root, '', $file) . ':' . $line : ''),
                'url' => mb_substr(($_SERVER['REQUEST_METHOD'] ?? 'CLI') . ' ' . ($_SERVER['REQUEST_URI'] ?? ''), 0, 200),
            ];
            @file_put_contents($path, json_encode($row, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n", FILE_APPEND | LOCK_EX);
        } catch (\Throwable $e) { /* günlük hatası siteyi bozmasın */ }
    }

    set_error_handler(function (int $no, string $str, string $file, int $line) {
        // @ ile bastırılanları ve gürültülü uyarıları (notice/deprecated) kaydetme
        if (!(error_reporting() & $no)) return false;
        $map = [E_WARNING => 'WARNING', E_USER_WARNING => 'WARNING', E_USER_ERROR => 'ERROR', E_RECOVERABLE_ERROR => 'ERROR'];
        if (isset($map[$no])) neonLogError($map[$no], $str, $file, $line);
        return true;
    });
    set_exception_handler(function (\Throwable $e) {
        neonLogError('EXCEPTION', get_class($e) . ': ' . $e->getMessage(), $e->getFile(), $e->getLine());
        if (!headers_sent()) http_response_code(500);
        echo 'Beklenmeyen bir hata oluştu.';
    });
    register_shutdown_function(function () {
        $e = error_get_last();
        if ($e && in_array($e['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
            neonLogError('FATAL', $e['message'], $e['file'], (int)$e['line']);
        }
    });
}
