<?php
// ============================================================
// NeonTV - Footer Bileşeni (Yeniden Tasarım)
// ============================================================
?>
</main><!-- /main -->

<!-- ===== FOOTER ===== -->
<footer class="mt-20 relative overflow-hidden" style="background:#090916;">

    <!-- Top glow line -->
    <div style="height:1px;background:linear-gradient(90deg,transparent,rgba(0,245,255,0.4),rgba(191,0,255,0.4),transparent);"></div>

    <!-- Ambient background glow -->
    <div class="absolute inset-0 pointer-events-none" style="
        background:
            radial-gradient(ellipse 60% 40% at 20% 0%, rgba(0,245,255,0.04) 0%, transparent 70%),
            radial-gradient(ellipse 60% 40% at 80% 0%, rgba(191,0,255,0.04) 0%, transparent 70%);
    "></div>

    <div class="max-w-screen-2xl mx-auto px-4 sm:px-6 relative">

        <!-- Main Footer Content -->
        <div class="py-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">

            <!-- Branding -->
            <div class="lg:col-span-2">
                <a href="<?= APP_URL ?>/index.php" class="inline-flex items-center gap-3 mb-4 group">
                    <div class="w-10 h-10 rounded-xl flex items-center justify-center transition-all group-hover:scale-110"
                         style="background:linear-gradient(135deg,rgba(0,245,255,0.15),rgba(191,0,255,0.15));border:1px solid rgba(0,245,255,0.3);">
                        <i class="fa-solid fa-tv text-base" style="color:#00f5ff;filter:drop-shadow(0 0 8px #00f5ff);"></i>
                    </div>
                    <span class="text-xl font-bold" style="background:linear-gradient(135deg,#00f5ff,#bf00ff);-webkit-background-clip:text;-webkit-text-fill-color:transparent;">
                        NeonTV
                    </span>
                </a>
                <p class="text-sm text-gray-500 leading-relaxed max-w-sm mb-6">
                    Neon ışıklı video deneyimi. En kaliteli içerikleri izleyin, yorum yapın ve beğenin. AI destekli altyazı ve içerik oluşturma ile geleceğin platformu.
                </p>
                <!-- Social / AI badges -->
                <div class="flex items-center gap-2 flex-wrap">
                    <span class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold"
                          style="background:rgba(0,245,255,0.06);color:#00f5ff;border:1px solid rgba(0,245,255,0.15);">
                        <i class="fa-solid fa-robot text-[10px]"></i>AI Destekli
                    </span>
                    <span class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold"
                          style="background:rgba(191,0,255,0.06);color:#bf00ff;border:1px solid rgba(191,0,255,0.15);">
                        <i class="fa-solid fa-closed-captioning text-[10px]"></i>Otomatik Altyazı
                    </span>
                    <span class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold"
                          style="background:rgba(255,0,122,0.06);color:#ff007a;border:1px solid rgba(255,0,122,0.15);">
                        <i class="fa-solid fa-cloud text-[10px]"></i>HD Streaming
                    </span>
                </div>
            </div>

            <!-- Keşfet -->
            <div>
                <h4 class="text-xs font-bold text-gray-300 mb-5 uppercase tracking-widest flex items-center gap-2">
                    <span class="w-4 h-px" style="background:linear-gradient(90deg,#00f5ff,transparent);"></span>
                    Keşfet
                </h4>
                <ul class="space-y-3">
                    <li>
                        <a href="<?= APP_URL ?>/index.php"
                           class="group flex items-center gap-2.5 text-sm text-gray-500 hover:text-white transition-all duration-200">
                            <i class="fa-solid fa-house text-[10px] w-3.5 text-gray-700 group-hover:text-cyan-400 transition-colors"></i>
                            Ana Sayfa
                            <i class="fa-solid fa-arrow-right text-[8px] opacity-0 group-hover:opacity-100 -translate-x-1 group-hover:translate-x-0 transition-all"></i>
                        </a>
                    </li>
                    <li>
                        <a href="<?= APP_URL ?>/search.php"
                           class="group flex items-center gap-2.5 text-sm text-gray-500 hover:text-white transition-all duration-200">
                            <i class="fa-solid fa-magnifying-glass text-[10px] w-3.5 text-gray-700 group-hover:text-cyan-400 transition-colors"></i>
                            Video Ara
                            <i class="fa-solid fa-arrow-right text-[8px] opacity-0 group-hover:opacity-100 -translate-x-1 group-hover:translate-x-0 transition-all"></i>
                        </a>
                    </li>
                    <li>
                        <a href="<?= APP_URL ?>/myprofile" id="footer-profile-link"
                           class="group flex items-center gap-2.5 text-sm text-gray-500 hover:text-white transition-all duration-200">
                            <i class="fa-solid fa-user text-[10px] w-3.5 text-gray-700 group-hover:text-cyan-400 transition-colors"></i>
                            Profilim
                            <i class="fa-solid fa-arrow-right text-[8px] opacity-0 group-hover:opacity-100 -translate-x-1 group-hover:translate-x-0 transition-all"></i>
                        </a>
                    </li>
                </ul>
            </div>

            <!-- Platform -->
            <div>
                <h4 class="text-xs font-bold text-gray-300 mb-5 uppercase tracking-widest flex items-center gap-2">
                    <span class="w-4 h-px" style="background:linear-gradient(90deg,#bf00ff,transparent);"></span>
                    Platform
                </h4>
                <ul class="space-y-3">
                    <?php if (isset($_SESSION['neontv_admin_logged_in'])): ?>
                    <li>
                        <a href="<?= APP_URL ?>/admin/index.php"
                           class="group flex items-center gap-2.5 text-sm text-gray-500 hover:text-white transition-all duration-200">
                            <i class="fa-solid fa-gauge text-[10px] w-3.5 text-gray-700 group-hover:text-purple-400 transition-colors"></i>
                            Admin Panel
                            <i class="fa-solid fa-arrow-right text-[8px] opacity-0 group-hover:opacity-100 -translate-x-1 group-hover:translate-x-0 transition-all"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                    <li>
                        <span class="flex items-center gap-2.5 text-sm text-gray-600">
                            <i class="fa-solid fa-shield-halved text-[10px] w-3.5"></i>
                            Gizlilik Politikası
                        </span>
                    </li>
                    <li>
                        <span class="flex items-center gap-2.5 text-sm text-gray-600">
                            <i class="fa-solid fa-file-lines text-[10px] w-3.5"></i>
                            Kullanım Koşulları
                        </span>
                    </li>
                    <li>
                        <a href="<?= APP_URL ?>/iletisim.php"
                           class="group flex items-center gap-2.5 text-sm text-gray-500 hover:text-white transition-all duration-200">
                            <i class="fa-solid fa-envelope text-[10px] w-3.5 text-gray-700 group-hover:text-pink-400 transition-colors"></i>
                            İletişim
                            <i class="fa-solid fa-arrow-right text-[8px] opacity-0 group-hover:opacity-100 -translate-x-1 group-hover:translate-x-0 transition-all"></i>
                        </a>
                    </li>
                    <li>
                        <a href="<?= APP_URL ?>/app.php"
                           class="group flex items-center gap-2.5 text-sm text-gray-500 hover:text-white transition-all duration-200">
                            <i class="fa-solid fa-mobile-screen-button text-[10px] w-3.5 text-gray-700 group-hover:text-cyan-400 transition-colors"></i>
                            Uygulamayı İndir
                            <i class="fa-solid fa-arrow-right text-[8px] opacity-0 group-hover:opacity-100 -translate-x-1 group-hover:translate-x-0 transition-all"></i>
                        </a>
                    </li>
                </ul>
            </div>
        </div>

        <!-- Bottom Bar -->
        <div class="flex flex-col sm:flex-row items-center justify-between gap-3 py-6"
             style="border-top:1px solid rgba(255,255,255,0.05);">
            <p class="text-xs text-gray-600 flex items-center gap-1.5">
                <i class="fa-regular fa-copyright text-[10px]"></i>
                <?= date('Y') ?> <strong class="text-gray-500"><?= APP_NAME ?></strong>. Tüm haklar saklıdır.
            </p>
            <div class="flex items-center gap-4">
                <div class="flex items-center gap-1.5 text-xs text-gray-700">
                    <span class="w-1.5 h-1.5 rounded-full bg-green-500 inline-block" style="box-shadow:0 0 4px #22c55e;"></span>
                    Tüm sistemler aktif
                </div>
                <div class="flex items-center gap-1 text-xs text-gray-700">
                    <i class="fa-solid fa-bolt text-[10px]" style="color:#00f5ff;"></i>
                    <span>NeonTV Platform</span>
                </div>
            </div>
        </div>
    </div>
</footer>

<!-- ===== GLOBAL JS ===== -->
<script>
// Supabase Client
const _supabaseUrl  = '<?= SUPABASE_URL ?>';
const _supabaseAnon = '<?= SUPABASE_ANON_KEY ?>';
const _appUrl       = '<?= APP_URL ?>';
const sbClient      = supabase.createClient(_supabaseUrl, _supabaseAnon);

// --------------------------------------------------------
// Mobile Search Toggle
// --------------------------------------------------------
document.getElementById('mobile-search-toggle')?.addEventListener('click', () => {
    const ms = document.getElementById('mobile-search');
    ms.classList.toggle('hidden');
});

// --------------------------------------------------------
// User Menu Dropdown
// --------------------------------------------------------
document.getElementById('user-menu-btn')?.addEventListener('click', (e) => {
    e.stopPropagation();
    document.getElementById('user-dropdown')?.classList.toggle('hidden');
});
document.addEventListener('click', () => {
    document.getElementById('user-dropdown')?.classList.add('hidden');
});

// --------------------------------------------------------
// Auth State - Supabase
// --------------------------------------------------------
(async function initAuth() {
    const { data: { session } } = await sbClient.auth.getSession();
    updateAuthUI(session);

    sbClient.auth.onAuthStateChange((_event, session) => {
        updateAuthUI(session);
    });
})();

function updateAuthUI(session) {
    const authBtns  = document.getElementById('auth-buttons');
    const userMenu  = document.getElementById('user-menu');
    const logoutBtn = document.getElementById('logout-btn');

    if (session && session.user) {
        authBtns?.classList.add('hidden');
        userMenu?.classList.remove('hidden');

        const user     = session.user;
        const username = user.user_metadata?.username || user.email?.split('@')[0] || 'Kullanici';
        const initial  = username.charAt(0).toUpperCase();
        const avatarUrl = user.user_metadata?.avatar_url || '';

        if (document.getElementById('user-avatar-initial'))
            document.getElementById('user-avatar-initial').textContent = initial;
        if (document.getElementById('user-display-name'))
            document.getElementById('user-display-name').textContent = username;
        if (document.getElementById('user-display-email'))
            document.getElementById('user-display-email').textContent = user.email || '';

        // Profil resmi desteği
        const avatarImg = document.getElementById('user-avatar-img');
        const avatarInitial = document.getElementById('user-avatar-initial');
        if (avatarImg && avatarUrl) {
            avatarImg.src = avatarUrl;
            avatarImg.classList.remove('hidden');
            if (avatarInitial) avatarInitial.classList.add('hidden');
        }

        localStorage.setItem('sb_access_token', session.access_token);
        localStorage.setItem('sb_user', JSON.stringify({ id: user.id, username, email: user.email, avatar_url: avatarUrl }));
    } else {
        authBtns?.classList.remove('hidden');
        userMenu?.classList.add('hidden');
        localStorage.removeItem('sb_access_token');
        localStorage.removeItem('sb_user');
    }

    if (logoutBtn) {
        logoutBtn.addEventListener('click', async () => {
            await sbClient.auth.signOut();
            window.location.reload();
        });
    }
}

// Kullanıcı token helper
function getAuthToken() {
    return localStorage.getItem('sb_access_token');
}
function getCurrentUser() {
    const raw = localStorage.getItem('sb_user');
    return raw ? JSON.parse(raw) : null;
}
</script>

<script src="<?= APP_URL ?>/assets/js/main.js"></script>
<script>
// Bildirim rozeti
window.addEventListener('load', async function () {
    try {
        const { data } = await sbClient.auth.getSession(); const t = data.session && data.session.access_token; if (!t) return;
        const j = await (await fetch('<?= APP_URL ?>/api/notifications.php?token=' + encodeURIComponent(t), { headers: { 'Authorization': 'Bearer ' + t, 'X-Access-Token': t } })).json();
        const n = j && j.data ? j.data.unread : 0, b = document.getElementById('notif-badge');
        if (b && n > 0) { b.textContent = n > 9 ? '9+' : n; b.classList.remove('hidden'); }
    } catch (e) {}
});
</script>
<script>
// Engellenen kanal/kullanıcı içeriklerini gizle (giriş yapmış kullanıcı için)
window.addEventListener('load', async function () {
    try {
        const { data } = await sbClient.auth.getSession(); const t = data.session && data.session.access_token; if (!t) return;
        let B = null; try { B = JSON.parse(sessionStorage.getItem('neon_blocks') || 'null'); } catch (e) {}
        if (!B || Date.now() - B.t > 60000) {
            const j = await (await fetch('<?= APP_URL ?>/api/blocks.php?token=' + encodeURIComponent(t), { headers: { 'Authorization': 'Bearer ' + t, 'X-Access-Token': t } })).json();
            if (!j.success) return;
            B = { t: Date.now(), c: j.data.channels.map(x => x.id), u: j.data.users.map(x => x.id) };
            try { sessionStorage.setItem('neon_blocks', JSON.stringify(B)); } catch (e) {}
        }
        if (B.c.length) document.querySelectorAll('[data-channel-id]').forEach(el => { if (B.c.includes(el.dataset.channelId) && el.id !== 'channel-subscribe-btn') el.style.display = 'none'; });
        if (B.u.length) document.querySelectorAll('.comment-item[data-uid]').forEach(el => {
            if (!B.u.includes(el.dataset.uid)) return;
            const th = el.closest('.comment-thread');
            (th && th.querySelector('.comment-item') === el ? th : el).style.display = 'none';
        });
    } catch (e) {}
});
</script>
</body>
</html>
