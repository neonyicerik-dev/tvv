<?php
// ============================================================
// NeonTV - Header Bileşeni
// ============================================================
if (!defined('APP_NAME')) {
    require_once __DIR__ . '/../includes/config.php';
    require_once __DIR__ . '/../includes/helpers.php';
}
// Store erişimi (Store daha önce yüklenmemişse yükle)
if (!class_exists('Store')) {
    require_once __DIR__ . '/../includes/store.php';
}

// G1: settings.json yerine Store (Supabase) kullan
$siteSettings        = Store::getSettings();
$ageWarningEnabled   = !empty($siteSettings['age_warning_enabled']);
$ageWarningTitle     = $siteSettings['age_warning_title']    ?? '+18 İçerik Uyarısı';
$ageWarningText      = $siteSettings['age_warning_text']     ?? 'Bu site 18 yaş ve üzeri yetişkinlere yönelik içerikler barındırmaktadır.';
$ageWarningBtnYes    = $siteSettings['age_warning_btn_yes']  ?? '18 Yaşındayım, Devam Et';
$ageWarningBtnNo     = $siteSettings['age_warning_btn_no']   ?? 'Hayır, Çık';
$ageWarningRedirect  = $siteSettings['age_warning_redirect'] ?? 'https://www.google.com';

$currentPage = basename($_SERVER['PHP_SELF'], '.php');
$searchQuery = e(input('q', '', 'GET'));

// G1: page_meta ve site_meta_robots artık Store üzerinden geliyor
$pageMeta   = is_array($siteSettings['page_meta'] ?? null) ? $siteSettings['page_meta'] : [];
$metaRobots = $siteSettings['site_meta_robots'] ?? 'index,follow';
$siteOgImage= $siteSettings['site_og_image'] ?? '';

// F2/F3: Popup kontrolu (bir kez al, sayfa genelinde kullan)
$activePopup = Store::getActivePopup();
$bannerAd    = Store::getActiveBannerAd();
$videoAds    = Store::getActiveVideoAds();
// JS'e aktar
$videoAdsJson   = json_encode($videoAds, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
$bannerAdJson   = $bannerAd ? json_encode($bannerAd, JSON_UNESCAPED_UNICODE) : 'null';

// Özel/arama sayfaları indekslenmesin
if (in_array($currentPage, ['library', 'notifications', 'myprofile', 'auth', 'random', 'subscriptions'], true) || ($currentPage === 'search')) {
    $metaRobots = 'noindex,follow';
}

// Canonical URL
$canonicalUrl = APP_URL . strtok($_SERVER['REQUEST_URI'] ?? '/', '?');
// Video/Kanal sayfaları için tam URL (query string ile)
if (in_array($currentPage, ['video', 'channel', 'user'], true) && !empty($_GET['id'])) {
    $canonicalUrl = APP_URL . '/' . $currentPage . '.php?id=' . urlencode((string)$_GET['id']);
}

// Sayfa başlığı ve açıklaması — önce page_meta'yı kontrol et, yoksa mevcut değişkenleri kullan
switch ($currentPage) {
    case 'index':
        if (!isset($pageTitle) && isset($pageMeta['index']['title'])) {
            $pageTitle = $pageMeta['index']['title'];
        }
        if (!isset($metaDesc) && isset($pageMeta['index']['description'])) {
            $metaDesc = $pageMeta['index']['description'];
        }
        if (!isset($ogImage) && !empty($pageMeta['index']['og_image'])) {
            $ogImage = $pageMeta['index']['og_image'];
        }
        break;
    case 'search':
        if (!isset($pageTitle) && !empty($pageMeta['search']['title'])) {
            $pageTitle = $pageMeta['search']['title'];
        }
        if (!isset($metaDesc) && isset($pageMeta['search']['description'])) {
            $metaDesc = $pageMeta['search']['description'];
        }
        break;
    case 'auth':
        if (!isset($pageTitle) && isset($pageMeta['auth']['title'])) {
            $pageTitle = $pageMeta['auth']['title'];
        }
        if (!isset($metaDesc) && isset($pageMeta['auth']['description'])) {
            $metaDesc = $pageMeta['auth']['description'];
        }
        break;
    case 'video':
        // Video sayfası için format uygula
        if (isset($metaDesc) && !empty($pageMeta['video']['description_format']) && str_contains($pageMeta['video']['description_format'], '%s')) {
            $metaDesc = truncate(sprintf($pageMeta['video']['description_format'], $metaDesc), 200);
        }
        if (isset($pageTitle) && !empty($pageMeta['video']['title_format']) && str_contains($pageMeta['video']['title_format'], '%s')) {
            $pageTitle = sprintf($pageMeta['video']['title_format'], $pageTitle);
        }
        break;
    case 'channel':
        // Kanal sayfası için format uygula
        if (isset($metaDesc) && !empty($pageMeta['channel']['description_format']) && str_contains($pageMeta['channel']['description_format'], '%s') && isset($GLOBALS['channel']['name'])) {
            $metaDesc = truncate(sprintf($pageMeta['channel']['description_format'], $GLOBALS['channel']['name']), 200);
        }
        if (isset($pageTitle) && !empty($pageMeta['channel']['title_format']) && str_contains($pageMeta['channel']['title_format'], '%s')) {
            $pageTitle = sprintf($pageMeta['channel']['title_format'], $pageTitle);
        }
        break;
}

// OG Image için site geneli fallback
if (!isset($ogImage) || $ogImage === '') {
    $ogImage = $siteOgImage;
}

// Nihai başlık: sayfa title_format yoksa klasik format
$finalTitle = isset($pageTitle)
    ? (str_contains($pageTitle, APP_NAME) ? $pageTitle : $pageTitle . ' | ' . APP_NAME)
    : (APP_NAME . ' - ' . APP_TAGLINE);
$finalDesc  = isset($metaDesc)
    ? $metaDesc
    : ($siteSettings['page_meta']['index']['description'] ?? 'NeonTV - Neon ışıklı video deneyimi. En iyi videoları izleyin.');
?>
<!DOCTYPE html>
<html lang="tr" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?= e($finalDesc) ?>">
    <meta name="robots" content="<?= e($metaRobots) ?>">
    <meta property="og:title" content="<?= e($finalTitle) ?>">
    <meta property="og:description" content="<?= e($finalDesc) ?>">
    <meta property="og:url" content="<?= e($canonicalUrl) ?>">
    <?php if (!empty($ogImage)): ?>
    <meta property="og:image" content="<?= e($ogImage) ?>">
    <meta name="twitter:image" content="<?= e($ogImage) ?>">
    <?php endif; ?>
    <meta property="og:type" content="<?= $currentPage === 'video' ? 'video.other' : 'website' ?>">
    <meta property="og:locale" content="tr_TR">
    <meta property="og:site_name" content="<?= APP_NAME ?>">
    <meta name="twitter:card" content="<?= !empty($ogImage) ? 'summary_large_image' : 'summary' ?>">
    <meta name="twitter:title" content="<?= e($finalTitle) ?>">
    <meta name="twitter:description" content="<?= e($finalDesc) ?>">
    <title><?= e($finalTitle) ?></title>
    <link rel="canonical" href="<?= e($canonicalUrl) ?>">
    <meta name="view-transition" content="same-origin">

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="<?= APP_URL ?>/assets/img/favicon.ico">
    <link rel="shortcut icon" type="image/x-icon" href="<?= APP_URL ?>/assets/img/favicon.ico">

    <!-- Tailwind (önceden derlenmiş; yeniden üretmek için deploy/build-tailwind.sh) -->
    <link rel="stylesheet" href="<?= APP_URL ?>/assets/css/tw.css?v=<?= (int)@filemtime(__DIR__ . '/../assets/css/tw.css') ?>">
    <!-- NeTvYZ & Popup Stilleri -->
    <link rel="stylesheet" href="<?= APP_URL ?>/assets/css/assistant.css">

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet" media="print" onload="this.media='all'">
    <noscript><link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet"></noscript>

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" media="print" onload="this.media='all'">
    <noscript><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"></noscript>
    <link rel="preconnect" href="https://cdnjs.cloudflare.com" crossorigin>

    <!-- Supabase JS -->
    <script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/dist/umd/supabase.min.js"></script>

    <script>try{var __t=localStorage.getItem('neon_theme');if(__t)document.documentElement.setAttribute('data-theme',__t);}catch(e){}</script>
    <style id="theme-css">
        :root{--ac1:0 245 255;--ac2:191 0 255;--ac1h:#00f5ff;--ac2h:#bf00ff}
        html[data-theme="mavi"]{--ac1:96 165 250;--ac2:99 102 241;--ac1h:#60a5fa;--ac2h:#6366f1}
        html[data-theme="kirmizi"]{--ac1:255 77 109;--ac2:255 122 0;--ac1h:#ff4d6d;--ac2h:#ff7a00}
        html[data-theme="sade"]{--ac1:226 232 240;--ac2:148 163 184;--ac1h:#e2e8f0;--ac2h:#94a3b8}
        html[data-theme] .text-cyan-300,html[data-theme] .text-cyan-400,html[data-theme] .text-cyan-500,html[data-theme] .hover\:text-cyan-400:hover{color:var(--ac1h)!important}
        html[data-theme] .bg-cyan-300,html[data-theme] .bg-cyan-400,html[data-theme] .bg-cyan-500,html[data-theme] .hover\:bg-cyan-300:hover{background-color:var(--ac1h)!important}
        html[data-theme] .border-cyan-400,html[data-theme] .border-cyan-500{border-color:var(--ac1h)!important}
        html[data-theme] [style*="linear-gradient(135deg,#00f5ff,#bf00ff)"],html[data-theme] [style*="linear-gradient(135deg, #00f5ff, #bf00ff)"]{background:linear-gradient(135deg,var(--ac1h),var(--ac2h))!important}
        html[data-theme] [style*="background:#00f5ff"]{background:var(--ac1h)!important}
        html[data-theme] #progress-bar{background:linear-gradient(90deg,var(--ac1h),var(--ac2h))!important}
        .theme-dot{width:22px;height:22px;border-radius:999px;border:2px solid transparent;cursor:pointer}
        .theme-dot.on{border-color:#fff}
    </style>
    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?= APP_URL ?>/assets/css/app.css">
    <?php if (!empty($needThemes)): ?><link rel="stylesheet" href="<?= APP_URL ?>/assets/css/themes.css?v=<?= (int)@filemtime(__DIR__ . '/../assets/css/themes.css') ?>"><?php endif; ?>

    <style>
        body { font-family: 'Outfit', sans-serif; background-color: #070711; color: #fff; }
    </style>
</head>
<body class="bg-dark-900 text-white min-h-screen flex flex-col">
<?php
$__an = $siteSettings['site_announcement'] ?? null;
if (is_array($__an) && !empty($__an['enabled']) && trim($__an['text'] ?? '') !== '' && (empty($__an['ends_at']) || strtotime($__an['ends_at']) > time())):
    $__col = ['cyan' => ['#00f5ff', '#001a1c'], 'purple' => ['#bf00ff', '#fff'], 'red' => ['#ff3b5c', '#fff'], 'green' => ['#22c55e', '#00180a'], 'yellow' => ['#fbbf24', '#1c1300']][$__an['color'] ?? 'cyan'] ?? ['#00f5ff', '#001a1c'];
?>
<div id="site-announce" data-id="<?= e($__an['id'] ?? '1') ?>" style="display:none;background:<?= $__col[0] ?>;color:<?= $__col[1] ?>;" class="relative z-50 text-center text-sm font-semibold px-10 py-2">
    <?php if (!empty($__an['link'])): ?><a href="<?= e($__an['link']) ?>" style="color:inherit;text-decoration:underline"><?= e($__an['text']) ?></a><?php else: ?><?= e($__an['text']) ?><?php endif; ?>
    <button type="button" id="site-announce-x" aria-label="Kapat" style="position:absolute;right:12px;top:50%;transform:translateY(-50%);color:inherit;font-size:16px;line-height:1">✕</button>
</div>
<script>(function(){var b=document.getElementById('site-announce');if(!b)return;var k='ann_closed_'+b.dataset.id,c=false;try{c=localStorage.getItem(k)==='1'}catch(e){}if(!c)b.style.display='block';document.getElementById('site-announce-x').onclick=function(){b.style.display='none';try{localStorage.setItem(k,'1')}catch(e){}};})();</script>
<?php endif; ?>

<?php if ($ageWarningEnabled): $ageCookieOk = ($_COOKIE['neontv_age_ok'] ?? '') === '1'; ?>
<!-- ===== +18 YAŞ UYARI MODALI ===== -->
<div id="age-warning-modal" role="dialog" aria-modal="true" aria-label="+18 uyarısı" style="
    display:<?= $ageCookieOk ? 'none' : 'flex' ?>;
    position:fixed;inset:0;z-index:99999;
    background:rgba(7,7,17,0.97);
    backdrop-filter:blur(20px);
    align-items:center;justify-content:center;
">
    <!-- Animasyonlu arkaplan -->
    <div style="position:absolute;inset:0;overflow:hidden;pointer-events:none;">
        <div style="position:absolute;width:600px;height:600px;border-radius:50%;background:radial-gradient(circle,rgba(255,0,122,0.08) 0%,transparent 70%);top:-200px;left:-200px;"></div>
        <div style="position:absolute;width:500px;height:500px;border-radius:50%;background:radial-gradient(circle,rgba(191,0,255,0.07) 0%,transparent 70%);bottom:-150px;right:-100px;"></div>
    </div>

    <!-- Modal Kutusu -->
    <div style="
        position:relative;z-index:1;
        max-width:460px;width:90%;
        background:#0f0f1e;
        border:1px solid rgba(255,0,122,0.3);
        border-radius:1.5rem;
        padding:2.5rem 2rem;
        text-align:center;
        animation:ageModalIn 0.4s cubic-bezier(0.34,1.56,0.64,1);
    " id="age-modal-box">

        <!-- İkon -->
        <div style="
            width:80px;height:80px;border-radius:50%;
            background:linear-gradient(135deg,rgba(255,0,122,0.2),rgba(191,0,255,0.2));
            border:2px solid rgba(255,0,122,0.4);
            display:flex;align-items:center;justify-content:center;
            margin:0 auto 1.5rem;
            animation:pulsePink 2s ease-in-out infinite;
        ">
            <span style="font-size:2rem;">🔞</span>
        </div>
        <div style="display:inline-block;margin:-0.5rem auto 1rem;padding:2px 12px;border-radius:999px;background:#ff007a;color:#fff;font-weight:900;letter-spacing:.08em;font-size:.8rem;">SADECE 18 YAŞ ÜSTÜ</div>

        <!-- Başlık -->
        <h2 style="font-size:1.5rem;font-weight:800;color:#fff;margin-bottom:0.75rem;line-height:1.2;">
            <?= e($ageWarningTitle) ?>
        </h2>

        <!-- Açıklama -->
        <p style="font-size:0.875rem;color:#9ca3af;margin-bottom:0.5rem;line-height:1.6;">
            <?= e($ageWarningText) ?>
        </p>
        <p style="font-size:0.75rem;color:#6b7280;margin-bottom:2rem;">
            Devam ederek <strong style="color:#fff;">kullanım koşullarımızı</strong> kabul etmiş olursunuz.
        </p>

        <!-- Butonlar -->
        <div style="display:flex;gap:1rem;justify-content:center;flex-wrap:wrap;">
            <button id="age-yes-btn" onclick="ageAccept()" style="
                flex:1;min-width:140px;
                padding:0.875rem 1.5rem;
                border-radius:12px;
                background:linear-gradient(135deg,#ff007a,#bf00ff);
                color:#fff;font-weight:700;font-size:0.875rem;
                border:none;cursor:pointer;
                transition:all 0.2s;
                box-shadow:0 0 20px rgba(255,0,122,0.3);
            " onmouseover="this.style.transform='scale(1.04)'" onmouseout="this.style.transform='scale(1)'">
                <i class="fa-solid fa-check mr-2"></i><?= e($ageWarningBtnYes) ?>
            </button>
            <button onclick="ageReject()" style="
                flex:1;min-width:120px;
                padding:0.875rem 1.5rem;
                border-radius:12px;
                background:rgba(255,255,255,0.06);
                border:1px solid rgba(255,255,255,0.12);
                color:#9ca3af;font-weight:600;font-size:0.875rem;
                cursor:pointer;transition:all 0.2s;
            " onmouseover="this.style.color='#fff'" onmouseout="this.style.color='#9ca3af'">
                <i class="fa-solid fa-xmark mr-2"></i><?= e($ageWarningBtnNo) ?>
            </button>
        </div>
    </div>
</div>

<style>
@keyframes ageModalIn {
    from { opacity:0; transform:scale(0.8) translateY(20px); }
    to   { opacity:1; transform:scale(1) translateY(0); }
}
@keyframes pulsePink {
    0%,100% { box-shadow:0 0 0 0 rgba(255,0,122,0.3); }
    50%      { box-shadow:0 0 0 12px rgba(255,0,122,0); }
}
</style>

<script>
(function(){
    const REDIRECT = <?= json_encode($ageWarningRedirect) ?>;
    const KEY = 'neontv_age_ok', DAYS = 30;
    const modal = document.getElementById('age-warning-modal');
    if (!modal) return;
    const secure = location.protocol === 'https:' ? '; Secure' : '';
    function setCookie() { document.cookie = KEY + '=1; max-age=' + (DAYS * 86400) + '; path=/; SameSite=Lax' + secure; }
    function legacyOk() { try { const v = localStorage.getItem(KEY); if (!v) return false; if (v === '1') return true; return (Date.now() - parseInt(v, 10)) < DAYS * 86400000; } catch (e) { return false; } }
    const hasCookie = document.cookie.split('; ').indexOf(KEY + '=1') !== -1;

    function reminder() {
        try { if (sessionStorage.getItem('neontv_age_bar')) return; sessionStorage.setItem('neontv_age_bar', '1'); } catch (e) {}
        const b = document.createElement('div');
        b.style.cssText = 'position:fixed;left:0;right:0;bottom:0;z-index:9998;display:flex;align-items:center;gap:10px;justify-content:center;padding:8px 14px;background:rgba(255,0,122,.92);color:#fff;font-size:12px;font-weight:600;';
        const t = document.createElement('span'); t.textContent = '🔞 Bu site yalnızca 18 yaş ve üzeri içindir.';
        const x = document.createElement('button'); x.textContent = '✕'; x.setAttribute('aria-label', 'Kapat'); x.style.cssText = 'background:none;border:0;color:#fff;cursor:pointer;font-size:14px';
        x.onclick = () => b.remove(); b.append(t, x); document.body.appendChild(b);
        setTimeout(() => b.remove(), 12000);
    }

    if (hasCookie || legacyOk()) {
        if (!hasCookie) setCookie();
        modal.style.display = 'none'; document.body.style.overflow = ''; reminder();
    } else {
        modal.style.display = 'flex'; document.body.style.overflow = 'hidden';
    }

    window.ageAccept = function() {
        setCookie(); try { localStorage.setItem(KEY, String(Date.now())); sessionStorage.setItem('neontv_age_bar', '1'); } catch (e) {}
        modal.style.opacity = '0'; modal.style.transition = 'opacity 0.3s';
        setTimeout(() => { modal.style.display = 'none'; document.body.style.overflow = ''; }, 300);
    };
    window.ageReject = function() { window.location.href = REDIRECT; };
})();
</script>
<?php endif; ?>


<nav id="navbar" class="sticky top-0 z-50 transition-all duration-300" style="background:rgba(7,7,17,0.85);backdrop-filter:blur(20px);border-bottom:1px solid rgba(255,255,255,0.06);">
    <div class="max-w-screen-2xl mx-auto px-4 sm:px-6">
        <div class="flex items-center justify-between h-16">

            <!-- Logo -->
            <a href="<?= APP_URL ?>/index.php" class="flex items-center gap-2 group" id="nav-logo">
                <div class="relative">
                    <i class="fa-solid fa-tv text-2xl" style="color:#00f5ff;filter:drop-shadow(0 0 8px #00f5ff);"></i>
                </div>
                <span class="text-xl font-bold tracking-tight" style="background:linear-gradient(135deg,#00f5ff,#bf00ff);-webkit-background-clip:text;-webkit-text-fill-color:transparent;">
                    Neon<span class="font-black">TV</span>
                </span>
            </a>

            <!-- Search Bar (masaüstü) -->
            <form action="<?= APP_URL ?>/search.php" method="GET" class="hidden md:flex flex-1 max-w-xl mx-8" id="search-form" autocomplete="off">
                <a href="<?= APP_URL ?>/random.php" title="Rastgele video" id="random-btn"
                   class="shrink-0 w-9 h-9 rounded-full flex items-center justify-center text-gray-300 hover:text-black transition-all mr-2 hover:bg-cyan-300"
                   style="background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);">
                    <i class="fa-solid fa-shuffle text-sm"></i>
                </a>
                <div class="relative w-full" id="search-wrapper">
                    <input
                        type="text"
                        name="q"
                        id="search-input"
                        value="<?= $searchQuery ?>"
                        placeholder="Video ara..."
                        autocomplete="off"
                        class="w-full py-2 pl-4 pr-12 rounded-full text-sm text-white placeholder-gray-500 outline-none transition-all duration-300"
                        style="background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);"
                        onfocus="this.style.borderColor='rgba(0,245,255,0.5)';this.style.boxShadow='0 0 0 3px rgba(0,245,255,0.08)'"
                        onblur="this.style.borderColor='rgba(255,255,255,0.1)';this.style.boxShadow='none'"
                    >
                    <button type="submit" class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-neon-cyan transition-colors" id="search-btn">
                        <i class="fa-solid fa-magnifying-glass text-sm"></i>
                    </button>
                    <!-- Canlı Arama Dropdown -->
                    <div id="search-dropdown"
                         style="display:none;position:absolute;top:calc(100% + 8px);left:0;right:0;
                                background:#13131f;border:1px solid rgba(0,245,255,0.15);border-radius:14px;
                                box-shadow:0 16px 48px rgba(0,0,0,0.6),0 0 0 1px rgba(0,245,255,0.05);
                                z-index:200;overflow:hidden;backdrop-filter:blur(20px);">
                        <div id="search-dropdown-list"></div>
                        <div id="search-dropdown-footer" style="display:none;padding:8px 12px;border-top:1px solid rgba(255,255,255,0.05);"></div>
                    </div>
                </div>
            </form>

            <!-- Sağ Menü -->
            <div class="flex items-center gap-3">
                <!-- Mobil arama -->
                <button id="mobile-search-toggle" class="md:hidden text-gray-400 hover:text-white p-2 transition-colors">
                    <i class="fa-solid fa-magnifying-glass"></i>
                </button>

                <!-- Auth Butonları -->
                <div id="auth-buttons" class="flex items-center gap-2">
                    <a href="<?= APP_URL ?>/auth.php" id="login-btn-nav"
                       class="flex items-center gap-2 px-3 sm:px-4 py-2 rounded-full text-xs sm:text-sm font-medium transition-all duration-200 hover:bg-white/10"
                       style="border:1px solid rgba(255,255,255,0.15);">
                        <i class="fa-solid fa-right-to-bracket text-xs"></i>
                        <span>Giris Yap</span>
                    </a>
                    <a href="<?= APP_URL ?>/auth.php?tab=register" id="register-btn-nav"
                       class="flex items-center gap-2 px-3 sm:px-4 py-2 rounded-full text-xs sm:text-sm font-semibold transition-all duration-200"
                       style="background:linear-gradient(135deg,#00f5ff,#bf00ff);color:#000;">
                        <i class="fa-solid fa-user-plus text-xs"></i>
                        <span>Kayit Ol</span>
                    </a>
                </div>

                <!-- Kullanıcı Menüsü (giriş yapıldığında gösterilir) -->
                <div id="user-menu" class="relative hidden">
                    <button id="user-menu-btn" class="flex items-center gap-2 p-1 rounded-full hover:bg-white/10 transition-colors">
                        <div class="w-8 h-8 rounded-full overflow-hidden flex items-center justify-center text-sm font-bold" style="background:linear-gradient(135deg,#00f5ff,#bf00ff);color:#000;" id="user-avatar-wrap">
                            <img id="user-avatar-img" src="" alt="" class="w-full h-full object-cover hidden">
                            <span id="user-avatar-initial">U</span>
                        </div>
                        <i class="fa-solid fa-chevron-down text-xs text-gray-400"></i>
                    </button>
                    <div id="user-dropdown" class="hidden absolute right-0 top-full mt-2 w-52 rounded-xl py-2 shadow-2xl z-50"
                         style="background:#13131f;border:1px solid rgba(255,255,255,0.1);">
                        <div class="px-4 py-2 border-b border-white/10">
                            <p class="text-sm font-medium" id="user-display-name">Kullanici</p>
                            <p class="text-xs text-gray-500" id="user-display-email"></p>
                        </div>
                        <a href="<?= APP_URL ?>/myprofile" class="w-full text-left px-4 py-2 text-sm text-gray-300 hover:text-cyan-400 hover:bg-white/5 transition-colors flex items-center gap-2">
                            <i class="fa-solid fa-user text-xs"></i>
                            Profilim
                        </a>
                        <a href="<?= APP_URL ?>/library.php?tab=history" class="w-full text-left px-4 py-2 text-sm text-gray-300 hover:text-cyan-400 hover:bg-white/5 transition-colors flex items-center gap-2">
                            <i class="fa-solid fa-clock-rotate-left text-xs"></i>
                            İzleme Geçmişi
                        </a>
                        <a href="<?= APP_URL ?>/subscriptions.php" class="w-full text-left px-4 py-2 text-sm text-gray-300 hover:text-cyan-400 hover:bg-white/5 transition-colors flex items-center gap-2">
                            <i class="fa-solid fa-bell text-xs"></i>
                            Abonelikler
                        </a>
                        <a href="<?= APP_URL ?>/library.php?tab=lists" class="w-full text-left px-4 py-2 text-sm text-gray-300 hover:text-cyan-400 hover:bg-white/5 transition-colors flex items-center gap-2">
                            <i class="fa-solid fa-list-ul text-xs"></i>
                            Listelerim
                        </a>
                        <a href="<?= APP_URL ?>/blocks.php" class="w-full text-left px-4 py-2 text-sm text-gray-300 hover:text-cyan-400 hover:bg-white/5 transition-colors flex items-center gap-2">
                            <i class="fa-solid fa-ban text-xs"></i>
                            Engellediklerim
                        </a>
                        <a href="<?= APP_URL ?>/comments.php" class="w-full text-left px-4 py-2 text-sm text-gray-300 hover:text-cyan-400 hover:bg-white/5 transition-colors flex items-center gap-2">
                            <i class="fa-regular fa-comments text-xs"></i>
                            Son Yorumlar
                        </a>
                        <a href="<?= APP_URL ?>/notifications.php" class="w-full text-left px-4 py-2 text-sm text-gray-300 hover:text-cyan-400 hover:bg-white/5 transition-colors flex items-center gap-2">
                            <i class="fa-solid fa-bell text-xs"></i>
                            Bildirimler <span id="notif-badge" class="hidden ml-auto text-[10px] font-bold px-1.5 rounded-full text-black" style="background:#00f5ff"></span>
                        </a>
                        <a href="<?= APP_URL ?>/library.php?tab=later" class="w-full text-left px-4 py-2 text-sm text-gray-300 hover:text-cyan-400 hover:bg-white/5 transition-colors flex items-center gap-2">
                            <i class="fa-solid fa-clock text-xs"></i>
                            Daha Sonra İzle
                        </a>
                        <a href="<?= APP_URL ?>/library.php?tab=history" class="w-full text-left px-4 py-2 text-sm text-gray-300 hover:text-cyan-400 hover:bg-white/5 transition-colors flex items-center gap-2">
                            <i class="fa-solid fa-clock-rotate-left text-xs"></i>
                            İzleme Geçmişi
                        </a>
                        <a href="<?= APP_URL ?>/requests.php" class="w-full text-left px-4 py-2 text-sm text-gray-300 hover:text-cyan-400 hover:bg-white/5 transition-colors flex items-center gap-2">
                            <i class="fa-solid fa-inbox text-xs"></i>
                            Video İstekleri
                        </a>
                        <a href="<?= APP_URL ?>/random.php" class="md:hidden w-full text-left px-4 py-2 text-sm text-gray-300 hover:text-cyan-400 hover:bg-white/5 transition-colors flex items-center gap-2">
                            <i class="fa-solid fa-shuffle text-xs"></i>
                            Rastgele Video
                        </a>
                        <div class="px-4 py-2 flex items-center gap-2 text-sm text-gray-300 border-t border-white/5" id="theme-row">
                            <i class="fa-solid fa-palette text-xs"></i><span class="mr-1">Tema</span>
                            <button type="button" class="theme-dot" data-th="" title="Neon" style="background:linear-gradient(135deg,#00f5ff,#bf00ff)"></button>
                            <button type="button" class="theme-dot" data-th="mavi" title="Mavi" style="background:linear-gradient(135deg,#60a5fa,#6366f1)"></button>
                            <button type="button" class="theme-dot" data-th="kirmizi" title="Kırmızı" style="background:linear-gradient(135deg,#ff4d6d,#ff7a00)"></button>
                            <button type="button" class="theme-dot" data-th="sade" title="Sade koyu" style="background:linear-gradient(135deg,#e2e8f0,#94a3b8)"></button>
                        </div>
                        <button id="logout-btn" class="w-full text-left px-4 py-2 text-sm text-gray-300 hover:text-red-400 hover:bg-white/5 transition-colors flex items-center gap-2">
                            <i class="fa-solid fa-right-from-bracket text-xs"></i>
                            Cikis Yap
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Mobil Arama (toggle ile açılır) -->
        <div id="mobile-search" class="hidden pb-3 md:hidden">
            <form action="<?= APP_URL ?>/search.php" method="GET" autocomplete="off">
                <div class="relative" id="mobile-search-wrapper">
                    <input type="text" name="q" id="mobile-search-input" value="<?= $searchQuery ?>" placeholder="Video ara..."
                           class="w-full py-2 pl-4 pr-10 rounded-full text-sm text-white placeholder-gray-500 outline-none"
                           style="background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);">
                    <button type="submit" class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">
                        <i class="fa-solid fa-magnifying-glass text-sm"></i>
                    </button>
                    <!-- Mobil Dropdown -->
                    <div id="mobile-search-dropdown"
                         style="display:none;position:absolute;top:calc(100% + 6px);left:0;right:0;
                                background:#13131f;border:1px solid rgba(0,245,255,0.15);border-radius:14px;
                                box-shadow:0 16px 48px rgba(0,0,0,0.7);z-index:200;overflow:hidden;">
                        <div id="mobile-dropdown-list"></div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</nav>

<!-- Flash Mesajı -->
<?php $flash = getFlash(); if ($flash): ?>
<div class="max-w-screen-2xl mx-auto px-4 pt-4 animate-slide-up">
    <div class="flex items-center gap-3 px-4 py-3 rounded-xl border
        <?= $flash['type'] === 'success' ? 'bg-green-500/10 border-green-500/30 text-green-400' :
            ($flash['type'] === 'error'   ? 'bg-red-500/10 border-red-500/30 text-red-400'       :
                                            'bg-cyan-500/10 border-cyan-500/30 text-cyan-400') ?>">
        <i class="fa-solid fa-<?= $flash['type'] === 'success' ? 'circle-check' : ($flash['type'] === 'error' ? 'circle-xmark' : 'circle-info') ?>"></i>
        <?= e($flash['message']) ?>
    </div>
</div>
<?php endif; ?>

<!-- Ana İçerik Başlangıcı -->
<main class="flex-1">

<script>
(function(){
    function mark(){var c='';try{c=localStorage.getItem('neon_theme')||''}catch(e){}document.querySelectorAll('#theme-row .theme-dot').forEach(function(b){b.classList.toggle('on',b.dataset.th===c)});}
    document.addEventListener('click',function(e){var b=e.target.closest('#theme-row .theme-dot');if(!b)return;e.stopPropagation();var t=b.dataset.th;
        try{if(t)localStorage.setItem('neon_theme',t);else localStorage.removeItem('neon_theme');}catch(x){}
        if(t)document.documentElement.setAttribute('data-theme',t);else document.documentElement.removeAttribute('data-theme');mark();});
    document.addEventListener('DOMContentLoaded',mark);
})();
</script>
<!-- ===== CANLI ARAMA ÖNERİLERİ JS ===== -->
<script>
(function () {
    const APP_URL_SEARCH = '<?= APP_URL ?>';

    /* Debounce yardımcısı */
    function debounce(fn, ms) {
        let t;
        return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
    }

    /* Sayı formatlayıcı */
    function fmtNum(n) {
        if (n >= 1e6) return (n / 1e6).toFixed(1) + 'M';
        if (n >= 1e3) return (n / 1e3).toFixed(1) + 'K';
        return String(n);
    }

    /* Tek bir arama widget'ı kur */
    function initSearch(inputId, dropdownId, listId) {
        const input    = document.getElementById(inputId);
        const dropdown = document.getElementById(dropdownId);
        const list     = document.getElementById(listId);
        if (!input || !dropdown || !list) return;

        let items      = [];
        let activeIdx  = -1;

        function show() { dropdown.style.display = 'block'; }
        function hide() { dropdown.style.display = 'none'; activeIdx = -1; }

        const esc = t => String(t ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
        function renderItems(data, tags, chans) {
            tags = tags || []; chans = chans || [];
            items = [];
            tags.forEach(t => items.push({ kind: 'tag', href: `${APP_URL_SEARCH}/search.php?q=${encodeURIComponent(t)}`, label: t }));
            chans.forEach(c => items.push({ kind: 'chan', href: `${APP_URL_SEARCH}/channel.php?id=${encodeURIComponent(c.id)}`, label: c.name, img: c.avatar_url }));
            data.forEach(v => items.push(Object.assign({ kind: 'video', href: `${APP_URL_SEARCH}/video.php?id=${encodeURIComponent(v.id)}` }, v)));
            activeIdx = -1;
            if (!items.length) { hide(); return; }
            const rowCss = 'display:flex;align-items:center;gap:10px;padding:10px 14px;text-decoration:none;transition:background 0.15s;border-bottom:1px solid rgba(255,255,255,0.04);';
            list.innerHTML = items.map((v, i) => {
                if (v.kind === 'tag') return `<a href="${esc(v.href)}" class="suggest-item" data-idx="${i}" style="${rowCss}" onmouseenter="this.style.background='rgba(0,245,255,0.06)'" onmouseleave="this.style.background=''"><span style="width:64px;text-align:center;color:#00f5ff;font-size:14px"><i class="fa-solid fa-hashtag"></i></span><p style="font-size:13px;color:#fff">${esc(v.label)} <span style="color:#6b7280;font-size:11px">etiket</span></p></a>`;
                if (v.kind === 'chan') return `<a href="${esc(v.href)}" class="suggest-item" data-idx="${i}" style="${rowCss}" onmouseenter="this.style.background='rgba(0,245,255,0.06)'" onmouseleave="this.style.background=''"><span style="width:64px;display:flex;justify-content:center">${v.img ? `<img src="${esc(v.img)}" style="width:32px;height:32px;border-radius:50%;object-fit:cover">` : '<i class="fa-solid fa-user" style="color:#bf00ff"></i>'}</span><p style="font-size:13px;color:#fff">${esc(v.label)} <span style="color:#6b7280;font-size:11px">kanal</span></p></a>`;
                return `
                <a href="${esc(v.href)}" class="suggest-item" data-idx="${i}" style="${rowCss}" onmouseenter="this.style.background='rgba(0,245,255,0.06)'" onmouseleave="this.style.background=''">
                    <img src="${esc(v.thumbnail_url || 'https://placehold.co/80x45/070711/00f5ff?text=NeonTV')}" style="width:64px;height:36px;object-fit:cover;border-radius:6px;flex-shrink:0;background:#0d0d1a;" loading="lazy">
                    <div style="flex:1;min-width:0;">
                        <p style="font-size:13px;font-weight:600;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${esc(v.title)}</p>
                        <p style="font-size:11px;color:#6b7280;margin-top:2px;">
                            <i class="fa-solid fa-eye" style="font-size:9px;"></i> ${fmtNum(v.views)}
                            ${v.duration ? `<span style="margin-left:6px;"><i class="fa-regular fa-clock" style="font-size:9px;"></i> ${esc(v.duration)}</span>` : ''}
                        </p>
                    </div>
                    <i class="fa-solid fa-arrow-up" style="transform:rotate(-45deg);font-size:10px;color:#374151;flex-shrink:0;"></i>
                </a>`;
            }).join('');
            show();
        }

        function setActive(idx) {
            const els = list.querySelectorAll('.suggest-item');
            els.forEach((el, i) => {
                el.style.background = i === idx ? 'rgba(0,245,255,0.08)' : '';
            });
            activeIdx = idx;
        }

        const fetchSuggestions = debounce(async (q) => {
            if (q.length < 2) { hide(); return; }
            try {
                const res  = await fetch(`${APP_URL_SEARCH}/api/search_suggest.php?q=${encodeURIComponent(q)}`);
                const json = await res.json();
                renderItems(json.data || [], json.tags || [], json.channels || []);
            } catch (e) { hide(); }
        }, 280);

        input.addEventListener('input', (e) => fetchSuggestions(e.target.value.trim()));

        input.addEventListener('keydown', (e) => {
            if (!items.length) return;
            if (e.key === 'ArrowDown') {
                e.preventDefault();
                setActive(Math.min(activeIdx + 1, items.length - 1));
            } else if (e.key === 'ArrowUp') {
                e.preventDefault();
                setActive(Math.max(activeIdx - 1, -1));
            } else if (e.key === 'Enter' && activeIdx >= 0) {
                e.preventDefault();
                window.location.href = items[activeIdx].href;
            } else if (e.key === 'Escape') {
                hide();
            }
        });

        input.addEventListener('focus', () => {
            if (items.length) show();
        });

        /* Dışarı tıklanınca kapat */
        document.addEventListener('click', (e) => {
            if (!input.closest('#search-wrapper, #mobile-search-wrapper')?.contains(e.target)) hide();
        });
    }

    document.addEventListener('DOMContentLoaded', () => {
        initSearch('search-input',        'search-dropdown',        'search-dropdown-list');
        initSearch('mobile-search-input', 'mobile-search-dropdown', 'mobile-dropdown-list');
    });
})();
</script>

<?php /* ==================== F5: NeTvYZ Butonu ==================== */ ?>
<button id="netvy-btn" title="NeTvYZ - YZ Asistan" aria-label="NeTvYZ Yapay Zeka Asistan">
    <i class="fa-solid fa-robot"></i>
    <span class="netvy-badge">YZ</span>
</button>

<!-- NeTvYZ Chat Panel -->
<div id="netvy-panel" role="dialog" aria-label="NeTvYZ Chat" aria-modal="true">
    <div class="netvy-header">
        <div class="netvy-header-avatar"><i class="fa-solid fa-robot"></i></div>
        <div class="netvy-header-info">
            <div class="netvy-header-name">NeTvYZ</div>
            <div class="netvy-header-sub">Video Öneri Asistanı</div>
        </div>
        <span id="netvy-quota" class="netvy-quota-label"></span>
        <button id="netvy-close" aria-label="Kapat"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div id="netvy-messages"></div>
    <form id="netvy-form" class="netvy-input-area" autocomplete="off">
        <input type="text" id="netvy-input" name="netvy_msg" placeholder="Video önerisi isteyin..." maxlength="500" autocomplete="off">
        <button type="submit" class="netvy-send-btn" aria-label="Gönder">
            <i class="fa-solid fa-paper-plane"></i>
        </button>
    </form>
    <div style="padding:0 0.75rem 0.55rem;font-size:0.62rem;line-height:1.35;color:#6b7280;text-align:center;">NeTvYZ hata yapabilir, bilgileri kontrol edin. 18 yaşından küçükler kullanamaz. Sohbetlerin geçmişte tutulur; çöp kutusuyla silebilirsin.</div>
</div>

<?php /* ==================== F3: Popup Reklam ==================== */ ?>
<?php if (!empty($activePopup)): ?>
<?php
    // Cookie ile gün başına bir kez göster
    $popupCookieName = 'neontv_popup_' . md5($activePopup['id']);
    $showPopup       = empty($_COOKIE[$popupCookieName]);
?>
<?php if ($showPopup): ?>
<div id="neontv-popup-overlay" role="dialog" aria-modal="true" aria-label="Duyuru">
    <div class="neontv-popup-box">
        <div class="neontv-popup-head">
            <span class="neontv-popup-title"><?= e($activePopup['title'] ?: 'Uygulama') ?></span>
            <button class="neontv-popup-close" id="popup-close-btn" aria-label="Kapat">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>
        <?php if (!empty($activePopup['image_url'])): ?>
        <a href="<?= e($activePopup['link_url'] ?? '#') ?>" target="_blank" rel="noopener" class="neontv-popup-imglink">
            <img src="<?= e($activePopup['image_url']) ?>" alt="<?= e($activePopup['title']) ?>" class="neontv-popup-img" loading="eager">
        </a>
        <?php endif; ?>
    </div>
</div>
<script>
(function(){
    const overlay = document.getElementById('neontv-popup-overlay');
    if (!overlay) return;
    // Güvenli cookie: HttpOnly eklenemez JS'den, sadece path/SameSite
    document.getElementById('popup-close-btn').addEventListener('click', () => {
        overlay.remove();
        document.cookie = '<?= $popupCookieName ?>=1; path=/; max-age=86400; SameSite=Lax';
    });
    overlay.addEventListener('click', (e) => {
        if (e.target === overlay) {
            overlay.remove();
            document.cookie = '<?= $popupCookieName ?>=1; path=/; max-age=86400; SameSite=Lax';
        }
    });
})();
</script>
<?php endif; ?>
<?php endif; ?>

<?php /* Reklam ve YZ değişkenleri (video.php / player için) */ ?>
<script>
 window.NEONTV_VIDEO_ADS  = <?= $videoAdsJson ?>;
 window.NEONTV_BANNER_AD  = <?= $bannerAdJson ?>;
</script>
<script defer src="<?= APP_URL ?>/assets/js/assistant.js"></script>
