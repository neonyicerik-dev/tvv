<?php
// ============================================================
// NeonTV - Video Kart Bileşeni
// Kullanım: include ile dahil et, $video değişkeni gerekli
// ============================================================
if (!isset($video) || !is_array($video)) return;

// Arama sonuçlarında aranan kelimeleri vurgula ($highlightQuery tanımlıysa)
if (!function_exists('neonHighlight')) {
    function neonHighlight(string $text, string $q): string {
        $safe = e($text);
        $words = array_filter(preg_split('/\s+/u', trim($q)), fn($w) => mb_strlen($w) >= 2);
        if (!$words) return $safe;
        $pat = implode('|', array_map(fn($w) => preg_quote(e($w), '/'), $words));
        return preg_replace('/(' . $pat . ')/iu', '<mark style="background:rgba(0,245,255,0.25);color:#00f5ff;border-radius:3px;padding:0 2px;">$1</mark>', $safe) ?? $safe;
    }
}

$vid        = $video;
$thumbnail  = $vid['thumbnail_url'] ?? 'https://placehold.co/640x360/070711/00f5ff?text=NeonTV';
$title      = $vid['title'] ?? 'Basliksiz Video';
$duration   = isset($vid['duration']) ? formatDuration((int)$vid['duration']) : '';
$views      = isset($vid['views']) ? formatNumber((int)$vid['views']) : '0';
$time       = isset($vid['created_at']) ? timeAgo($vid['created_at']) : '';
$videoId    = $vid['id'] ?? '';
$videoUrl   = APP_URL . '/video.php?id=' . $videoId;
$previewUrl = $vid['preview_clip_url'] ?? '';
$rawVideo   = $vid['video_url'] ?? '';
?>
<article class="video-card group" data-video-id="<?= e($videoId) ?>" data-channel-id="<?= e($vid['channel_id'] ?? '') ?>">
    <a href="<?= e($videoUrl) ?>" class="block" id="video-card-<?= e($videoId) ?>">

        <!-- Thumbnail + Preview -->
        <div class="relative overflow-hidden rounded-xl aspect-video card-thumb-wrap"
             style="background:#13131f;"
             <?php if ($rawVideo): ?>
             data-raw-video="<?= e($rawVideo) ?>"
             <?php endif; ?>
             <?php if ($previewUrl): ?>
             data-preview="<?= e($previewUrl) ?>"
             <?php endif; ?>>

            <!-- Statik Thumbnail -->
            <img
                class="card-thumb w-full h-full object-cover transition-all duration-500 group-hover:scale-105"
                src="<?= e($thumbnail) ?>"
                alt="<?= e($title) ?>"
                loading="lazy"
                style="transition:transform 0.5s ease,opacity 0.4s ease;"
                onerror="this.src='https://placehold.co/640x360/070711/00f5ff?text=NeonTV'"
            >

            <!-- Preview Video (ham video_url'den rastgele klip VEYA hazır preview_clip) -->
            <?php if ($rawVideo || $previewUrl): ?>
            <video
                class="card-preview absolute inset-0 w-full h-full object-cover pointer-events-none"
                <?php if ($previewUrl): ?>
                src="<?= e($previewUrl) ?>"
                loop
                <?php endif; ?>
                muted
                playsinline
                preload="none"
                tabindex="-1"
                style="opacity:0;transition:opacity 0.4s ease;"
            ></video>
            <?php endif; ?>

            <!-- Gradient overlay on hover -->
            <div class="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                 style="background:linear-gradient(to top,rgba(0,0,0,0.7) 0%,transparent 60%);"></div>

            <!-- YENİ rozeti (son 3 gün) -->
            <?php if (!empty($vid['created_at']) && strtotime($vid['created_at']) > time() - 3 * 86400): ?>
            <div class="absolute top-2 right-2 px-2 py-0.5 rounded text-[10px] font-bold"
                 style="background:linear-gradient(135deg,#00f5ff,#bf00ff);color:#000;">YENİ</div>
            <?php endif; ?>

            <!-- #5 Yakında kalkacak rozeti (expires_at ≤ 14 gün) -->
            <?php if (!empty($vid['expires_at']) && ($__exp = strtotime($vid['expires_at'])) && $__exp > time() && $__exp < time() + 14 * 86400): $__d = max(1, (int)ceil(($__exp - time()) / 86400)); ?>
            <div class="absolute top-2 left-2 px-2 py-0.5 rounded text-[10px] font-bold" style="background:rgba(255,95,122,0.92);color:#fff;" title="Bu video yakında kaldırılacak"><i class="fa-solid fa-hourglass-half mr-1"></i><?= $__d ?> gün kaldı</div>
            <?php endif; ?>

            <!-- Duration Badge -->
            <?php if ($duration): ?>
            <div class="absolute bottom-2 right-2 px-2 py-0.5 rounded text-xs font-semibold card-duration-badge"
                 style="background:rgba(0,0,0,0.85);color:#fff;transition:opacity 0.3s ease;">
                <?= e($duration) ?>
            </div>
            <?php endif; ?>

            <!-- Play Button (hover) -->
            <div class="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300 transform group-hover:scale-100 scale-75">
                <div class="w-14 h-14 rounded-full flex items-center justify-center shadow-2xl"
                     style="background:rgba(0,245,255,0.9);backdrop-filter:blur(8px);">
                    <i class="fa-solid fa-play text-black text-xl ml-1"></i>
                </div>
            </div>

            <!-- Glow border on hover -->
            <div class="absolute inset-0 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"
                 style="box-shadow:inset 0 0 0 1px rgba(0,245,255,0.4);"></div>

            <!-- Preview indicator -->
            <?php if ($rawVideo || $previewUrl): ?>
            <div class="absolute top-2 left-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 card-preview-badge">
                <span class="text-[9px] px-1.5 py-0.5 rounded font-bold"
                      style="background:rgba(0,245,255,0.2);color:#00f5ff;border:1px solid rgba(0,245,255,0.3);">
                    <i class="fa-solid fa-play-circle mr-0.5"></i>ÖNİZLEME
                </span>
            </div>
            <?php endif; ?>
        </div>

        <!-- Video Info -->
        <div class="mt-3 px-0.5">
            <h3 class="text-sm font-semibold text-white leading-snug line-clamp-2 group-hover:text-neon-cyan transition-colors duration-200"
                style="-webkit-line-clamp:2;display:-webkit-box;-webkit-box-orient:vertical;overflow:hidden;">
                <?= !empty($highlightQuery) ? neonHighlight($title, $highlightQuery) : e($title) ?>
            </h3>

            <div class="flex items-center gap-3 mt-2 text-xs text-gray-500">
                <span class="flex items-center gap-1">
                    <i class="fa-solid fa-eye text-[10px]"></i>
                    <?= e($views) ?>
                </span>
                <?php if ($time): ?>
                <span class="flex items-center gap-1">
                    <i class="fa-regular fa-clock text-[10px]"></i>
                    <?= e($time) ?>
                </span>
                <?php endif; ?>
                <?php if (!empty($vid['likes_count'])): ?>
                <span class="flex items-center gap-1">
                    <i class="fa-solid fa-heart text-[10px] text-neon-pink"></i>
                    <?= formatNumber((int)$vid['likes_count']) ?>
                </span>
                <?php endif; ?>
            </div>
        </div>
    </a>
</article>
