<?php
// NeonTV - Herkese açık kullanıcı profili
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/supabase.php';
require_once __DIR__ . '/includes/store.php';
require_once __DIR__ . '/includes/themes.php';

$uid = trim($_GET['id'] ?? '');
if (!isUuid($uid)) { header('Location: ' . APP_URL . '/index.php'); exit; }
$db = new Supabase();
$p  = $db->first('profiles', 'id=eq.' . $uid . '&select=*', true);
if (!$p) { require_once __DIR__ . '/404.php'; exit; }

$isPrem = Store::isPremium($uid);
$needThemes = true;
$thm   = $isPrem ? (Store::getUserThemes([$uid], [$uid => true])[$uid] ?? null) : null;
$theme = $thm['theme'] ?? null;
$followerCount  = $db->count('user_follows', 'following_id=eq.' . $uid, true);
$followingCount = $db->count('user_follows', 'follower_id=eq.' . $uid, true);
$frame = $thm['frame'] ?? null;
$subs = $db->select('subscriptions', 'user_id=eq.' . $uid . '&select=channels(id,name,avatar_url)&limit=60', true)['data'] ?? [];
$subs = array_values(array_filter(array_map(fn($x) => $x['channels'] ?? null, $subs)));
$commentCount = $db->count('comments', 'user_id=eq.' . $uid, true);
$ratingCount  = $db->count('video_ratings', 'user_id=eq.' . $uid, true);
$lists = $db->select('user_playlists', 'user_id=eq.' . $uid . '&is_public=eq.true&order=created_at.desc&limit=30', true)['data'] ?? [];
$name = $p['username'] ?: 'Kullanıcı';
$pageTitle = e($name) . ' - Profil';
$metaDesc  = $name . ' kullanıcısının NeonTV profili.';
?>
<?php include __DIR__ . '/components/header.php'; ?>
<?php if ($theme): ?><div class="nvt nvt-page nvt-<?= e($theme) ?>" aria-hidden="true"></div><?php endif; ?>
<div class="max-w-screen-lg mx-auto px-4 sm:px-6 py-6">
    <div class="<?= $theme ? 'nvt nvt-' . e($theme) . ' rounded-2xl mb-8' : '' ?>">
    <?php if ($theme): ?>
    <div class="nvt-cover" style="<?= empty($p['cover_url']) ? 'height:90px' : '' ?>"><?php if (!empty($p['cover_url'])): ?><img src="<?= e($p['cover_url']) ?>" alt=""><?php endif; ?></div>
    <?php elseif (!empty($p['cover_url'])): ?>
    <div class="rounded-2xl overflow-hidden mb-6" style="height:160px;background:#0d0d1a"><img src="<?= e($p['cover_url']) ?>" alt="" class="w-full h-full object-cover"></div>
    <?php else: ?>
    <div class="rounded-2xl mb-6" style="height:100px;background:linear-gradient(135deg,rgba(0,245,255,0.15),rgba(191,0,255,0.15))"></div>
    <?php endif; ?>
    <div class="flex items-center gap-5 <?= $theme ? 'px-5 pb-5 -mt-6' : 'mb-8' ?>">
        <?= nvFrameOpen($frame, 'lg') ?>
        <div class="w-24 h-24 rounded-full overflow-hidden flex items-center justify-center text-4xl font-bold bg-gray-800 shrink-0 <?= $frame ? 'nvf-in' : '' ?>" style="<?= $frame ? '' : 'border:3px solid rgba(0,245,255,0.4)' ?>">
            <?php if (!empty($p['avatar_url'])): ?><img src="<?= e($p['avatar_url']) ?>" class="w-full h-full object-cover" alt=""><?php else: ?><?= e(strtoupper(mb_substr($name, 0, 1))) ?><?php endif; ?>
        </div>
        <?= nvFrameClose($frame) ?>
        <div class="min-w-0">
            <h1 class="text-2xl font-bold text-white flex items-center gap-2 flex-wrap"><span class="<?= $theme ? 'nvt-name' : '' ?>"><?= e($name) ?></span>
                <?php if ($isPrem): ?><span class="inline-flex items-center gap-1 text-xs font-bold px-2 py-0.5 rounded-full" style="background:linear-gradient(135deg,#ffd76a,#ff9d00);color:#000"><i class="fa-solid fa-crown text-[10px]"></i>Premium</span><?php endif; ?></h1>
            <?php if (!empty($p['bio'])): ?><p class="text-sm text-gray-300 mt-2 max-w-xl whitespace-pre-wrap"><?= e($p['bio']) ?></p><?php endif; ?>
            <p class="text-sm text-gray-400 mt-1">Üyelik: <?= e(date('d.m.Y', strtotime($p['created_at'] ?? 'now'))) ?></p>
            <div class="flex gap-4 text-sm text-gray-300 mt-2 flex-wrap">
                <span><i class="fa-regular fa-comment mr-1 text-cyan-400"></i><?= (int)$commentCount ?> yorum</span>
                <span><i class="fa-solid fa-star mr-1" style="color:#ffd76a"></i><?= (int)$ratingCount ?> puan</span>
                <span><i class="fa-solid fa-bell mr-1 text-purple-400"></i><?= count($subs) ?> abonelik</span>
                <span><i class="fa-solid fa-user-group mr-1 text-pink-400"></i><b id="follower-n"><?= (int)$followerCount ?></b> takipçi · <?= (int)$followingCount ?> takip</span>
            </div>
        </div>
    </div>
    </div>

    <button id="user-follow-btn" type="button" class="hidden mb-3 mr-3 px-5 py-2 rounded-full text-sm font-bold text-black" style="background:linear-gradient(135deg,#00f5ff,#bf00ff)"><i class="fa-solid fa-user-plus mr-1"></i><span>Takip et</span></button>
    <button id="user-block-btn" type="button" class="hidden mb-6 text-xs text-gray-500 hover:text-pink-400"><i class="fa-solid fa-ban mr-1"></i><span>Kullanıcıyı engelle</span></button>

    <h2 class="text-lg font-bold text-white mb-3">Abone Olduğu Kanallar</h2>
    <?php if (!$subs): ?><p class="text-gray-500 text-sm mb-8">Henüz abonelik yok.</p>
    <?php else: ?><div class="flex flex-wrap gap-3 mb-8">
        <?php foreach ($subs as $c): ?>
        <a href="<?= APP_URL ?>/channel.php?id=<?= e($c['id']) ?>" class="flex items-center gap-2 px-3 py-2 rounded-full text-sm text-gray-200 hover:text-cyan-400" style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1)">
            <span class="w-7 h-7 rounded-full overflow-hidden bg-gray-800 flex items-center justify-center text-xs font-bold"><?php if (!empty($c['avatar_url'])): ?><img src="<?= e($c['avatar_url']) ?>" class="w-full h-full object-cover" alt=""><?php else: ?><?= e(strtoupper(mb_substr($c['name'], 0, 1))) ?><?php endif; ?></span>
            <?= e($c['name']) ?></a>
        <?php endforeach; ?></div><?php endif; ?>

    <h2 class="text-lg font-bold text-white mb-3">Herkese Açık Listeler</h2>
    <?php if (!$lists): ?><p class="text-gray-500 text-sm">Herkese açık liste yok.</p>
    <?php else: ?><div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <?php foreach ($lists as $l): ?>
        <a href="<?= APP_URL ?>/library.php?tab=lists&id=<?= e($l['id']) ?>" class="px-4 py-3 rounded-xl text-white hover:text-cyan-400" style="background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08)"><i class="fa-solid fa-list-ul mr-2 text-cyan-400"></i><?= e($l['title']) ?></a>
        <?php endforeach; ?></div><?php endif; ?>
</div>
<script>
window.addEventListener('load', async function () {
    const b = document.getElementById('user-block-btn'), fb = document.getElementById('user-follow-btn'); if (!b) return;
    const UID = <?= json_encode($uid) ?>, BASE = <?= json_encode(APP_URL) ?>;
    let t = null, me = null; try { const { data } = await sbClient.auth.getSession(); if (data.session) { t = data.session.access_token; me = data.session.user.id; } } catch (e) {}
    if (!t || me === UID) return;
    b.classList.remove('hidden');
    // Takip
    if (fb) {
        fb.classList.remove('hidden');
        const hh = () => ({ 'Authorization': 'Bearer ' + t, 'X-Access-Token': t, 'Content-Type': 'application/json' }), qq = '?token=' + encodeURIComponent(t);
        const fp = (on, n) => { fb.dataset.on = on ? '1' : ''; fb.querySelector('span').textContent = on ? 'Takiptesin' : 'Takip et'; fb.querySelector('i').className = 'fa-solid mr-1 ' + (on ? 'fa-user-check' : 'fa-user-plus'); fb.style.background = on ? 'rgba(255,255,255,.12)' : 'linear-gradient(135deg,#00f5ff,#bf00ff)'; fb.style.color = on ? '#fff' : '#000'; if (n != null) document.getElementById('follower-n').textContent = n; };
        try { const j = await (await fetch(BASE + '/api/follow.php' + qq + '&user_id=' + UID, { headers: hh() })).json(); if (j.success) fp(j.data.following, j.data.followers); } catch (e) {}
        fb.addEventListener('click', async () => { fb.disabled = true; try { const j = await (await fetch(BASE + '/api/follow.php' + qq, { method: 'POST', headers: hh(), body: JSON.stringify({ user_id: UID, follow: !fb.dataset.on }) })).json(); if (j.success) fp(j.data.following, j.data.followers); } catch (e) {} fb.disabled = false; });
    } else {}
    const h = () => ({ 'Authorization': 'Bearer ' + t, 'X-Access-Token': t, 'Content-Type': 'application/json' }), q = '?token=' + encodeURIComponent(t);
    const paint = on => { b.querySelector('span').textContent = on ? 'Engeli kaldır' : 'Kullanıcıyı engelle'; b.dataset.on = on ? '1' : ''; };
    try { const j = await (await fetch(BASE + '/api/blocks.php' + q, { headers: h() })).json(); paint(!!(j.data && j.data.users.some(u => u.id === UID))); } catch (e) {}
    b.addEventListener('click', async () => {
        try { const j = await (await fetch(BASE + '/api/blocks.php' + q, { method: 'POST', headers: h(), body: JSON.stringify({ kind: 'user', target_id: UID, block: !b.dataset.on }) })).json(); if (j.success) { paint(j.data.blocked); try { sessionStorage.removeItem('neon_blocks'); } catch (e) {} } } catch (e) {}
    });
});
</script>
<?php include __DIR__ . '/components/footer.php'; ?>
