-- ============================================================
-- NeonTV - 3. özellik paketi: yorum beğenisi
-- (NEONTV_TUM_SQL.sql içinde de vardır; tekrar çalıştırılabilir)
-- ============================================================
CREATE TABLE IF NOT EXISTS public.comment_likes (
    user_id    uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    comment_id uuid NOT NULL REFERENCES public.comments(id) ON DELETE CASCADE,
    created_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, comment_id)
);
CREATE INDEX IF NOT EXISTS comment_likes_comment_idx ON public.comment_likes (comment_id);
ALTER TABLE public.comment_likes ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.comment_likes FROM anon, authenticated;
GRANT ALL ON public.comment_likes TO service_role;
