<?php
// NeonTV - Engellediklerim
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/helpers.php';
$pageTitle = 'Engellediklerim'; $metaDesc = 'Engellediğin kanallar ve kullanıcılar.';
?>
<?php include __DIR__ . '/components/header.php'; ?>
<div class="max-w-screen-md mx-auto px-4 sm:px-6 py-8">
    <h1 class="text-xl font-bold text-white mb-1"><i class="fa-solid fa-ban text-pink-400 mr-2"></i>Engellediklerim</h1>
    <p class="text-sm text-gray-500 mb-6">Engellediğin kanalların videoları ana sayfada, engellediğin kullanıcıların yorumları video sayfalarında sana gösterilmez.</p>
    <div id="b-msg" class="text-gray-500 text-sm py-6 text-center">Yükleniyor...</div>
    <div id="b-box" class="space-y-6"></div>
</div>
<script>
window.addEventListener('load', async function () {
    const BASE = '<?= APP_URL ?>', msg = document.getElementById('b-msg'), box = document.getElementById('b-box');
    const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
    let t = null; try { const { data } = await sbClient.auth.getSession(); t = data.session ? data.session.access_token : null; } catch (e) {}
    if (!t) { try { t = localStorage.getItem('sb_access_token'); } catch (e) {} }
    if (!t) { msg.innerHTML = 'Bu sayfa için <a class="text-cyan-400 underline" href="' + BASE + '/auth.php">giriş yapmalısın</a>.'; return; }
    const h = { 'Authorization': 'Bearer ' + t, 'X-Access-Token': t, 'Content-Type': 'application/json' }, q = '?token=' + encodeURIComponent(t);
    async function load() {
        const j = await (await fetch(BASE + '/api/blocks.php' + q, { headers: h })).json();
        const d = j.data || { channels: [], users: [] };
        try { sessionStorage.removeItem('neon_blocks'); } catch (e) {}
        msg.textContent = (d.channels.length + d.users.length) ? '' : 'Engellediğin kimse yok.';
        const sec = (title, arr, kind, key) => arr.length ? '<div><h2 class="text-sm font-bold text-gray-300 mb-2">' + title + '</h2>' + arr.map(x =>
            '<div class="flex items-center gap-3 px-4 py-2.5 rounded-xl mb-2" style="background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08)"><span class="flex-1 text-white text-sm truncate">' + esc(x[key]) + '</span>' +
            '<button data-k="' + kind + '" data-id="' + esc(x.id) + '" class="unb text-xs font-semibold text-cyan-400 hover:underline">Engeli kaldır</button></div>').join('') + '</div>' : '';
        box.innerHTML = sec('Kanallar', d.channels, 'channel', 'name') + sec('Kullanıcılar', d.users, 'user', 'username');
    }
    box.addEventListener('click', async e => {
        const b = e.target.closest('.unb'); if (!b) return;
        await fetch(BASE + '/api/blocks.php' + q, { method: 'POST', headers: h, body: JSON.stringify({ kind: b.dataset.k, target_id: b.dataset.id, block: false }) });
        load();
    });
    load();
});
</script>
<?php include __DIR__ . '/components/footer.php'; ?>
