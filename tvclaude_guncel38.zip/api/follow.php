<?php
// Takip sistemi
// GET  ?user_id=UUID -> {following, followers}
// POST {user_id, follow?:bool} -> takip et / bırak (follow verilmezse tersine çevir)
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/user_auth.php';
error_reporting(0); ini_set('display_errors', 0);

$db = new Supabase();
$user = requireUserApi($db); $uid = $user['id'];

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $t = trim($_GET['user_id'] ?? ''); requireUuid($t, 'Kullanıcı ID');
    $ex = $db->first('user_follows', 'follower_id=eq.' . $uid . '&following_id=eq.' . $t . '&select=follower_id', true);
    jsonSuccess(['following' => (bool)$ex, 'followers' => $db->count('user_follows', 'following_id=eq.' . $t, true)]);
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonError('Geçersiz istek', 405);

$in = inputJson() ?? [];
$t = trim($in['user_id'] ?? ''); requireUuid($t, 'Kullanıcı ID');
if ($t === $uid) jsonError('Kendini takip edemezsin');
$ex = $db->first('user_follows', 'follower_id=eq.' . $uid . '&following_id=eq.' . $t . '&select=follower_id', true);
$want = array_key_exists('follow', $in) ? !empty($in['follow']) : !$ex;

if ($want && !$ex) {
    if (!$db->first('profiles', 'id=eq.' . $t . '&select=id', true)) jsonError('Kullanıcı bulunamadı', 404);
    if ($db->count('user_follows', 'follower_id=eq.' . $uid, true) >= 2000) jsonError('Takip listesi dolu');
    $r = $db->insert('user_follows', ['follower_id' => $uid, 'following_id' => $t], true);
    if (($r['status'] ?? 500) >= 400) jsonError('Kaydedilemedi', 500);
    // Bildirim: yalnızca ilk kez takipte (tekrar takip/bırak ile spam olmasın)
    try {
        $link = '/user.php?id=' . $uid;
        if (!$db->first('notifications', 'user_id=eq.' . $t . '&type=eq.follow&link=eq.' . rawurlencode($link) . '&select=id', true)) {
            $me = $db->first('profiles', 'id=eq.' . $uid . '&select=username', true);
            $db->insert('notifications', ['user_id' => $t, 'type' => 'follow', 'message' => ($me['username'] ?? 'Birisi') . ' seni takip etmeye başladı', 'link' => $link], true);
        }
    } catch (\Throwable $e) {}
} elseif (!$want && $ex) {
    $db->delete('user_follows', 'follower_id=eq.' . $uid . '&following_id=eq.' . $t, true);
}
jsonSuccess(['following' => $want, 'followers' => $db->count('user_follows', 'following_id=eq.' . $t, true)]);
