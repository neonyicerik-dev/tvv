<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/supabase.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

$db = new Supabase();
// Test token parsing
$res = $db->verifyToken('invalid_token');
var_dump($res);

// Test selecting
$comments = $db->select('comments', 'limit=1', true);
var_dump($comments);

echo "OK";
