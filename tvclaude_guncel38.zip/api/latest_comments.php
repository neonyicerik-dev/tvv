<?php
// Son yorumlar (sayfalı)
// GET ?page=1&per=12&scope=all|following   (following için giriş gerekir)
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/store.php';
error_reporting(0); ini_set('display_errors', 0);

$db = new Supabase();
$page = max(1, (int)($_GET['page'] ?? 1));
$per  = max(1, min(30, (int)($_GET['per'] ?? 12)));
$scope = ($_GET['scope'] ?? 'all') === 'following' ? 'following' : 'all';

$extra = '';
$cacheKey = null;
if ($scope === 'following') {
    require_once __DIR__ . '/../includes/user_auth.php';
    $user = requireUserApi($db);
    $f = $db->select('user_follows', 'follower_id=eq.' . $user['id'] . '&select=following_id&limit=2000', true)['data'] ?? [];
    $ids = array_values(array_filter(array_column(is_array($f) ? $f : [], 'following_id'), 'isUuid'));
    if (!$ids) jsonSuccess(['items' => [], 'total' => 0, 'page' => 1, 'pages' => 1, 'per' => $per]);
    $extra = '&user_id=in.(' . implode(',', $ids) . ')';
} else {
    $cacheKey = "latest_comments_{$per}_{$page}";
}

$build = function () use ($db, $page, $per, $extra) {
    $base = 'videos.status=eq.published' . $extra;
    $total = $db->count('comments', 'select=id,videos!inner(status)&' . $base, true);
    $pages = max(1, (int)ceil($total / $per));
    $page  = min($page, $pages);
    $rows = $db->select('comments',
        'select=id,video_id,user_id,parent_id,content,created_at,profiles(username,avatar_url),videos!inner(title,thumbnail_url,status)&' . $base .
        '&order=created_at.desc&limit=' . $per . '&offset=' . (($page - 1) * $per), true)['data'] ?? [];
    $items = [];
    foreach (is_array($rows) ? $rows : [] as $r) {
        $gif = '';
        $txt = preg_replace_callback('#\[gif:(https://media\d*\.giphy\.com/[A-Za-z0-9_/.\-]+\.(?:gif|webp))\]#', function ($m) use (&$gif) { if ($gif === '') $gif = $m[1]; return ''; }, (string)$r['content']);
        $txt = trim(preg_replace('/\s+/u', ' ', (string)$txt));
        $items[] = [
            'gif' => $gif,
            'id' => $r['id'], 'video_id' => $r['video_id'], 'user_id' => $r['user_id'],
            'username' => $r['profiles']['username'] ?? 'Kullanıcı', 'avatar_url' => $r['profiles']['avatar_url'] ?? '',
            'content' => mb_substr($txt, 0, 220), 'is_reply' => !empty($r['parent_id']),
            'created_at' => $r['created_at'], 'ago' => timeAgo($r['created_at']),
            'video_title' => $r['videos']['title'] ?? '', 'thumb' => $r['videos']['thumbnail_url'] ?? '',
        ];
    }
    return ['items' => $items, 'total' => $total, 'page' => $page, 'pages' => $pages, 'per' => $per];
};
jsonSuccess($cacheKey ? Store::remember($cacheKey, 20, $build) : $build());
