<?php
// ============================================================
// NeonTV - Auth API
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';

$method = $_SERVER['REQUEST_METHOD'];
$db     = new Supabase();
$input  = inputJson();

if ($method === 'GET') {
    // Profil bilgisi getir (token ile)
    $token = getBearerToken();
    if (!$token) jsonError('Token gerekli', 401);

    $user = $db->verifyToken($token);
    if (!$user) jsonError('Gecersiz token', 401);

    // Premium bilgisi (sunucuda hesaplanır, istemci değiştiremez)
    require_once __DIR__ . '/../includes/store.php';
    $user['is_premium'] = !empty($user['id']) ? Store::isPremium($user['id']) : false;

    jsonSuccess($user);
}

jsonError('Gecersiz metod', 405);
