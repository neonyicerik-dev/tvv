<?php
// ============================================================
// NeonTV - GIPHY vekil API (anahtar sunucuda kalır)
// GET ?q=kelime  (boşsa trend)   -> {items:[{id,preview,url}]}
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/user_auth.php';
require_once __DIR__ . '/../includes/store.php';
error_reporting(0); ini_set('display_errors', 0);

$db = new Supabase();
requireUserApi($db);

$q = trim($_GET['q'] ?? '');
if (mb_strlen($q) > 60) $q = mb_substr($q, 0, 60);
$base = 'https://api.giphy.com/v1/gifs/';
$url  = $base . ($q !== '' ? 'search' : 'trending') . '?api_key=' . urlencode(GIPHY_API_KEY) . '&limit=18&rating=r&lang=tr&bundle=messaging_non_clips'
      . ($q !== '' ? '&q=' . urlencode($q) : '');

$ck = 'giphy_' . md5($q);
$cached = Store::remember($ck, 600, function () use ($url) {
$ch = curl_init($url);
$o = [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 10, CURLOPT_CONNECTTIMEOUT => 6];
if (defined('CA_BUNDLE_PATH') && CA_BUNDLE_PATH !== '' && file_exists(CA_BUNDLE_PATH)) $o[CURLOPT_CAINFO] = CA_BUNDLE_PATH;
curl_setopt_array($ch, $o);
$raw = curl_exec($ch); $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
$j = is_string($raw) ? json_decode($raw, true) : null;
if ($http !== 200 || !is_array($j)) return null;
return $j;
});
if (!is_array($cached)) { Store::clearCache($ck); jsonError('GIF servisine ulaşılamadı', 502); }
$j = $cached;

$items = [];
foreach (($j['data'] ?? []) as $g) {
    $prev = $g['images']['fixed_width_small']['url'] ?? ($g['images']['fixed_width']['url'] ?? '');
    $full = $g['images']['fixed_height']['url'] ?? ($g['images']['downsized']['url'] ?? '');
    // yalnızca giphy medya adresleri ve sorgu parametresiz biçim
    $full = strtok($full, '?'); $prev = strtok($prev, '?');
    if (!preg_match(commentGifRe(), '[gif:' . $full . ']')) continue;
    $items[] = ['id' => $g['id'] ?? '', 'preview' => $prev, 'url' => $full];
}
jsonSuccess(['items' => $items]);
