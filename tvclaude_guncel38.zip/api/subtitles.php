<?php
// ============================================================
// NeonTV - Subtitles API (CloudConvert gerektirmez)
// Akış: URL indir → Gemini inline veya File API → VTT kaydet
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';

error_reporting(0);
ini_set('display_errors', 0);
set_time_limit(0);

requireAdmin();

$httpMethod = $_SERVER['REQUEST_METHOD'];

// ── GET: Mevcut altyazıyı getir ─────────────────────────────────────────────
if ($httpMethod === 'GET') {
    $videoId = $_GET['video_id'] ?? '';
    if (!$videoId) jsonError('Video ID gerekli');
    $db  = new Supabase();
    $sub = $db->first('subtitles', 'video_id=eq.' . $videoId . '&language=eq.tr', true);
    jsonSuccess($sub ?? []);
}

if ($httpMethod === 'PATCH') {
    $input = inputJson();
    $videoId = $_GET['video_id'] ?? $input['video_id'] ?? '';
    $content = $input['content'] ?? null;
    
    if (!$videoId) jsonError('Video ID gerekli');
    if ($content === null) jsonError('Icerik (content) gerekli');
    
    $db = new Supabase();
    $existing = $db->first('subtitles', 'video_id=eq.' . $videoId . '&language=eq.tr', true);
    
    if ($existing) {
        $res = $db->update('subtitles', ['content' => $content], 'id=eq.' . $existing['id'], true);
        if ($res['status'] >= 400) jsonError('Kaydedilemedi: ' . ($res['error'] ?? 'Bilinmeyen hata'));
        jsonSuccess([], 'Altyazı guncellendi');
    } else {
        jsonError('Duzenlenecek altyazi bulunamadi');
    }
}

if ($httpMethod !== 'POST') jsonError('Gecersiz metod', 405);

$input    = inputJson();
$videoId  = $input['video_id']  ?? '';
$videoUrl = $input['video_url'] ?? '';

if (!$videoId)  jsonError('Video ID gerekli');
if (!$videoUrl) jsonError('URL gerekli (video veya mp3)');

$db = new Supabase();

// ── Ayarlar ─────────────────────────────────────────────────────────────────
require_once __DIR__ . '/../includes/store.php';
$settings = loadSettingsCompat();

$subtitleLanguage    = $settings['subtitle_language']    ?? 'tr';
$subtitleTemperature = (float)($settings['subtitle_temperature'] ?? 0.2);

$systemPrompt = !empty($settings['subtitle_system_prompt'])
    ? $settings['subtitle_system_prompt']
    : 'Bu video veya ses kaydını analiz et ve Türkçe altyazı (WebVTT formatında) oluştur. '
    . 'Sadece geçerli bir WebVTT içeriği döndür. Başında "WEBVTT" olsun, sonra boş bir satır '
    . 've zaman damgaları (00:00:00.000 --> 00:00:05.000) ile metinler gelsin. '
    . 'Yabancı dilde konuşuluyorsa doğrudan Türkçeye çevir. '
    . 'Kesinlikle kod bloğu veya markdown işareti kullanma, sadece saf WebVTT formatı döndür.';

// ============================================================
// ADIM 1: Dosyayı İndir
// ============================================================
$ch = curl_init($videoUrl);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_MAXREDIRS      => 5,
    CURLOPT_TIMEOUT        => 120,
    CURLOPT_RANGE          => '0-20971520', // İlk 20MB (MP3 için fazlasıyla yeterli)
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_SSL_VERIFYHOST => false,
    CURLOPT_USERAGENT      => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    CURLOPT_HTTPHEADER     => ['Accept: */*'],
]);
$rawData    = curl_exec($ch);
$dlHttpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$dlMime     = curl_getinfo($ch, CURLINFO_CONTENT_TYPE) ?? '';
$curlErr    = curl_error($ch);
curl_close($ch);

if ($curlErr) {
    jsonError('Dosya indirilemedi (CURL hatası): ' . $curlErr);
}
if (($dlHttpCode >= 400 && $dlHttpCode !== 206) || empty($rawData) || strlen($rawData) < 200) {
    // Range desteklenmiyorsa tam indirme dene
    $ch = curl_init($videoUrl);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS      => 5,
        CURLOPT_TIMEOUT        => 90,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_USERAGENT      => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        CURLOPT_HTTPHEADER     => ['Accept: */*'],
    ]);
    $rawData    = curl_exec($ch);
    $dlHttpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $dlMime     = curl_getinfo($ch, CURLINFO_CONTENT_TYPE) ?? '';
    $curlErr    = curl_error($ch);
    curl_close($ch);

    if ($curlErr || $dlHttpCode >= 400 || empty($rawData) || strlen($rawData) < 200) {
        jsonError("Dosya indirilemedi (HTTP $dlHttpCode)" . ($curlErr ? ": $curlErr" : '') . ". URL: " . substr($videoUrl, 0, 80));
    }
}

// MIME türünü belirle
$mimeType = trim(explode(';', $dlMime)[0] ?? '');
if (!$mimeType || !in_array($mimeType, [
    'video/mp4', 'video/webm', 'video/ogg', 'video/quicktime', 'video/x-msvideo',
    'video/mpeg', 'video/3gpp', 'video/x-matroska',
    'audio/mpeg', 'audio/mp3', 'audio/wav', 'audio/ogg', 'audio/aac',
    'audio/webm', 'audio/mp4', 'audio/x-m4a',
])) {
    // URL uzantısından tahmin et
    $ext = strtolower(pathinfo(parse_url($videoUrl, PHP_URL_PATH), PATHINFO_EXTENSION));
    $mimeType = match($ext) {
        'mp3'        => 'audio/mpeg',
        'mp4'        => 'video/mp4',
        'webm'       => 'video/webm',
        'mov'        => 'video/quicktime',
        'avi'        => 'video/x-msvideo',
        'mkv'        => 'video/x-matroska',
        'wav'        => 'audio/wav',
        'aac'        => 'audio/aac',
        'm4a'        => 'audio/mp4',
        default      => 'audio/mpeg', // MP3 URL girilmişse varsayılan ses
    };
}

$fileSize = strlen($rawData);

// ============================================================
// ADIM 2: Gemini'ye Gönder
// ============================================================
$geminiUrl  = GEMINI_API_BASE . GEMINI_MODEL . ':generateContent?key=' . GEMINI_API_KEY;
$vttContent = null;
$methodUsed = '';

// ── Yöntem A: ≤18MB → inline base64 (hızlı) ────────────────────────────────
if ($fileSize <= 18 * 1024 * 1024) {
    $methodUsed = 'inline';
    $payload = [
        'system_instruction' => ['parts' => [['text' => $systemPrompt]]],
        'contents' => [[
            'parts' => [
                ['text' => 'Bu medya dosyasını analiz ederek WebVTT formatında Türkçe altyazı oluştur.'],
                ['inline_data' => [
                    'mime_type' => $mimeType,
                    'data'      => base64_encode($rawData),
                ]],
            ],
        ]],
        'generationConfig' => ['temperature' => $subtitleTemperature],
    ];

    $ch = curl_init($geminiUrl);
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json', 'Expect:'],
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_TIMEOUT        => 600,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);
    $gResp = curl_exec($ch);
    $gCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($gCode === 200) {
        $gData = json_decode($gResp, true);
        $vttContent = $gData['candidates'][0]['content']['parts'][0]['text'] ?? null;
    } else {
        $gErrData = json_decode($gResp, true);
        $inlineErr = $gErrData['error']['message'] ?? "HTTP $gCode";
    }
}

// ── Yöntem B: Büyük dosya veya inline başarısız → Gemini File API ─────────
if (!$vttContent) {
    $methodUsed = 'file_api';

    // B1: Upload session başlat
    $ch = curl_init('https://generativelanguage.googleapis.com/upload/v1beta/files?uploadType=resumable&key=' . GEMINI_API_KEY);
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HEADER         => true,
        CURLOPT_HTTPHEADER     => [
            'X-Goog-Upload-Protocol: resumable',
            'X-Goog-Upload-Command: start',
            'X-Goog-Upload-Header-Content-Length: ' . $fileSize,
            'X-Goog-Upload-Header-Content-Type: ' . $mimeType,
            'Content-Type: application/json',
        ],
        CURLOPT_POSTFIELDS     => json_encode(['file' => ['display_name' => 'sub_' . $videoId]]),
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);
    $initResp   = curl_exec($ch);
    $initCode   = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    curl_close($ch);

    if ($initCode !== 200) {
        $errDetail = isset($inlineErr) ? " (Inline hatası: $inlineErr)" : '';
        jsonError('Gemini File API başlatılamadı (HTTP ' . $initCode . ').' . $errDetail);
    }

    // Upload URL'yi al
    $uploadUrl = null;
    foreach (explode("\r\n", substr($initResp, 0, $headerSize)) as $line) {
        if (stripos($line, 'x-goog-upload-url:') === 0) {
            $uploadUrl = trim(substr($line, strlen('x-goog-upload-url:')));
            break;
        }
    }
    if (!$uploadUrl) jsonError('Gemini File API upload URL alınamadı.');

    // B2: Dosyayı yükle
    $ch = curl_init($uploadUrl);
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => [
            'X-Goog-Upload-Offset: 0',
            'X-Goog-Upload-Command: upload, finalize',
            'Content-Length: ' . $fileSize,
        ],
        CURLOPT_POSTFIELDS     => $rawData,
        CURLOPT_TIMEOUT        => 300,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);
    $upResp = curl_exec($ch);
    $upCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($upCode !== 200) jsonError('Dosya Gemini\'ye yüklenemedi (HTTP ' . $upCode . ').');

    $upData   = json_decode($upResp, true);
    $fileUri  = $upData['file']['uri']  ?? null;
    $fileName = $upData['file']['name'] ?? null;

    if (!$fileUri || !$fileName) jsonError('Gemini File URI alınamadı.');

    // B3: ACTIVE olmasını bekle
    $statusUrl = 'https://generativelanguage.googleapis.com/v1beta/' . $fileName . '?key=' . GEMINI_API_KEY;
    for ($i = 0; $i < 20; $i++) {
        sleep(3);
        $sCh = curl_init($statusUrl);
        curl_setopt_array($sCh, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15, CURLOPT_SSL_VERIFYPEER => true]);
        $sData = json_decode(curl_exec($sCh), true);
        curl_close($sCh);
        $state = $sData['state'] ?? 'PROCESSING';
        if ($state === 'ACTIVE') break;
        if ($state === 'FAILED') jsonError('Gemini dosya işleme başarısız (FAILED).');
    }

    // B4: Gemini'ye gönder
    $payload = [
        'system_instruction' => ['parts' => [['text' => $systemPrompt]]],
        'contents' => [[
            'parts' => [
                ['text' => 'Bu medya dosyasını analiz ederek WebVTT formatında Türkçe altyazı oluştur.'],
                ['file_data' => ['mime_type' => $mimeType, 'file_uri' => $fileUri]],
            ],
        ]],
        'generationConfig' => ['temperature' => $subtitleTemperature],
    ];

    $ch = curl_init($geminiUrl);
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json', 'Expect:'],
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_TIMEOUT        => 900,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);
    $gResp = curl_exec($ch);
    $gCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($gCode !== 200) {
        $gErrData = json_decode($gResp, true);
        jsonError('Gemini hatası (HTTP ' . $gCode . '): ' . ($gErrData['error']['message'] ?? substr($gResp, 0, 200)));
    }

    $gData = json_decode($gResp, true);
    $vttContent = $gData['candidates'][0]['content']['parts'][0]['text'] ?? null;
}

if (!$vttContent) {
    jsonError('Gemini altyazı üretemedi. Dosya formatı veya içeriği desteklenmiyor olabilir.');
}

// ============================================================
// ADIM 3: VTT Temizle
// ============================================================
$vttContent = preg_replace('/^```(vtt|webvtt)?\s*\n|```\s*$/im', '', $vttContent);
$vttContent = trim($vttContent);
if (strpos($vttContent, 'WEBVTT') === false) {
    $vttContent = "WEBVTT\n\n" . $vttContent;
}

// ============================================================
// ADIM 4: Supabase'e Kaydet
// ============================================================
$existing = $db->first('subtitles', 'video_id=eq.' . $videoId . '&language=eq.' . $subtitleLanguage, true);

if ($existing) {
    $res = $db->update('subtitles', ['content' => $vttContent], 'id=eq.' . $existing['id'], true);
} else {
    $res = $db->insert('subtitles', [
        'video_id' => $videoId,
        'language' => $subtitleLanguage,
        'content'  => $vttContent,
    ], true);
}

if ($res['status'] >= 400) {
    jsonError('Veritabanına kaydedilemedi: ' . ($res['error'] ?? 'Bilinmeyen hata'));
}

jsonSuccess(['vtt' => $vttContent, 'method' => $methodUsed], 'Altyazı başarıyla oluşturuldu');
