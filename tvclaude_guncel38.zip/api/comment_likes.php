<?php
// GET ?video_id=..   -> {liked:[comment_id,...]} (giriş yapmış kullanıcının beğendikleri)
// POST {comment_id}  -> beğen / beğeniyi kaldır -> {liked, count}
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/user_auth.php';
error_reporting(0); ini_set('display_errors', 0);

$db = new Supabase();
$user = requireUserApi($db);
if ($_SERVER['REQUEST_METHOD'] === 'POST') denyIfBanned($db, $user['id']);
$uid = $user['id'];

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $vid = trim($_GET['video_id'] ?? ''); requireUuid($vid, 'Video ID');
    $cs = $db->select('comments', 'video_id=eq.' . $vid . '&select=id&limit=2000', true)['data'] ?? [];
    $ids = array_values(array_filter(array_column($cs, 'id'), 'isUuid'));
    $liked = [];
    if ($ids) {
        $r = $db->select('comment_likes', 'user_id=eq.' . $uid . '&comment_id=in.(' . implode(',', $ids) . ')&select=comment_id', true)['data'] ?? [];
        $liked = array_column($r, 'comment_id');
    }
    jsonSuccess(['liked' => $liked]);
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $in = inputJson() ?? [];
    $cid = trim($in['comment_id'] ?? ''); requireUuid($cid, 'Yorum ID');
    if (!$db->first('comments', 'id=eq.' . $cid . '&select=id', true)) jsonError('Yorum bulunamadı', 404);
    $ex = $db->first('comment_likes', 'user_id=eq.' . $uid . '&comment_id=eq.' . $cid . '&select=comment_id', true);
    if ($ex) $db->delete('comment_likes', 'user_id=eq.' . $uid . '&comment_id=eq.' . $cid, true);
    else $db->insert('comment_likes', ['user_id' => $uid, 'comment_id' => $cid], true);
    jsonSuccess(['liked' => !$ex, 'count' => $db->count('comment_likes', 'comment_id=eq.' . $cid, true)]);
}
jsonError('Geçersiz metod', 405);
