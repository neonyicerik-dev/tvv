<?php
// GET ?video_id=..            -> {avg, count, mine}
// POST {video_id, rating 1-5} -> puan ver/güncelle
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/user_auth.php';
error_reporting(0); ini_set('display_errors', 0);

$db = new Supabase();
function ratingSummary(Supabase $db, string $vid, ?string $uid): array {
    $rows = $db->select('video_ratings', 'video_id=eq.' . $vid . '&select=rating,user_id&limit=50000', true)['data'] ?? [];
    $n = count($rows); $sum = 0; $mine = 0;
    foreach ($rows as $r) { $sum += (int)$r['rating']; if ($uid && $r['user_id'] === $uid) $mine = (int)$r['rating']; }
    return ['avg' => $n ? round($sum / $n, 1) : 0, 'count' => $n, 'mine' => $mine];
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $vid = trim($_GET['video_id'] ?? ''); requireUuid($vid, 'Video ID');
    $uid = null; $tok = getBearerToken();
    if ($tok) { $u = $db->verifyToken($tok); if ($u && !empty($u['id'])) $uid = $u['id']; }
    jsonSuccess(ratingSummary($db, $vid, $uid));
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = requireUserApi($db);
    denyIfBanned($db, $user['id']);
    $in = inputJson() ?? [];
    $vid = trim($in['video_id'] ?? ''); requireUuid($vid, 'Video ID');
    $rt = (int)($in['rating'] ?? 0);
    if ($rt < 1 || $rt > 5) jsonError('Puan 1-5 arasında olmalı');
    $ex = $db->first('video_ratings', 'user_id=eq.' . $user['id'] . '&video_id=eq.' . $vid . '&select=video_id', true);
    if ($ex) $db->update('video_ratings', ['rating' => $rt], 'user_id=eq.' . $user['id'] . '&video_id=eq.' . $vid, true);
    else $db->insert('video_ratings', ['user_id' => $user['id'], 'video_id' => $vid, 'rating' => $rt], true);
    jsonSuccess(ratingSummary($db, $vid, $user['id']));
}
jsonError('Geçersiz metod', 405);
