<?php
// ============================================================
// NeonTV - Daha Sonra İzle API (hesaba bağlı)
// GET ?video_id=..  -> {saved:bool}
// POST {video_id}   -> ekle/çıkar (toggle) -> {saved:bool}
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/user_auth.php';
error_reporting(0); ini_set('display_errors', 0);

$db   = new Supabase();
$user = requireUserApi($db);
$uid  = $user['id'];
$m    = $_SERVER['REQUEST_METHOD'];

if ($m === 'GET' && !empty($_GET['list'])) {
    $r = $db->select('watch_later', 'user_id=eq.' . $uid . '&order=created_at.desc&limit=200&select=created_at,videos(id,title,thumbnail_url,duration,views,status)', true);
    $out = [];
    foreach (($r['data'] ?? []) as $row) { if (!empty($row['videos']) && ($row['videos']['status'] ?? '') === 'published') $out[] = $row; }
    jsonSuccess(['items' => $out]);
}
if ($m === 'GET') {
    $vid = trim($_GET['video_id'] ?? '');
    requireUuid($vid, 'Video ID');
    $r = $db->first('watch_later', 'user_id=eq.' . $uid . '&video_id=eq.' . $vid . '&select=video_id', true);
    jsonSuccess(['saved' => (bool)$r]);
}
if ($m === 'POST') {
    $in  = inputJson() ?? [];
    $vid = trim($in['video_id'] ?? '');
    requireUuid($vid, 'Video ID');
    $r = $db->first('watch_later', 'user_id=eq.' . $uid . '&video_id=eq.' . $vid . '&select=video_id', true);
    if ($r) {
        $db->delete('watch_later', 'user_id=eq.' . $uid . '&video_id=eq.' . $vid, true);
        jsonSuccess(['saved' => false]);
    }
    $exists = $db->first('videos', 'id=eq.' . $vid . '&select=id', true);
    if (!$exists) jsonError('Video bulunamadı', 404);
    $db->insert('watch_later', ['user_id' => $uid, 'video_id' => $vid], true);
    jsonSuccess(['saved' => true]);
}
jsonError('Geçersiz metod', 405);
