<?php
// ============================================================
// NeonTV - Comments API
// G3: UUID doğrulama, G8: error_handler güvenli
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/user_auth.php';

error_reporting(0);
ini_set('display_errors', 0);

$method = $_SERVER['REQUEST_METHOD'];
$db     = new Supabase();
$input  = inputJson();

if ($method === 'POST') {
    $token = getBearerToken();
    if (!$token) jsonError('Giriş yapmanız gerekli', 401);

    $user = $db->verifyToken($token);
    if (!$user) jsonError('Geçersiz token', 401);
    denyIfBanned($db, $user['id']);

    $videoId = trim($input['video_id'] ?? '');
    $content = sanitizeCommentContent(trim($input['content'] ?? ''));

    // G3: UUID doğrulama
    requireUuid($videoId, 'Video ID');

    if (!$content) jsonError('Yorum içeriği gerekli');
    if (mb_strlen($content) > 2000) jsonError('Yorum çok uzun (maks 2000 karakter)');

    // İsteğe bağlı parent_id UUID doğrulaması
    $parentId = null;
    if (!empty($input['parent_id'])) {
        $raw = trim($input['parent_id']);
        if (!isUuid($raw)) jsonError('Geçersiz parent_id formatı');
        $parentId = $raw;
    }

    $profile  = $db->first('profiles', 'id=eq.' . urlencode($user['id']), true);
    $username = $user['user_metadata']['username'] ?? explode('@', $user['email'])[0];

    if (!$profile) {
        $db->insert('profiles', [
            'id'         => $user['id'],
            'username'   => $username,
            'avatar_url' => $user['user_metadata']['avatar_url'] ?? '',
        ], true);
    }

    $res = $db->insert('comments', [
        'video_id'  => $videoId,
        'user_id'   => $user['id'],
        'content'   => $content,
        'parent_id' => $parentId,
    ], true);

    if ($res['status'] >= 400) jsonError('Yorum kaydedilemedi', 500);

    $inserted = isset($res['data'][0]) ? $res['data'][0] : $res['data'];
    $inserted['profiles'] = [
        'username'   => $profile ? $profile['username'] : $username,
        'avatar_url' => $profile ? ($profile['avatar_url'] ?? '') : ($user['user_metadata']['avatar_url'] ?? ''),
    ];

    // Yanıt bildirimi: kök yorumun sahibine (kendisi değilse ve etiketlenmediyse)
    $notifiedIds = [];
    try {
        if ($parentId) {
            $pc = $db->first('comments', 'id=eq.' . urlencode($parentId) . '&select=user_id', true);
            if ($pc && $pc['user_id'] !== $user['id']) {
                $meName = $profile ? $profile['username'] : $username;
                $db->insert('notifications', [
                    'user_id' => $pc['user_id'], 'type' => 'reply',
                    'message' => mb_substr($meName . ' yorumuna yanıt verdi: ' . $content, 0, 300),
                    'link'    => '/video.php?id=' . $videoId . '#comment-' . ($inserted['id'] ?? ''),
                ], true);
                $notifiedIds[$pc['user_id']] = true;
            }
        }
    } catch (\Throwable $e) {}

    // @kullanici etiketleri -> bildirim (en fazla 5 kişi)
    try {
        if (preg_match_all('/@([a-zA-Z0-9_.\-]{2,40})/u', $content, $mm)) {
            $names = array_slice(array_unique($mm[1]), 0, 5);
            $me    = $profile ? $profile['username'] : $username;
            foreach ($names as $nm) {
                $t = $db->first('profiles', 'username=ilike.' . urlencode(str_replace(['*', '%'], '', $nm)) . '&select=id', true);
                if ($t && $t['id'] !== $user['id'] && empty($notifiedIds[$t['id']])) {
                    $db->insert('notifications', [
                        'user_id' => $t['id'], 'type' => 'mention',
                        'message' => mb_substr($me . ' seni bir yorumda etiketledi: ' . $content, 0, 300),
                        'link'    => '/video.php?id=' . $videoId . '#comment-' . ($inserted['id'] ?? ''),
                    ], true);
                }
            }
        }
    } catch (\Throwable $e) {}

    require_once __DIR__ . '/../includes/store.php';
    $inserted['is_premium'] = Store::isPremium($user['id']);
    $inserted['frame'] = $inserted['is_premium'] ? (Store::getUserThemes([$user['id']], [$user['id'] => true])[$user['id']]['frame'] ?? null) : null;

    jsonSuccess($inserted);
}

if ($method === 'PATCH') {
    $token = getBearerToken();
    if (!$token) jsonError('Giriş yapmanız gerekli', 401);
    $user = $db->verifyToken($token);
    if (!$user || empty($user['id'])) jsonError('Geçersiz token', 401);
    denyIfBanned($db, $user['id']);

    $id = trim($input['id'] ?? ($_GET['id'] ?? ''));
    requireUuid($id, 'Yorum ID');
    $content = sanitizeCommentContent(trim($input['content'] ?? ''));
    if ($content === '') jsonError('Yorum içeriği gerekli');
    if (mb_strlen($content) > 2000) jsonError('Yorum çok uzun (maks 2000 karakter)');

    $comment = $db->first('comments', 'id=eq.' . urlencode($id), true);
    if (!$comment) jsonError('Yorum bulunamadı', 404);
    if ($comment['user_id'] !== $user['id']) jsonError('Bu yorumu düzenleme yetkiniz yok', 403);
    if ($comment['content'] === $content) jsonSuccess(['content' => $content, 'edited' => !empty($comment['edited_at'])]);

    $r = $db->update('comments', ['content' => $content, 'edited_at' => gmdate('Y-m-d\TH:i:s\Z')], 'id=eq.' . urlencode($id), true);
    if ($r['status'] >= 400) jsonError('Güncellenemedi (SQL güncellemesi çalıştırıldı mı?)', 500);
    jsonSuccess(['content' => $content, 'edited' => true], 'Güncellendi');
}

if ($method === 'DELETE') {
    $token = getBearerToken();
    if (!$token) jsonError('Giriş yapmanız gerekli', 401);

    $id = trim($_GET['id'] ?? '');
    requireUuid($id, 'Yorum ID');

    // Sahiplik kontrolü – sadece kendi yorumunu silebilir
    $user    = $db->verifyToken($token);
    if (!$user) jsonError('Geçersiz token', 401);

    $comment = $db->first('comments', 'id=eq.' . urlencode($id), true);
    if (!$comment) jsonError('Yorum bulunamadı', 404);

    if ($comment['user_id'] !== $user['id']) {
        jsonError('Bu yorumu silme yetkiniz yok', 403);
    }

    $res = $db->delete('comments', 'id=eq.' . urlencode($id), true);
    if ($res['status'] >= 400) jsonError('Silinemedi', 500);
    jsonSuccess([], 'Silindi');
}

jsonError('Geçersiz metod', 405);
