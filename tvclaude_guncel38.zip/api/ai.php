<?php
// ============================================================
// NeonTV - AI API (Google Gemini)
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/gemini.php';

requireAdmin();

$method = $_SERVER['REQUEST_METHOD'];
if ($method !== 'POST') jsonError('Gecersiz metod', 405);

$input  = inputJson();
$action = $input['action'] ?? '';

// Ayarlardan sistem promptunu oku
require_once __DIR__ . '/../includes/store.php';
$settings = loadSettingsCompat();

if ($action === 'generate_title_desc') {
    $topic       = $input['topic'] ?? '';
    $imageBase64 = $input['image_base64'] ?? '';
    $videoBase64 = $input['video_base64'] ?? '';
    $videoMime   = $input['video_mime_type'] ?? 'video/mp4';
    $fileName    = $input['file_name'] ?? '';

    $systemPrompt = $input['system_prompt'] ?? '';
    if (empty($systemPrompt)) {
        $systemPrompt = !empty($settings['ai_title_system_prompt'])
            ? $settings['ai_title_system_prompt']
            : 'Sen bir video platformu için içerik yöneticisisin. Türkçe yaz. SEO uyumlu, dikkat çekici başlıklar ve açıklamalar oluştur.';
    }

    $titleTemperature = (float)($settings['title_temperature'] ?? 0.7);

    if (!$topic && !$imageBase64 && !$videoBase64 && !$fileName) jsonError('Konu, dosya adı, kapak görseli veya video gerekli');

    $prompt = "Aşağıdaki bilgiler ve (varsa) medya hakkında bir video için ilgi çekici, tıklama oranını artıracak bir başlık ve detaylı bir SEO uyumlu açıklama oluştur.
    Lütfen yanıtını SADECE aşağıdaki JSON formatında ver, başka hiçbir metin ekleme:
    {
        \"title\": \"Videonun Başlığı\",
        \"description\": \"Videonun Açıklaması\"
    }\n";
    
    if ($topic) $prompt .= "Kullanıcının Girdiği Konu: " . $topic . "\n";
    if ($fileName) $prompt .= "Orijinal Video Dosyası Adı (Büyük bir ipucudur, bunu baz alarak mantıklı bir başlık kur): " . $fileName . "\n";
    if (!$topic && !$fileName) $prompt .= "Konu: Medya içeriğine göre uygun bir konu belirle.\n";

    $parts = [['text' => $prompt]];

    if ($imageBase64) {
        $parts[] = ['inlineData' => ['mimeType' => 'image/jpeg', 'data' => $imageBase64]];
    }
    if ($videoBase64) {
        $parts[] = ['inlineData' => ['mimeType' => $videoMime, 'data' => $videoBase64]];
    }

    $payload = [
        'systemInstruction' => ['parts' => [['text' => $systemPrompt]]],
        'contents' => [['parts' => $parts]],
        'generationConfig' => ['responseMimeType' => 'application/json', 'temperature' => $titleTemperature]
    ];

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => GEMINI_API_BASE . GEMINI_MODEL . ':generateContent?key=' . GEMINI_API_KEY,
        CURLOPT_POST           => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_TIMEOUT        => 60, // Video analizleri için timeout biraz daha uzun olabilir
        CURLOPT_SSL_VERIFYPEER => true
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    geminiLogFailure('ai.php', $ch, $response, $httpCode);
    curl_close($ch);

    if ($httpCode !== 200) jsonError('AI servisi yanit vermedi.');

    $data = json_decode($response, true);
    $text = $data['candidates'][0]['content']['parts'][0]['text'] ?? '';

    $jsonStart = strpos($text, '{');
    $jsonEnd   = strrpos($text, '}');

    if ($jsonStart !== false && $jsonEnd !== false) {
        $cleanJson = substr($text, $jsonStart, $jsonEnd - $jsonStart + 1);
        $result    = json_decode($cleanJson, true);
        if ($result && isset($result['title']) && isset($result['description'])) {
            jsonSuccess($result);
        }
    }

    jsonError('AI yaniti anlasilamadi');
}

// YENİ: Videonun Sesini (veya Tamamını) Dinleyerek Analiz Etme
if ($action === 'analyze_video') {
    $videoId = $input['video_id'] ?? '';
    $publicId = $input['cloudinary_public_id'] ?? '';
    if (!$videoId || !$publicId) jsonError('Video ID ve Cloudinary ID gerekli');

    require_once __DIR__ . '/../includes/cloudinary.php';
    require_once __DIR__ . '/../includes/supabase.php';
    $cld = new Cloudinary();
    $db = new Supabase();

    // 1. Videonun süresini veritabanından al
    $videoRow = $db->first('videos', 'id=eq.' . $videoId, true);
    $duration = $videoRow['duration'] ?? 0;
    
    // Veritabanında yoksa Cloudinary'den al
    if (!$duration) {
        $duration = $cld->getVideoDuration($publicId) ?: 0;
    }
    
    // Videonun ortasından başla
    $startOffset = 0;
    if ($duration > 15) {
        $startOffset = (int)($duration * 0.5); // Ortadan başla
    }

    // 2. Videonun Kısa Klibini Cloudinary'den İndir (İstenen noktadan 8 saniye)
    $videoData = $cld->downloadVideoClip($publicId, $startOffset);
    if (!$videoData) jsonError('Video klibi analiz için indirilemedi (boyut çok büyük olabilir).');

    $base64Video = base64_encode($videoData);

    $prompt = "Sen uzman bir YouTube içerik üreticisisin. Sana gönderilen bu kısa video klibini (görüntülerini İZLE ve seslerini DİNLE) analiz et. 
    Bu videoda ne olduğunu tam olarak anla ve tıklama oranını artıracak çok ilgi çekici bir Türkçe Başlık ile detaylı bir SEO uyumlu Açıklama yaz.
    Yanıtını SADECE JSON formatında ver, başka hiçbir metin ekleme:
    {
        \"title\": \"Harika Başlık\",
        \"description\": \"Detaylı açıklama...\"
    }";

    $payload = [
        'contents' => [
            [
                'parts' => [
                    ['text' => $prompt],
                    ['inlineData' => ['mimeType' => 'video/mp4', 'data' => $base64Video]]
                ]
            ]
        ],
        'generationConfig' => ['responseMimeType' => 'application/json', 'temperature' => 0.7]
    ];

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => GEMINI_API_BASE . GEMINI_MODEL . ':generateContent?key=' . GEMINI_API_KEY,
        CURLOPT_POST           => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_TIMEOUT        => 120, // Video analizi uzun sürebilir
        CURLOPT_SSL_VERIFYPEER => true
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode !== 200) {
        jsonError('Gemini API hatası (HTTP ' . $httpCode . '). Ayrıntı sunucu günlüğünde.');
    }

    $data = json_decode($response, true);
    
    // Finish reason kontrolü
    $finishReason = $data['candidates'][0]['finishReason'] ?? '';
    if (in_array($finishReason, ['OTHER', 'RECITATION', 'SAFETY'])) {
        jsonError('AI içerik politikası nedeniyle yanıt üretemedi. Farklı bir video deneyin.');
    }
    
    $text = $data['candidates'][0]['content']['parts'][0]['text'] ?? '';

    if (!$text) {
        jsonError('AI boş yanıt döndürdü. Video klibi çok kısa veya oynatılamaz olabilir.');
    }

    $jsonStart = strpos($text, '{');
    $jsonEnd   = strrpos($text, '}');

    if ($jsonStart !== false && $jsonEnd !== false) {
        $cleanJson = substr($text, $jsonStart, $jsonEnd - $jsonStart + 1);
        $result    = json_decode($cleanJson, true);
        if ($result && isset($result['title']) && isset($result['description'])) {
            // Veritabanını Güncelle
            $db->update('videos', [
                'title' => $result['title'],
                'description' => $result['description']
            ], 'id=eq.' . $videoId);

            jsonSuccess($result);
        }
    }
    jsonError('AI yanıtı JSON formatında değil: ' . substr($text, 0, 200));
}

// ============================================================
// YENİ: URL'den Video Klibini CloudConvert ile İndir + Gemini Analizi
// Cloudinary GEREKTIRMEZ - Herhangi bir video URL'si çalışır
// ============================================================
if ($action === 'analyze_video_url') {
    $videoUrl = trim($input['video_url'] ?? '');
    $videoId  = trim($input['video_id'] ?? '');

    if (!$videoUrl) jsonError('Video URL gerekli');

    // Geçerli URL mü kontrol et
    if (!filter_var($videoUrl, FILTER_VALIDATE_URL)) {
        jsonError('Geçersiz video URL formatı');
    }

    // CloudConvert API Key kontrol
    if (!defined('CLOUDCONVERT_API_KEY') || CLOUDCONVERT_API_KEY === 'YOUR_CLOUDCONVERT_API_KEY_HERE') {
        // CloudConvert yoksa URL'yi doğrudan indirmeyi dene (küçük dosyalar için)
        $videoData = @file_get_contents($videoUrl, false, stream_context_create([
            'http' => ['timeout' => 30, 'header' => "Range: bytes=0-8388608\r\n"] // Max 8MB
        ]));
        
        if (!$videoData || strlen($videoData) < 1000) {
            jsonError('CloudConvert API anahtarı ayarlanmamış. includes/config.php dosyasında CLOUDCONVERT_API_KEY değerini ayarlayın. https://cloudconvert.com/dashboard/api/v2/keys adresinden ücretsiz key alabilirsiniz.');
        }
        
        $base64Video = base64_encode($videoData);
        goto gemini_analyze;
    }

    // ---- ADIM 1: CloudConvert Job Oluştur ----
    // Trim: videonun 10-20. saniyesini al, 480p'ye düşür
    $jobPayload = [
        'tasks' => [
            'import-video' => [
                'operation' => 'import/url',
                'url'       => $videoUrl,
                'filename'  => 'input_video.mp4',
            ],
            'convert-video' => [
                'operation'     => 'convert',
                'input'         => 'import-video',
                'output_format' => 'mp4',
                'engine'        => 'ffmpeg',
                'trim_from'     => 8,     // 8. saniyeden başla
                'trim_to'       => 18,    // 18. saniyeye kadar (10 sn)
                'width'         => 480,
                'height'        => 270,
                'video_codec'   => 'h264',
                'crf'           => 28,    // Düşük kalite = küçük dosya
                'audio_codec'   => 'aac',
            ],
            'export-video' => [
                'operation'         => 'export/url',
                'input'             => 'convert-video',
                'inline'            => false,
                'archive_multiple_files' => false,
            ]
        ]
    ];

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => 'https://api.cloudconvert.com/v2/jobs',
        CURLOPT_POST           => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => [
            'Authorization: Bearer ' . CLOUDCONVERT_API_KEY,
            'Content-Type: application/json',
        ],
        CURLOPT_POSTFIELDS     => json_encode($jobPayload),
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);

    $ccResponse = curl_exec($ch);
    $ccHttpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($ccHttpCode !== 201) {
        $ccErr = json_decode($ccResponse, true);
        $errMsg = $ccErr['message'] ?? ('CloudConvert job oluşturulamadı: HTTP ' . $ccHttpCode);
        if ($ccHttpCode === 422) $errMsg = 'CloudConvert: Video URL erişilemez veya desteklenmiyor.';
        if ($ccHttpCode === 402) $errMsg = 'CloudConvert kredi bitti. Hesabınızı kontrol edin.';
        if ($ccHttpCode === 401) $errMsg = 'CloudConvert API anahtarı geçersiz. config.php\'yi kontrol edin.';
        jsonError($errMsg);
    }

    $ccData = json_decode($ccResponse, true);
    $jobId  = $ccData['data']['id'] ?? '';
    if (!$jobId) jsonError('CloudConvert job ID alınamadı.');

    // ---- ADIM 2: Job Tamamlanana Kadar Bekle (Polling) ----
    $maxWait  = 90; // saniye
    $interval = 3;  // saniye
    $waited   = 0;
    $exportUrl = null;

    while ($waited < $maxWait) {
        sleep($interval);
        $waited += $interval;

        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => 'https://api.cloudconvert.com/v2/jobs/' . $jobId,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER     => ['Authorization: Bearer ' . CLOUDCONVERT_API_KEY],
            CURLOPT_TIMEOUT        => 15,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);
        $statusResp = curl_exec($ch);
        curl_close($ch);

        $statusData = json_decode($statusResp, true);
        $jobStatus  = $statusData['data']['status'] ?? 'waiting';

        if ($jobStatus === 'error') {
            $taskErrors = [];
            foreach (($statusData['data']['tasks'] ?? []) as $task) {
                if (($task['status'] ?? '') === 'error') {
                    $taskErrors[] = $task['message'] ?? 'Bilinmeyen görev hatası';
                }
            }
            jsonError('CloudConvert dönüşüm hatası: ' . implode('; ', $taskErrors));
        }

        if ($jobStatus === 'finished') {
            // Export task'ındaki URL'yi bul
            foreach (($statusData['data']['tasks'] ?? []) as $task) {
                if (($task['operation'] ?? '') === 'export/url' && ($task['status'] ?? '') === 'finished') {
                    $exportUrl = $task['result']['files'][0]['url'] ?? null;
                    break;
                }
            }
            break;
        }
    }

    if (!$exportUrl) {
        jsonError('CloudConvert: Video dönüşümü zaman aşımına uğradı veya export URL bulunamadı.');
    }

    // ---- ADIM 3: Dönüştürülmüş Klibi İndir ----
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => $exportUrl,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_TIMEOUT        => 60,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);
    $videoData = curl_exec($ch);
    $dlHttpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($dlHttpCode !== 200 || !$videoData || strlen($videoData) < 100) {
        jsonError('Dönüştürülmüş video klip indirilemedi.');
    }

    // Boyut kontrolü (Gemini inline limit ~20MB)
    if (strlen($videoData) > 18 * 1024 * 1024) {
        jsonError('Video klibi Gemini için çok büyük. CloudConvert ayarları kontrol edilmeli.');
    }

    $base64Video = base64_encode($videoData);

    // ---- ADIM 4: Gemini ile Analiz ----
    gemini_analyze:

    $titleSystemPrompt = !empty($settings['ai_title_system_prompt'])
        ? $settings['ai_title_system_prompt']
        : 'Sen bir video platformu için içerik yöneticisisin. Türkçe yaz. SEO uyumlu, dikkat çekici başlıklar ve açıklamalar oluştur.';

    $titleTemperature = (float)($settings['title_temperature'] ?? 0.7);

    $analyzePrompt = "Sen uzman bir video içerik üreticisisin. Sana gönderilen bu kısa video klibini (görüntülerini İZLE ve seslerini DİNLE) analiz et.\n"
        . "Bu videoda ne olduğunu tam olarak anla ve tıklama oranını artıracak çok ilgi çekici bir Türkçe Başlık ile detaylı bir SEO uyumlu Açıklama yaz.\n"
        . "Yanıtını SADECE aşağıdaki JSON formatında ver, başka hiçbir metin ekleme:\n"
        . "{\n    \"title\": \"Harika Başlık\",\n    \"description\": \"Detaylı açıklama...\"\n}";

    $geminiPayload = [
        'systemInstruction' => ['parts' => [['text' => $titleSystemPrompt]]],
        'contents' => [[
            'parts' => [
                ['text' => $analyzePrompt],
                ['inlineData' => ['mimeType' => 'video/mp4', 'data' => $base64Video]]
            ]
        ]],
        'generationConfig' => [
            'responseMimeType' => 'application/json',
            'temperature'      => $titleTemperature,
        ]
    ];

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => GEMINI_API_BASE . GEMINI_MODEL . ':generateContent?key=' . GEMINI_API_KEY,
        CURLOPT_POST           => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
        CURLOPT_POSTFIELDS     => json_encode($geminiPayload),
        CURLOPT_TIMEOUT        => 120,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);

    $geminiResponse = curl_exec($ch);
    $geminiHttpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($geminiHttpCode !== 200) {
        jsonError('Gemini API hatası (HTTP ' . $geminiHttpCode . '). Ayrıntı sunucu günlüğünde.');
    }

    $geminiData = json_decode($geminiResponse, true);

    $finishReason = $geminiData['candidates'][0]['finishReason'] ?? '';
    if (in_array($finishReason, ['OTHER', 'RECITATION', 'SAFETY'])) {
        jsonError('Gemini içerik politikası nedeniyle yanıt üretemedi. Farklı bir video deneyin.');
    }

    $text = $geminiData['candidates'][0]['content']['parts'][0]['text'] ?? '';
    if (!$text) {
        jsonError('Gemini boş yanıt döndürdü. Video klibi oynatılamıyor olabilir.');
    }

    $jsonStart = strpos($text, '{');
    $jsonEnd   = strrpos($text, '}');

    if ($jsonStart !== false && $jsonEnd !== false) {
        $cleanJson = substr($text, $jsonStart, $jsonEnd - $jsonStart + 1);
        $result    = json_decode($cleanJson, true);
        if ($result && isset($result['title']) && isset($result['description'])) {
            // Eğer video_id verilmişse veritabanını da güncelle
            if ($videoId) {
                require_once __DIR__ . '/../includes/supabase.php';
                $db = new Supabase();
                $db->update('videos', [
                    'title'       => $result['title'],
                    'description' => $result['description'],
                ], 'id=eq.' . $videoId);
            }
            jsonSuccess($result);
        }
    }

    jsonError('Gemini yanıtı JSON formatında değil: ' . substr($text, 0, 200));
}


// Videodan Belirli Saniyeden Thumbnail Çıkar ve Güncelle
if ($action === 'extract_thumbnail') {
    $videoId  = $input['video_id'] ?? '';
    $publicId = $input['cloudinary_public_id'] ?? '';
    $offset   = (int)($input['offset'] ?? 0); // Kaçıncı saniye

    if (!$videoId || !$publicId) jsonError('Video ID ve Cloudinary ID gerekli');
    if ($offset < 0) $offset = 0;

    require_once __DIR__ . '/../includes/cloudinary.php';
    require_once __DIR__ . '/../includes/supabase.php';
    $cld = new Cloudinary();
    $db  = new Supabase();

    // Cloudinary transformation ile belirtilen saniyeden thumbnail URL'i oluştur
    $cloudName = CLOUDINARY_CLOUD_NAME;
    $thumbnailUrl = "https://res.cloudinary.com/{$cloudName}/video/upload/so_{$offset},w_1280,h_720,c_fill,q_auto,f_jpg/{$publicId}.jpg";

    // URL'in gerçekten çalışıp çalışmadığını kontrol et
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => $thumbnailUrl,
        CURLOPT_NOBODY         => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_TIMEOUT        => 15,
    ]);
    curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode !== 200) {
        jsonError('Thumbnail oluşturulamadı. Cloudinary bu anı işleyemedi (HTTP ' . $httpCode . ')');
    }

    // Veritabanını güncelle
    $db->update('videos', ['thumbnail_url' => $thumbnailUrl], 'id=eq.' . $videoId);

    jsonSuccess(['thumbnail_url' => $thumbnailUrl]);
}

if ($action === 'generate_channel_desc') {
    $channelId = $input['channel_id'] ?? '';
    if (!$channelId) jsonError('Kanal ID gerekli');

    require_once __DIR__ . '/../includes/supabase.php';
    $db = new Supabase();
    
    // Kanalın videolarını çek
    $videosRes = $db->select('videos', 'channel_id=eq.' . $channelId . '&select=title,description', true);
    $videos = $videosRes['data'] ?? [];
    
    if (empty($videos)) jsonError('Kanalda analiz edilecek video bulunamadı.');

    $videoInfo = [];
    foreach ($videos as $v) {
        $videoInfo[] = "- Başlık: " . $v['title'] . "\n  Açıklama: " . $v['description'];
    }
    
    $videoText = implode("\n", $videoInfo);
    
    $systemPrompt = $settings['ai_channel_desc_system_prompt'] ?? 'Sen bir video platformu için kanal yöneticisisin. Türkçe yaz. Verilen kanal videolarını analiz ederek kanalı en iyi tanımlayan, SEO uyumlu, ilgi çekici bir kanal açıklaması oluştur. Açıklama 2-4 cümle uzunluğunda olsun.';
    $temperature = (float)($settings['channel_desc_temperature'] ?? 0.7);

    $prompt = "Aşağıdaki videolara sahip bir kanal için en uygun kanal açıklamasını oluştur. Yanıtında sadece açıklamayı ver, hiçbir ek başlık veya mesaj ekleme.\n\nKanalın Videoları:\n" . $videoText;

    $payload = [
        'systemInstruction' => ['parts' => [['text' => $systemPrompt]]],
        'contents' => [['parts' => [['text' => $prompt]]]],
        'generationConfig' => ['temperature' => $temperature]
    ];

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => GEMINI_API_BASE . GEMINI_MODEL . ':generateContent?key=' . GEMINI_API_KEY,
        CURLOPT_POST           => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_SSL_VERIFYPEER => true
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    geminiLogFailure('ai.php', $ch, $response, $httpCode);
    curl_close($ch);

    if ($httpCode !== 200) jsonError('AI servisi yanit vermedi.');

    $data = json_decode($response, true);
    $text = $data['candidates'][0]['content']['parts'][0]['text'] ?? '';
    $text = trim($text);

    if ($text) {
        jsonSuccess(['description' => $text]);
    }

    jsonError('AI yaniti olusturulamadi.');
}

if ($action === 'generate_thumbnail') {
    $topic = $input['topic'] ?? '';
    if (!$topic) jsonError('Konu gerekli');

    $prompt = "Write a highly detailed, cinematic English prompt for an AI image generator (like Midjourney or DALL-E) to create a YouTube thumbnail about the following topic: '" . $topic . "'.
    The image should be eye-catching, vibrant, neon-themed if applicable, and without any text/words in the image.
    Return ONLY the English prompt string, nothing else.";

    $payload = [
        'contents' => [['parts' => [['text' => $prompt]]]],
        'generationConfig' => ['temperature' => 0.8]
    ];

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => GEMINI_API_BASE . GEMINI_MODEL . ':generateContent?key=' . GEMINI_API_KEY,
        CURLOPT_POST           => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_SSL_VERIFYPEER => true
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    geminiLogFailure('ai.php', $ch, $response, $httpCode);
    curl_close($ch);

    if ($httpCode !== 200) jsonError('Gemini API hatasi');

    $data = json_decode($response, true);
    $generatedPrompt = $data['candidates'][0]['content']['parts'][0]['text'] ?? '';
    $generatedPrompt = trim($generatedPrompt);

    if (!$generatedPrompt) jsonError('Prompt uretilemedi');

    // Pollinations.ai URL oluştur (URL Encode)
    $imageUrl = "https://image.pollinations.ai/prompt/" . rawurlencode($generatedPrompt) . "?width=1280&height=720&nologo=true";

    jsonSuccess(['thumbnail_url' => $imageUrl, 'prompt' => $generatedPrompt]);
}

if ($action === 'fix_spelling') {
    $textInput = $input['text'] ?? '';
    if (!$textInput) jsonError('Metin girilmedi.');

    $systemPrompt = "Sen bir Türkçe dil bilgisi uzmanısın. Kullanıcının gönderdiği metindeki yazım hatalarını, noktalama eksikliklerini ve anlatım bozukluklarını düzelt. 
Metnin anlamını değiştirmeden sadece dil bilgisini iyileştir. 
Yanıt olarak sadece düzeltilmiş metni ver, başka hiçbir açıklama yapma.";

    $payload = [
        'systemInstruction' => ['parts' => [['text' => $systemPrompt]]],
        'contents' => [['parts' => [['text' => $textInput]]]],
        'generationConfig' => ['temperature' => 0.2]
    ];

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => GEMINI_API_BASE . GEMINI_MODEL . ':generateContent?key=' . GEMINI_API_KEY,
        CURLOPT_POST           => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_SSL_VERIFYPEER => true
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    geminiLogFailure('ai.php', $ch, $response, $httpCode);
    curl_close($ch);

    if ($httpCode !== 200) jsonError('AI servisi yanit vermedi.');

    $data = json_decode($response, true);
    $correctedText = $data['candidates'][0]['content']['parts'][0]['text'] ?? '';
    $correctedText = trim($correctedText);

    if ($correctedText) {
        jsonSuccess(['corrected_text' => $correctedText]);
    }

    jsonError('Düzeltilmiş metin olusturulamadi.');
}

jsonError('Gecersiz islem');
