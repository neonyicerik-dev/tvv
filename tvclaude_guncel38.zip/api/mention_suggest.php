<?php
// @ etiketleme önerisi: GET ?q=ab  -> kullanıcı adı "ab" ile başlayan en fazla 6 profil (yalnızca herkese açık bilgiler)
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
error_reporting(0); ini_set('display_errors', 0);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$q = trim((string)($_GET['q'] ?? ''));
if (!preg_match('/^[a-zA-Z0-9_.\-]{1,40}$/', $q)) { echo json_encode(['data' => []]); exit; }

// çok sık istek atılmasını engelle (IP başına saniyede ~5)
$rl = sys_get_temp_dir() . '/nv_ms_' . md5(($_SERVER['REMOTE_ADDR'] ?? '0')) . '.t';
$now = microtime(true);
if (is_file($rl) && $now - (float)@file_get_contents($rl) < 0.2) { echo json_encode(['data' => []]); exit; }
@file_put_contents($rl, (string)$now);

$db = new Supabase();
$r  = $db->select('profiles', 'username=ilike.' . rawurlencode(str_replace('_', '\\_', $q) . '*') . '&select=id,username,avatar_url&order=username.asc&limit=6', true);
$out = [];
foreach (($r['data'] ?? []) as $p) {
    if (!empty($p['username'])) $out[] = ['id' => $p['id'], 'username' => $p['username'], 'avatar_url' => $p['avatar_url'] ?? ''];
}
echo json_encode(['data' => $out], JSON_UNESCAPED_UNICODE);
