<?php
// GET -> "Senin için" önerileri (izleme geçmişindeki kategori/etiketlere göre)
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/user_auth.php';
error_reporting(0); ini_set('display_errors', 0);

$db = new Supabase();
$user = requireUserApi($db);
$uid = $user['id'];

$hist = $db->select('watch_history', 'user_id=eq.' . $uid . '&order=watched_at.desc&limit=30&select=video_id', true)['data'] ?? [];
$seen = array_values(array_filter(array_column($hist, 'video_id'), 'isUuid'));
$out = [];
$sel = 'select=id,title,thumbnail_url,duration,views,created_at';
$excl = $seen ? '&id=not.in.(' . implode(',', $seen) . ')' : '';

if ($seen) {
    $cats = $db->select('video_categories', 'video_id=in.(' . implode(',', $seen) . ')&select=category_id', true)['data'] ?? [];
    $freq = [];
    foreach ($cats as $c) $freq[$c['category_id']] = ($freq[$c['category_id']] ?? 0) + 1;
    arsort($freq);
    $top = array_slice(array_keys(array_filter($freq, 'isUuid', ARRAY_FILTER_USE_KEY)), 0, 3);
    if ($top) {
        $vc = $db->select('video_categories', 'category_id=in.(' . implode(',', $top) . ')&select=video_id&limit=500', true)['data'] ?? [];
        $cand = array_values(array_diff(array_unique(array_column($vc, 'video_id')), $seen));
        $cand = array_slice(array_filter($cand, 'isUuid'), 0, 200);
        if ($cand) {
            $out = $db->select('videos', 'status=eq.published&id=in.(' . implode(',', $cand) . ')&order=views.desc&limit=12&' . $sel, true)['data'] ?? [];
        }
    }
}
if (count($out) < 8) { // yetmezse popülerlerle tamamla
    $have = array_column($out, 'id');
    $more = $db->select('videos', 'status=eq.published' . $excl . '&order=views.desc&limit=16&' . $sel, true)['data'] ?? [];
    foreach ($more as $v) { if (count($out) >= 12) break; if (!in_array($v['id'], $have, true)) $out[] = $v; }
}
jsonSuccess(['items' => array_slice($out, 0, 12), 'personal' => !empty($seen)]);
