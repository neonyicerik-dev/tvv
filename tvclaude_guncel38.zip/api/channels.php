<?php
// ============================================================
// NeonTV - Channels API
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';

error_reporting(0);
ini_set('display_errors', 0);

$method = $_SERVER['REQUEST_METHOD'];
$db     = new Supabase();
$input  = inputJson();

if ($method === 'GET') {
    // Abone durumu kontrol et
    if (isset($_GET['check_subscribe'])) {
        $channelId = (string)$_GET['check_subscribe'];
        if (!$channelId || !isUuid($channelId)) jsonSuccess(['subscribed' => false]);
        $token = getBearerToken();
        if (!$token) jsonSuccess(['subscribed' => false]);
        $user = $db->verifyToken($token);
        if (!$user) jsonSuccess(['subscribed' => false]);
        $check = $db->first('subscriptions', 'channel_id=eq.' . $channelId . '&user_id=eq.' . $user['id'], true);
        jsonSuccess(['subscribed' => !empty($check)]);
    }

    $id = $_GET['id'] ?? '';
    if ($id) {
        $res = $db->first('channels', 'id=eq.' . $id);
        jsonSuccess($res ?? []);
    }

    $order = $_GET['order'] ?? 'created_at.desc';
    $res = $db->select('channels', 'order=' . $order);
    jsonSuccess($res['data'] ?? []);
}

if ($method === 'POST') {
    // Abone olma (kullanıcı)
    if (isset($_GET['subscribe'])) {
        $channelId = (string)$_GET['subscribe'];
        if (!$channelId || !isUuid($channelId)) jsonError('Geçersiz kanal ID');

        $token = getBearerToken();
        if (!$token) jsonError('Giris yapmaniz gerekli', 401);
        $user = $db->verifyToken($token);
        if (!$user) jsonError('Gecersiz token', 401);

        // Önce silmeyi dene (silinen satır dönerse abonelik vardı = çıkış). Yoksa ekle. Tek tur eksik sorgu.
        $del = $db->delete('subscriptions', 'channel_id=eq.' . $channelId . '&user_id=eq.' . $user['id'], true);
        if (($del['status'] ?? 500) < 400 && !empty($del['data']) && is_array($del['data'])) {
            jsonSuccess(['subscribed' => false]);
        }
        $res = $db->insert('subscriptions', [
            'channel_id' => $channelId,
            'user_id'    => $user['id']
        ], true);
        if ($res['status'] >= 400 && $res['status'] !== 409) jsonError($res['error'] ?? 'Abone olunamadi');
        jsonSuccess(['subscribed' => true]);
    }

    // Admin kanal oluşturma
    requireAdmin();
    if (empty($input['name'])) jsonError('Kanal adı gerekli');

    $res = $db->insert('channels', [
        'name'        => $input['name'],
        'description' => $input['description'] ?? '',
        'avatar_url'  => $input['avatar_url'] ?? '',
        'cover_url'   => $input['cover_url'] ?? ''
    ], true);

    if ($res['status'] >= 400) jsonError($res['error'] ?? 'Kanal olusturulamadi');
    jsonSuccess($res['data'] ?? []);
}

if ($method === 'PATCH') {
    requireAdmin();
    $id = $_GET['id'] ?? '';
    if (!$id) jsonError('ID gerekli');

    $updateData = [];
    if (isset($input['name']))        $updateData['name']        = $input['name'];
    if (isset($input['description'])) $updateData['description'] = $input['description'];
    if (isset($input['avatar_url']))  $updateData['avatar_url']  = $input['avatar_url'];
    if (isset($input['cover_url']))   $updateData['cover_url']   = $input['cover_url'];
    $updateData['updated_at'] = gmdate('Y-m-d\TH:i:s\Z');

    $res = $db->update('channels', $updateData, 'id=eq.' . $id, true);
    if ($res['status'] >= 400) jsonError($res['error'] ?? 'Guncelleme basarisiz');
    jsonSuccess($res['data'] ?? []);
}

if ($method === 'DELETE') {
    requireAdmin();
    $id = $_GET['id'] ?? '';
    if (!$id) jsonError('ID gerekli');

    $res = $db->delete('channels', 'id=eq.' . $id, true);
    if ($res['status'] >= 400) jsonError($res['error'] ?? 'Silinemedi');
    jsonSuccess([], 'Kanal silindi');
}

jsonError('Gecersiz metod', 405);
