<?php
// ============================================================
// NeonTV - Chapters API (CRUD + AI oluşturma)
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';

error_reporting(0);
ini_set('display_errors', 0);

requireAdmin();

$method  = $_SERVER['REQUEST_METHOD'];
$db      = new Supabase();

// GET: Bölümleri listele
if ($method === 'GET') {
    $videoId = $_GET['video_id'] ?? '';
    if (!$videoId) jsonError('Video ID gerekli');
    $res = $db->select('chapters', 'video_id=eq.' . $videoId . '&order=start_time.asc', true);
    jsonSuccess($res['data'] ?? []);
}

// DELETE: Bölüm sil
if ($method === 'DELETE') {
    $id = $_GET['id'] ?? '';
    if (!$id) jsonError('Chapter ID gerekli');
    $res = $db->delete('chapters', 'id=eq.' . $id, true);
    jsonSuccess([], 'Bölüm silindi');
}

$input = inputJson();

// POST: Bölüm ekle veya AI ile otomatik oluştur
if ($method === 'POST') {
    $videoId = $input['video_id'] ?? '';
    if (!$videoId) jsonError('Video ID gerekli');

    // AI ile otomatik oluştur
    if (!empty($input['ai'])) {
        $subtitleContent = $input['subtitle_content'] ?? '';
        if (!$subtitleContent) jsonError('Altyazı içeriği gerekli');

        require_once __DIR__ . '/../includes/store.php';
        $settings = loadSettingsCompat();

        $defaultPrompt = "Aşağıdaki WebVTT altyazı içeriğini analiz et ve videoyu anlamlı bölümlere (chapters) ayır. " .
            "Her bölüm için bir başlık ve o bölümün başladığı saniyeyi belirle. " .
            "Bölüm sayısı konuya göre 3-10 arasında olsun. " .
            "SADECE JSON formatında yanıt ver, başka hiçbir şey yazma:\n" .
            "[{\"title\": \"Bölüm Adı\", \"start_time\": 0}]";

        $basePrompt = !empty($settings['ai_chapter_system_prompt']) ? $settings['ai_chapter_system_prompt'] : $defaultPrompt;
        $prompt = $basePrompt . "\n\nAltyazı:\n" . substr($subtitleContent, 0, 8000);

        $payload = [
            'contents' => [['parts' => [['text' => $prompt]]]],
            'generationConfig' => ['responseMimeType' => 'application/json', 'temperature' => 0.3]
        ];

        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => GEMINI_API_BASE . GEMINI_MODEL . ':generateContent?key=' . GEMINI_API_KEY,
            CURLOPT_POST           => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
            CURLOPT_POSTFIELDS     => json_encode($payload),
            CURLOPT_TIMEOUT        => 60,
            CURLOPT_SSL_VERIFYPEER => true
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode !== 200) jsonError('Gemini API hatası: ' . substr($response, 0, 200));

        $data     = json_decode($response, true);
        $jsonText = $data['candidates'][0]['content']['parts'][0]['text'] ?? '';

        // JSON temizle
        $jsonText = preg_replace('/^```(json)?\s*\n|```\s*$/im', '', trim($jsonText));
        $chapters = json_decode($jsonText, true);

        if (!is_array($chapters) || empty($chapters)) {
            jsonError('AI geçerli bölüm listesi üretemedi');
        }

        // Mevcut bölümleri sil
        $db->delete('chapters', 'video_id=eq.' . $videoId, true);

        // Yenilerini ekle
        $inserted = [];
        foreach ($chapters as $ch) {
            if (empty($ch['title'])) continue;
            $res = $db->insert('chapters', [
                'video_id'   => $videoId,
                'title'      => substr($ch['title'], 0, 100),
                'start_time' => (int)($ch['start_time'] ?? 0)
            ], true);
            if (!empty($res['data'])) $inserted[] = $res['data'][0] ?? $res['data'];
        }

        jsonSuccess($inserted, count($inserted) . ' bölüm oluşturuldu');
    }

    // Elle bölüm ekle
    $title     = trim($input['title'] ?? '');
    $startTime = (int)($input['start_time'] ?? 0);
    if (!$title) jsonError('Bölüm başlığı gerekli');

    $res = $db->insert('chapters', [
        'video_id'   => $videoId,
        'title'      => $title,
        'start_time' => $startTime
    ], true);

    jsonSuccess($res['data'][0] ?? $res['data'], 'Bölüm eklendi');
}

// PUT: Bölüm güncelle
if ($method === 'PUT' || $method === 'PATCH') {
    $id        = $_GET['id'] ?? '';
    $title     = trim($input['title'] ?? '');
    $startTime = (int)($input['start_time'] ?? 0);
    if (!$id)    jsonError('Chapter ID gerekli');
    if (!$title) jsonError('Bölüm başlığı gerekli');

    $res = $db->update('chapters', ['title' => $title, 'start_time' => $startTime], 'id=eq.' . $id, true);
    jsonSuccess($res['data'] ?? [], 'Bölüm güncellendi');
}

jsonError('Geçersiz metod', 405);
