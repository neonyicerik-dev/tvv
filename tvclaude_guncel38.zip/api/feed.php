<?php
// GET ?page=1 -> abone olunan kanalların yeni videoları
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/user_auth.php';
error_reporting(0); ini_set('display_errors', 0);

$db = new Supabase();
$user = requireUserApi($db);
$subs = $db->select('subscriptions', 'user_id=eq.' . $user['id'] . '&select=channel_id&limit=500', true)['data'] ?? [];
$ids = array_values(array_filter(array_column($subs, 'channel_id'), 'isUuid'));
if (!$ids) jsonSuccess(['items' => [], 'channels' => 0, 'has_more' => false]);

$per = 24; $page = max(1, (int)($_GET['page'] ?? 1));
$r = $db->select('videos', 'status=eq.published&channel_id=in.(' . implode(',', $ids) . ')&order=created_at.desc&limit=' . ($per + 1) . '&offset=' . (($page - 1) * $per)
    . '&select=id,title,thumbnail_url,duration,views,created_at,channels(id,name)', true)['data'] ?? [];
$more = count($r) > $per;
jsonSuccess(['items' => array_slice($r, 0, $per), 'channels' => count($ids), 'has_more' => $more]);
