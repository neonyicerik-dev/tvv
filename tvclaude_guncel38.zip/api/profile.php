<?php
// POST {bio} -> kısa biyografiyi kaydet (en fazla 300 karakter)
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/user_auth.php';
error_reporting(0); ini_set('display_errors', 0);

$db = new Supabase();
$user = requireUserApi($db);
$uid = $user['id'];
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $p = $db->first('profiles', 'id=eq.' . $uid . '&select=bio,cover_url', true);
    jsonSuccess(['bio' => $p['bio'] ?? '', 'cover_url' => $p['cover_url'] ?? '']);
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $in = inputJson() ?? [];
    $bio = mb_substr(trim((string)($in['bio'] ?? '')), 0, 300);
    $r = $db->update('profiles', ['bio' => $bio], 'id=eq.' . $uid, true);
    if ($r['status'] >= 400) jsonError('Kaydedilemedi (SQL güncellemesi çalıştırıldı mı?)', 500);
    jsonSuccess(['bio' => $bio]);
}
jsonError('Geçersiz metod', 405);
