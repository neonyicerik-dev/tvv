<?php
// GET -> son 30 bildirim + okunmamış sayısı | POST {action:'read_all'}
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/user_auth.php';
error_reporting(0); ini_set('display_errors', 0);

$db = new Supabase();
$user = requireUserApi($db);
$uid = $user['id'];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db->update('notifications', ['is_read' => true], 'user_id=eq.' . $uid . '&is_read=eq.false', true);
    jsonSuccess([]);
}
$items  = $db->select('notifications', 'user_id=eq.' . $uid . '&order=created_at.desc&limit=30', true)['data'] ?? [];
$unread = 0; foreach ($items as $i) if (!$i['is_read']) $unread++;
jsonSuccess(['items' => $items, 'unread' => $unread]);
