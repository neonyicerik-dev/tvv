<?php
// Web push
// GET  ?action=key                    -> {key}
// POST {action:'subscribe', endpoint} -> giriş gerekli
// POST {action:'unsubscribe', endpoint}
// POST ?action=latest {endpoint}      -> service worker için son bildirim metni (uç adresi gizli bilgi sayılır)
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/user_auth.php';
error_reporting(0); ini_set('display_errors', 0);

$db = new Supabase();
$action = $_GET['action'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'key') {
    $k = nvVapidPublic(); if (!$k) jsonError('Push yapılandırılamadı', 500);
    jsonSuccess(['key' => $k]);
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonError('Geçersiz istek', 405);
$in = inputJson() ?? [];
$action = $action ?: (string)($in['action'] ?? '');
$endpoint = (string)($in['endpoint'] ?? '');
if (!nvPushEndpointOk($endpoint)) jsonError('Geçersiz uç adresi');

if ($action === 'latest') {
    $sub = $db->first('push_subscriptions', 'endpoint=eq.' . rawurlencode($endpoint) . '&select=user_id', true);
    $out = ['title' => 'NeonTV', 'body' => 'Yeni bildirimin var.', 'url' => APP_URL . '/notifications.php'];
    if ($sub) {
        $n = $db->first('notifications', 'user_id=eq.' . $sub['user_id'] . '&is_read=eq.false&order=created_at.desc&select=message,link,created_at&limit=1', true);
        if ($n && strtotime($n['created_at']) > time() - 900) {
            $out['body'] = mb_substr((string)$n['message'], 0, 140);
            if (!empty($n['link']) && str_starts_with($n['link'], '/')) $out['url'] = APP_URL . $n['link'];
        }
    }
    jsonSuccess($out);
}

$user = requireUserApi($db); $uid = $user['id'];
if ($action === 'subscribe') {
    if ($db->count('push_subscriptions', 'user_id=eq.' . $uid, true) >= 5) jsonError('En fazla 5 cihaz');
    $db->delete('push_subscriptions', 'endpoint=eq.' . rawurlencode($endpoint), true);
    $r = $db->insert('push_subscriptions', ['user_id' => $uid, 'endpoint' => $endpoint], true);
    if (($r['status'] ?? 500) >= 400) jsonError('Kaydedilemedi', 500);
    jsonSuccess(['subscribed' => true]);
}
if ($action === 'unsubscribe') {
    $db->delete('push_subscriptions', 'user_id=eq.' . $uid . '&endpoint=eq.' . rawurlencode($endpoint), true);
    jsonSuccess(['subscribed' => false]);
}
jsonError('Bilinmeyen işlem');
