<?php
// Admin: yorum sabitle / kaldır. POST {comment_id, pinned:bool, csrf_token}
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
error_reporting(0); ini_set('display_errors', 0);
requireAdmin(['moderator', 'editor']);
if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonError('Geçersiz istek', 405);
$in = inputJson() ?? [];
if (!verifyCsrfToken((string)($in['csrf_token'] ?? ''))) jsonError('Güvenlik doğrulaması başarısız', 403);
$cid = trim($in['comment_id'] ?? ''); requireUuid($cid, 'Yorum ID');
$db = new Supabase();
$c = $db->first('comments', 'id=eq.' . $cid . '&select=id,video_id,parent_id', true);
if (!$c) jsonError('Yorum bulunamadı', 404);
if (!empty($c['parent_id'])) jsonError('Yalnızca ana yorumlar sabitlenebilir');
$pin = !empty($in['pinned']);
if ($pin) $db->update('comments', ['is_pinned' => false], 'video_id=eq.' . $c['video_id'] . '&is_pinned=eq.true', true); // videoda tek sabit yorum
$r = $db->update('comments', ['is_pinned' => $pin], 'id=eq.' . $cid, true);
if (($r['status'] ?? 500) >= 400) jsonError('Kaydedilemedi (SQL çalıştırıldı mı?)', 500);
jsonSuccess(['pinned' => $pin]);
