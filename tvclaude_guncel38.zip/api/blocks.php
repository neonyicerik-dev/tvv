<?php
// Engellenenler
// GET           -> {channels:[{id,name}], users:[{id,username}]}
// POST {kind:'channel'|'user', target_id, block:true|false}
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
require_once __DIR__ . '/../includes/user_auth.php';
error_reporting(0); ini_set('display_errors', 0);

$db = new Supabase();
$user = requireUserApi($db);
$uid = $user['id'];

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $rows = $db->select('user_blocks', 'user_id=eq.' . $uid . '&select=kind,target_id&limit=1000', true)['data'] ?? [];
    $cid = []; $uids = [];
    foreach ($rows as $r) { if ($r['kind'] === 'channel') $cid[] = $r['target_id']; else $uids[] = $r['target_id']; }
    $cid = array_values(array_filter($cid, 'isUuid')); $uids = array_values(array_filter($uids, 'isUuid'));
    $ch = $cid ? ($db->select('channels', 'id=in.(' . implode(',', $cid) . ')&select=id,name', true)['data'] ?? []) : [];
    $us = $uids ? ($db->select('profiles', 'id=in.(' . implode(',', $uids) . ')&select=id,username', true)['data'] ?? []) : [];
    // profili silinmiş kullanıcılar da listede kalsın
    $known = array_column($us, 'id');
    foreach ($uids as $u) if (!in_array($u, $known, true)) $us[] = ['id' => $u, 'username' => 'Kullanıcı'];
    $knownC = array_column($ch, 'id');
    foreach ($cid as $c) if (!in_array($c, $knownC, true)) $ch[] = ['id' => $c, 'name' => 'Kanal'];
    jsonSuccess(['channels' => $ch, 'users' => $us]);
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $in = inputJson() ?? [];
    $kind = ($in['kind'] ?? '') === 'user' ? 'user' : (($in['kind'] ?? '') === 'channel' ? 'channel' : '');
    if (!$kind) jsonError('Geçersiz tür');
    $tid = trim($in['target_id'] ?? ''); requireUuid($tid, 'Hedef ID');
    if ($kind === 'user' && $tid === $uid) jsonError('Kendini engelleyemezsin');
    $q = 'user_id=eq.' . $uid . '&kind=eq.' . $kind . '&target_id=eq.' . $tid;
    $want = array_key_exists('block', $in) ? !empty($in['block']) : null;
    $ex = $db->first('user_blocks', $q . '&select=target_id', true);
    if ($want === null) $want = !$ex;
    if ($want && !$ex) {
        if ($db->count('user_blocks', 'user_id=eq.' . $uid, true) >= 500) jsonError('Engel listesi dolu');
        $db->insert('user_blocks', ['user_id' => $uid, 'kind' => $kind, 'target_id' => $tid], true);
    } elseif (!$want && $ex) {
        $db->delete('user_blocks', $q, true);
    }
    jsonSuccess(['blocked' => $want]);
}
jsonError('Geçersiz metod', 405);
