<?php
// ============================================================
// NeonTV - İzleyici ısı çizgisi
// GET  ?video_id=..            -> {buckets:[100 adet 0..1], total}
// POST {video_id, hits:[100]}  -> kovalara ekle (anonim, sınırlı)
// ============================================================
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/supabase.php';
error_reporting(0); ini_set('display_errors', 0);

$db = new Supabase();
$m  = $_SERVER['REQUEST_METHOD'];

if ($m === 'GET') {
    $vid = trim($_GET['video_id'] ?? '');
    requireUuid($vid, 'Video ID');
    $r = $db->select('video_replay_heat', 'video_id=eq.' . $vid . '&select=bucket,hits&limit=100', true);
    $b = array_fill(0, 100, 0);
    foreach (($r['data'] ?? []) as $row) { $i = (int)$row['bucket']; if ($i >= 0 && $i < 100) $b[$i] = (int)$row['hits']; }
    $first = $b[0]; $max = max($b);
    header('Cache-Control: public, max-age=300');
    if ($first < 10 || $max <= 0) jsonSuccess(['buckets' => [], 'total' => $first]);
    jsonSuccess(['buckets' => array_map(fn($h) => round($h / $max, 3), $b), 'total' => $first]);
}

if ($m === 'POST') {
    $in  = inputJson() ?? [];
    $vid = trim($in['video_id'] ?? '');
    requireUuid($vid, 'Video ID');
    $hits = is_array($in['hits'] ?? null) ? array_slice(array_map(fn($x) => max(0, min(3, (int)$x)), $in['hits']), 0, 100) : [];
    if (!$hits || array_sum($hits) > 300) jsonError('Geçersiz veri', 400);
    // Basit sınır: aynı IP + video için 10 sn'de bir (oturum açmadan, geçici dosya ile)
    $lk = sys_get_temp_dir() . '/nv_hm_' . md5(($_SERVER['REMOTE_ADDR'] ?? '') . $vid);
    if (is_file($lk) && time() - filemtime($lk) < 10) jsonSuccess([], 'Atlandı');
    @touch($lk);
    $ex = $db->first('videos', 'id=eq.' . $vid . '&status=eq.published&select=id', true);
    if (!$ex) jsonError('Video yok', 404);
    $db->rpc('add_replay_hits', ['p_video' => $vid, 'p_hits' => array_values($hits)], true);
    jsonSuccess([], 'Kaydedildi');
}
jsonError('Geçersiz metod', 405);
