/* ============================================================
   NeonTV - Video Player JS (player.js) - Enhanced v3
   Özellikler:
   - #3  Klavye kısayol rehberi (? tuşu)
   - #5  Devam et (localStorage resume)
   - #7  Hız hatırlama (localStorage speed)
   - #13 Mini Player / PiP (IntersectionObserver + Native PiP API)
   - #14 Loop modu butonu
   - TAP  Mobil dokunma ile kontroller gizle/göster
============================================================ */

document.addEventListener('DOMContentLoaded', () => {
    const video = document.getElementById('main-video');
    if (!video) return;

    const playerContainer = document.getElementById('player-container');
    const playBtn         = document.getElementById('play-pause-btn');
    const playIcon        = document.getElementById('play-icon');
    const bigPlayBtn      = document.getElementById('big-play-btn');
    const bigPlayIcon     = document.getElementById('big-play-icon');
    const muteBtn         = document.getElementById('mute-btn');
    const volumeIcon      = document.getElementById('volume-icon');
    const volumeSlider    = document.getElementById('volume-slider');
    const currentTimeEl   = document.getElementById('current-time');
    const totalTimeEl     = document.getElementById('total-time');
    const progressContainer = document.getElementById('progress-container');
    const progressBar       = document.getElementById('progress-bar');
    const progressBuffered  = document.getElementById('progress-buffered');
    const progressThumb     = document.getElementById('progress-thumb');
    const timeTooltip       = document.getElementById('time-tooltip');
    const fullscreenBtn     = document.getElementById('fullscreen-btn');
    const fullscreenIcon    = document.getElementById('fullscreen-icon');
    const theaterBtn        = document.getElementById('theater-btn');
    const skipBackBtn       = document.getElementById('skip-back-btn');
    const skipFwdBtn        = document.getElementById('skip-fwd-btn');
    const speedBtn          = document.getElementById('speed-btn');
    const subtitleBtn       = document.getElementById('subtitle-btn');
    const loopBtn           = document.getElementById('loop-btn');
    const videoControls     = document.getElementById('video-controls');

    let hideControlsTimer = null;
    let mobileInactivityTimer = null;
    let isDragging        = false;
    let theaterMode       = false;
    let currentSpeed      = 1;
    let touchStartX       = 0;
    let touchStartY       = 0;
    let touchStartTime    = 0;
    let pipActive         = false;
    let resumeSaveTimer   = null;

    const VIDEO_STORAGE_KEY = 'neontv_resume_' + (typeof VIDEO_ID !== 'undefined' ? VIDEO_ID : 'unknown');
    const SPEED_STORAGE_KEY = 'neontv_speed';
    const LOOP_STORAGE_KEY  = 'neontv_loop';

    // --------------------------------------------------------
    // Ayarlar menüsü (liquid glass) + indirmeden önce onay
    // --------------------------------------------------------
    const settingsBtn   = document.getElementById('settings-btn');
    const settingsPanel = document.getElementById('settings-panel');
    const settingsOpen  = () => !!(settingsPanel && settingsPanel.classList.contains('open'));
    function setSettings(open) {
        if (!settingsPanel) return;
        settingsPanel.classList.toggle('open', open);
        settingsBtn?.setAttribute('aria-expanded', open ? 'true' : 'false');
        if (open) { playerContainer.classList.add('controls-visible'); clearTimeout(hideControlsTimer); clearTimeout(mobileInactivityTimer); }
        else { document.getElementById('chapters-panel')?.classList.add('hidden'); }
    }
    settingsBtn?.addEventListener('click', (e) => { e.stopPropagation(); setSettings(!settingsOpen()); });
    document.addEventListener('click', (e) => {
        if (!settingsOpen()) return;
        if (e.target.closest('#settings-panel, #settings-btn, #chapters-panel, .sub-style-menu')) return;
        setSettings(false);
    });
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && settingsOpen()) setSettings(false); });

    const DL_KEY = 'neontv_dlask';
    let dlMode = 'always';
    try { const m = localStorage.getItem(DL_KEY); if (m === 'cellular' || m === 'never' || m === 'always') dlMode = m; } catch (e) {}
    let consented = false;
    function paintDl() { document.querySelectorAll('#dl-ask button').forEach(b => b.classList.toggle('active', b.dataset.m === dlMode)); }
    function setDlMode(m) { dlMode = m; try { localStorage.setItem(DL_KEY, m); } catch (e) {} paintDl(); }
    document.getElementById('dl-ask')?.addEventListener('click', (e) => { const b = e.target.closest('button[data-m]'); if (b) setDlMode(b.dataset.m); });
    paintDl();
    function needConsent() {
        if (consented || video.readyState > 0 || !(video.currentSrc || video.querySelector('source'))) return false;
        if (dlMode === 'never') return false;
        if (dlMode === 'cellular') {
            const c = navigator.connection || {};
            return !!(c.saveData || c.type === 'cellular' || /(^|-)(slow-2g|2g|3g)$/.test(c.effectiveType || ''));
        }
        return true;
    }
    if (dlMode === 'never' && video.preload === 'none') { consented = true; video.preload = 'metadata'; try { video.load(); } catch (e) {} }
    const nativePlay = video.play.bind(video);
    function showConsent() {
        if (document.getElementById('dl-consent')) return;
        const o = document.createElement('div'); o.id = 'dl-consent';
        o.innerHTML = '<div class="glass-card" role="dialog" aria-modal="true"><i class="fa-solid fa-cloud-arrow-down" style="font-size:26px;color:#7df9ff"></i><h3>Video indirilsin mi?</h3>' +
            '<p>Video, oynatmak için internet kotanı kullanır. İndirmeye başlayalım mı?<br><small style="color:#9ca3af">Video cihazında saklanmaz; yalnızca izlerken geçici olarak yüklenir, kapatınca silinir.</small></p>' +
            '<button type="button" class="dl-ok">İndir ve oynat</button><button type="button" class="dl-no">Vazgeç</button>' +
            '<label><input type="checkbox" class="dl-never"> Bir daha sorma</label></div>';
        o.addEventListener('click', e => e.stopPropagation());
        o.querySelector('.dl-ok').onclick = () => {
            if (o.querySelector('.dl-never').checked) setDlMode('never');
            consented = true; video.preload = "auto"; o.remove(); try { if (video.readyState === 0) video.load(); } catch (e) {} nativePlay().catch(() => {});
        };
        o.querySelector('.dl-no').onclick = () => o.remove();
        playerContainer.appendChild(o);
        o.querySelector('.dl-ok').focus();
    }
    video.play = function () {
        if (needConsent()) { showConsent(); return Promise.resolve(); }
        return nativePlay();
    };

    // --------------------------------------------------------
    // #7 Hız Hatırlama
    // --------------------------------------------------------
    const savedSpeed = parseFloat(localStorage.getItem(SPEED_STORAGE_KEY) || '1');
    if (savedSpeed && savedSpeed !== 1) {
        video.playbackRate = savedSpeed;
        currentSpeed = savedSpeed;
        if (speedBtn) speedBtn.textContent = savedSpeed + '×';
    }

    // Ses seviyesi / sessiz hatırlama
    const VOL_KEY = 'neontv_volume', MUTE_KEY = 'neontv_muted';
    try {
        const sv = parseFloat(localStorage.getItem(VOL_KEY));
        if (!isNaN(sv) && sv >= 0 && sv <= 1) { video.volume = sv; if (volumeSlider) volumeSlider.value = sv; }
        if (localStorage.getItem(MUTE_KEY) === '1') { video.muted = true; if (volumeSlider) volumeSlider.value = 0; }
    } catch (e) {}
    video.addEventListener('volumechange', () => {
        try { localStorage.setItem(VOL_KEY, String(video.volume)); localStorage.setItem(MUTE_KEY, video.muted ? '1' : '0'); } catch (e) {}
    });

    // --------------------------------------------------------
    // #14 Loop Modu - Başlangıç durumu
    // --------------------------------------------------------
    const savedLoop = localStorage.getItem(LOOP_STORAGE_KEY) === 'true';
    if (savedLoop) {
        video.loop = true;
        loopBtn?.classList.add('active');
    }
    loopBtn?.addEventListener('click', () => {
        video.loop = !video.loop;
        loopBtn.classList.toggle('active', video.loop);
        localStorage.setItem(LOOP_STORAGE_KEY, video.loop);
    });

    // --------------------------------------------------------
    // Controls Show / Hide
    // --------------------------------------------------------
    function showControls() {
        playerContainer.classList.add('controls-visible');
        clearTimeout(hideControlsTimer);
        clearTimeout(mobileInactivityTimer);
        hideControlsTimer = setTimeout(() => {
            if (!video.paused && !settingsOpen()) playerContainer.classList.remove('controls-visible');
        }, 3000);
    }

    function hideControls() {
        if (!video.paused && !settingsOpen()) {
            clearTimeout(hideControlsTimer);
            clearTimeout(mobileInactivityTimer);
            playerContainer.classList.remove('controls-visible');
        }
    }

    // Mobil: herhangi bir dokunma aktivitesinde otomatik gizleme zamanlayıcısını yeniden başlat
    function resetMobileInactivityTimer() {
        clearTimeout(mobileInactivityTimer);
        if (!video.paused && playerContainer.classList.contains('controls-visible')) {
            mobileInactivityTimer = setTimeout(() => {
                if (!settingsOpen()) playerContainer.classList.remove('controls-visible');
            }, 3500);
        }
    }

    playerContainer.addEventListener('mousemove', showControls);
    playerContainer.addEventListener('mouseleave', () => {
        if (!video.paused) {
            hideControlsTimer = setTimeout(() => {
                if (!settingsOpen()) playerContainer.classList.remove('controls-visible');
            }, 1000);
        }
    });

    // --------------------------------------------------------
    // MOBIL: Dokunma ile kontrol gizle / göster (Tap-to-Toggle)
    // Ekrana dokunmadan birkaç saniye beklenirse kontroller gizlenir
    // Tekrar dokunulduğunda tekrar görünür
    // --------------------------------------------------------
    let controlsVisible = false;

    playerContainer.addEventListener('touchstart', (e) => {
        touchStartX    = e.touches[0].clientX;
        touchStartY    = e.touches[0].clientY;
        touchStartTime = Date.now();
        // Her dokunmada inaktivite zamanlayıcısını sıfırla
        resetMobileInactivityTimer();
    }, { passive: true });

    playerContainer.addEventListener('touchend', (e) => {
        const dx       = Math.abs(e.changedTouches[0].clientX - touchStartX);
        const dy       = Math.abs(e.changedTouches[0].clientY - touchStartY);
        const elapsed  = Date.now() - touchStartTime;

        // Swipe değil, gerçek tap ise (hareket < 10px, süre < 300ms)
        if (dx < 10 && dy < 10 && elapsed < 300) {
            const controls = videoControls;
            const isOnControls = controls && controls.contains(e.target);
            const isOnBigPlay  = bigPlayBtn && bigPlayBtn.contains(e.target);

            if (!isOnControls && !isOnBigPlay) {
                if (playerContainer.classList.contains('controls-visible')) {
                    // Kontroller görünür → gizle (sadece oynatılırken)
                    if (!video.paused) {
                        hideControls();
                    }
                } else {
                    // Kontroller gizli → göster + otomatik gizle zamanlayıcı başlat
                    showControls();
                    resetMobileInactivityTimer();
                }
            }
        }
    }, { passive: true });

    // Kontrol butonlarına dokunulduğunda da inaktivite zamanlayıcısını sıfırla
    videoControls?.addEventListener('touchstart', () => {
        resetMobileInactivityTimer();
    }, { passive: true });

    video.addEventListener('pause', () => {
        playerContainer.classList.add('controls-visible');
        clearTimeout(hideControlsTimer);
        clearTimeout(mobileInactivityTimer);
    });
    video.addEventListener('play', () => { showControls(); resetMobileInactivityTimer(); });

    // --------------------------------------------------------
    // Play / Pause
    // --------------------------------------------------------
    function togglePlay() {
        if (video.paused) { video.play(); } else { video.pause(); }
    }

    playBtn?.addEventListener('click', togglePlay);

    if (bigPlayBtn) {
        bigPlayBtn.addEventListener('click', (e) => { e.stopPropagation(); togglePlay(); });
    }

    // Ekrana tıklayınca kontrol gizle/göster (desktop)
    function handleScreenClick(e) {
        const controls       = videoControls;
        const autoplayOverlay = document.getElementById('autoplay-overlay');
        if (!controls?.contains(e.target) && !autoplayOverlay?.contains(e.target) && e.target !== bigPlayBtn && !bigPlayBtn?.contains(e.target)) {
            if (playerContainer.classList.contains('controls-visible')) { hideControls(); }
            else { showControls(); }
        }
    }

    video.addEventListener('click', handleScreenClick);
    playerContainer.addEventListener('click', (e) => { if (e.target !== video) handleScreenClick(e); });

    video.addEventListener('play', () => {
        if (playIcon) playIcon.className = 'fa-solid fa-pause';
        if (bigPlayBtn) { bigPlayBtn.style.opacity = '0'; bigPlayBtn.style.pointerEvents = 'none'; }
    });
    video.addEventListener('pause', () => {
        if (playIcon) playIcon.className = 'fa-solid fa-play';
        if (bigPlayBtn) { bigPlayBtn.style.opacity = '1'; bigPlayBtn.style.pointerEvents = 'auto'; }
    });

    // Ekrana çift tıklayınca tam ekran yap (kontrol barı ve butonların dışında)
    playerContainer.addEventListener('dblclick', (e) => {
        // Kontrol barı, skip butonları veya diğer UI elemanları üzerindeyse fullscreen tetikleme
        const controls       = videoControls;
        const autoplayOverlay = document.getElementById('autoplay-overlay');
        const isOnControls   = controls && controls.contains(e.target);
        const isOnBigPlay    = bigPlayBtn && bigPlayBtn.contains(e.target);
        const isOnOverlay    = autoplayOverlay && autoplayOverlay.contains(e.target);
        if (!isOnControls && !isOnBigPlay && !isOnOverlay) {
            toggleFullscreen();
        }
    });

    // Giriş atla: admin videoya intro_end (sn) girdiyse, giriş bitene kadar buton görünür
    (function () {
        const end = (typeof INTRO_END !== 'undefined') ? INTRO_END : 0;
        if (!end || end < 5) return;
        const b = document.createElement('button');
        b.type = 'button'; b.textContent = 'Girişi atla ›';
        b.style.cssText = 'display:none;position:absolute;right:14px;bottom:76px;z-index:55;padding:8px 14px;border-radius:8px;background:rgba(0,0,0,.72);border:1px solid rgba(255,255,255,.5);color:#fff;font-size:13px;font-weight:700;cursor:pointer';
        b.addEventListener('click', e => { e.stopPropagation(); video.currentTime = end; b.style.display = 'none'; });
        b.addEventListener('dblclick', e => e.stopPropagation());
        playerContainer.appendChild(b);
        video.addEventListener('timeupdate', () => { b.style.display = (video.currentTime >= 1 && video.currentTime < end - 1) ? 'block' : 'none'; });
    })();

    // Dokunmatik çift dokunuş: sol/sağ üçte birlik alan ∓10 sn (orta alan etkilenmez)
    (function () {
        let lastT = 0, lastX = 0;
        playerContainer.addEventListener('touchend', (e) => {
            if (e.changedTouches.length !== 1 || e.target.closest('button, input, a, #video-controls, #autoplay-overlay')) return;
            const t = e.changedTouches[0], r = playerContainer.getBoundingClientRect(), x = (t.clientX - r.left) / r.width, now = Date.now();
            if (now - lastT < 320 && Math.abs(t.clientX - lastX) < 60 && (x < 0.33 || x > 0.67)) {
                skipTime(x > 0.5 ? 10 : -10); lastT = 0; e.preventDefault(); // eşlik eden dblclick (tam ekran) tetiklenmesin
            } else { lastT = now; lastX = t.clientX; }
        }, { passive: false });
    })();

    // --------------------------------------------------------
    // Skip (10s)
    // --------------------------------------------------------
    function skipTime(seconds) {
        video.currentTime = Math.max(0, Math.min(video.duration || 0, video.currentTime + seconds));
        showSkipRipple(seconds > 0);
    }

    function showSkipRipple(forward) {
        const ripple = document.createElement('div');
        ripple.className = 'skip-ripple';
        ripple.style.left = forward ? '65%' : '35%';
        playerContainer.appendChild(ripple);
        setTimeout(() => ripple.remove(), 650);
    }

    skipBackBtn?.addEventListener('click', () => skipTime(-10));
    skipFwdBtn?.addEventListener('click',  () => skipTime(10));

    // --------------------------------------------------------
    // Time Formatting
    // --------------------------------------------------------
    function formatTime(s) {
        if (isNaN(s) || s < 0) return '0:00';
        const h   = Math.floor(s / 3600);
        const m   = Math.floor((s % 3600) / 60);
        const sec = Math.floor(s % 60);
        if (h > 0) return `${h}:${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}`;
        return `${m}:${String(sec).padStart(2, '0')}`;
    }

    const updateTotal = () => {
        if (totalTimeEl && isFinite(video.duration) && video.duration > 0) totalTimeEl.textContent = formatTime(video.duration);
    };
    video.addEventListener('loadedmetadata', updateTotal);
    video.addEventListener('durationchange', updateTotal);
    updateTotal();

    // --------------------------------------------------------
    // Progress Bar
    // --------------------------------------------------------
    video.addEventListener('timeupdate', () => {
        if (isDragging) return;
        const pct = video.duration ? (video.currentTime / video.duration) * 100 : 0;
        if (progressBar)    progressBar.style.width    = `${pct}%`;
        if (progressThumb)  progressThumb.style.left   = `${pct}%`;
        if (currentTimeEl)  currentTimeEl.textContent  = formatTime(video.currentTime);

        if (video.buffered.length > 0 && video.duration) {
            const bEnd = video.buffered.end(video.buffered.length - 1);
            if (progressBuffered) progressBuffered.style.width = `${(bEnd / video.duration) * 100}%`;
        }

        updateChapterDisplay();
    });

    function seekTo(e) {
        if (!video.duration) return;
        const rect = progressContainer.getBoundingClientRect();
        const pos  = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
        video.currentTime = pos * video.duration;
        if (progressBar)   progressBar.style.width  = `${pos * 100}%`;
        if (progressThumb) progressThumb.style.left = `${pos * 100}%`;
    }

    progressContainer?.addEventListener('mousedown', (e) => { isDragging = true; seekTo(e); });
    document.addEventListener('mousemove', (e) => { if (!isDragging) return; seekTo(e); });
    document.addEventListener('mouseup', () => { isDragging = false; });

    // #10 Seekbar önizleme (küçük gizli video ile) + #15 bölüm başlığı
    let pvVideo = null, pvTimeEl = null, pvChEl = null, pvLastSeek = 0, pvReady = false;
    function initPreview() {
        if (pvVideo || !timeTooltip || !(consented || video.readyState > 0)) return;
        timeTooltip.innerHTML = '';
        timeTooltip.style.padding = '4px';
        timeTooltip.style.textAlign = 'center';
        pvVideo = document.createElement('video');
        pvVideo.muted = true; pvVideo.preload = 'metadata'; pvVideo.playsInline = true;
        pvVideo.style.cssText = 'display:none;width:160px;height:90px;object-fit:cover;border-radius:4px;background:#000;margin-bottom:3px;';
        pvVideo.addEventListener('loadeddata', () => { pvReady = true; pvVideo.style.display = 'block'; });
        pvVideo.addEventListener('error', () => { pvVideo.style.display = 'none'; pvReady = false; });
        pvChEl = document.createElement('div');
        pvChEl.style.cssText = 'font-size:10px;color:#00f5ff;max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;display:none;';
        pvTimeEl = document.createElement('div');
        timeTooltip.appendChild(pvVideo); timeTooltip.appendChild(pvChEl); timeTooltip.appendChild(pvTimeEl);
        const src = video.currentSrc || (video.querySelector('source') || {}).src;
        if (src) pvVideo.src = src;
    }
    function chapterAt(t) {
        const list = window._chapters || []; let cur = null;
        for (const c of list) { if (c.start_time <= t) cur = c; else break; }
        return cur;
    }
    progressContainer?.addEventListener('mousemove', (e) => {
        if (!video.duration) return;
        const rect = progressContainer.getBoundingClientRect();
        const pos  = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
        const t = pos * video.duration;
        if (timeTooltip) {
            initPreview();
            timeTooltip.style.display   = 'block';
            if (pvTimeEl) pvTimeEl.textContent = formatTime(t); else timeTooltip.textContent = formatTime(t);
            if (pvChEl) { const c = chapterAt(t); pvChEl.textContent = c ? c.title : ''; pvChEl.style.display = c ? 'block' : 'none'; }
            const half = 85;
            const left = Math.max(half, Math.min(rect.width - half, pos * rect.width));
            timeTooltip.style.left      = `${left}px`;
            timeTooltip.style.transform = 'translateX(-50%)';
            const now = Date.now();
            if (pvVideo && now - pvLastSeek > 120) { pvLastSeek = now; try { pvVideo.currentTime = t; } catch (err) {} }
        }
    });
    progressContainer?.addEventListener('mouseleave', () => {
        if (timeTooltip) timeTooltip.style.display = 'none';
    });

    // Touch seek
    progressContainer?.addEventListener('touchstart', (e) => { isDragging = true; e.stopPropagation(); const t = e.touches[0]; seekTo({ clientX: t.clientX }); }, { passive: true });
    progressContainer?.addEventListener('touchmove',  (e) => {
        if (!isDragging) return; const t = e.touches[0]; seekTo({ clientX: t.clientX });
        if (timeTooltip && video.duration) {
            const rect = progressContainer.getBoundingClientRect();
            const pos = Math.max(0, Math.min(1, (t.clientX - rect.left) / rect.width)), tm = pos * video.duration;
            initPreview(); timeTooltip.style.display = 'block';
            if (pvTimeEl) pvTimeEl.textContent = formatTime(tm);
            if (pvChEl) { const c = chapterAt(tm); pvChEl.textContent = c ? c.title : ''; pvChEl.style.display = c ? 'block' : 'none'; }
            timeTooltip.style.left = Math.max(85, Math.min(rect.width - 85, pos * rect.width)) + 'px';
            timeTooltip.style.transform = 'translateX(-50%)';
            const now = Date.now(); if (pvVideo && now - pvLastSeek > 150) { pvLastSeek = now; try { pvVideo.currentTime = tm; } catch (err) {} }
        }
    }, { passive: true });
    progressContainer?.addEventListener('touchend', () => { if (timeTooltip) timeTooltip.style.display = 'none'; }, { passive: true });
    progressContainer?.addEventListener('touchend',   () => { isDragging = false; });

    // --------------------------------------------------------
    // Volume
    // --------------------------------------------------------
    function updateVolumeIcon() {
        if (!volumeIcon) return;
        if (video.muted || video.volume === 0) volumeIcon.className = 'fa-solid fa-volume-xmark';
        else if (video.volume < 0.5)           volumeIcon.className = 'fa-solid fa-volume-low';
        else                                   volumeIcon.className = 'fa-solid fa-volume-high';
    }

    muteBtn?.addEventListener('click', () => {
        video.muted = !video.muted;
        if (volumeSlider) volumeSlider.value = video.muted ? 0 : video.volume;
        updateVolumeIcon();
    });

    volumeSlider?.addEventListener('input', (e) => {
        video.volume  = parseFloat(e.target.value);
        video.muted   = parseFloat(e.target.value) === 0;
        updateVolumeIcon();
    });

    // --------------------------------------------------------
    // #7 Playback Speed (with save)
    // --------------------------------------------------------
    window.setSpeed = function(speed) {
        video.playbackRate = speed;
        currentSpeed       = speed;
        if (speedBtn) speedBtn.textContent = speed + '×';
        localStorage.setItem(SPEED_STORAGE_KEY, speed);
        document.querySelectorAll('.speed-opt').forEach(btn => {
            btn.classList.toggle('active', parseFloat(btn.dataset.speed || btn.textContent) === speed);
        });
    };

    // --------------------------------------------------------
    // Fullscreen
    // --------------------------------------------------------
    function toggleFullscreen() {
        if (!document.fullscreenElement) {
            (playerContainer.requestFullscreen || playerContainer.webkitRequestFullscreen || playerContainer.mozRequestFullScreen || playerContainer.msRequestFullscreen)?.call(playerContainer);
        } else {
            (document.exitFullscreen || document.webkitExitFullscreen || document.mozCancelFullScreen || document.msExitFullscreen)?.call(document);
        }
    }

    fullscreenBtn?.addEventListener('click', toggleFullscreen);

    document.addEventListener('fullscreenchange', () => {
        if (fullscreenIcon) {
            fullscreenIcon.className = document.fullscreenElement ? 'fa-solid fa-compress' : 'fa-solid fa-expand';
        }
        // PiP'i kapat
        if (document.fullscreenElement) exitPiP();
        // Mobilde tam ekranda otomatik yatay çevirme (yatay videolar), çıkınca serbest bırak
        try {
            const so = screen.orientation;
            if (document.fullscreenElement) {
                const isMobile = window.matchMedia('(pointer:coarse)').matches;
                const landscapeVid = !video.videoWidth || video.videoWidth >= video.videoHeight;
                if (isMobile && landscapeVid && so && so.lock) so.lock('landscape').catch(() => {});
            } else if (so && so.unlock) { so.unlock(); }
        } catch (e) {}
    });

    // --------------------------------------------------------
    // Mobil tam ekran hareketleri: sol yarı = parlaklık, sağ yarı = ses (dikey sürükle)
    // --------------------------------------------------------
    (function () {
        let g = null, bright = 1, hudT = null;
        const hud = document.createElement('div');
        hud.style.cssText = 'position:absolute;top:18%;left:50%;transform:translateX(-50%);z-index:60;padding:8px 16px;border-radius:999px;background:rgba(0,0,0,0.7);color:#fff;font-size:14px;font-weight:700;display:none;pointer-events:none;white-space:nowrap';
        playerContainer.appendChild(hud);
        const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
        const inFs = () => !!(document.fullscreenElement || document.webkitFullscreenElement);
        playerContainer.addEventListener('touchstart', (e) => {
            g = null;
            if (!inFs() || e.touches.length !== 1) return;
            if (videoControls && videoControls.contains(e.target)) return;
            const t = e.touches[0], r = playerContainer.getBoundingClientRect();
            g = { x: t.clientX, y: t.clientY, side: (t.clientX - r.left) < r.width / 2 ? 'b' : 'v', v0: video.muted ? 0 : video.volume, b0: bright, on: false, h: r.height };
        }, { passive: true });
        playerContainer.addEventListener('touchmove', (e) => {
            if (!g) return;
            const t = e.touches[0], dy = g.y - t.clientY, dx = t.clientX - g.x;
            if (!g.on) { if (Math.abs(dy) > 14 && Math.abs(dy) > Math.abs(dx) * 1.5) g.on = true; else return; }
            e.preventDefault();
            const d = dy / (g.h * 0.7);
            if (g.side === 'v') {
                const v = clamp(g.v0 + d, 0, 1); video.muted = false; video.volume = v;
                hud.innerHTML = '<i class="fa-solid ' + (v === 0 ? 'fa-volume-xmark' : 'fa-volume-high') + '"></i> ' + Math.round(v * 100) + '%';
            } else {
                bright = clamp(g.b0 + d, 0.3, 1.6); video.style.filter = 'brightness(' + bright.toFixed(2) + ')';
                hud.innerHTML = '<i class="fa-solid fa-sun"></i> ' + Math.round(bright * 100) + '%';
            }
            hud.style.display = 'block'; clearTimeout(hudT);
        }, { passive: false });
        const end = () => { g = null; clearTimeout(hudT); hudT = setTimeout(() => { hud.style.display = 'none'; }, 700); };
        playerContainer.addEventListener('touchend', end, { passive: true });
        playerContainer.addEventListener('touchcancel', end, { passive: true });
    })();

    // --------------------------------------------------------
    // Sinema modunda ortam ışığı (videonun ortalama rengi)
    // --------------------------------------------------------
    let ambientTimer = null, ambientBlocked = false;
    const ambCanvas = document.createElement('canvas'); ambCanvas.width = 16; ambCanvas.height = 9;
    const ambCtx = ambCanvas.getContext('2d', { willReadFrequently: true });
    function ambientTick() {
        if (!theaterMode) return;
        let rgb = '191,0,255';
        if (!ambientBlocked && !video.paused && video.readyState >= 2) {
            try {
                ambCtx.drawImage(video, 0, 0, 16, 9);
                const d = ambCtx.getImageData(0, 0, 16, 9).data; let r = 0, gg = 0, b = 0, n = d.length / 4;
                for (let i = 0; i < d.length; i += 4) { r += d[i]; gg += d[i + 1]; b += d[i + 2]; }
                rgb = Math.round(r / n) + ',' + Math.round(gg / n) + ',' + Math.round(b / n);
            } catch (err) { ambientBlocked = true; }   // farklı kaynak (CORS) -> sabit neon ışık
        }
        playerContainer.style.transition = 'box-shadow .8s ease';
        playerContainer.style.boxShadow = '0 0 140px 30px rgba(' + rgb + ',0.38)';
    }
    function setAmbient(on) {
        clearInterval(ambientTimer);
        if (on) { ambientTick(); ambientTimer = setInterval(ambientTick, 700); }
        else playerContainer.style.boxShadow = '';
    }

    // --------------------------------------------------------
    // Theater Mode
    // --------------------------------------------------------
    theaterBtn?.addEventListener('click', () => {
        theaterMode = !theaterMode;
        document.body.classList.toggle('theater-mode', theaterMode);
        theaterBtn.classList.toggle('active', theaterMode);
        const mainCol = document.getElementById('main-col');
        if (mainCol) mainCol.style.maxWidth = theaterMode ? '100%' : '';
        setAmbient(theaterMode);
    });

    // --------------------------------------------------------
    // #12 Chapters - Chapter display
    // --------------------------------------------------------
    window._chapters = [];

    function updateChapterDisplay() {
        if (!window._chapters.length || !video.duration) return;
        const current = video.currentTime;
        let activeChapter = null;
        for (const ch of window._chapters) {
            if (ch.start_time <= current) activeChapter = ch;
            else break;
        }
        const el = document.getElementById('current-chapter-name');
        if (el && activeChapter) {
            el.textContent = activeChapter.title;
            el.parentElement?.classList.remove('hidden');
        } else if (el) {
            el.parentElement?.classList.add('hidden');
        }
    }

    window.seekToChapter = function(seconds) {
        video.currentTime = seconds;
        video.play();
        document.getElementById('chapters-panel')?.classList.add('hidden');
    };

    // --------------------------------------------------------
    // Subtitle Toggle
    // --------------------------------------------------------
    if (subtitleBtn && typeof HAS_SUBTITLE !== 'undefined' && HAS_SUBTITLE) {
        let subtitlesOn = true;
        function enableSubtitles() {
            if (video.textTracks && video.textTracks.length > 0) {
                video.textTracks[0].mode = 'showing';
                subtitleBtn.classList.add('active');
            }
        }
        enableSubtitles();
        video.addEventListener('loadedmetadata', enableSubtitles);

        subtitleBtn.addEventListener('click', () => {
            subtitlesOn = !subtitlesOn;
            if (video.textTracks && video.textTracks.length > 0) {
                video.textTracks[0].mode = subtitlesOn ? 'showing' : 'hidden';
            }
            subtitleBtn.classList.toggle('active', subtitlesOn);
        });

        // #11 Altyazı stil ayarları (boyut / renk / arka plan) — localStorage'da saklanır
        const SUB_KEY = 'neontv_sub_style';
        const defs = { size: 100, color: '#ffffff', bg: 'rgba(0,0,0,0.6)' };
        let st = Object.assign({}, defs);
        try { st = Object.assign(st, JSON.parse(localStorage.getItem(SUB_KEY) || '{}')); } catch (e) {}
        const styleEl = document.createElement('style'); document.head.appendChild(styleEl);
        const okCol = v => /^#[0-9a-fA-F]{6}$/.test(v) || /^rgba\(0,0,0,(0|0\.\d+|1)\)$/.test(v);
        function applySub() {
            if (!okCol(st.color)) st.color = defs.color; if (!okCol(st.bg)) st.bg = defs.bg;
            st.size = Math.max(60, Math.min(220, parseInt(st.size, 10) || 100));
            styleEl.textContent = 'video::cue{color:' + st.color + ';background-color:' + st.bg + ';font-size:' + st.size + '%;}';
        }
        applySub();
        const menu = document.createElement('div');
        menu.className = 'sub-style-menu glass-card';
        menu.style.cssText = 'display:none;position:absolute;right:14px;bottom:88px;z-index:60;width:230px;max-width:calc(100% - 28px);padding:14px;border-radius:20px;color:#fff;font-size:12px;';
        const colors = [['Beyaz','#ffffff'],['Sarı','#ffe600'],['Camgöbeği','#00f5ff'],['Yeşil','#39ff14']];
        const bgs = [['Koyu','rgba(0,0,0,0.6)'],['Tam siyah','rgba(0,0,0,1)'],['Yok','rgba(0,0,0,0)']];
        const row = (label) => { const d = document.createElement('div'); d.style.margin = '6px 0'; const l = document.createElement('div'); l.textContent = label; l.style.cssText = 'color:#9ca3af;margin-bottom:4px'; d.appendChild(l); return d; };
        const chips = (list, key) => { const w = document.createElement('div'); w.style.cssText = 'display:flex;gap:4px;flex-wrap:wrap'; list.forEach(([n, v]) => { const b = document.createElement('button'); b.type = 'button'; b.textContent = n; b.style.cssText = 'padding:3px 8px;border-radius:999px;border:1px solid rgba(255,255,255,.2);background:transparent;color:#fff;font-size:11px;cursor:pointer'; b.onclick = () => { st[key] = v; save(); }; b.dataset.v = v; w.appendChild(b); }); return w; };
        const rs = row('Boyut'); const rng = document.createElement('input'); rng.type = 'range'; rng.min = 60; rng.max = 220; rng.step = 10; rng.style.width = '100%'; rng.oninput = () => { st.size = rng.value; save(); }; rs.appendChild(rng);
        const rc = row('Renk'); const cc = chips(colors, 'color'); rc.appendChild(cc);
        const rb = row('Arka plan'); const bc = chips(bgs, 'bg'); rb.appendChild(bc);
        const rr = document.createElement('button'); rr.type = 'button'; rr.textContent = 'Sıfırla'; rr.style.cssText = 'margin-top:6px;font-size:11px;color:#00f5ff;background:none;border:0;cursor:pointer'; rr.onclick = () => { st = Object.assign({}, defs); save(); };
        menu.append(rs, rc, rb, rr);
        function paintMenu() { rng.value = st.size; cc.querySelectorAll('button').forEach(b => b.style.background = b.dataset.v === st.color ? 'rgba(0,245,255,.25)' : 'transparent'); bc.querySelectorAll('button').forEach(b => b.style.background = b.dataset.v === st.bg ? 'rgba(0,245,255,.25)' : 'transparent'); }
        function save() { applySub(); paintMenu(); try { localStorage.setItem(SUB_KEY, JSON.stringify(st)); } catch (e) {} }
        paintMenu();
        playerContainer.appendChild(menu);
        const gear = document.createElement('button'); gear.type = 'button'; gear.className = 'set-row'; gear.title = 'Altyazı stili';
        gear.innerHTML = '<i class="fa-solid fa-text-height"></i><span>Altyazı stili</span><i class="fa-solid fa-chevron-right sp-chev"></i>';
        gear.onclick = (e) => { e.stopPropagation(); menu.style.display = menu.style.display === 'none' ? 'block' : 'none'; };
        subtitleBtn.after(gear);
        menu.addEventListener('click', e => e.stopPropagation()); menu.addEventListener('touchstart', e => e.stopPropagation(), { passive: true });
        document.addEventListener('click', () => { menu.style.display = 'none'; });
    }

    // --------------------------------------------------------
    // #13 Native Picture-in-Picture (PiP) — Scroll ile açılır
    // Video sayfa görünümünden çıkınca otomatik PiP başlar
    // --------------------------------------------------------
    function canUsePiP() {
        return document.pictureInPictureEnabled && !video.disablePictureInPicture;
    }

    async function enterPiP() {
        if (pipActive || video.paused || document.fullscreenElement) return;
        if (!canUsePiP()) return;
        try {
            await video.requestPictureInPicture();
            pipActive = true;
        } catch (e) {
            // PiP desteklenmiyor veya izin yok — sessizce geç
        }
    }

    async function exitPiP() {
        if (!pipActive) return;
        try {
            if (document.pictureInPictureElement) {
                await document.exitPictureInPicture();
            }
        } catch (e) {}
        pipActive = false;
    }

    // PiP kapanınca senkronize et
    video.addEventListener('leavepictureinpicture', () => {
        pipActive = false;
        // Kullanıcı PiP'i kapattıysa oynatmaya devam et
    });

    // IntersectionObserver ile player görünüm dışına çıkınca PiP aç
    if ('IntersectionObserver' in window) {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (!entry.isIntersecting && !video.paused) {
                    enterPiP();
                } else if (entry.isIntersecting && pipActive) {
                    exitPiP();
                }
            });
        }, { threshold: 0.2 });
        observer.observe(playerContainer);
    }

    // Eski mini-player referansları (varsa temizle)
    window.closeMiniPlayer = function() { exitPiP(); video.pause(); };
    window.goToMainPlayer  = function() { exitPiP(); playerContainer.scrollIntoView({ behavior: 'smooth', block: 'center' }); };

    // --------------------------------------------------------
    // #9 Video Zoom + Pan
    // --------------------------------------------------------
    const zoomBtn       = document.getElementById('zoom-btn');
    const zoomIndicator = document.getElementById('zoom-indicator');
    let zoomLevel    = 1;
    let zoomActive   = false;
    let panX = 0, panY = 0;
    let panStartX = 0, panStartY = 0;
    let isPanning = false;
    let zoomHideTimer = null;

    const ZOOM_LEVELS = [1, 1.5, 2, 2.5, 3];

    function applyZoom() {
        if (zoomLevel === 1) {
            video.style.transform = '';
            video.classList.remove('zoom-active');
            panX = 0; panY = 0;
        } else {
            video.classList.add('zoom-active');
            video.style.transform = `scale(${zoomLevel}) translate(${panX}px,${panY}px)`;
        }
        if (zoomIndicator) {
            zoomIndicator.textContent = zoomLevel.toFixed(1) + '×';
            zoomIndicator.classList.add('visible');
            clearTimeout(zoomHideTimer);
            zoomHideTimer = setTimeout(() => zoomIndicator.classList.remove('visible'), 1500);
        }
        if (zoomBtn) zoomBtn.classList.toggle('active', zoomLevel > 1);
    }

    function cycleZoom() {
        const idx = ZOOM_LEVELS.indexOf(zoomLevel);
        zoomLevel = ZOOM_LEVELS[(idx + 1) % ZOOM_LEVELS.length];
        panX = 0; panY = 0;
        applyZoom();
    }

    zoomBtn?.addEventListener('click', cycleZoom);

    // Mouse wheel zoom
    playerContainer.addEventListener('wheel', (e) => {
        // Büyüteç açık değilken (zoom 1×) kaydırma sayfayı kaydırsın, videoyu büyütmesin
        if (zoomLevel === 1) return;
        e.preventDefault();
        if (e.deltaY < 0) {
            zoomLevel = Math.min(3, zoomLevel + 0.25);
        } else {
            zoomLevel = Math.max(1, zoomLevel - 0.25);
        }
        panX = 0; panY = 0;
        applyZoom();
    }, { passive: false });

    // Pan (drag to move)
    video.addEventListener('mousedown', (e) => {
        if (zoomLevel <= 1) return;
        isPanning = true;
        panStartX = e.clientX - panX * zoomLevel;
        panStartY = e.clientY - panY * zoomLevel;
        video.classList.add('dragging');
    });
    document.addEventListener('mousemove', (e) => {
        if (!isPanning) return;
        panX = (e.clientX - panStartX) / zoomLevel;
        panY = (e.clientY - panStartY) / zoomLevel;
        video.style.transform = `scale(${zoomLevel}) translate(${panX}px,${panY}px)`;
    });
    document.addEventListener('mouseup', () => {
        isPanning = false;
        video.classList.remove('dragging');
    });

    // --------------------------------------------------------
    // #10 Screenshot (Canvas → PNG)
    // --------------------------------------------------------
    const screenshotBtn   = document.getElementById('screenshot-btn');
    const screenshotToast = document.getElementById('screenshot-toast');
    let toastTimer = null;

    function takeScreenshot() {
        try {
            const canvas = document.createElement('canvas');
            canvas.width  = video.videoWidth  || video.offsetWidth;
            canvas.height = video.videoHeight || video.offsetHeight;
            const ctx = canvas.getContext('2d');
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            canvas.toBlob((blob) => {
                if (!blob) return;
                const url  = URL.createObjectURL(blob);
                const a    = document.createElement('a');
                const time = Math.floor(video.currentTime);
                a.href     = url;
                a.download = `neontv_screenshot_${time}s.png`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
                showScreenshotToast();
            }, 'image/png');
        } catch (e) {
            console.warn('Screenshot hatası:', e);
        }
    }

    function showScreenshotToast() {
        if (!screenshotToast) return;
        screenshotToast.classList.add('show');
        clearTimeout(toastTimer);
        toastTimer = setTimeout(() => screenshotToast.classList.remove('show'), 2500);
    }

    screenshotBtn?.addEventListener('click', takeScreenshot);

    // --------------------------------------------------------
    // #3 Shortcut Modal (? tuşu)
    // --------------------------------------------------------

    // Tüm klavye kısayolları (eski + yeni)
    document.addEventListener('keydown', (e) => {
        if (['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement.tagName)) return;

        switch (e.code) {
            case 'Space':
            case 'KeyK':
                e.preventDefault();
                togglePlay();
                break;
            case 'KeyF':
                e.preventDefault();
                toggleFullscreen();
                break;
            case 'KeyM':
                e.preventDefault();
                muteBtn?.click();
                break;
            case 'KeyL':
                e.preventDefault();
                loopBtn?.click();
                break;
            case 'ArrowRight':
                e.preventDefault();
                skipTime(e.shiftKey ? 30 : 5);
                break;
            case 'ArrowLeft':
                e.preventDefault();
                skipTime(e.shiftKey ? -30 : -5);
                break;
            case 'ArrowUp':
                e.preventDefault();
                video.volume = Math.min(1, video.volume + 0.1);
                if (volumeSlider) volumeSlider.value = video.volume;
                video.muted = false;
                updateVolumeIcon();
                break;
            case 'ArrowDown':
                e.preventDefault();
                video.volume = Math.max(0, video.volume - 0.1);
                if (volumeSlider) volumeSlider.value = video.volume;
                updateVolumeIcon();
                break;
            case 'KeyC':
                subtitleBtn?.click();
                break;
            case 'KeyT':
                theaterBtn?.click();
                break;
            case 'KeyZ':
                e.preventDefault();
                cycleZoom();
                break;
            case 'KeyS':
                e.preventDefault();
                takeScreenshot();
                break;
            case 'Escape':
                exitPiP();
                break;
        }
    });

    // Video End & Autoplay
    let autoplayTimer = null;
    let autoplayCount = 5;

    window.cancelAutoplay = function() {
        clearInterval(autoplayTimer);
        document.getElementById('autoplay-overlay')?.classList.add('hidden');
        if (bigPlayBtn)  { bigPlayBtn.style.opacity = '1'; bigPlayBtn.style.pointerEvents = 'auto'; }
        if (bigPlayIcon) bigPlayIcon.className = 'fa-solid fa-rotate-right text-white text-2xl';
    };

    window.playNextVideo = function() {
        const queue = JSON.parse(localStorage.getItem('neontv_queue') || '[]');
        if (queue.length > 0) {
            const next = queue.shift();
            localStorage.setItem('neontv_queue', JSON.stringify(queue));
            const nextId = typeof next === 'object' ? next.id : next;
            window.location.href = (typeof APP_URL_JS !== 'undefined' ? APP_URL_JS : '') + '/video.php?id=' + nextId;
            return;
        }
        if (typeof NEXT_VIDEO_ID !== 'undefined' && NEXT_VIDEO_ID) {
            window.location.href = 'video.php?id=' + NEXT_VIDEO_ID;
        }
    };

    video.addEventListener('ended', () => {
        localStorage.removeItem(VIDEO_STORAGE_KEY);
        exitPiP();
        if (video.loop) return;

        let _ap = true; try { _ap = localStorage.getItem('neontv_autoplay') !== '0'; } catch (e) {}
        if (_ap && typeof NEXT_VIDEO_ID !== 'undefined' && NEXT_VIDEO_ID) {
            const overlay = document.getElementById('autoplay-overlay');
            const timerEl = document.getElementById('autoplay-timer');
            const circle  = document.getElementById('autoplay-circle');
            if (overlay && timerEl && circle) {
                overlay.classList.remove('hidden');
                autoplayCount = 5;
                timerEl.textContent = autoplayCount;
                circle.style.strokeDashoffset = '0';
                void circle.offsetWidth;
                circle.style.strokeDashoffset = '226.2';
                autoplayTimer = setInterval(() => {
                    autoplayCount--;
                    if (autoplayCount <= 0) { clearInterval(autoplayTimer); playNextVideo(); }
                    else timerEl.textContent = autoplayCount;
                }, 1000);
                return;
            }
        }
        if (bigPlayBtn)  { bigPlayBtn.style.opacity = '1'; bigPlayBtn.style.pointerEvents = 'auto'; }
        if (bigPlayIcon) bigPlayIcon.className = 'fa-solid fa-rotate-right text-white text-2xl';
    });


    // --------------------------------------------------------
    // #45 Transcode tetikleyici — video ilk yüklendiğinde
    // --------------------------------------------------------
    (function triggerTranscodeIfNeeded() {
        const qualitiesData = '<?php echo addslashes(json_encode($video["video_qualities"] ?? null)); ?>';
        if (qualitiesData && qualitiesData !== 'null' && qualitiesData !== '""') return; // zaten var
        const publicId = '<?php echo addslashes($video["cloudinary_public_id"] ?? ""); ?>';
        if (!publicId) return;

        fetch(APP_URL_JS + '/api/transcode.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ video_id: VIDEO_ID, cloudinary_public_id: publicId })
        }).catch(() => {}); // sessizce arka planda
    })();

});

// ============================================================
// F2: Video Reklam Sistemi (Preroll + rastgele Midroll)
// window.NEONTV_VIDEO_ADS = [...] header.php'den enjekte edilir.
// - Premium üyelere reklam gösterilmez.
// - Başta 1 reklam (düşük ihtimalle 2 farklı reklam), %50 ihtimalle ortada 1 reklam.
// - Reklam bitince/geçilince video kaldığı saniyeden devam eder.
// ============================================================
(function () {
    'use strict';

    const allAds = (typeof window.NEONTV_VIDEO_ADS === 'undefined') ? [] : window.NEONTV_VIDEO_ADS;
    const ads = Array.isArray(allAds) ? allAds.filter(a => a && a.video_url) : [];
    if (ads.length === 0) return;

    const video     = document.getElementById('main-video');
    const container = document.getElementById('player-container');
    if (!video || !container) return;

    const DOUBLE_PREROLL_CHANCE = 0.15; // 2 reklam ihtimali
    const MIDROLL_CHANCE        = 0.50; // ortada reklam ihtimali
    const MIN_DURATION_FOR_MID  = 60;   // saniye
    const API_BASE = (typeof APP_URL_JS !== 'undefined' && APP_URL_JS) ? APP_URL_JS : '';

    let adRunning = false;
    let planned   = false;
    let midTime   = null;      // saniye (null = ortada reklam yok)
    let midDone   = false;
    let lastPreId = null;
    let isPremiumUser = false;

    function reportStat(adId, stat) {
        fetch(API_BASE + '/api/ads.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ad_id: adId, stat: stat }),
            keepalive: true
        }).catch(() => {});
    }

    // Premium kontrolü (sunucudan; istemci tarafı sadece gösterimi atlar)
    async function checkPremium() {
        try {
            if (typeof sbClient === 'undefined') return false;
            const { data } = await sbClient.auth.getSession();
            const tok = data && data.session && data.session.access_token;
            if (!tok) return false;
            const r = await fetch(API_BASE + '/api/auth.php?token=' + encodeURIComponent(tok), { headers: { 'Authorization': 'Bearer ' + tok, 'X-Access-Token': tok } });
            if (!r.ok) return false;
            const j = await r.json();
            return !!(j && j.data && j.data.is_premium);
        } catch (e) { return false; }
    }

    // Belirtilen listeden (varsa hariç tutarak) rastgele reklam seç
    function pickAd(excludeId) {
        const pool = ads.filter(a => a.id !== excludeId);
        const list = pool.length ? pool : ads;
        return list[Math.floor(Math.random() * list.length)];
    }

    // Tek bir reklamı oynat; bitince/geçilince/hata olunca done() çağrılır
    function showAd(ad, done) {
        adRunning = true;
        let finished = false;
        let started  = false;

        const ov = document.createElement('div');
        ov.className = 'neontv-ad-overlay';
        ov.style.cssText = 'position:absolute;inset:0;z-index:500;display:flex;flex-direction:column;background:#000;';

        const av = document.createElement('video');
        av.src = ad.video_url;
        av.style.cssText = 'width:100%;height:100%;object-fit:contain;cursor:pointer;';
        av.playsInline = true;
        av.preload = 'auto';
        av.autoplay = true;

        const hud = document.createElement('div');
        hud.style.cssText = 'position:absolute;top:0;left:0;right:0;display:flex;align-items:center;justify-content:space-between;padding:0.5rem 1rem;background:linear-gradient(180deg,rgba(0,0,0,0.7) 0%,transparent 100%);font-size:0.75rem;color:#fff;pointer-events:none;';

        const label = document.createElement('span');
        label.textContent = 'Reklam';
        label.style.cssText = 'opacity:0.8;font-family:sans-serif;';

        const skipBtn = document.createElement('button');
        skipBtn.style.cssText = 'pointer-events:auto;background:rgba(0,0,0,0.6);border:1px solid rgba(255,255,255,0.35);color:#fff;padding:0.3rem 0.8rem;border-radius:0.375rem;font-size:0.75rem;cursor:not-allowed;font-family:sans-serif;';

        const skipAfter = Math.max(0, parseInt(ad.skip_after_seconds != null ? ad.skip_after_seconds : 5, 10) || 0);
        let canSkip = skipAfter === 0;
        function setSkipLabel(remaining) {
            if (canSkip) { skipBtn.textContent = 'Reklamı Geç ›'; skipBtn.style.cursor = 'pointer'; }
            else { skipBtn.textContent = 'Geçmek için ' + remaining; }
        }
        setSkipLabel(skipAfter);

        hud.appendChild(label);
        hud.appendChild(skipBtn);
        ov.appendChild(av);
        ov.appendChild(hud);

        function finish() {
            if (finished) return;
            finished = true;
            clearTimeout(loadTimer);
            try { av.pause(); av.removeAttribute('src'); av.load(); } catch (e) {}
            ov.remove();
            adRunning = false;
            done();
        }

        av.addEventListener('playing', () => { started = true; });
        av.addEventListener('timeupdate', () => {
            if (canSkip) return;
            const remaining = Math.max(0, Math.ceil(skipAfter - av.currentTime));
            if (remaining <= 0) { canSkip = true; setSkipLabel(0); }
            else setSkipLabel(remaining);
        });
        av.addEventListener('ended', finish);
        av.addEventListener('error', finish);
        skipBtn.addEventListener('click', (e) => { e.stopPropagation(); if (canSkip) finish(); });
        av.addEventListener('click', () => {
            if (ad.click_url) {
                reportStat(ad.id, 'clicks');
                window.open(ad.click_url, '_blank', 'noopener,noreferrer');
            }
        });

        // Reklam 6 sn içinde başlamazsa videoyu bekletme
        const loadTimer = setTimeout(() => { if (!started) finish(); }, 6000);

        container.appendChild(ov);
        reportStat(ad.id, 'impressions');
        av.play().catch(() => {});
    }

    // Ana videoyu durdur, reklam(lar)ı sırayla oynat, kaldığı yerden devam et
    function runAds(list, resumeAt) {
        if (!list.length) return;
        const wasFullscreen = !!document.fullscreenElement;
        video.pause();
        const startTime = (typeof resumeAt === 'number') ? resumeAt : video.currentTime;
        let i = 0;
        (function next() {
            if (i >= list.length) {
                try {
                    if (Math.abs(video.currentTime - startTime) > 0.5) video.currentTime = startTime;
                } catch (e) {}
                video.play().catch(() => {});
                return;
            }
            showAd(list[i++], next);
        })();
    }

    // Oynatmanın ilk anında plan yap
    async function planAds() {
        planned = true;
        video.pause();
        isPremiumUser = await checkPremium();
        if (isPremiumUser) { video.play().catch(() => {}); return; }

        const pre = [];
        const first = pickAd(null);
        pre.push(first);
        // Düşük ihtimalle 2. reklam (ilkinden FARKLI olmalı)
        if (ads.length > 1 && Math.random() < DOUBLE_PREROLL_CHANCE) {
            pre.push(pickAd(first.id));
        }
        lastPreId = pre[pre.length - 1].id;

        // Ortada reklam kararı (videonun %35–%65'i arasında rastgele bir an)
        const dur = video.duration;
        if (isFinite(dur) && dur >= MIN_DURATION_FOR_MID && Math.random() < MIDROLL_CHANCE) {
            midTime = dur * (0.35 + Math.random() * 0.30);
        }
        runAds(pre, 0 + (video.currentTime || 0));
    }

    video.addEventListener('play', function () {
        if (adRunning) { video.pause(); return; }
        if (!planned) planAds();
    });

    // Duration sonradan gelirse (metadata geç yüklenirse) ortada reklam planla
    video.addEventListener('loadedmetadata', function () {
        if (planned && !isPremiumUser && midTime === null && !midDone &&
            video.duration >= MIN_DURATION_FOR_MID && Math.random() < MIDROLL_CHANCE) {
            midTime = video.duration * (0.35 + Math.random() * 0.30);
        }
    });

    video.addEventListener('timeupdate', function () {
        if (!planned || isPremiumUser || adRunning || midDone || midTime === null) return;
        if (video.currentTime >= midTime) {
            midDone = true;
            runAds([pickAd(lastPreId)], video.currentTime);
        }
    });
})();
