<?php
// Rastgele bir yayınlanmış videoya yönlendirir.
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/supabase.php';

$db  = new Supabase();
$cnt = $db->count('videos', 'status=eq.published&select=id');
$url = APP_URL . '/index.php';
if ($cnt > 0) {
    $off = random_int(0, $cnt - 1);
    $r = $db->select('videos', 'status=eq.published&select=id&order=created_at.desc&limit=1&offset=' . $off);
    if (!empty($r['data'][0]['id'])) $url = APP_URL . '/video.php?id=' . $r['data'][0]['id'];
}
header('Cache-Control: no-store');
header('Location: ' . $url, true, 302);
exit;
