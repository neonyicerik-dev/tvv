<?php
// ============================================================
// NeonTV - İletişim Sayfası
// Mesajlar contact_messages tablosuna kaydedilir, admin panelden okunur.
// ============================================================
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/supabase.php';
require_once __DIR__ . '/includes/store.php';
require_once __DIR__ . '/includes/ip_log.php';

$pageTitle = 'İletişim';
$topics    = ['Reklam Vermek İstiyorum', 'Destek / Teknik Sorun', 'İçerik Kaldırma / Şikayet', 'Öneri', 'Diğer'];
$error     = '';
$success   = false;
$old       = ['topic' => '', 'name' => '', 'email' => '', 'message' => ''];

// Ön seçili konu (?konu=reklam)
if (($_GET['konu'] ?? '') === 'reklam') $old['topic'] = $topics[0];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $old['topic']   = trim($_POST['topic'] ?? '');
    $old['name']    = trim($_POST['name'] ?? '');
    $old['email']   = trim($_POST['email'] ?? '');
    $old['message'] = trim($_POST['message'] ?? '');

    $ip     = function_exists('getClientIp') ? getClientIp() : ($_SERVER['REMOTE_ADDR'] ?? '');
    $ipHash = Store::hashIp($ip);

    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $error = 'Güvenlik doğrulaması başarısız. Sayfayı yenileyip tekrar deneyin.';
    } elseif (!empty($_POST['website'])) {
        // Honeypot: botlar doldurur. Sessizce başarılı gibi davran.
        $success = true;
        $old = ['topic' => '', 'name' => '', 'email' => '', 'message' => ''];
    } elseif (!in_array($old['topic'], $topics, true)) {
        $error = 'Lütfen bir konu seçin.';
    } elseif ($old['name'] === '' || mb_strlen($old['name']) > 80) {
        $error = 'Lütfen adınızı yazın (en fazla 80 karakter).';
    } elseif (!validateEmail($old['email']) || mb_strlen($old['email']) > 120) {
        $error = 'Geçerli bir e-posta adresi yazın.';
    } elseif (mb_strlen($old['message']) < 5 || mb_strlen($old['message']) > 3000) {
        $error = 'Mesajınız 5 ile 3000 karakter arasında olmalı.';
    } else {
        $db = new Supabase();
        // Spam koruması: aynı IP'den saatte en fazla 3 mesaj
        $since  = gmdate('Y-m-d\TH:i:s\Z', time() - 3600);
        $recent = $db->select('contact_messages',
            'ip_hash=eq.' . urlencode($ipHash) . '&created_at=gte.' . urlencode($since) . '&select=id', true);
        if (is_array($recent['data'] ?? null) && count($recent['data']) >= 3) {
            $error = 'Çok fazla mesaj gönderdiniz. Lütfen daha sonra tekrar deneyin.';
        } else {
            $r = $db->insert('contact_messages', [
                'topic'   => $old['topic'],
                'name'    => $old['name'],
                'email'   => $old['email'],
                'message' => $old['message'],
                'ip_hash' => $ipHash,
            ], true);
            if (($r['status'] ?? 500) < 400) {
                $success = true;
                $old = ['topic' => '', 'name' => '', 'email' => '', 'message' => ''];
            } else {
                error_log('[iletisim] kayıt hatası: ' . ($r['error'] ?? ''));
                $error = 'Mesajınız gönderilemedi. Lütfen daha sonra tekrar deneyin.';
            }
        }
    }
}
?>
<?php include __DIR__ . '/components/header.php'; ?>

<div class="max-w-2xl mx-auto py-10 px-4 sm:px-6">
    <div class="p-6 sm:p-8 rounded-3xl" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">
        <h1 class="text-2xl font-bold text-white mb-1 flex items-center gap-3">
            <i class="fa-solid fa-envelope" style="color:#00f5ff;"></i> İletişim
        </h1>
        <p class="text-sm text-gray-500 mb-6">Reklam, destek, şikayet veya önerileriniz için bize yazın. Mesajınız doğrudan yönetim ekibine ulaşır.</p>

        <?php if ($success): ?>
        <div class="mb-6 p-4 rounded-xl text-sm font-medium border flex items-center gap-3 bg-green-500/10 border-green-500/40 text-green-400">
            <i class="fa-solid fa-circle-check"></i> Mesajınız alındı. En kısa sürede e-posta adresinizden dönüş yapacağız.
        </div>
        <?php elseif ($error): ?>
        <div class="mb-6 p-4 rounded-xl text-sm font-medium border flex items-center gap-3 bg-red-500/10 border-red-500/40 text-red-400">
            <i class="fa-solid fa-triangle-exclamation"></i> <?= e($error) ?>
        </div>
        <?php endif; ?>

        <form method="POST" class="space-y-5" autocomplete="on">
            <?= csrfField() ?>
            <!-- Honeypot -->
            <div style="position:absolute;left:-9999px;" aria-hidden="true">
                <label>Web sitesi <input type="text" name="website" tabindex="-1" autocomplete="off"></label>
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-400 mb-1.5" for="ct-topic">Konu</label>
                <select id="ct-topic" name="topic" required
                        class="w-full bg-black/30 border border-gray-800 rounded-xl py-3 px-4 text-white focus:outline-none focus:border-cyan-500">
                    <option value="" disabled <?= $old['topic'] === '' ? 'selected' : '' ?>>Konu seçin...</option>
                    <?php foreach ($topics as $t): ?>
                    <option value="<?= e($t) ?>" <?= $old['topic'] === $t ? 'selected' : '' ?>><?= e($t) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                    <label class="block text-sm font-medium text-gray-400 mb-1.5" for="ct-name">Adınız</label>
                    <input type="text" id="ct-name" name="name" required maxlength="80" value="<?= e($old['name']) ?>"
                           class="w-full bg-black/30 border border-gray-800 rounded-xl py-3 px-4 text-white focus:outline-none focus:border-cyan-500"
                           placeholder="Adınız">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-400 mb-1.5" for="ct-email">E-posta</label>
                    <input type="email" id="ct-email" name="email" required maxlength="120" value="<?= e($old['email']) ?>"
                           class="w-full bg-black/30 border border-gray-800 rounded-xl py-3 px-4 text-white focus:outline-none focus:border-cyan-500"
                           placeholder="ornek@mail.com">
                </div>
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-400 mb-1.5" for="ct-msg">Mesajınız</label>
                <textarea id="ct-msg" name="message" required rows="6" minlength="5" maxlength="3000"
                          class="w-full bg-black/30 border border-gray-800 rounded-xl py-3 px-4 text-white focus:outline-none focus:border-cyan-500"
                          placeholder="Ne hakkında yazmak istiyorsunuz?"><?= e($old['message']) ?></textarea>
            </div>

            <button type="submit" class="w-full sm:w-auto px-8 py-3 rounded-xl font-bold text-black transition-all hover:scale-105"
                    style="background:linear-gradient(135deg,#00f5ff,#bf00ff);box-shadow:0 0 20px rgba(0,245,255,0.3);">
                <i class="fa-solid fa-paper-plane mr-2"></i>Gönder
            </button>
        </form>
    </div>
</div>

<?php include __DIR__ . '/components/footer.php'; ?>
