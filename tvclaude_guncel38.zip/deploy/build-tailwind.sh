#!/bin/sh
# Yeni Tailwind sınıfı eklediğinde (PHP/JS içinde) CSS'i yeniden üret.
# Kullanım (proje kökünde):  sh deploy/build-tailwind.sh
# Tailwind v3 bağımsız çalıştırılabilir dosyası kullanılır (Node gerekmez).
set -e
cd "$(dirname "$0")/.."
BIN=deploy/tailwindcss
if [ ! -x "$BIN" ]; then
  curl -sSL -o "$BIN" https://github.com/tailwindlabs/tailwindcss/releases/download/v3.4.17/tailwindcss-linux-x64
  chmod +x "$BIN"
fi
"$BIN" -c tailwind.config.js -i deploy/tailwind-input.css -o assets/css/tw.css --minify
echo "assets/css/tw.css güncellendi."
