<?php
// ============================================================
// NeonTV - Ana Sayfa
// ============================================================
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/supabase.php';
require_once __DIR__ . '/includes/store.php';

if (isMaintenanceMode() && !isAdminLoggedIn()) {
    die('<!DOCTYPE html><html><head><meta charset="utf-8"><title>Bakım Modu</title><style>body{background:#070711;color:#fff;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;text-align:center;padding:20px;}h1{color:#00f5ff;}</style></head><body><div><h1>Bakım Modu</h1><p>' . htmlspecialchars(getMaintenanceMessage()) . '</p></div></body></html>');
}

// Zamanlanmış videoları yayınla (arka planda çalışır gibi)
publishScheduledVideos();

// IP Engel Kontrolü
if (isIpBlocked()) {
    http_response_code(403);
    die('<!DOCTYPE html><html><head><meta charset="utf-8"><title>Erisim Engellendi</title><style>body{background:#070711;color:#fff;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;text-align:center;}h1{color:#ff007a;}</style></head><body><div><h1>🚫 Erisim Engellendi</h1><p>IP adresiniz bu platforma erişim engellenmiştir.</p></div></body></html>');
}

// Ziyareti kaydet (arka planda)
logVisit();

$pageTitle = 'Ana Sayfa';
$metaDesc  = 'NeonTV - En yeni ve popüler videoları izleyin.';

$db   = new Supabase();
$page = max(1, (int)($_GET['page'] ?? 1));
$sort = in_array($_GET['sort'] ?? '', ['views', 'likes_count', 'created_at']) ? $_GET['sort'] : 'created_at';
$tag  = trim($_GET['tag'] ?? '');

$tagFilter = '';
if ($tag) {
    // Supabase REST array contains: cs.{"Tag"}
    $tagFilter = '&tags=cs.%7B%22' . urlencode($tag) . '%22%7D';
}

// Önbellekte olmayan sorguları ARTIK ART ARDA değil PARALEL çek (gecikme: toplam yerine en yavaş tek sorgu)
$__fKey = 'home_featured';
$__lKey = 'home_list_' . md5('status=eq.published' . $tagFilter . '&order=' . $sort . '.desc&limit=' . VIDEOS_PER_PAGE . '&offset=' . (($page - 1) * VIDEOS_PER_PAGE));
$__cKey = 'home_count_' . md5($tagFilter);
$__need = [];
if (!$tag && Store::peek($__fKey) === null) $__need['f'] = ['videos', 'status=eq.published&order=views.desc&limit=1'];
if (Store::peek($__lKey) === null) $__need['l'] = ['videos', 'status=eq.published' . $tagFilter . '&order=' . $sort . '.desc&limit=' . VIDEOS_PER_PAGE . '&offset=' . (($page - 1) * VIDEOS_PER_PAGE)];
if (Store::peek($__cKey) === null) $__need['c'] = ['videos', 'status=eq.published' . $tagFilter . '&select=id&limit=1'];
if (count($__need) > 1) {
    unset($__need['c']); // sayım ayrı (count=exact üstbilgisi gerekir), onu aşağıdaki mevcut çağrı yapar
    $__r = $db->selectMany($__need);
    if (isset($__r['f']) && $__r['f']['status'] === 200) Store::put($__fKey, 60, $__r['f']['data'][0] ?? null);
    if (isset($__r['l']) && $__r['l']['status'] === 200) Store::put($__lKey, 30, $__r['l']['data']);
}

// Öne çıkan video (en çok izlenen) - etiket seçili değilse göster
$featured = null;
if (!$tag) {
    $featured = Store::remember('home_featured', 60, fn() => $db->first('videos', 'status=eq.published&order=views.desc'));
}

// Video listesi
$offset  = ($page - 1) * VIDEOS_PER_PAGE;
$listQuery = 'status=eq.published' . $tagFilter . '&order=' . $sort . '.desc&limit=' . VIDEOS_PER_PAGE . '&offset=' . $offset;
$videos  = Store::remember('home_list_' . md5($listQuery), 30, function () use ($db, $listQuery) {
    $r = $db->select('videos', $listQuery);
    return is_array($r['data'] ?? null) ? $r['data'] : [];
});

// Toplam video sayısı (yalnızca sayım; tüm satırları çekme)
$total = (int)Store::remember('home_count_' . md5($tagFilter), 60, fn() => $db->count('videos', 'status=eq.published' . $tagFilter));
$pagination = paginate($total, VIDEOS_PER_PAGE, $page);
?>
<?php include __DIR__ . '/components/header.php'; ?>

<div class="max-w-screen-2xl mx-auto px-4 sm:px-6 py-6">

    <!-- ===== HERO / ÖNE ÇIKAN VIDEO ===== -->
    <?php if ($featured): ?>
    <style>
#featured-hero{aspect-ratio:21/9;max-height:480px}
@media (max-width:640px){
  #featured-hero{aspect-ratio:auto!important;height:300px;max-height:none!important}
  #featured-hero .feat-content{padding:16px!important;right:0;max-width:none!important}
  #featured-hero h1{font-size:1.15rem!important;line-height:1.3!important;margin-bottom:.6rem!important;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
  #featured-watch-btn{padding:.55rem 1.4rem!important}
}
</style>
    <section class="mb-8 sm:mb-10" id="featured-section">
        <div class="relative rounded-2xl overflow-hidden group cursor-pointer"
             id="featured-hero"
             style="background:#13131f;"
             data-video-url="<?= e($featured['video_url'] ?? '') ?>"
             onclick="window.location='<?= APP_URL ?>/video.php?id=<?= e($featured['id']) ?>'">

            <!-- Thumbnail -->
            <img id="featured-thumb"
                 src="<?= e($featured['thumbnail_url'] ?? 'https://placehold.co/1280x540/070711/00f5ff?text=NeonTV') ?>"
                 alt="<?= e($featured['title']) ?>"
                 class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                 style="filter:brightness(0.5);transition:opacity 0.4s ease;">

            <!-- Featured Hover Preview Video -->
            <video id="featured-preview-video"
                   muted playsinline preload="none"
                   style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;opacity:0;transition:opacity 0.5s ease;pointer-events:none;filter:brightness(0.5);"
            ></video>

            <!-- Gradient -->
            <div class="absolute inset-0" style="background:linear-gradient(to right,rgba(7,7,17,0.95) 0%,rgba(7,7,17,0.4) 50%,transparent 100%);"></div>
            <div class="absolute inset-0" style="background:linear-gradient(to top,rgba(7,7,17,0.8) 0%,transparent 50%);"></div>

            <!-- Glow Bar -->
            <div class="absolute top-0 left-0 right-0 h-0.5" style="background:linear-gradient(90deg,#00f5ff,#bf00ff,transparent);"></div>

            <!-- Content -->
            <div class="feat-content absolute bottom-0 left-0 p-6 sm:p-10 max-w-2xl">
                <div class="flex items-center gap-2 mb-3">
                    <span class="px-3 py-1 rounded-full text-xs font-bold tracking-wider"
                          style="background:linear-gradient(135deg,#00f5ff,#bf00ff);color:#000;">
                        <i class="fa-solid fa-fire-flame-curved mr-1"></i>ÖNE ÇIKAN
                    </span>
                </div>

                <h1 class="text-2xl sm:text-4xl font-bold text-white mb-3 leading-tight drop-shadow-lg">
                    <?= e($featured['title']) ?>
                </h1>

                <?php if (!empty($featured['description'])): ?>
                <p class="hidden sm:block text-gray-300 text-sm sm:text-base leading-relaxed mb-5 line-clamp-2"
                   style="display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;">
                    <?= e($featured['description']) ?>
                </p>
                <?php endif; ?>

                <div class="flex items-center gap-4 sm:gap-6 text-xs sm:text-sm text-gray-400 mb-4 sm:mb-6">
                    <span class="flex items-center gap-1.5">
                        <i class="fa-solid fa-eye text-neon-cyan"></i>
                        <?= formatNumber((int)($featured['views'] ?? 0)) ?> izlenme
                    </span>
                    <span class="flex items-center gap-1.5">
                        <i class="fa-solid fa-heart text-neon-pink"></i>
                        <?= formatNumber((int)($featured['likes_count'] ?? 0)) ?> beğeni
                    </span>
                    <span class="flex items-center gap-1.5">
                        <i class="fa-regular fa-clock text-gray-500"></i>
                        <?= timeAgo($featured['created_at']) ?>
                    </span>
                </div>

                <a href="<?= APP_URL ?>/video.php?id=<?= e($featured['id']) ?>"
                   id="featured-watch-btn"
                   class="inline-flex items-center gap-3 px-7 py-3 rounded-full font-bold text-black text-sm transition-all duration-300 hover:scale-105 hover:shadow-2xl"
                   style="background:linear-gradient(135deg,#00f5ff,#bf00ff);box-shadow:0 0 20px rgba(0,245,255,0.3);">
                    <i class="fa-solid fa-play"></i>
                    İzle
                </a>
            </div>
        </div>
    </section>

    <?php endif; ?>
    <!-- Kaldığın yerden devam (giriş yapmış kullanıcılar) -->
    <section id="cont-watch" class="mb-8 sm:mb-10 hidden">
        <h2 class="text-lg sm:text-xl font-bold text-white flex items-center gap-2 mb-3"><i class="fa-solid fa-clock-rotate-left text-neon-cyan"></i> Kaldığın Yerden Devam</h2>
        <div id="cont-row" style="display:flex;gap:12px;overflow-x:auto;scrollbar-width:none;-webkit-overflow-scrolling:touch;"></div>
        <style>#cont-row::-webkit-scrollbar{display:none}.cw-card{flex:0 0 auto;width:200px;position:relative}@media(min-width:640px){.cw-card{width:260px}}</style>
    </section>
    <script>
    window.addEventListener('load', async function () {
        try {
            const { data } = await sbClient.auth.getSession(); const t = data.session && data.session.access_token; if (!t) return;
            const H = { 'Authorization': 'Bearer ' + t, 'X-Access-Token': t };
            const j = await (await fetch('<?= APP_URL ?>/api/history.php?list=1&token=' + encodeURIComponent(t), { headers: H })).json();
            const items = ((j && j.data && j.data.items) || []).filter(x => x.position_seconds > 5 && x.duration_seconds > 0 && x.position_seconds < x.duration_seconds - 10).slice(0, 12);
            if (!items.length) return;
            const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
            const row = document.getElementById('cont-row');
            row.innerHTML = items.map(x => {
                const v = x.videos, pct = Math.min(100, Math.round(x.position_seconds / x.duration_seconds * 100)), left = Math.max(1, Math.round((x.duration_seconds - x.position_seconds) / 60));
                return '<div class="cw-card" data-id="' + esc(v.id) + '"><a href="<?= APP_URL ?>/video.php?id=' + esc(v.id) + '" class="block"><div class="rounded-xl overflow-hidden relative" style="aspect-ratio:16/9;background:#13131f"><img src="' + esc(v.thumbnail_url) + '" class="w-full h-full object-cover" loading="lazy" alt="">' +
                    '<div style="position:absolute;left:0;right:0;bottom:0;height:4px;background:rgba(255,255,255,0.25)"><div style="height:100%;width:' + pct + '%;background:#bf00ff"></div></div></div>' +
                    '<h3 class="text-sm font-semibold text-white mt-2" style="display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden">' + esc(v.title) + '</h3><p class="text-xs text-gray-400">' + left + ' dk kaldı</p></a>' +
                    '<button type="button" class="cw-x absolute top-1 right-1 w-6 h-6 rounded-full text-white text-xs" style="background:rgba(0,0,0,0.65)" aria-label="Listeden kaldır">✕</button></div>';
            }).join('');
            row.addEventListener('click', async e => {
                const b = e.target.closest('.cw-x'); if (!b) return; e.preventDefault();
                const c = b.closest('.cw-card');
                fetch('<?= APP_URL ?>/api/history.php?video_id=' + encodeURIComponent(c.dataset.id) + '&token=' + encodeURIComponent(t), { method: 'DELETE', headers: H }).catch(() => {});
                c.remove(); if (!row.children.length) document.getElementById('cont-watch').classList.add('hidden');
            });
            document.getElementById('cont-watch').classList.remove('hidden');
        } catch (e) {}
    });
    </script>
    <!-- Senin için (giriş yapmış kullanıcılar, izleme geçmişine göre; tek satır, sağa-sola sonsuz kaydırma) -->
    <section id="for-you" class="mb-8 sm:mb-10 hidden">
        <div class="flex items-center mb-3">
            <h2 class="text-lg sm:text-xl font-bold text-white flex items-center gap-2"><i class="fa-solid fa-wand-magic-sparkles text-neon-cyan"></i> Senin İçin</h2>
            <div class="ml-auto hidden sm:flex gap-2">
                <button type="button" id="fy-prev" class="w-8 h-8 rounded-full text-gray-300 hover:text-black hover:bg-cyan-300 transition-colors" style="background:rgba(255,255,255,0.08)" aria-label="Geri"><i class="fa-solid fa-chevron-left text-xs"></i></button>
                <button type="button" id="fy-next" class="w-8 h-8 rounded-full text-gray-300 hover:text-black hover:bg-cyan-300 transition-colors" style="background:rgba(255,255,255,0.08)" aria-label="İleri"><i class="fa-solid fa-chevron-right text-xs"></i></button>
            </div>
        </div>
        <div id="for-you-row" style="display:flex;gap:12px;overflow-x:auto;scrollbar-width:none;-webkit-overflow-scrolling:touch;scroll-snap-type:x proximity;"></div>
        <style>#for-you-row::-webkit-scrollbar{display:none}.fy-card{flex:0 0 auto;width:160px;scroll-snap-align:start}@media(min-width:640px){.fy-card{width:230px}}</style>
    </section>

    <script>
    window.addEventListener('load', async function () {
        try {
            const { data } = await sbClient.auth.getSession(); const t = data.session && data.session.access_token; if (!t) return;
            const j = await (await fetch('<?= APP_URL ?>/api/recommend.php?token=' + encodeURIComponent(t), { headers: { 'Authorization': 'Bearer ' + t, 'X-Access-Token': t } })).json();
            const items = j && j.data ? j.data.items : []; if (!items.length || !j.data.personal) return;
            const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
            const card = v => '<a href="<?= APP_URL ?>/video.php?id=' + esc(v.id) + '" class="fy-card block"><div class="rounded-xl overflow-hidden" style="aspect-ratio:16/9;background:#13131f"><img src="' + esc(v.thumbnail_url) + '" class="w-full h-full object-cover" loading="lazy" alt=""></div>' +
                '<h3 class="text-sm font-semibold text-white mt-2" style="display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden">' + esc(v.title) + '</h3></a>';
            const row = document.getElementById('for-you-row');
            const one = items.map(card).join('');
            const loop = items.length >= 4;
            row.innerHTML = loop ? one + one + one : one;   // 3 kopya: sonsuz döngü için
            document.getElementById('for-you').classList.remove('hidden');
            if (!loop) return;
            const setW = () => row.scrollWidth / 3;
            row.style.scrollSnapType = 'none';
            row.scrollLeft = setW();
            let fix = false;
            row.addEventListener('scroll', () => {
                if (fix) return;
                const w = setW();
                if (row.scrollLeft < w * 0.3) { fix = true; row.scrollLeft += w; requestAnimationFrame(() => fix = false); }
                else if (row.scrollLeft > w * 1.7) { fix = true; row.scrollLeft -= w; requestAnimationFrame(() => fix = false); }
            }, { passive: true });
            const step = () => Math.max(220, row.clientWidth * 0.8);
            document.getElementById('fy-prev')?.addEventListener('click', () => row.scrollBy({ left: -step(), behavior: 'smooth' }));
            document.getElementById('fy-next')?.addEventListener('click', () => row.scrollBy({ left: step(), behavior: 'smooth' }));
        } catch (e) {}
    });
    </script>

    <!-- ===== ETİKET FİLTRESİ ===== -->
    <?php
    // Yayınlanan videolardaki tüm etiketleri çek ve frekansa göre sırala
    $allTagRows = Store::remember('home_all_tags', 300, function () use ($db) {
        $r = $db->select('videos', 'status=eq.published&select=tags', false);
        return is_array($r['data'] ?? null) ? $r['data'] : [];
    });
    $tagFreq    = [];
    foreach ($allTagRows as $row) {
        $rowTags = $row['tags'] ?? [];
        if (is_string($rowTags)) {
            $rowTags = json_decode($rowTags, true) ?? [];
        }
        foreach ($rowTags as $t) {
            $t = trim($t);
            if ($t === '') continue;
            $tagFreq[$t] = ($tagFreq[$t] ?? 0) + 1;
        }
    }
    arsort($tagFreq);
    $popularTags = array_keys(array_slice($tagFreq, 0, 20, true));
    // Aktif filtre başa gelsin (listede yoksa)
    if ($tag && !in_array($tag, $popularTags)) {
        array_unshift($popularTags, $tag);
    }
    ?>
    <div class="flex items-center gap-3 overflow-x-auto pb-4 mb-6 scrollbar-hide" style="scrollbar-width:none;">
        <a href="?" class="whitespace-nowrap px-4 py-2 rounded-full text-sm font-medium transition-colors <?= !$tag ? 'bg-white text-black shadow-[0_0_15px_rgba(255,255,255,0.3)]' : 'bg-[#13131f] text-gray-400 hover:text-white border border-white/10' ?>">Tümü</a>
        <?php foreach ($popularTags as $t):
            $isActive = ($tag === $t);
        ?>
        <a href="?tag=<?= urlencode($t) ?>" class="whitespace-nowrap px-4 py-2 rounded-full text-sm font-medium transition-colors <?= $isActive ? 'bg-white text-black shadow-[0_0_15px_rgba(255,255,255,0.3)]' : 'bg-[#13131f] text-gray-400 hover:text-white border border-white/10' ?>">
            <?= e($t) ?>
        </a>
        <?php endforeach; ?>
        <?php if (empty($popularTags)): ?>
        <span class="text-xs text-gray-700">Henüz etiket yok</span>
        <?php endif; ?>
    </div>

    <!-- ===== SIRALAMA / FİLTRE ===== -->
    <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
        <div>
            <h2 class="text-xl font-bold text-white flex items-center gap-2">
                <i class="fa-solid fa-video text-neon-cyan text-base"></i>
                <?php if ($featured): ?>Tum Videolar<?php else: ?>Videolar<?php endif; ?>
            </h2>
            <p class="text-gray-500 text-sm mt-0.5"><?= $total ?> video bulundu</p>
        </div>

        <!-- Sıralama Butonları -->
        <div class="flex items-center gap-2 p-1 rounded-xl" style="background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08);">
            <?php
            $sorts = [
                'created_at'  => ['icon' => 'fa-clock', 'label' => 'Yeni'],
                'views'       => ['icon' => 'fa-eye',   'label' => 'Trend'],
                'likes_count' => ['icon' => 'fa-heart', 'label' => 'Populer'],
            ];
            foreach ($sorts as $key => $meta):
                $active = $sort === $key;
            ?>
            <a href="?sort=<?= $key ?>"
               id="sort-<?= $key ?>"
               class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all duration-200 <?= $active ? 'text-black' : 'text-gray-400 hover:text-white' ?>"
               style="<?= $active ? 'background:linear-gradient(135deg,#00f5ff,#bf00ff);' : '' ?>">
                <i class="fa-solid <?= $meta['icon'] ?> text-[10px]"></i>
                <?= $meta['label'] ?>
            </a>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- ===== VİDEO GRID ===== -->
    <?php if (empty($videos)): ?>
    <div class="text-center py-20" id="empty-state">
        <div class="w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-4"
             style="background:rgba(0,245,255,0.05);border:1px solid rgba(0,245,255,0.1);">
            <i class="fa-solid fa-film text-3xl" style="color:rgba(0,245,255,0.4);"></i>
        </div>
        <h3 class="text-lg font-semibold text-gray-400 mb-2">Henüz video yok</h3>
        <p class="text-gray-600 text-sm">Yakında yeni içerikler eklenecek.</p>
    </div>
    <?php else: ?>
    <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 2xl:grid-cols-6 gap-4" id="videos-grid">
        <?php foreach ($videos as $video): ?>
            <?php include __DIR__ . '/components/video_card.php'; ?>
        <?php endforeach; ?>
    </div>

    <!-- ===== PAGİNATİON ===== -->
    <?php if ($pagination['total_pages'] > 1): ?>
    <div class="flex items-center justify-center gap-2 mt-12" id="pagination">
        <?php if ($pagination['has_prev']): ?>
        <a href="?sort=<?= $sort ?>&page=1" title="En başa git" aria-label="En başa git"
           class="w-9 h-9 flex items-center justify-center rounded-lg text-sm font-medium text-gray-300 hover:text-white transition-all"
           style="background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);"><i class="fa-solid fa-angles-left text-xs"></i></a>
        <a href="?sort=<?= $sort ?>&page=<?= $page - 1 ?>"
           class="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium text-gray-300 hover:text-white transition-all"
           style="background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);">
            <i class="fa-solid fa-chevron-left text-xs"></i> Önceki
        </a>
        <?php endif; ?>

        <div class="flex items-center gap-1">
            <?php for ($i = max(1, $page - 2); $i <= min($pagination['total_pages'], $page + 2); $i++): ?>
            <a href="?sort=<?= $sort ?>&page=<?= $i ?>"
               class="w-9 h-9 flex items-center justify-center rounded-lg text-sm font-medium transition-all duration-200"
               style="<?= $i === $page
                    ? 'background:linear-gradient(135deg,#00f5ff,#bf00ff);color:#000;'
                    : 'background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);color:#9ca3af;' ?>">
                <?= $i ?>
            </a>
            <?php endfor; ?>
        </div>

        <?php if ($pagination['has_next']): ?>
        <a href="?sort=<?= $sort ?>&page=<?= $page + 1 ?>"
           class="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium text-gray-300 hover:text-white transition-all"
           style="background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);">
            Sonraki <i class="fa-solid fa-chevron-right text-xs"></i>
        </a>
        <a href="?sort=<?= $sort ?>&page=<?= (int)$pagination['total_pages'] ?>" title="Sona git" aria-label="Sona git"
           class="w-9 h-9 flex items-center justify-center rounded-lg text-sm font-medium text-gray-300 hover:text-white transition-all"
           style="background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);"><i class="fa-solid fa-angles-right text-xs"></i></a>
        <?php endif; ?>
    </div>
    <?php endif; ?>
    <?php endif; ?>

    <!-- Son yorumlar -->
    <section id="home-comments" class="mb-8 sm:mb-10 hidden">
        <div class="flex items-center mb-3">
            <h2 class="text-lg sm:text-xl font-bold text-white flex items-center gap-2"><i class="fa-regular fa-comments text-neon-cyan"></i> Son Yorumlar</h2>
            <a href="<?= APP_URL ?>/comments.php" class="ml-auto text-xs text-gray-400 hover:text-cyan-400 font-semibold">Tümünü gör <i class="fa-solid fa-chevron-right text-[10px] ml-1"></i></a>
        </div>
        <div id="home-comments-list" class="grid grid-cols-1 md:grid-cols-2 gap-2"></div>
    </section>
    <script>
    (function () {
        const BASE = <?= json_encode(APP_URL) ?>, sec = document.getElementById('home-comments'), box = document.getElementById('home-comments-list');
        const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
        fetch(BASE + '/api/latest_comments.php?per=6&page=1').then(r => r.json()).then(j => {
            const it = j && j.success && j.data.items || []; if (!it.length) return;
            box.innerHTML = it.map(c => {
                const href = BASE + '/video.php?id=' + encodeURIComponent(c.video_id) + '#comment-' + encodeURIComponent(c.id);
                const av = c.avatar_url ? '<img src="' + esc(c.avatar_url) + '" alt="" class="w-full h-full object-cover" loading="lazy">' : esc((c.username || 'U').charAt(0).toUpperCase());
                return '<a href="' + esc(href) + '" class="flex gap-3 p-3 rounded-xl hover:bg-white/5 transition-colors" style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.08)">' +
                    '<span class="w-9 h-9 rounded-full overflow-hidden shrink-0 flex items-center justify-center font-bold text-sm" style="background:linear-gradient(135deg,#bf00ff,#ff007a);color:#fff">' + av + '</span>' +
                    '<span class="min-w-0 flex-1"><span class="flex items-center gap-2 text-xs text-gray-500"><b class="text-white text-sm truncate">' + esc(c.username) + '</b><span>' + esc(c.ago) + '</span></span>' +
                    (c.gif ? '<img src="' + esc(c.gif) + '" alt="GIF" loading="lazy" class="rounded-lg mt-1" style="max-height:64px;max-width:120px;display:block">' : '') + (c.content ? '<span class="block text-sm text-gray-200 mt-0.5 break-words" style="display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden">' + esc(c.content) + '</span>' : '') +
                    '<span class="block text-xs text-gray-500 mt-1 truncate"><i class="fa-solid fa-play text-[9px] mr-1 text-cyan-400"></i>' + esc(c.video_title) + '</span></span></a>';
            }).join('');
            sec.classList.remove('hidden');
        }).catch(() => {});
    })();
    </script>

</div>

<!-- ===== FEATURED HOVER PREVIEW SCRIPT ===== -->
<script>
(function () {
    const hero      = document.getElementById('featured-hero');
    if (!hero) return;

    const videoUrl  = hero.dataset.videoUrl;
    if (!videoUrl)  return;

    const previewVid = document.getElementById('featured-preview-video');
    const thumb      = document.getElementById('featured-thumb');
    if (!previewVid || !thumb) return;

    /* --- Ayarlar --- */
    const CLIP_COUNT    = 4;      // kaç farklı klip
    const CLIP_MIN_SEC  = 4;      // min klip süresi (sn)
    const CLIP_MAX_SEC  = 12;     // max klip süresi (sn)
    const HOVER_DELAY   = 400;    // hover'dan sonra başlama gecikmesi (ms)
    const FADE_DURATION = 500;    // fade geçiş süresi (ms)

    let clips        = [];        // [{start, duration}, ...]
    let currentClip  = 0;
    let clipTimer    = null;
    let hoverTimer   = null;
    let durationKnown = false;
    let isPlaying    = false;

    /* Rastgele kesimsiz klip noktaları üret */
    function generateClips(totalDuration) {
        const margin   = 5;       // baştan ve sondan kaç saniye uzak
        const safe     = totalDuration - margin * 2;
        if (safe <= CLIP_MIN_SEC * CLIP_COUNT) return [];

        const durations = [];
        for (let i = 0; i < CLIP_COUNT; i++) {
            durations.push(CLIP_MIN_SEC + Math.random() * (CLIP_MAX_SEC - CLIP_MIN_SEC));
        }

        /* Üst üste binmeyen, rastgele başlangıç noktaları */
        const starts  = [];
        let attempts  = 0;
        while (starts.length < CLIP_COUNT && attempts < 1000) {
            attempts++;
            const s = margin + Math.random() * safe;
            const d = durations[starts.length];
            if (s + d > totalDuration - margin) continue;
            // Diğerleriyle çakışma kontrolü (en az 5 sn arayla)
            const noOverlap = starts.every((ps, idx) => Math.abs(ps - s) > durations[idx] + 3);
            if (noOverlap) starts.push(s);
        }

        // Eksik doluysa basit yerleştirme
        while (starts.length < CLIP_COUNT) {
            const idx = starts.length;
            starts.push(margin + (safe / CLIP_COUNT) * idx);
        }

        return starts.map((s, i) => ({ start: s, duration: durations[i] || CLIP_MAX_SEC }));
    }

    /* Tek bir klip oynat, bitince bir sonrakine geç */
    function playClip(index) {
        if (!isPlaying) return;
        const clip = clips[index % CLIP_COUNT];

        previewVid.currentTime = clip.start;
        previewVid.play().catch(() => {});

        clipTimer = setTimeout(() => {
            if (!isPlaying) return;
            /* Sonraki klip */
            currentClip = (index + 1) % CLIP_COUNT;
            previewVid.pause();
            playClip(currentClip);
        }, clip.duration * 1000);
    }

    /* Önizlemeyi başlat */
    function startPreview() {
        if (isPlaying) return;
        isPlaying = true;

        /* Video src henüz set edilmemişse yükle */
        if (!previewVid.src || previewVid.src === window.location.href) {
            previewVid.src = videoUrl;
        }

        const doStart = () => {
            if (!durationKnown) return; // metadata bekleniyor
            currentClip = 0;
            /* Thumbnail'i soldur */
            previewVid.style.opacity = '1';
            thumb.style.opacity      = '0';
            playClip(currentClip);
        };

        if (durationKnown) {
            doStart();
        } else {
            previewVid.addEventListener('loadedmetadata', function onMeta() {
                previewVid.removeEventListener('loadedmetadata', onMeta);
                durationKnown = true;
                clips = generateClips(previewVid.duration);
                if (isPlaying) doStart();
            });
            previewVid.load();
        }
    }

    /* Önizlemeyi durdur */
    function stopPreview() {
        isPlaying = false;
        clearTimeout(clipTimer);
        clearTimeout(hoverTimer);
        previewVid.pause();
        previewVid.style.opacity = '0';
        thumb.style.opacity      = '1';
    }

    /* Hover olayları — onclick engellememe için tıklama geçsin */
    hero.addEventListener('mouseenter', () => {
        hoverTimer = setTimeout(startPreview, HOVER_DELAY);
    });

    hero.addEventListener('mouseleave', () => {
        clearTimeout(hoverTimer);
        stopPreview();
    });
})();
</script>

<?php /* ==================== F2: Banner Reklam (footer üstü, sadece ana sayfa) ==================== */ ?>
<?php $homeBanners = Store::getActiveBannerAds(); ?>
<?php if (!empty($homeBanners)): ?>
<section id="neontv-banner-ad" style="display:none;max-width:1200px;margin:2rem auto 1.5rem;padding:0 1rem;">
    <div style="position:relative;">
        <?php foreach ($homeBanners as $i => $bn): ?>
        <a href="<?= e($bn['click_url']) ?>" target="_blank" rel="noopener noreferrer sponsored"
           class="neontv-banner-item" data-ad-id="<?= e($bn['id']) ?>"
           style="display:none;line-height:0;">
            <img src="<?= e($bn['gif_url']) ?>" alt="Reklam" loading="lazy" style="width:100%;height:auto;display:block;border-radius:0.75rem;">
        </a>
        <?php endforeach; ?>
    </div>
    <div style="font-size:10px;color:#6b7280;text-align:right;margin-top:4px;letter-spacing:.05em;">Reklam</div>
</section>
<script>
(function () {
    const box = document.getElementById('neontv-banner-ad');
    if (!box) return;
    const items = Array.from(box.querySelectorAll('.neontv-banner-item'));
    if (!items.length) return;

    function getToken() {
        try {
            for (let i = 0; i < localStorage.length; i++) {
                const k = localStorage.key(i);
                if (k && k.startsWith('sb-') && k.endsWith('-auth-token')) {
                    return (JSON.parse(localStorage.getItem(k) || '{}') || {}).access_token || null;
                }
            }
        } catch (e) {}
        return null;
    }
    function stat(adId, type) {
        try {
            fetch('<?= APP_URL ?>/api/ads.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ ad_id: adId, stat: type }),
                keepalive: true
            }).catch(() => {});
        } catch (e) {}
    }

    let cur = Math.floor(Math.random() * items.length);
    function showItem(i) {
        items.forEach((el, idx) => { el.style.display = idx === i ? 'block' : 'none'; });
        stat(items[i].dataset.adId, 'impressions');
    }
    items.forEach(el => el.addEventListener('click', () => stat(el.dataset.adId, 'clicks')));

    function start() {
        box.style.display = 'block';
        showItem(cur);
        if (items.length > 1) {
            setInterval(() => { cur = (cur + 1) % items.length; showItem(cur); }, 6000);
        }
    }

    // Misafir -> göster. Giriş yapmış -> premium ise gizle, değilse göster.
    const token = getToken();
    if (!token) { start(); return; }
    fetch('<?= APP_URL ?>/api/auth.php?token=' + encodeURIComponent(token), { headers: { 'Authorization': 'Bearer ' + token, 'X-Access-Token': token } })
        .then(r => r.ok ? r.json() : null)
        .then(j => { if (!(j && j.data && j.data.is_premium)) start(); })
        .catch(() => start());
})();
</script>
<?php endif; ?>

<?php include __DIR__ . '/components/footer.php'; ?>
