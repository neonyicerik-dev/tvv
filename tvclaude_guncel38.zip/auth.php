<?php
// ============================================================
// NeonTV - Kullanıcı Giriş / Kayıt Sayfası
// ============================================================
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/helpers.php';

$tab       = in_array($_GET['tab'] ?? 'login', ['login', 'register']) ? $_GET['tab'] : 'login';
$pageTitle = $tab === 'register' ? 'Kayıt Ol' : 'Giriş Yap';
$metaDesc  = 'NeonTV hesabınıza giriş yapın veya yeni hesap oluşturun.';
?>
<?php include __DIR__ . '/components/header.php'; ?>

<div class="min-h-[calc(100vh-4rem)] flex items-center justify-center px-4 py-12">
    <div class="w-full max-w-md">

        <!-- Logo -->
        <div class="text-center mb-8">
            <a href="<?= APP_URL ?>/index.php" class="inline-flex items-center gap-2 mb-4">
                <i class="fa-solid fa-tv text-3xl" style="color:#00f5ff;filter:drop-shadow(0 0 10px #00f5ff);"></i>
                <span class="text-2xl font-bold" style="background:linear-gradient(135deg,#00f5ff,#bf00ff);-webkit-background-clip:text;-webkit-text-fill-color:transparent;">
                    NeonTV
                </span>
            </a>
            <p class="text-gray-500 text-sm">Yorumlamak ve beğenmek için hesap oluşturun</p>
        </div>

        <!-- Card -->
        <div class="rounded-2xl p-8 shadow-2xl" style="background:#13131f;border:1px solid rgba(255,255,255,0.08);">

            <!-- Tab Seçici -->
            <div class="flex rounded-xl p-1 mb-6" style="background:rgba(255,255,255,0.04);">
                <button id="tab-login-btn" onclick="switchTab('login')"
                        class="flex-1 py-2.5 rounded-lg text-sm font-semibold transition-all duration-200 <?= $tab === 'login' ? 'text-black' : 'text-gray-500 hover:text-white' ?>"
                        style="<?= $tab === 'login' ? 'background:linear-gradient(135deg,#00f5ff,#bf00ff);' : '' ?>">
                    <i class="fa-solid fa-right-to-bracket mr-2"></i>Giris Yap
                </button>
                <button id="tab-register-btn" onclick="switchTab('register')"
                        class="flex-1 py-2.5 rounded-lg text-sm font-semibold transition-all duration-200 <?= $tab === 'register' ? 'text-black' : 'text-gray-500 hover:text-white' ?>"
                        style="<?= $tab === 'register' ? 'background:linear-gradient(135deg,#00f5ff,#bf00ff);' : '' ?>">
                    <i class="fa-solid fa-user-plus mr-2"></i>Kayit Ol
                </button>
            </div>

            <!-- Hata / Başarı Mesajı -->
            <div id="auth-message" class="hidden mb-4 px-4 py-3 rounded-xl text-sm border"></div>

            <!-- ===== GİRİŞ FORMU ===== -->
            <form id="login-form" class="<?= $tab !== 'login' ? 'hidden' : '' ?> space-y-4" onsubmit="handleLogin(event)">
                <div>
                    <label class="block text-xs font-semibold text-gray-400 mb-1.5 uppercase tracking-wider">
                        <i class="fa-solid fa-envelope mr-1"></i>E-posta
                    </label>
                    <input type="email" id="login-email" name="email"
                           placeholder="ornek@email.com"
                           required autocomplete="email"
                           class="w-full px-4 py-3 rounded-xl text-sm text-white placeholder-gray-600 outline-none transition-all duration-200"
                           style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);"
                           onfocus="this.style.borderColor='rgba(0,245,255,0.5)'"
                           onblur="this.style.borderColor='rgba(255,255,255,0.1)'">
                </div>

                <div>
                    <label class="block text-xs font-semibold text-gray-400 mb-1.5 uppercase tracking-wider">
                        <i class="fa-solid fa-lock mr-1"></i>Sifre
                    </label>
                    <div class="relative">
                        <input type="password" id="login-password" name="password"
                               placeholder="••••••••"
                               required autocomplete="current-password"
                               class="w-full px-4 py-3 pr-12 rounded-xl text-sm text-white placeholder-gray-600 outline-none transition-all duration-200"
                               style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);"
                               onfocus="this.style.borderColor='rgba(0,245,255,0.5)'"
                               onblur="this.style.borderColor='rgba(255,255,255,0.1)'">
                        <button type="button" onclick="togglePass('login-password', this)"
                                class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300 transition-colors">
                            <i class="fa-regular fa-eye"></i>
                        </button>
                    </div>
                </div>

                <button type="submit" id="login-submit-btn"
                        class="w-full py-3 rounded-xl font-bold text-black text-sm transition-all duration-300 hover:scale-[1.02] hover:shadow-lg flex items-center justify-center gap-2"
                        style="background:linear-gradient(135deg,#00f5ff,#bf00ff);box-shadow:0 0 20px rgba(0,245,255,0.2);">
                    <i class="fa-solid fa-right-to-bracket"></i>
                    Giris Yap
                </button>
            </form>

            <!-- ===== KAYIT FORMU ===== -->
            <form id="register-form" class="<?= $tab !== 'register' ? 'hidden' : '' ?> space-y-4" onsubmit="handleRegister(event)">
                <div>
                    <label class="block text-xs font-semibold text-gray-400 mb-1.5 uppercase tracking-wider">
                        <i class="fa-solid fa-user mr-1"></i>Kullanici Adi
                    </label>
                    <input type="text" id="register-username" name="username"
                           placeholder="kullanici_adi"
                           required minlength="3" maxlength="30"
                           pattern="[a-zA-Z0-9_]+"
                           class="w-full px-4 py-3 rounded-xl text-sm text-white placeholder-gray-600 outline-none transition-all duration-200"
                           style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);"
                           onfocus="this.style.borderColor='rgba(0,245,255,0.5)'"
                           onblur="this.style.borderColor='rgba(255,255,255,0.1)'">
                    <p class="text-xs text-gray-600 mt-1">Sadece harf, rakam ve alt çizgi</p>
                </div>

                <div>
                    <label class="block text-xs font-semibold text-gray-400 mb-1.5 uppercase tracking-wider">
                        <i class="fa-solid fa-envelope mr-1"></i>E-posta
                    </label>
                    <input type="email" id="register-email" name="email"
                           placeholder="ornek@email.com"
                           required autocomplete="email"
                           class="w-full px-4 py-3 rounded-xl text-sm text-white placeholder-gray-600 outline-none transition-all duration-200"
                           style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);"
                           onfocus="this.style.borderColor='rgba(0,245,255,0.5)'"
                           onblur="this.style.borderColor='rgba(255,255,255,0.1)'">
                </div>

                <div>
                    <label class="block text-xs font-semibold text-gray-400 mb-1.5 uppercase tracking-wider">
                        <i class="fa-solid fa-lock mr-1"></i>Sifre
                    </label>
                    <div class="relative">
                        <input type="password" id="register-password" name="password"
                               placeholder="En az 6 karakter"
                               required minlength="6" autocomplete="new-password"
                               class="w-full px-4 py-3 pr-12 rounded-xl text-sm text-white placeholder-gray-600 outline-none transition-all duration-200"
                               style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);"
                               onfocus="this.style.borderColor='rgba(0,245,255,0.5)'"
                               onblur="this.style.borderColor='rgba(255,255,255,0.1)'">
                        <button type="button" onclick="togglePass('register-password', this)"
                                class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300 transition-colors">
                            <i class="fa-regular fa-eye"></i>
                        </button>
                    </div>
                </div>

                <button type="submit" id="register-submit-btn"
                        class="w-full py-3 rounded-xl font-bold text-black text-sm transition-all duration-300 hover:scale-[1.02] hover:shadow-lg flex items-center justify-center gap-2"
                        style="background:linear-gradient(135deg,#00f5ff,#bf00ff);box-shadow:0 0 20px rgba(0,245,255,0.2);">
                    <i class="fa-solid fa-user-plus"></i>
                    Kayit Ol
                </button>

                <p class="text-xs text-gray-600 text-center">
                    Kayıt olarak hizmet şartlarımızı kabul etmiş olursunuz.
                </p>
            </form>

        </div>

        <!-- Alt Link -->
        <p class="text-center text-sm text-gray-600 mt-6">
            <a href="<?= APP_URL ?>/index.php" class="hover:text-gray-400 transition-colors flex items-center justify-center gap-1">
                <i class="fa-solid fa-arrow-left text-xs"></i>
                Ana sayfaya dön
            </a>
        </p>

    </div>
</div>

<script>
function switchTab(tab) {
    const isLogin = tab === 'login';

    document.getElementById('login-form').classList.toggle('hidden', !isLogin);
    document.getElementById('register-form').classList.toggle('hidden', isLogin);

    const loginBtn    = document.getElementById('tab-login-btn');
    const registerBtn = document.getElementById('tab-register-btn');

    const activeStyle   = 'background:linear-gradient(135deg,#00f5ff,#bf00ff);';
    const inactiveStyle = '';

    loginBtn.style.cssText    = isLogin ? activeStyle : inactiveStyle;
    registerBtn.style.cssText = !isLogin ? activeStyle : inactiveStyle;

    loginBtn.classList.toggle('text-black',   isLogin);
    loginBtn.classList.toggle('text-gray-500', !isLogin);
    registerBtn.classList.toggle('text-black',   !isLogin);
    registerBtn.classList.toggle('text-gray-500', isLogin);

    document.getElementById('auth-message').classList.add('hidden');
    history.replaceState(null, '', `?tab=${tab}`);
}

function showMsg(text, type) {
    const el = document.getElementById('auth-message');
    const colors = {
        success: 'bg-green-500/10 border-green-500/30 text-green-400',
        error:   'bg-red-500/10 border-red-500/30 text-red-400',
    };
    el.className = `mb-4 px-4 py-3 rounded-xl text-sm border ${colors[type] || colors.error}`;
    el.innerHTML = `<i class="fa-solid fa-${type === 'success' ? 'circle-check' : 'circle-xmark'} mr-2"></i>${text}`;
    el.classList.remove('hidden');
}

function togglePass(inputId, btn) {
    const input = document.getElementById(inputId);
    const isPass = input.type === 'password';
    input.type = isPass ? 'text' : 'password';
    btn.innerHTML = `<i class="fa-regular fa-${isPass ? 'eye-slash' : 'eye'}"></i>`;
}

    // Zaten giriş yapılmışsa ana sayfaya yönlendir
    document.addEventListener('DOMContentLoaded', () => {
        (async function checkExistingSession() {
            if (typeof sbClient !== 'undefined') {
                const { data: { session } } = await sbClient.auth.getSession();
                if (session) {
                    window.location.href = '<?= APP_URL ?>/index.php';
                }
            }
        })();
    });

    async function handleLogin(e) {
    e.preventDefault();
    const btn = document.getElementById('login-submit-btn');
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Giris yapiliyor...';

    const email    = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;

    const resetBtn = () => { btn.disabled = false; btn.innerHTML = '<i class="fa-solid fa-right-to-bracket"></i> Giris Yap'; };
    let res = null;
    try {
        // Sunucu taraflı giriş: hız sınırı + yeni cihaz uyarısı
        const r = await fetch('<?= APP_URL ?>/api/login.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password }) });
        let j = null; try { j = await r.json(); } catch (x) {}
        res = { status: r.status, json: j };
    } catch (err) { res = null; }

    if (res && res.json && res.json.success && res.json.data && res.json.data.access_token) {
        const d = res.json.data;
        const { error: sErr } = await sbClient.auth.setSession({ access_token: d.access_token, refresh_token: d.refresh_token });
        if (!sErr) {
            showMsg(d.new_device ? 'Giris basarili! Bu cihazdan ilk kez giriş yaptın; bildirimlerini kontrol et.' : 'Giris basarili! Yönlendiriliyor...', 'success');
            setTimeout(() => window.location.href = '<?= APP_URL ?>/index.php', d.new_device ? 1800 : 1000);
            return;
        }
        showMsg('Oturum açılamadı. Lütfen tekrar deneyin.', 'error'); resetBtn(); return;
    }
    if (res && (res.status === 401 || res.status === 429)) {
        showMsg((res.json && res.json.message) || 'E-posta veya sifre hatalı.', 'error'); resetBtn(); return;
    }
    // Sunucu girişi ulaşılamazsa (ağ hatası/404/5xx) doğrudan girişe dön
    const { data, error } = await sbClient.auth.signInWithPassword({ email, password });
    if (error) { showMsg('E-posta veya sifre hatalı.', 'error'); resetBtn(); }
    else { showMsg('Giris basarili! Yönlendiriliyor...', 'success'); setTimeout(() => window.location.href = '<?= APP_URL ?>/index.php', 1000); }
}

async function handleRegister(e) {
    e.preventDefault();
    const btn = document.getElementById('register-submit-btn');
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Kayit yapiliyor...';

    const username = document.getElementById('register-username').value.trim();
    const email    = document.getElementById('register-email').value;
    const password = document.getElementById('register-password').value;

    if (!/^[a-zA-Z0-9_]{3,30}$/.test(username)) {
        showMsg('Kullanici adi sadece harf, rakam ve _ icermelidir (3-30 karakter).', 'error');
        btn.disabled = false;
        btn.innerHTML = '<i class="fa-solid fa-user-plus"></i> Kayit Ol';
        return;
    }

    const { data, error } = await sbClient.auth.signUp({
        email, password,
        options: { data: { username } }
    });

    if (error) {
        showMsg(error.message === 'User already registered' ? 'Bu e-posta adresi zaten kayıtlı.' : 'Kayıt başarısız. Lütfen tekrar deneyin.', 'error');
        btn.disabled = false;
        btn.innerHTML = '<i class="fa-solid fa-user-plus"></i> Kayit Ol';
    } else {
        showMsg('Kayit basarili! E-postanizi kontrol edin (doğrulama gerekebilir).', 'success');
        setTimeout(() => switchTab('login'), 2000);
        btn.disabled = false;
        btn.innerHTML = '<i class="fa-solid fa-user-plus"></i> Kayit Ol';
    }
}
</script>

<?php include __DIR__ . '/components/footer.php'; ?>
