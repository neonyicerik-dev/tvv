-- ============================================================
-- NeonTV – Özellikler 9 (Kasım 2026)
--  • Yorum sabitleme (comments.is_pinned)
--  • Girişi atla (videos.intro_end, saniye)
--  • Takip sistemi (user_follows)
--  • Web push abonelikleri (push_subscriptions)
-- Yeni tablolar: RLS açık, anon/authenticated kapalı, yalnızca service_role.
-- ============================================================

ALTER TABLE public.comments ADD COLUMN IF NOT EXISTS is_pinned boolean NOT NULL DEFAULT false;
CREATE INDEX IF NOT EXISTS comments_pinned_idx ON public.comments (video_id) WHERE is_pinned;

ALTER TABLE public.videos ADD COLUMN IF NOT EXISTS intro_end integer;

CREATE TABLE IF NOT EXISTS public.user_follows (
    follower_id  uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    following_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    created_at   timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (follower_id, following_id),
    CHECK (follower_id <> following_id)
);
CREATE INDEX IF NOT EXISTS user_follows_following_idx ON public.user_follows (following_id);
ALTER TABLE public.user_follows ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.user_follows FROM anon, authenticated;
GRANT ALL ON public.user_follows TO service_role;

CREATE TABLE IF NOT EXISTS public.push_subscriptions (
    id         bigserial PRIMARY KEY,
    user_id    uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    endpoint   text NOT NULL UNIQUE,
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS push_subscriptions_user_idx ON public.push_subscriptions (user_id);
ALTER TABLE public.push_subscriptions ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.push_subscriptions FROM anon, authenticated;
GRANT ALL ON public.push_subscriptions TO service_role;
GRANT USAGE, SELECT ON SEQUENCE public.push_subscriptions_id_seq TO service_role;
