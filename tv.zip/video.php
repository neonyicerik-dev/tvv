<?php
// ============================================================
// NeonTV - Video İzleme Sayfası
// ============================================================
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/supabase.php';
require_once __DIR__ . '/includes/store.php';

if (isMaintenanceMode() && !isAdminLoggedIn()) {
    die('<!DOCTYPE html><html><head><meta charset="utf-8"><title>Bakım Modu</title><style>body{background:#070711;color:#fff;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;text-align:center;padding:20px;}h1{color:#00f5ff;}</style></head><body><div><h1>Bakım Modu</h1><p>' . htmlspecialchars(getMaintenanceMessage()) . '</p></div></body></html>');
}

// Zamanlanmış videoları yayınla
publishScheduledVideos();

// IP Engel Kontrolü
if (isIpBlocked()) {
    http_response_code(403);
    die('<!DOCTYPE html><html><head><meta charset="utf-8"><title>Erisim Engellendi</title><style>body{background:#070711;color:#fff;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;text-align:center;}h1{color:#ff007a;}</style></head><body><div><h1>🚫 Erisim Engellendi</h1><p>IP adresiniz bu platforma erişim engellenmiştir.</p></div></body></html>');
}

// Ziyareti kaydet
logVisit();

$videoId = trim($_GET['id'] ?? '');
if (!$videoId || !preg_match('/^[0-9a-f\-]{36}$/', $videoId)) {
    header('Location: ' . APP_URL . '/index.php');
    exit;
}

$db    = new Supabase();
$videoRes = $db->select('videos', 'id=eq.' . $videoId . '&status=eq.published&select=*,channels(*)');
$video = $videoRes['data'][0] ?? null;

if (!$video) {
    require_once __DIR__ . '/404.php';
    exit;
}

// @Etiketleme Parser Fonksiyonu
function parseMentions($text) {
    return renderCommentText((string)$text);
}


// Premium erken erişim: tarih gelene kadar yalnızca premium üyeler izler (kaynak URL sayfaya yazılmaz)
$earlyLocked = !empty($video['premium_only_until']) && strtotime($video['premium_only_until']) > time();

// Subtitle
$subtitle = $db->first('subtitles', 'video_id=eq.' . $videoId . '&language=eq.tr');

// Chapters
$chaptersRes = $db->select('chapters', 'video_id=eq.' . $videoId . '&order=start_time.asc', true);
$chapters    = $chaptersRes['data'] ?? [];

// İlgili videolar
$relatedVideos = Store::remember('related_' . $videoId, 60, function () use ($db, $videoId) {
    $r = $db->select('videos', 'status=eq.published&id=neq.' . $videoId . '&order=views.desc&limit=8');
    return is_array($r['data'] ?? null) ? $r['data'] : [];
});

// Yorumları çek ve ağaç yapısı oluştur (Nested Comments)
$commentsRes = $db->select('comments',
    'video_id=eq.' . $videoId . '&order=created_at.asc&select=*,profiles(username,avatar_url)'
);
$commentsRaw = $commentsRes['data'] ?? [];
$commentTree = [];
foreach ($commentsRaw as $c) {
    if (!$c['parent_id']) $commentTree[$c['id']] = ['comment' => $c, 'replies' => []];
}
foreach ($commentsRaw as $c) {
    if ($c['parent_id'] && isset($commentTree[$c['parent_id']])) {
        $commentTree[$c['parent_id']]['replies'][] = $c;
    }
}
// Yorum sahiplerinden premium olanlar (rozet için)
$premiumUsers = Store::getPremiumUserIds(array_column($commentsRaw, 'user_id'));
require_once __DIR__ . '/includes/themes.php';
$needThemes = true;
$commentFrames = Store::getUserThemes(array_column($commentsRaw, 'user_id'), $premiumUsers);
$premiumBadge = '<span class="inline-flex items-center gap-1 text-[10px] font-bold px-1.5 py-0.5 rounded-full" style="background:linear-gradient(135deg,#ffd76a,#ff9d00);color:#000;"><i class="fa-solid fa-crown text-[8px]"></i>Premium</span>';

// Yorum beğeni sayıları
$commentLikeCounts = [];
$cids = array_values(array_filter(array_column($commentsRaw, 'id'), 'isUuid'));
if ($cids) {
    foreach (($db->select('comment_likes', 'comment_id=in.(' . implode(',', $cids) . ')&select=comment_id&limit=20000', true)['data'] ?? []) as $cl) {
        $commentLikeCounts[$cl['comment_id']] = ($commentLikeCounts[$cl['comment_id']] ?? 0) + 1;
    }
}
// Kök yorumlar: en çok beğenilen (en az 1 beğeni) en üstte sabit, kalanlar yeniden eskiye
usort($commentTree, fn($a, $b) => strtotime($b['comment']['created_at']) - strtotime($a['comment']['created_at']));
$pinnedId = '';
foreach ($commentTree as $it) { if (!empty($it['comment']['is_pinned'])) { $pinnedId = $it['comment']['id']; break; } }
$isAdminViewer = isAdminLoggedIn();
$topCommentId = '';
if ($commentLikeCounts) {
    $best = 0;
    foreach ($commentTree as $it) { $n = $commentLikeCounts[$it['comment']['id']] ?? 0; if ($n > $best) { $best = $n; $topCommentId = $it['comment']['id']; } }
    if ($topCommentId) {
        usort($commentTree, fn($a, $b) => (($b['comment']['id'] === $topCommentId) <=> ($a['comment']['id'] === $topCommentId)));
    }
}
if ($pinnedId) usort($commentTree, fn($a, $b) => (($b['comment']['id'] === $pinnedId) <=> ($a['comment']['id'] === $pinnedId)));
function commentLikeBtn(string $id, array $counts): string {
    $n = (int)($counts[$id] ?? 0);
    return '<button type="button" class="clike-btn text-xs text-gray-500 hover:text-pink-400 mt-2 mr-3 font-semibold transition-colors" data-id="' . e($id) . '"><i class="fa-regular fa-heart mr-1"></i><span class="clike-n">' . $n . '</span></button><div class="creact flex flex-wrap items-center gap-1 mt-1" data-id="' . e($id) . '"></div>';
}


$pageTitle = $video['title'];
$metaDesc  = truncate($video['description'] ?? 'NeonTV videosunu izleyin.', 160);
$ogImage   = $video['thumbnail_url'] ?? '';
?>
<?php include __DIR__ . '/components/header.php'; ?>

<!-- Player Page Styles -->
<style>
#player-container {
    position: relative;
    background: #000;
    border-radius: 1rem;
    overflow: hidden;
    box-shadow: 0 0 60px rgba(0, 245, 255, 0.08), 0 0 0 1px rgba(255,255,255,0.06);
}

/* Controls overlay */
#video-controls {
    position: absolute;
    inset: 0;
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
    opacity: 0;
    transition: opacity 0.35s ease;
    background: linear-gradient(to top,
        rgba(0,0,0,0.9) 0%,
        rgba(0,0,0,0.3) 40%,
        transparent 70%
    );
    pointer-events: none;
}
#video-controls > * {
    pointer-events: auto;
}
#player-container:hover #video-controls,
#player-container.controls-visible #video-controls {
    opacity: 1;
}

/* Progress Bar */
.cgif { max-height:170px; max-width:100%; border-radius:12px; display:block; margin-top:6px; }
.ts-link { cursor:pointer; }
#progress-container {
    position: relative;
    height: 4px;
    border-radius: 4px;
    cursor: pointer;
    transition: height 0.2s;
    background: rgba(255,255,255,0.2);
}
#progress-container:hover {
    height: 6px;
}
#progress-bar {
    position: absolute;
    top: 0; left: 0; height: 100%;
    border-radius: 4px;
    background: linear-gradient(90deg, #00f5ff, #bf00ff);
    width: 0%;
    transition: width 0.1s linear;
}
#progress-buffered {
    position: absolute;
    top: 0; left: 0; height: 100%;
    border-radius: 4px;
    background: rgba(255,255,255,0.25);
    width: 0%;
}
#progress-thumb {
    position: absolute;
    top: 50%;
    transform: translateY(-50%) translateX(-50%);
    width: 14px; height: 14px;
    border-radius: 50%;
    background: #fff;
    box-shadow: 0 0 8px rgba(0,245,255,0.6);
    opacity: 0;
    transition: opacity 0.2s;
    pointer-events: none;
    left: 0%;
}
#progress-container:hover #progress-thumb { opacity: 1; }

/* Time tooltip */
#time-tooltip {
    position: absolute;
    bottom: 14px;
    background: rgba(0,0,0,0.85);
    color: #fff;
    font-size: 11px;
    padding: 3px 8px;
    border-radius: 6px;
    pointer-events: none;
    display: none;
    white-space: nowrap;
    border: 1px solid rgba(255,255,255,0.1);
}

/* Control buttons */
.ctrl-btn {
    background: transparent;
    border: none;
    color: rgba(255,255,255,0.85);
    cursor: pointer;
    padding: 0.4rem;
    border-radius: 0.5rem;
    transition: color 0.15s, background 0.15s, transform 0.15s;
    line-height: 1;
    display: flex; align-items: center; justify-content: center;
}
.ctrl-btn:hover {
    color: #00f5ff;
    background: rgba(0,245,255,0.1);
    transform: scale(1.1);
}
.ctrl-btn.active { color: #00f5ff; }

/* Volume slider */
#volume-slider {
    -webkit-appearance: none;
    appearance: none;
    height: 3px;
    border-radius: 2px;
    background: rgba(255,255,255,0.3);
    outline: none;
    width: 0;
    transition: width 0.3s ease;
    cursor: pointer;
}
#volume-slider::-webkit-slider-thumb {
    -webkit-appearance: none;
    width: 12px; height: 12px;
    border-radius: 50%;
    background: #00f5ff;
    cursor: pointer;
    box-shadow: 0 0 6px rgba(0,245,255,0.5);
}
.vol-group:hover #volume-slider { width: 80px; }

/* Speed menu */
.speed-menu {
    position: absolute;
    bottom: calc(100% + 8px);
    right: 0;
    background: #13131f;
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 0.75rem;
    padding: 4px;
    display: none;
    z-index: 50;
    min-width: 72px;
    box-shadow: 0 8px 32px rgba(0,0,0,0.5);
}
.speed-group:hover .speed-menu { display: block; }
.speed-opt {
    display: block;
    width: 100%;
    padding: 6px 12px;
    text-align: center;
    font-size: 12px;
    font-family: monospace;
    color: #9ca3af;
    background: none;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    transition: all 0.15s;
}
.speed-opt:hover { background: rgba(255,255,255,0.08); color: #fff; }
.speed-opt.active { color: #00f5ff; font-weight: bold; }

/* Big play button */
#big-play-btn {
    position: absolute;
    inset: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: opacity 0.3s;
}
.big-play-circle {
    width: 76px; height: 76px;
    border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    background: rgba(0,0,0,0.5);
    backdrop-filter: blur(10px);
    border: 2px solid rgba(0,245,255,0.5);
    box-shadow: 0 0 30px rgba(0,245,255,0.2), inset 0 0 20px rgba(0,245,255,0.05);
    transition: transform 0.2s, box-shadow 0.2s;
}
#big-play-btn:hover .big-play-circle {
    transform: scale(1.1);
    box-shadow: 0 0 50px rgba(0,245,255,0.35), inset 0 0 20px rgba(0,245,255,0.08);
}

/* Skip ripple */
@keyframes skip-ripple {
    0%   { opacity: 1; transform: scale(0.7); }
    100% { opacity: 0; transform: scale(2); }
}
.skip-ripple {
    position: absolute;
    top: 50%; left: 50%;
    transform: translate(-50%, -50%);
    width: 60px; height: 60px;
    border-radius: 50%;
    background: rgba(0,245,255,0.15);
    animation: skip-ripple 0.6s ease-out forwards;
    pointer-events: none;
}

/* Theater mode */
.theater-mode #player-container { border-radius: 0; }

/* Subtitle styles */
video::cue {
    font-family: 'Outfit', sans-serif;
    font-size: 1em;
    background: rgba(0,0,0,0.8);
    color: #fff;
    padding: 2px 8px;
    border-radius: 4px;
    line-height: 1.5;
}
#main-video::-webkit-media-text-track-container {
    transform: translateY(-30px) !important;
}

/* #12 Chapter markers on progress bar */
.chapter-marker {
    position: absolute;
    top: 0; bottom: 0;
    width: 2px;
    background: rgba(255,255,255,0.5);
    border-radius: 2px;
    pointer-events: none;
    z-index: 2;
    transition: background 0.2s;
}
.chapter-marker:hover { background: #00f5ff; }

/* #13 Mini Player */
#mini-player {
    position: fixed;
    bottom: 20px;
    right: 20px;
    width: 320px;
    background: #0d0d1a;
    border-radius: 14px;
    overflow: hidden;
    box-shadow: 0 8px 40px rgba(0,0,0,0.7), 0 0 0 1px rgba(0,245,255,0.15);
    z-index: 9999;
    transition: transform 0.3s ease, opacity 0.3s ease;
}
#mini-player video {
    width: 100%;
    display: block;
    aspect-ratio: 16/9;
    background: #000;
}
.mini-player-controls {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 8px 12px;
    gap: 8px;
    background: rgba(13,13,26,0.95);
}

/* #5 Resume Banner */
#resume-banner {
    position: absolute;
    bottom: 70px;
    left: 50%;
    transform: translateX(-50%);
    background: rgba(13,13,26,0.92);
    border: 1px solid rgba(0,245,255,0.3);
    border-radius: 12px;
    padding: 10px 16px;
    display: flex;
    align-items: center;
    gap: 12px;
    z-index: 30;
    white-space: nowrap;
    backdrop-filter: blur(10px);
    box-shadow: 0 4px 24px rgba(0,0,0,0.5);
}

/* #3 Shortcut Modal */
#shortcut-modal {
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,0.75);
    backdrop-filter: blur(8px);
    z-index: 99999;
    display: flex;
    align-items: center;
    justify-content: center;
}
.shortcut-grid {
    display: grid;
    grid-template-columns: auto 1fr;
    gap: 8px 20px;
    align-items: center;
}
.shortcut-key {
    background: rgba(255,255,255,0.1);
    border: 1px solid rgba(255,255,255,0.15);
    border-radius: 6px;
    padding: 3px 10px;
    font-family: monospace;
    font-size: 12px;
    color: #00f5ff;
    text-align: center;
    white-space: nowrap;
}

/* #12 Chapters panel */
#chapters-panel {
    position: absolute;
    bottom: 70px;
    right: 12px;
    width: 260px;
    background: rgba(13,13,26,0.97);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 14px;
    overflow: hidden;
    z-index: 40;
    box-shadow: 0 8px 32px rgba(0,0,0,0.6);
    backdrop-filter: blur(20px);
    max-height: 280px;
    overflow-y: auto;
}
.chapter-item {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 10px 14px;
    cursor: pointer;
    transition: background 0.15s;
    border-bottom: 1px solid rgba(255,255,255,0.04);
}
.chapter-item:hover { background: rgba(0,245,255,0.06); }
.chapter-item.active { background: rgba(0,245,255,0.1); }
.chapter-item .chapter-time {
    font-size: 11px;
    font-family: monospace;
    color: #00f5ff;
    flex-shrink: 0;
}
.chapter-item .chapter-title {
    font-size: 13px;
    color: #e5e7eb;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
}

/* #9 Video Zoom */
#main-video.zoom-active {
    cursor: grab;
    transform-origin: center center;
    transition: transform 0.2s ease;
}
#main-video.zoom-active.dragging { cursor: grabbing; }
#zoom-indicator {
    position: absolute;
    top: 12px;
    left: 12px;
    background: rgba(0,0,0,0.75);
    color: #00f5ff;
    font-size: 11px;
    font-family: monospace;
    padding: 3px 9px;
    border-radius: 6px;
    pointer-events: none;
    opacity: 0;
    transition: opacity 0.3s;
    border: 1px solid rgba(0,245,255,0.2);
}
#zoom-indicator.visible { opacity: 1; }

/* #10 Screenshot Toast */
#screenshot-toast {
    position: fixed;
    bottom: 28px;
    left: 50%;
    transform: translateX(-50%) translateY(20px);
    background: rgba(13,13,26,0.95);
    border: 1px solid rgba(0,245,255,0.3);
    color: #fff;
    font-size: 13px;
    padding: 10px 20px;
    border-radius: 12px;
    z-index: 99999;
    opacity: 0;
    transition: all 0.3s ease;
    pointer-events: none;
    backdrop-filter: blur(16px);
    box-shadow: 0 8px 32px rgba(0,0,0,0.5);
    white-space: nowrap;
}
#screenshot-toast.show {
    opacity: 1;
    transform: translateX(-50%) translateY(0);
}

/* #30 Queue Panel */
#queue-panel {
    background: rgba(13,13,26,0.8);
    border: 1px solid rgba(255,255,255,0.08);
    border-radius: 16px;
    overflow: hidden;
    margin-top: 16px;
}
.queue-item {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 10px 14px;
    border-bottom: 1px solid rgba(255,255,255,0.04);
    cursor: grab;
    transition: background 0.15s;
}
.queue-item:hover { background: rgba(255,255,255,0.04); }
.queue-item:last-child { border-bottom: none; }
.queue-item.dragging-item { opacity: 0.4; }


/* ===== Liquid glass oynatıcı ===== */
#video-controls{background:linear-gradient(to top,rgba(0,0,0,.55) 0%,rgba(0,0,0,.12) 38%,transparent 62%)}
.glass-bar,#settings-panel,#chapters-panel,.glass-card{
    background:linear-gradient(135deg,rgba(255,255,255,.16),rgba(255,255,255,.05) 55%,rgba(255,255,255,.1));
    -webkit-backdrop-filter:blur(22px) saturate(180%) brightness(1.05);backdrop-filter:blur(22px) saturate(180%) brightness(1.05);
    border:1px solid rgba(255,255,255,.26);
    box-shadow:inset 0 1px 0 rgba(255,255,255,.55),inset 0 -1px 0 rgba(255,255,255,.08),inset 0 0 18px rgba(255,255,255,.05),0 10px 34px rgba(0,0,0,.45);
}
.glass-bar{margin:0 12px 12px;border-radius:22px;position:relative;overflow:hidden}
.glass-bar::before{content:"";position:absolute;inset:0;border-radius:inherit;pointer-events:none;background:radial-gradient(120% 90% at 15% -20%,rgba(255,255,255,.22),transparent 55%)}
.glass-bar>*{position:relative}
#progress-container{height:5px;background:rgba(255,255,255,.28)}
#progress-container:hover{height:7px}
#progress-buffered{background:rgba(255,255,255,.35)}
.ctrl-btn{border-radius:50%;color:#fff}
.ctrl-btn:hover{background:rgba(255,255,255,.2);color:#fff;transform:scale(1.08);box-shadow:inset 0 1px 0 rgba(255,255,255,.4)}
.ctrl-btn.active{color:#7df9ff;background:rgba(0,245,255,.16)}
#settings-btn[aria-expanded="true"] #settings-icon{transform:rotate(60deg)}
#settings-icon{transition:transform .35s cubic-bezier(.34,1.56,.64,1)}
.big-play-circle{background:linear-gradient(135deg,rgba(255,255,255,.22),rgba(255,255,255,.06));-webkit-backdrop-filter:blur(18px) saturate(180%);backdrop-filter:blur(18px) saturate(180%);border:1px solid rgba(255,255,255,.4);box-shadow:inset 0 1px 0 rgba(255,255,255,.6),0 8px 32px rgba(0,0,0,.4)}
#time-tooltip{background:rgba(20,20,30,.55);-webkit-backdrop-filter:blur(14px);backdrop-filter:blur(14px);border:1px solid rgba(255,255,255,.25)}
#settings-panel{position:absolute;right:14px;bottom:88px;width:268px;max-width:calc(100% - 28px);max-height:calc(100% - 110px);overflow-y:auto;border-radius:22px;padding:8px;z-index:45;
    opacity:0;transform:translateY(10px) scale(.96);transform-origin:bottom right;pointer-events:none;visibility:hidden;transition:opacity .22s,transform .28s cubic-bezier(.34,1.56,.64,1),visibility .22s;scrollbar-width:none}
#settings-panel::-webkit-scrollbar{display:none}
#settings-panel.open{opacity:1;transform:none;pointer-events:auto;visibility:visible}
#chapters-panel{position:absolute;right:14px;bottom:88px;border-radius:22px;z-index:46;background-color:transparent}
.sp-title{font-size:12px;font-weight:700;color:#fff;padding:4px 10px 4px;letter-spacing:.04em;display:flex;gap:8px;align-items:center;opacity:.9}
.sp-sec{padding:4px 8px 6px}
.sp-lbl{display:flex;align-items:center;gap:8px;font-size:12px;color:#e5e7eb;margin-bottom:8px}
.sp-val{margin-left:auto;font:700 12px monospace;color:#7df9ff;background:none;border:0;cursor:default}
.sp-chips{display:flex;flex-wrap:wrap;gap:5px}
.sp-chips button,.sp-chips .speed-opt{width:auto;display:inline-block;padding:5px 10px;border-radius:999px;font-size:11px;font-weight:600;font-family:inherit;color:#e5e7eb;background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.16);cursor:pointer;transition:all .15s}
.sp-chips button:hover{background:rgba(255,255,255,.22);color:#fff}
.sp-chips button.active,.sp-chips .speed-opt.active{background:rgba(0,245,255,.25);border-color:rgba(0,245,255,.6);color:#fff}
.set-row{display:flex;align-items:center;gap:12px;width:100%;padding:7px 12px;border-radius:14px;background:none;border:0;color:#fff;font-size:13px;font-weight:600;cursor:pointer;text-align:left;transition:background .15s}
.set-row:hover{background:rgba(255,255,255,.14)}
.set-row>i:first-child{width:18px;text-align:center;color:#cfd8ff}
.set-row span{flex:1}
.set-row .sp-chev{font-size:10px;opacity:.6}
.set-row .sw{width:34px;height:20px;border-radius:999px;background:rgba(255,255,255,.2);position:relative;transition:background .2s;flex-shrink:0}
.set-row .sw::after{content:"";position:absolute;top:2px;left:2px;width:16px;height:16px;border-radius:50%;background:#fff;box-shadow:0 1px 3px rgba(0,0,0,.4);transition:transform .22s cubic-bezier(.34,1.56,.64,1)}
.set-row.active .sw{background:linear-gradient(135deg,#00f5ff,#7a5cff)}
.set-row.active .sw::after{transform:translateX(14px)}
.set-row.active>i:first-child{color:#7df9ff}
#dl-consent{position:absolute;inset:0;z-index:48;display:flex;align-items:center;justify-content:center;padding:16px;background:rgba(0,0,0,.35);-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px)}
#dl-consent .glass-card{max-width:340px;width:100%;border-radius:26px;padding:22px 20px;text-align:center;color:#fff}
#dl-consent h3{font-size:17px;font-weight:800;margin:8px 0 6px}
#dl-consent p{font-size:12.5px;color:#d1d5db;line-height:1.5;margin-bottom:12px}
#dl-consent .dl-ok{width:100%;padding:11px;border-radius:14px;font-weight:800;font-size:14px;color:#00121a;background:linear-gradient(135deg,#7df9ff,#a78bfa);border:0;cursor:pointer;box-shadow:inset 0 1px 0 rgba(255,255,255,.6),0 6px 20px rgba(0,245,255,.25)}
#dl-consent .dl-no{width:100%;padding:9px;margin-top:8px;border-radius:14px;font-size:13px;font-weight:600;color:#e5e7eb;background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.18);cursor:pointer}
#dl-consent label{display:flex;gap:8px;align-items:center;justify-content:center;font-size:11.5px;color:#cbd5e1;margin-top:10px;cursor:pointer}
@media (max-width:640px){.glass-bar{margin:0 6px 6px;border-radius:18px}#settings-panel{bottom:76px;right:8px}#chapters-panel{bottom:76px;right:8px}}
/* Mobile Player Controls - Taşma Düzeltmesi */
@media (max-width: 640px) {
    #video-controls .flex.items-center.justify-between {
        gap: 1px;
        padding-left: 8px;
        padding-right: 8px;
    }
    .ctrl-btn {
        padding: 0.3rem;
        font-size: 0.8rem;
    }
    .ctrl-btn.w-10 { width: 2rem; height: 2rem; }
    .ctrl-btn.w-8 { width: 1.75rem; height: 1.75rem; }
    .vol-group #volume-slider { display: none; }
    #video-controls .font-mono { font-size: 10px; }
}

@media (max-width: 420px) {
    #theater-btn { display: none !important; }
    .ctrl-btn.w-8 { width: 1.5rem; height: 1.5rem; font-size: 0.7rem; }
    .ctrl-btn.w-10 { width: 1.75rem; height: 1.75rem; }
    .speed-group .ctrl-btn { padding: 0 4px; font-size: 10px; }
    #video-controls .flex.items-center.justify-between {
        padding-left: 4px;
        padding-right: 4px;
    }
}
</style>

<div class="max-w-screen-2xl mx-auto px-4 sm:px-6 py-6" id="video-page">
    <div class="flex flex-col xl:flex-row gap-6">

        <!-- ===== SOL: VİDEO OYNATICI + BİLGİ ===== -->
        <div class="flex-1 min-w-0" id="main-col">

            <!-- Video Player -->
            <div id="player-container" style="aspect-ratio:16/9;">
                <?php if ($earlyLocked): ?>
                <div id="early-lock" style="position:absolute;inset:0;z-index:30;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:16px;background:rgba(7,7,17,0.92);">
                    <i class="fa-solid fa-crown" style="font-size:34px;color:#ffd24d;margin-bottom:10px;"></i>
                    <p class="text-white font-bold mb-1">Premium Erken Erişim</p>
                    <p class="text-gray-400 text-sm mb-3" id="early-lock-text">Bu video <?= e(date('d.m.Y H:i', strtotime($video['premium_only_until']))) ?> tarihinde herkese açılacak.</p>
                    <a href="<?= APP_URL ?>/auth.php" id="early-lock-login" class="px-5 py-2 rounded-full text-sm font-bold text-black" style="background:linear-gradient(135deg,#ffd24d,#ff9a00);">Giriş Yap</a>
                </div>
                <?php endif; ?>
                <video
                    id="main-video"
                    class="w-full h-full"
                    preload="none"
                    poster="<?= e($video['thumbnail_url'] ?? '') ?>"
                    crossorigin="anonymous"
                >
                    <?php if (!$earlyLocked): ?><source src="<?= e($video['video_url']) ?>" type="video/mp4"><?php endif; ?>
                    <?php if ($subtitle): ?>
                    <track
                        kind="subtitles"
                        srclang="tr"
                        label="Türkçe"
                        default
                        src="data:text/vtt;charset=utf-8;base64,<?= base64_encode($subtitle['content']) ?>"
                    >
                    <?php endif; ?>
                    Tarayıcınız video oynatmayı desteklemiyor.
                </video>


                <!-- Autoplay Overlay -->
                <div id="autoplay-overlay" class="hidden absolute inset-0 bg-black/80 backdrop-blur-md z-40 flex flex-col items-center justify-center">
                    <div class="relative flex items-center justify-center mb-6">
                        <svg class="w-20 h-20 transform -rotate-90">
                            <circle cx="40" cy="40" r="36" stroke="currentColor" stroke-width="4" fill="transparent" class="text-gray-700"></circle>
                            <circle cx="40" cy="40" r="36" stroke="currentColor" stroke-width="4" fill="transparent" stroke-dasharray="226.2" stroke-dashoffset="0" class="text-cyan-400" id="autoplay-circle" style="transition: stroke-dashoffset 1s linear;"></circle>
                        </svg>
                        <span class="absolute text-2xl font-bold text-white font-mono" id="autoplay-timer">5</span>
                    </div>
                    <h3 class="text-xl font-bold text-white mb-2">Sıradaki Video Başlıyor</h3>
                    <?php if(!empty($relatedVideos[0])): ?>
                        <p class="text-gray-400 mb-6 truncate max-w-xs text-center"><?= e($relatedVideos[0]['title']) ?></p>
                    <?php endif; ?>
                    <div class="flex gap-4">
                        <button onclick="cancelAutoplay()" class="px-6 py-2.5 rounded-full font-bold text-black bg-gray-300 hover:bg-white transition-colors">İptal</button>
                        <button onclick="playNextVideo()" class="px-6 py-2.5 rounded-full font-bold text-black bg-gradient-to-r from-cyan-400 to-purple-500 hover:scale-105 transition-transform shadow-[0_0_20px_rgba(0,245,255,0.3)]">Hemen Oynat</button>
                    </div>
                </div>

                <!-- Big Play Button -->
                <div id="big-play-btn">
                    <div class="big-play-circle">
                        <i class="fa-solid fa-play text-white text-2xl ml-1" id="big-play-icon"></i>
                    </div>
                </div>

                <!-- Controls Overlay -->
                <div id="video-controls">
                    <div class="glass-bar">
                    <!-- Progress -->
                    <div class="px-4 pb-2 pt-3">
                        <div id="progress-container">
                            <div id="progress-buffered"></div>
                            <div id="progress-bar"></div>
                            <div id="progress-thumb"></div>
                        </div>
                        <div id="time-tooltip">0:00</div>
                    </div>

                    <!-- Control Bar -->
                    <div class="flex items-center justify-between px-3 pb-3 gap-2">
                        <div class="flex items-center gap-1">
                            <!-- Play/Pause -->
                            <button id="play-pause-btn" class="ctrl-btn text-xl w-10 h-10" title="Oynat / Durdur (Space)">
                                <i class="fa-solid fa-play" id="play-icon"></i>
                            </button>

                            <!-- Skip Back -->
                            <button id="skip-back-btn" class="ctrl-btn w-8 h-8 text-sm" title="Geri Al 10s">
                                <i class="fa-solid fa-rotate-left"></i>
                            </button>

                            <!-- Skip Forward -->
                            <button id="skip-fwd-btn" class="ctrl-btn w-8 h-8 text-sm" title="İleri Al 10s">
                                <i class="fa-solid fa-rotate-right"></i>
                            </button>

                            <!-- Volume -->
                            <div class="flex items-center gap-1 vol-group">
                                <button id="mute-btn" class="ctrl-btn w-8 h-8 text-sm" title="Sesi Kapat (M)">
                                    <i class="fa-solid fa-volume-high" id="volume-icon"></i>
                                </button>
                                <input id="volume-slider" type="range" min="0" max="1" step="0.02" value="1">
                            </div>

                            <!-- Time -->
                            <span class="text-[11px] sm:text-xs text-gray-300 font-mono ml-1 whitespace-nowrap select-none">
                                <span id="current-time">0:00</span>
                                <span class="text-gray-600 mx-0.5">/</span>
                                <span id="total-time"><?= !empty($video['duration']) ? e(formatDuration((int)$video['duration'])) : '0:00' ?></span>
                            </span>
                        </div>

                        <div class="flex items-center gap-1">
                            <!-- #12 Chapter adı -->
                            <div id="current-chapter-wrap" class="hidden items-center mr-2">
                                <span class="text-xs text-gray-300 max-w-[130px] truncate" id="current-chapter-name"></span>
                            </div>

                            <!-- Ayarlar (tüm ikincil seçenekler tek menüde) -->
                            <button id="settings-btn" class="ctrl-btn w-8 h-8 text-sm" title="Ayarlar" aria-haspopup="true" aria-expanded="false">
                                <i class="fa-solid fa-gear" id="settings-icon"></i>
                            </button>

                            <!-- Theater Mode -->
                            <button id="theater-btn" class="ctrl-btn w-8 h-8 text-sm hidden xl:flex" title="Tiyatro Modu">
                                <i class="fa-solid fa-window-maximize"></i>
                            </button>

                            <!-- Fullscreen -->
                            <button id="fullscreen-btn" class="ctrl-btn w-8 h-8 text-sm" title="Tam Ekran (F)">
                                <i class="fa-solid fa-expand" id="fullscreen-icon"></i>
                            </button>
                        </div>
                    </div>
                    </div><!-- /glass-bar -->

                    <!-- Ayarlar paneli (liquid glass) -->
                    <div id="settings-panel" role="menu" aria-label="Oynatıcı ayarları">
                        <div class="sp-title"><i class="fa-solid fa-sliders"></i> Ayarlar</div>
                        <div class="sp-sec">
                            <div class="sp-lbl"><i class="fa-solid fa-gauge-high"></i> Oynatma hızı <button type="button" id="speed-btn" class="sp-val" tabindex="-1">1×</button></div>
                            <div class="sp-chips"><button class="speed-opt <?= 0.25 == 1 ? 'active' : '' ?>" data-speed="0.25" onclick="setSpeed(0.25)">0.25×</button><button class="speed-opt <?= 0.5 == 1 ? 'active' : '' ?>" data-speed="0.5" onclick="setSpeed(0.5)">0.5×</button><button class="speed-opt <?= 0.75 == 1 ? 'active' : '' ?>" data-speed="0.75" onclick="setSpeed(0.75)">0.75×</button><button class="speed-opt <?= 1 == 1 ? 'active' : '' ?>" data-speed="1" onclick="setSpeed(1)">1×</button><button class="speed-opt <?= 1.25 == 1 ? 'active' : '' ?>" data-speed="1.25" onclick="setSpeed(1.25)">1.25×</button><button class="speed-opt <?= 1.5 == 1 ? 'active' : '' ?>" data-speed="1.5" onclick="setSpeed(1.5)">1.5×</button><button class="speed-opt <?= 1.75 == 1 ? 'active' : '' ?>" data-speed="1.75" onclick="setSpeed(1.75)">1.75×</button><button class="speed-opt <?= 2 == 1 ? 'active' : '' ?>" data-speed="2" onclick="setSpeed(2)">2×</button></div>
                        </div>
                        <?php if ($subtitle): ?>
                        <button id="subtitle-btn" type="button" class="set-row" title="Altyazı (C)"><i class="fa-solid fa-closed-captioning"></i><span>Altyazı</span><em class="sw"></em></button>
                        <?php endif; ?>
                        <button id="loop-btn" type="button" class="set-row" title="Döngü (L)"><i class="fa-solid fa-repeat"></i><span>Döngü</span><em class="sw"></em></button>
                        <button id="zoom-btn" type="button" class="set-row" title="Zoom (Z)"><i class="fa-solid fa-magnifying-glass-plus"></i><span>Yakınlaştır</span><em class="sw"></em></button>
                        <button id="screenshot-btn" type="button" class="set-row" title="Ekran Görüntüsü (S)"><i class="fa-solid fa-camera"></i><span>Ekran görüntüsü</span></button>
                        <?php if (!empty($chapters)): ?>
                        <button id="chapters-btn" type="button" class="set-row" title="Bölümler" onclick="document.getElementById('chapters-panel').classList.toggle('hidden')"><i class="fa-solid fa-list-ul"></i><span>Bölümler</span><i class="fa-solid fa-chevron-right sp-chev"></i></button>
                        <?php endif; ?>
                        <div class="sp-sec">
                            <div class="sp-lbl"><i class="fa-solid fa-cloud-arrow-down"></i> İndirmeden önce sor</div>
                            <div class="sp-chips" id="dl-ask">
                                <button type="button" data-m="always">Her zaman</button><button type="button" data-m="cellular">Mobil veri</button><button type="button" data-m="never">Hiç</button>
                            </div>
                        </div>
                    </div>

                    <?php if (!empty($chapters)): ?>
                    <!-- Chapters Panel -->
                    <div id="chapters-panel" class="hidden">
                        <div class="px-3 py-2 border-b border-gray-800"><p class="text-xs font-bold text-white">Bölümler</p></div>
                        <?php foreach ($chapters as $i => $ch): ?>
                        <div class="chapter-item" onclick="seekToChapter(<?= (int)$ch['start_time'] ?>)">
                            <span class="chapter-time"><?= gmdate('H:i:s', (int)$ch['start_time']) ?></span>
                            <span class="chapter-title"><?= e($ch['title']) ?></span>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- #9 Zoom indicator -->
            <div id="zoom-indicator">1.0×</div>

            <!-- ===== VİDEO BİLGİLERİ ===== -->
            <div class="mt-4">
                <?php if (!empty($video['expires_at']) && ($__exp = strtotime($video['expires_at'])) && $__exp > time() && $__exp < time() + 14 * 86400): $__d = max(1, (int)ceil(($__exp - time()) / 86400)); ?>
                <div class="mb-3 px-4 py-2.5 rounded-xl text-sm flex items-center gap-2" style="background:rgba(255,95,122,0.12);border:1px solid rgba(255,95,122,0.4);color:#ff8fa3;">
                    <i class="fa-solid fa-hourglass-half"></i> Bu video geçici olarak yayında ve <strong><?= $__d ?> gün</strong> içinde (<?= e(date('d.m.Y', $__exp)) ?>) kaldırılacak. İzlemek istiyorsan acele et!
                </div>
                <?php endif; ?>
                <h1 class="text-xl sm:text-2xl font-bold text-white leading-tight" id="video-title">
                    <?= e($video['title']) ?>
                </h1>

                <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mt-3">
                    <!-- Puan -->
                    <div id="rating-box" class="flex items-center gap-2 text-sm">
                        <span id="rating-stars" class="flex gap-0.5 text-lg cursor-pointer select-none" title="Puan ver">
                            <?php for ($i = 1; $i <= 5; $i++): ?><i class="fa-regular fa-star" data-r="<?= $i ?>" style="color:#ffd76a"></i><?php endfor; ?>
                        </span>
                        <span id="rating-text" class="text-xs text-gray-500"></span>
                        <label class="ml-3 flex items-center gap-1.5 text-xs text-gray-500 cursor-pointer" title="Video bitince sonrakine otomatik geç">
                            <input type="checkbox" id="autoplay-toggle" class="w-3.5 h-3.5 accent-cyan-400"> Otomatik oynat
                        </label>
                        <?php if ($subtitle): ?>
                        <details class="relative ml-3" id="sub-settings">
                            <summary class="text-xs text-gray-500 hover:text-cyan-400 cursor-pointer select-none list-none"><i class="fa-solid fa-closed-captioning mr-1"></i>Altyazı ayarı</summary>
                            <div class="absolute z-30 mt-2 w-56 p-3 rounded-xl space-y-2 text-xs text-gray-300" style="background:#13131f;border:1px solid rgba(255,255,255,0.12);">
                                <label class="flex items-center justify-between gap-2">Boyut
                                    <select id="sub-size" class="bg-black/40 border border-gray-700 rounded px-1 py-0.5"><option value="80">Küçük</option><option value="100">Normal</option><option value="130">Büyük</option><option value="170">Çok büyük</option></select></label>
                                <label class="flex items-center justify-between gap-2">Renk
                                    <select id="sub-color" class="bg-black/40 border border-gray-700 rounded px-1 py-0.5"><option value="#ffffff">Beyaz</option><option value="#ffe14d">Sarı</option><option value="#00f5ff">Camgöbeği</option><option value="#7CFC00">Yeşil</option></select></label>
                                <label class="flex items-center justify-between gap-2">Arka plan
                                    <select id="sub-bg" class="bg-black/40 border border-gray-700 rounded px-1 py-0.5"><option value="0.75">Koyu</option><option value="0.45">Yarı saydam</option><option value="0">Yok</option></select></label>
                                <button type="button" id="sub-reset" class="text-gray-500 hover:text-cyan-400">Varsayılana dön</button>
                            </div>
                        </details>
                        <?php endif; ?>
                    </div>
                    <!-- İstatistikler -->
                    <div class="flex items-center gap-5 text-sm text-gray-500">
                        <span class="flex items-center gap-1.5">
                            <i class="fa-solid fa-eye text-gray-600"></i>
                            <span id="view-count"><?= formatNumber((int)($video['views'] ?? 0)) ?></span> izlenme
                        </span>
                        <span class="flex items-center gap-1.5">
                            <i class="fa-regular fa-clock text-gray-600"></i>
                            <?= timeAgo($video['created_at']) ?>
                        </span>
                        <?php if (!empty($video['duration'])): ?>
                        <span class="flex items-center gap-1.5">
                            <i class="fa-solid fa-film text-gray-600"></i>
                            <?= formatDuration((int)$video['duration']) ?>
                        </span>
                        <?php endif; ?>
                    </div>

                    <!-- Aksiyon Butonları -->
                    <div class="flex items-center gap-2 flex-wrap">
                        <!-- Beğeni -->
                        <button id="like-btn" data-video-id="<?= e($videoId) ?>"
                                class="flex items-center gap-2 px-4 py-2 rounded-full font-semibold text-sm transition-all duration-300 hover:scale-105"
                                style="background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.12);">
                            <i class="fa-regular fa-heart text-sm" id="like-icon"></i>
                            <span id="like-count"><?= formatNumber((int)($video['likes_count'] ?? 0)) ?></span>
                            <span class="hidden sm:inline text-gray-400">Beğen</span>
                        </button>

                        <!-- Paylaş -->
                        <button id="share-btn"
                                class="flex items-center gap-2 px-4 py-2 rounded-full text-sm text-gray-400 hover:text-white transition-all duration-300 hover:scale-105"
                                style="background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.12);"
                                onclick="shareVideo()">
                            <i class="fa-solid fa-share-nodes text-sm"></i>
                            <span class="hidden sm:inline">Paylaş</span>
                        </button>

                        <?php if (!empty($siteSettings['allow_download'])): ?>
                        <!-- İndir -->
                        <a href="<?= e($video['video_url']) ?>" download="<?= e($video['title']) ?>.mp4"
                           class="flex items-center gap-2 px-4 py-2 rounded-full text-sm text-gray-400 hover:text-cyan-400 transition-all duration-300 hover:scale-105"
                           style="background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.12);">
                            <i class="fa-solid fa-download text-sm"></i>
                            <span class="hidden sm:inline">İndir</span>
                        </a>
                        <?php endif; ?>


                        <!-- Daha sonra izle -->
                        <?php if ($subtitle && !$earlyLocked): ?>
                        <button id="sum-btn" type="button" class="flex items-center gap-2 px-4 py-2 rounded-full text-sm text-gray-300 hover:text-white transition-all duration-300 hover:scale-105"
                                style="background:rgba(191,0,255,0.12);border:1px solid rgba(191,0,255,0.35);">
                            <i class="fa-solid fa-wand-magic-sparkles text-sm" style="color:#d36bff"></i><span class="hidden sm:inline">Altyazı Özeti</span>
                        </button>
                        <?php endif; ?>
                        <!-- Listeye ekle -->
                        <div class="relative" id="pl-wrap">
                            <button id="pl-btn" type="button" class="flex items-center gap-2 px-4 py-2 rounded-full text-sm text-gray-400 hover:text-white transition-all duration-300 hover:scale-105"
                                    style="background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.12);">
                                <i class="fa-solid fa-list-ul text-sm"></i><span class="hidden sm:inline">Listeye Ekle</span>
                            </button>
                            <div id="pl-menu" class="hidden absolute right-0 mt-2 w-64 rounded-xl p-2 z-40 shadow-2xl" style="background:#13131f;border:1px solid rgba(255,255,255,0.12);">
                                <div id="pl-items" class="max-h-52 overflow-y-auto text-sm"></div>
                                <form id="pl-new" class="flex gap-1 mt-2 pt-2" style="border-top:1px solid rgba(255,255,255,0.08);">
                                    <input id="pl-new-title" maxlength="80" placeholder="Yeni liste adı" class="flex-1 min-w-0 bg-black/30 border border-gray-800 rounded-lg px-2 py-1.5 text-white text-xs focus:outline-none">
                                    <button class="px-2 rounded-lg text-xs font-bold text-black" style="background:#00f5ff">+</button>
                                </form>
                            </div>
                        </div>
                        <button id="later-btn" type="button"
                                class="flex items-center gap-2 px-4 py-2 rounded-full text-sm text-gray-400 hover:text-white transition-all duration-300 hover:scale-105"
                                style="background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.12);">
                            <i class="fa-regular fa-clock text-sm" id="later-icon"></i>
                            <span class="hidden sm:inline" id="later-label">Sonra İzle</span>
                        </button>

                        <!-- Premium indirme (yalnızca premium üyelerde görünür) -->
                        <a id="premium-dl-btn" href="#" class="hidden items-center gap-2 px-4 py-2 rounded-full text-sm transition-all duration-300 hover:scale-105"
                           style="background:rgba(255,200,0,0.1);border:1px solid rgba(255,200,0,0.35);color:#ffd24d;" rel="noopener">
                            <i class="fa-solid fa-crown text-sm"></i>
                            <span class="hidden sm:inline">Premium İndir</span>
                        </a>

                        <?php if ($subtitle): ?>
                        <!-- Altyazı badge -->
                        <span class="flex items-center gap-1.5 px-3 py-2 rounded-full text-xs font-semibold"
                              style="background:rgba(0,245,255,0.08);border:1px solid rgba(0,245,255,0.2);color:#00f5ff;">
                            <i class="fa-solid fa-closed-captioning text-xs"></i>
                            Altyazı
                        </span>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Kanal Bilgisi -->
                <?php if (!empty($video['channels'])): ?>
                <div class="mt-5 p-4 rounded-xl flex items-center justify-between" style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.06);">
                    <a href="<?= APP_URL ?>/channel?id=<?= e($video['channels']['id']) ?>" class="flex items-center gap-4 group min-w-0">
                        <div class="w-12 h-12 rounded-full overflow-hidden bg-gray-800 flex items-center justify-center text-xl font-bold border-2 border-transparent group-hover:border-cyan-400 transition-colors shrink-0">
                            <?php if (!empty($video['channels']['avatar_url'])): ?>
                                <img src="<?= e($video['channels']['avatar_url']) ?>" class="w-full h-full object-cover">
                            <?php else: ?>
                                <?= strtoupper(substr($video['channels']['name'], 0, 1)) ?>
                            <?php endif; ?>
                        </div>
                        <div class="min-w-0">
                            <h3 class="font-bold text-white text-lg group-hover:text-cyan-400 transition-colors truncate"><?= e($video['channels']['name']) ?></h3>
                            <p class="text-xs text-gray-500">Resmi Kanal</p>
                        </div>
                    </a>
                    <button id="subscribe-btn" data-channel-id="<?= e($video['channels']['id']) ?>"
                            class="shrink-0 ml-4 px-5 py-2 rounded-full font-bold text-sm text-black bg-white hover:bg-cyan-400 transition-colors">
                        <i class="fa-solid fa-bell mr-1"></i>Abone Ol
                    </button>
                </div>
                <?php endif; ?>

                <!-- Divider -->
                <div class="my-4" style="border-top:1px solid rgba(255,255,255,0.06);"></div>

                <!-- Tags -->
                <?php if (!empty($video['tags'])): ?>
                <div class="flex flex-wrap gap-2 mb-4">
                    <?php foreach ((array)$video['tags'] as $tag): ?>
                    <span class="px-3 py-1 rounded-full text-xs font-medium"
                          style="background:rgba(191,0,255,0.08);color:#bf00ff;border:1px solid rgba(191,0,255,0.2);">
                        #<?= e($tag) ?>
                    </span>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>

                <!-- Açıklama -->
                <?php if (!empty($video['description'])): ?>
                <div id="description-block" class="rounded-xl overflow-hidden"
                     style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.06);">
                    <div class="p-4">
                        <p class="text-gray-300 text-sm leading-relaxed whitespace-pre-line" id="video-description"
                           style="max-height: 100px; overflow: hidden;" id="desc-text">
                            <?php
                                $descSafe = e($video['description']);
                                $descWithLinks = preg_replace_callback('/#([\wıİğĞüÜşŞöÖçÇ]+)/u', function($m) {
                                    $word = $m[1];
                                    return '<a href="' . APP_URL . '/search.php?q=%23' . urlencode($word) . '" class="hover:underline transition-colors" style="color: #00f5ff; font-weight: 500;">#' . $word . '</a>';
                                }, $descSafe);
                                echo $descWithLinks;
                            ?>
                        </p>
                    </div>
                    <button onclick="toggleDesc(this)"
                            class="w-full text-center py-2 text-xs text-gray-600 hover:text-cyan-400 transition-colors"
                            style="border-top:1px solid rgba(255,255,255,0.04);"
                            data-expanded="false">
                        <i class="fa-solid fa-chevron-down text-[10px] mr-1"></i>Devamını Göster
                    </button>
                </div>
                <?php endif; ?>
            </div>

            <!-- ===== YORUMLAR ===== -->
            <div class="mt-8" id="comments-section">
                <h2 class="text-lg font-bold text-white mb-5 flex items-center gap-2">
                    <i class="fa-solid fa-comments text-base" style="color:#bf00ff;"></i>
                    Yorumlar
                    <span class="text-sm font-normal text-gray-500 ml-1"><?= (int)($video['comments_count'] ?? 0) ?></span>
                </h2>

                <!-- Yorum Formu -->
                <div id="comment-form-area" class="mb-6">
                    <!-- Giriş yapılmadıysa -->
                    <div id="comment-login-prompt" class="rounded-xl p-4 flex items-center gap-4"
                         style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.08);">
                        <div class="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0"
                             style="background:rgba(255,255,255,0.06);">
                            <i class="fa-solid fa-lock text-gray-600 text-sm"></i>
                        </div>
                        <div>
                            <p class="text-gray-300 text-sm font-medium">Yorum yapmak için giriş yapın</p>
                            <a href="<?= APP_URL ?>/auth.php" class="text-neon-cyan text-sm hover:underline">Giriş Yap / Kayıt Ol</a>
                        </div>
                    </div>

                    <!-- Giriş yapıldıysa -->
                    <form id="comment-form" class="hidden" onsubmit="submitComment(event)">
                        <div class="flex gap-3">
                            <div class="w-9 h-9 rounded-full flex-shrink-0 flex items-center justify-center text-xs font-bold mt-0.5"
                                 style="background:linear-gradient(135deg,#00f5ff,#bf00ff);color:#000;" id="comment-user-avatar">
                                U
                            </div>
                            <div class="flex-1">
                                <textarea
                                    id="comment-input"
                                    placeholder="Düşüncelerinizi paylaşın..."
                                    rows="3"
                                    maxlength="2000"
                                    class="w-full px-4 py-3 rounded-xl text-sm text-white placeholder-gray-600 resize-none outline-none transition-all duration-200"
                                    style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);"
                                    onfocus="this.style.borderColor='rgba(0,245,255,0.4)'"
                                    onblur="this.style.borderColor='rgba(255,255,255,0.1)'"
                                ></textarea>
                                <div id="gif-chip" class="hidden mt-2 relative inline-block"><img id="gif-chip-img" alt="GIF" class="cgif" style="max-height:110px"><button type="button" id="gif-chip-x" class="absolute -top-2 -right-2 w-6 h-6 rounded-full text-xs text-white" style="background:rgba(0,0,0,0.8)" aria-label="GIF'i kaldır">✕</button></div>
                                <div id="cpick" class="hidden mt-2 p-2 rounded-xl" style="background:#0f0f1e;border:1px solid rgba(255,255,255,0.1)">
                                    <div id="cpick-emoji" class="hidden flex flex-wrap gap-1 text-xl max-h-40 overflow-y-auto"></div>
                                    <div id="cpick-gif" class="hidden">
                                        <input id="cpick-q" type="text" placeholder="GIF ara (örn. gülmek, şaşırmak)" maxlength="60" class="w-full mb-2 px-3 py-1.5 rounded-lg text-sm text-white outline-none" style="background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1)">
                                        <div id="cpick-gifs" class="grid grid-cols-3 sm:grid-cols-4 gap-1 max-h-56 overflow-y-auto"></div>
                                        <p class="text-[10px] text-gray-600 mt-1 text-right">GIPHY ile</p>
                                    </div>
                                </div>
                                <div class="flex items-center justify-between mt-2">
                                    <div class="flex items-center gap-2">
                                        <span class="text-xs text-gray-700" id="comment-char-count">0 / 2000</span>
                                        <button type="button" id="btn-emoji" class="px-2 py-1 rounded-lg text-sm text-gray-400 hover:text-white" style="background:rgba(255,255,255,0.06)" aria-label="Emoji">😊</button>
                                        <button type="button" id="btn-gif" class="px-2 py-1 rounded-lg text-xs font-bold text-gray-400 hover:text-white" style="background:rgba(255,255,255,0.06)">GIF</button>
                                    </div>
                                    <div class="flex gap-2">
                                        <button type="button" onclick="cancelReply()" id="cancel-reply-btn"
                                                class="hidden px-4 py-1.5 rounded-lg text-xs text-gray-500 hover:text-white transition-colors"
                                                style="background:rgba(255,255,255,0.06);">
                                            Yanıtı İptal Et
                                        </button>
                                        <button type="button" onclick="document.getElementById('comment-input').value='';updateCharCount()"
                                                class="px-4 py-1.5 rounded-lg text-xs text-gray-500 hover:text-white transition-colors"
                                                style="background:rgba(255,255,255,0.06);">
                                            Temizle
                                        </button>
                                        <button type="submit" id="comment-submit-btn"
                                                class="flex items-center gap-2 px-5 py-1.5 rounded-lg text-xs font-semibold text-black transition-all duration-200 hover:scale-105"
                                                style="background:linear-gradient(135deg,#00f5ff,#bf00ff);">
                                            <i class="fa-solid fa-paper-plane text-xs"></i>
                                            Gönder
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>

                <div class="flex items-center gap-2 mb-4 text-xs text-gray-500">
                    <i class="fa-solid fa-arrow-down-wide-short"></i>
                    <select id="comment-sort" class="bg-transparent border border-gray-800 rounded-lg px-2 py-1 text-gray-300 text-xs focus:outline-none">
                        <option value="rec" style="background:#13131f">Önerilen</option>
                        <option value="new" style="background:#13131f">En yeni</option>
                        <option value="old" style="background:#13131f">En eski</option>
                        <option value="top" style="background:#13131f">En beğenilen</option>
                    </select>
                </div>
                <div id="comments-list" class="space-y-6">
                    <?php if (empty($commentTree)): ?>
                    <div class="text-center py-8 text-gray-600" id="no-comments-msg">
                        <i class="fa-regular fa-comment-dots text-3xl mb-2 block opacity-40"></i>
                        Henüz yorum yok. İlk yorumu siz yapın!
                    </div>
                    <?php else: ?>
                    <?php foreach ($commentTree as $item): $comment = $item['comment']; ?>
                    <div class="comment-thread" id="thread-<?= e($comment['id']) ?>" data-time="<?= (int)strtotime($comment['created_at']) ?>" data-pinned="<?= $topCommentId === $comment['id'] ? '1' : '0' ?>" data-apin="<?= $pinnedId === $comment['id'] ? '1' : '0' ?>">
                        <!-- Root Comment -->
                        <div class="flex gap-3 comment-item" id="comment-<?= e($comment['id']) ?>" data-cid="<?= e($comment['id']) ?>" data-uid="<?= e($comment['user_id'] ?? '') ?>">
                            <?php $fr = $commentFrames[$comment['user_id'] ?? '']['frame'] ?? null; ?>
                            <?= nvFrameOpen($fr, 'md') ?>
                            <?php if (!empty($comment['profiles']['avatar_url'])): ?>
                            <img src="<?= e($comment['profiles']['avatar_url']) ?>" alt="Avatar" class="w-10 h-10 rounded-full object-cover flex-shrink-0 border border-gray-700">
                            <?php else: ?>
                            <div class="w-10 h-10 rounded-full flex-shrink-0 flex items-center justify-center text-sm font-bold <?= $fr ? 'nvf-in' : '' ?>"
                                 style="background:linear-gradient(135deg,#bf00ff,#ff007a);color:#fff;">
                                <?= strtoupper(substr($comment['profiles']['username'] ?? 'U', 0, 1)) ?>
                            </div>
                            <?php endif; ?>
                            <?= nvFrameClose($fr) ?>
                            <div class="flex-1 min-w-0">
                                <div class="flex items-center gap-2 mb-1">
                                    <a href="<?= APP_URL ?>/user.php?id=<?= e($comment['user_id'] ?? '') ?>" class="text-sm font-bold text-white hover:text-cyan-400"><?= e($comment['profiles']['username'] ?? 'Kullanıcı') ?></a>
                                    <?= !empty($premiumUsers[$comment['user_id'] ?? '']) ? $premiumBadge : '' ?>
                                    <?php if ($pinnedId === $comment['id']): ?><span class="text-[10px] font-bold px-1.5 py-0.5 rounded-full" style="background:rgba(255,215,106,0.15);color:#ffd76a;border:1px solid rgba(255,215,106,0.45)"><i class="fa-solid fa-thumbtack mr-1"></i>Sabitlendi</span><?php endif; ?>
                                    <?php if ($topCommentId === $comment['id']): ?><span class="text-[10px] font-bold px-1.5 py-0.5 rounded-full" style="background:rgba(255,0,122,0.15);color:#ff5fa8;border:1px solid rgba(255,0,122,0.4)"><i class="fa-solid fa-thumbtack mr-1"></i>En çok beğenilen</span><?php endif; ?>
                                    <span class="text-xs text-gray-600"><?= timeAgo($comment['created_at']) ?></span>
                                </div>
                                <p class="ctext text-gray-300 text-sm leading-relaxed whitespace-pre-wrap"><?= parseMentions($comment['content']) ?></p><?= !empty($comment['edited_at']) ? '<span class="cedited text-[10px] text-gray-600">(düzenlendi)</span>' : '<span class="cedited text-[10px] text-gray-600"></span>' ?>
                                <?= commentLikeBtn($comment['id'], $commentLikeCounts) ?>
                                <button onclick="replyTo('<?= e($comment['id']) ?>', '<?= e($comment['profiles']['username']) ?>')" class="text-xs text-gray-500 hover:text-cyan-400 mt-2 font-semibold transition-colors">
                                    Yanıtla
                                </button>
                                <?php if ($isAdminViewer): ?><button type="button" class="pin-btn text-xs text-gray-500 hover:text-yellow-400 mt-2 ml-3 font-semibold" data-cid="<?= e($comment['id']) ?>" data-pin="<?= $pinnedId === $comment['id'] ? '0' : '1' ?>"><i class="fa-solid fa-thumbtack mr-1"></i><?= $pinnedId === $comment['id'] ? 'Sabiti kaldır' : 'Sabitle' ?></button><?php endif; ?>
                            </div>
                        </div>

                        <!-- Replies -->
                        <?php if (!empty($item['replies'])): ?>
                        <div class="ml-10 mt-4 space-y-4 border-l-2 border-gray-800 pl-4">
                            <?php foreach ($item['replies'] as $reply): ?>
                            <div class="flex gap-3 comment-item" id="comment-<?= e($reply['id']) ?>" data-cid="<?= e($reply['id']) ?>" data-uid="<?= e($reply['user_id'] ?? '') ?>">
                                <?php $fr = $commentFrames[$reply['user_id'] ?? '']['frame'] ?? null; ?>
                                <?= nvFrameOpen($fr, 'sm') ?>
                                <?php if (!empty($reply['profiles']['avatar_url'])): ?>
                                <img src="<?= e($reply['profiles']['avatar_url']) ?>" alt="Avatar" class="w-8 h-8 rounded-full object-cover flex-shrink-0 border border-gray-700">
                                <?php else: ?>
                                <div class="w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center text-xs font-bold <?= $fr ? 'nvf-in' : '' ?>"
                                     style="background:linear-gradient(135deg,#00f5ff,#bf00ff);color:#000;">
                                    <?= strtoupper(substr($reply['profiles']['username'] ?? 'U', 0, 1)) ?>
                                </div>
                                <?php endif; ?>
                                <?= nvFrameClose($fr) ?>
                                <div class="flex-1 min-w-0">
                                    <div class="flex items-center gap-2 mb-1">
                                        <a href="<?= APP_URL ?>/user.php?id=<?= e($reply['user_id'] ?? '') ?>" class="text-sm font-bold text-white hover:text-cyan-400"><?= e($reply['profiles']['username'] ?? 'Kullanıcı') ?></a>
                                        <?= !empty($premiumUsers[$reply['user_id'] ?? '']) ? $premiumBadge : '' ?>
                                        <span class="text-xs text-gray-600"><?= timeAgo($reply['created_at']) ?></span>
                                    </div>
                                    <p class="ctext text-gray-300 text-sm leading-relaxed whitespace-pre-wrap"><?= parseMentions($reply['content']) ?></p><?= !empty($reply['edited_at']) ? '<span class="cedited text-[10px] text-gray-600">(düzenlendi)</span>' : '<span class="cedited text-[10px] text-gray-600"></span>' ?>
                                    <?= commentLikeBtn($reply['id'], $commentLikeCounts) ?>
                                    <button onclick="replyTo('<?= e($comment['id']) ?>', '<?= e($reply['profiles']['username'] ?? '') ?>')" class="text-xs text-gray-500 hover:text-cyan-400 mt-2 font-semibold transition-colors">Yanıtla</button>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- ===== SAĞ: İLGİLİ VİDEOLAR ===== -->
        <div class="xl:w-96 flex-shrink-0" id="related-sidebar">
            <h3 class="text-base font-semibold text-white mb-4 flex items-center gap-2">
                <i class="fa-solid fa-list-ul text-neon-cyan text-sm"></i>
                İlgili Videolar
            </h3>

            <?php if (empty($relatedVideos)): ?>
            <p class="text-gray-600 text-sm">Başka video bulunamadı.</p>
            <?php else: ?>
            <div class="space-y-3" id="related-videos-list">
                <?php foreach ($relatedVideos as $rv): ?>
                <div class="group rounded-xl p-2 transition-all duration-200 hover:bg-white/[0.04]">
                    <a href="<?= APP_URL ?>/video.php?id=<?= e($rv['id']) ?>"
                       class="flex gap-3"
                       id="related-<?= e($rv['id']) ?>">
                        <div class="relative flex-shrink-0 w-32 rounded-lg overflow-hidden" style="aspect-ratio:16/9;background:#0d0d1a;">
                            <img src="<?= e($rv['thumbnail_url'] ?? 'https://placehold.co/320x180/070711/00f5ff?text=NeonTV') ?>"
                                 alt="<?= e($rv['title']) ?>"
                                 class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                                 loading="lazy">
                            <?php if (!empty($rv['duration'])): ?>
                            <div class="absolute bottom-1 right-1 text-[10px] font-bold px-1.5 py-0.5 rounded"
                                 style="background:rgba(0,0,0,0.8);color:#fff;">
                                <?= formatDuration((int)$rv['duration']) ?>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="flex-1 min-w-0">
                            <p class="text-sm font-medium text-gray-200 leading-snug group-hover:text-cyan-400 transition-colors"
                               style="display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;">
                                <?= e($rv['title']) ?>
                            </p>
                            <p class="text-xs text-gray-600 mt-1.5 flex items-center gap-1">
                                <i class="fa-solid fa-eye text-[10px]"></i><?= formatNumber((int)($rv['views'] ?? 0)) ?>
                                <span class="mx-0.5">·</span>
                                <?= timeAgo($rv['created_at']) ?>
                            </p>
                        </div>
                    </a>
                    <!-- #15 Kuyruğa Ekle -->
                    <button onclick="addToQueue('<?= e($rv['id']) ?>', '<?= e(addslashes($rv['title'])) ?>', '<?= e($rv['thumbnail_url'] ?? '') ?>', this)"
                            class="mt-1.5 w-full text-left text-xs text-gray-600 hover:text-cyan-400 transition-colors px-1 flex items-center gap-1"
                            id="queue-btn-<?= e($rv['id']) ?>">
                        <i class="fa-solid fa-circle-plus text-[10px]"></i>
                        <span>Kuyruğa Ekle</span>
                    </button>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <!-- #30 Queue Panel -->
            <div id="queue-panel" class="hidden mt-4">
                <div class="flex items-center justify-between px-4 py-3" style="border-bottom:1px solid rgba(255,255,255,0.06);">
                    <h4 class="text-sm font-bold text-white flex items-center gap-2">
                        <i class="fa-solid fa-layer-group text-neon-cyan text-xs"></i>
                        Sıra <span id="queue-count" class="text-xs text-gray-500 font-normal"></span>
                    </h4>
                    <button onclick="clearQueue()" class="text-xs text-gray-600 hover:text-red-400 transition-colors">
                        <i class="fa-solid fa-trash-can text-[10px] mr-1"></i>Temizle
                    </button>
                </div>
                <div id="queue-list" class="divide-y divide-white/[0.04]"></div>
            </div>
        </div>

    </div>
</div>

<!-- ===== MINI PLAYER ===== -->
<div id="mini-player" class="hidden">
    <video id="mini-video" playsinline muted></video>
    <div class="mini-player-controls">
        <p class="text-xs text-gray-300 truncate flex-1"><?= e($video['title']) ?></p>
        <button onclick="goToMainPlayer()" class="text-xs text-cyan-400 hover:text-white transition-colors flex-shrink-0" title="Ana Ekrana Git">
            <i class="fa-solid fa-up-right-from-square"></i>
        </button>
        <button onclick="closeMiniPlayer()" class="text-xs text-gray-500 hover:text-white transition-colors flex-shrink-0" title="Kapat">
            <i class="fa-solid fa-xmark"></i>
        </button>
    </div>
</div>

<!-- #10 Screenshot Toast -->
<div id="screenshot-toast"><i class="fa-solid fa-check mr-2" style="color:#00f5ff;"></i>Ekran görüntüsü kaydedildi!</div>






<!-- ===== HIDDEN DATA ===== -->
<script>
const VIDEO_ID      = '<?= e($videoId) ?>';
const VIDEO_URL     = '<?= e($video['video_url']) ?>';
const HAS_SUBTITLE  = <?= $subtitle ? 'true' : 'false' ?>;
const INTRO_END     = <?= max(0, (int)($video['intro_end'] ?? 0)) ?>;
const NEXT_VIDEO_ID = '<?= !empty($relatedVideos[0]) ? e($relatedVideos[0]['id']) : '' ?>';
const APP_URL_JS    = '<?= APP_URL ?>';
const VIDEO_TITLE   = '<?= e(addslashes($video['title'])) ?>';
const VIDEO_PAGE_URL = window.location.href;

// #12 Chapters verisi
window._chapters = <?= json_encode(array_values($chapters)) ?>;

// #15 Kuyruk fonksiyonları - Güncel (thumbnail destekli)
function addToQueue(videoId, title, thumb, btn) {
    const queue = JSON.parse(localStorage.getItem('neontv_queue') || '[]');
    if (queue.find(q => q.id === videoId)) {
        if (btn) { btn.innerHTML = '<i class="fa-solid fa-check text-[10px]"></i><span>Eklendi</span>'; btn.style.color = '#6b7280'; }
        return;
    }
    queue.push({ id: videoId, title: title, thumb: thumb });
    localStorage.setItem('neontv_queue', JSON.stringify(queue));
    if (btn) {
        btn.innerHTML = '<i class="fa-solid fa-check text-[10px] text-cyan-400"></i><span class="text-cyan-400">Kuyruğa Eklendi!</span>';
        setTimeout(() => { btn.innerHTML = '<i class="fa-solid fa-circle-plus text-[10px]"></i><span>Kuyruğa Ekle</span>'; btn.style.color = ''; }, 2000);
    }
    renderQueuePanel();
}

function clearQueue() {
    localStorage.removeItem('neontv_queue');
    renderQueuePanel();
}

function removeFromQueue(videoId) {
    const queue = JSON.parse(localStorage.getItem('neontv_queue') || '[]').filter(q => q.id !== videoId);
    localStorage.setItem('neontv_queue', JSON.stringify(queue));
    renderQueuePanel();
}

function renderQueuePanel() {
    const panel = document.getElementById('queue-panel');
    const list  = document.getElementById('queue-list');
    const count = document.getElementById('queue-count');
    if (!panel || !list) return;

    const queue = JSON.parse(localStorage.getItem('neontv_queue') || '[]');
    if (!queue.length) { panel.classList.add('hidden'); return; }

    panel.classList.remove('hidden');
    if (count) count.textContent = `(${queue.length})`;

    list.innerHTML = queue.map((item, i) => `
        <div class="queue-item" data-id="${item.id}">
            <span class="text-xs text-gray-600 font-mono w-4 text-center">${i + 1}</span>
            <img src="${item.thumb || 'https://placehold.co/64x36/070711/00f5ff?text=N'}"
                 style="width:56px;height:32px;object-fit:cover;border-radius:6px;flex-shrink:0;background:#0d0d1a;">
            <a href="${APP_URL_JS}/video.php?id=${item.id}" class="flex-1 min-w-0 text-xs text-gray-300 hover:text-cyan-400 transition-colors"
               style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${item.title}</a>
            <button onclick="removeFromQueue('${item.id}')" class="text-gray-600 hover:text-red-400 transition-colors flex-shrink-0">
                <i class="fa-solid fa-xmark text-[10px]"></i>
            </button>
        </div>
    `).join('');
}

document.addEventListener('DOMContentLoaded', () => renderQueuePanel());

// #12 Progress bar'a chapter marker'ları ekle
document.addEventListener('DOMContentLoaded', () => {
    if (!window._chapters || !window._chapters.length) return;
    const video = document.getElementById('main-video');
    const progressContainer = document.getElementById('progress-container');
    if (!video || !progressContainer) return;

    let _chDone = false;
    const addChapterMarkers = () => {
        if (_chDone || !video.duration) return; _chDone = true;
        window._chapters.forEach(ch => {
            if (!video.duration || ch.start_time >= video.duration) return;
            const marker = document.createElement('div');
            marker.className = 'chapter-marker';
            marker.style.left = ((ch.start_time / video.duration) * 100) + '%';
            marker.title = ch.title;
            progressContainer.appendChild(marker);
        });
    };
    video.addEventListener('loadedmetadata', addChapterMarkers);
    if (video.readyState >= 1) addChapterMarkers();
});

// Görüntülenme sayısını artır
fetch('<?= APP_URL ?>/api/views.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ video_id: VIDEO_ID })
});

// Video süresi algılama ve kaydetme
<?php if (empty($video['duration'])): ?>
document.getElementById('main-video')?.addEventListener('loadedmetadata', async function() {
    const dur = Math.round(this.duration);
    if (dur > 0) {
        // Toplam süreyi göster
        const totalTimeEl = document.getElementById('total-time');
        // Süreyi DB'ye kaydet
        try {
            await fetch('<?= APP_URL ?>/api/videos.php?id=<?= e($videoId) ?>', {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ duration: dur })
            });
        } catch(e) {}
    }
});
<?php endif; ?>

// Abonelik düğmesi görünümü (+ önbellek)
function applySubState(btn, on) {
    btn.dataset.subscribed = on ? 'true' : 'false';
    try { localStorage.setItem('sub_' + btn.dataset.channelId, on ? '1' : '0'); } catch (e) {}
    if (on) {
        btn.innerHTML = '<i class="fa-solid fa-check mr-1"></i>Abone Olundu';
        btn.style.background = '#00f5ff';
        btn.style.color = '#000';
    } else {
        btn.innerHTML = '<i class="fa-solid fa-bell mr-1"></i>Abone Ol';
        btn.style.background = '';
        btn.style.color = '';
    }
}

// Subscribe butonu
document.getElementById('subscribe-btn')?.addEventListener('click', async function() {
    let token = getAuthToken();
    try { const { data: { session } } = await sbClient.auth.getSession(); if (session) token = session.access_token; } catch (e) {}
    if (!token) {
        window.location.href = '<?= APP_URL ?>/auth.php';
        return;
    }
    const btn = this;
    const channelId = btn.dataset.channelId;
    const isSubscribed = btn.dataset.subscribed === 'true';
    // Anında göster (hata olursa geri alınır)
    applySubState(btn, !isSubscribed);
    btn.disabled = true;
    
    try {
        const res = await fetch('<?= APP_URL ?>/api/channels.php?subscribe=' + channelId + '&token=' + token, {
            method: 'POST',
            headers: { 'Authorization': 'Bearer ' + token, 'Content-Type': 'application/json' }
        });
        const resp = await res.json();
        if (!resp.success) throw new Error(resp.message || 'İşlem başarısız');
        applySubState(btn, !!((resp.data && resp.data.subscribed) || resp.subscribed));
    } catch(e) {
        alert(e.message || 'Abone olunamadı. Lütfen tekrar deneyin.');
        applySubState(btn, isSubscribed);
    }
    btn.disabled = false;
});

// Açıklama toggle
function toggleDesc(btn) {
    const desc = document.getElementById('video-description');
    const expanded = btn.dataset.expanded === 'true';
    if (expanded) {
        desc.style.maxHeight = '100px';
        desc.style.overflow = 'hidden';
        btn.innerHTML = '<i class="fa-solid fa-chevron-down text-[10px] mr-1"></i>Devamını Göster';
        btn.dataset.expanded = 'false';
    } else {
        desc.style.maxHeight = 'none';
        desc.style.overflow = 'visible';
        btn.innerHTML = '<i class="fa-solid fa-chevron-up text-[10px] mr-1"></i>Daha Az Göster';
        btn.dataset.expanded = 'true';
    }
}

// Yorum karakter sayacı
function updateCharCount() {
    const input = document.getElementById('comment-input');
    const counter = document.getElementById('comment-char-count');
    if (counter) counter.textContent = (input?.value?.length || 0) + ' / 2000';
}
document.getElementById('comment-input')?.addEventListener('input', updateCharCount);

// @kullanıcı otomatik tamamlama
(function () {
    const ta = document.getElementById('comment-input'); if (!ta) return;
    const box = document.createElement('div');
    box.id = 'mention-box';
    box.style.cssText = 'display:none;position:absolute;z-index:60;min-width:200px;max-width:280px;background:#0f0f1e;border:1px solid rgba(0,245,255,.3);border-radius:12px;box-shadow:0 8px 30px rgba(0,0,0,.6);overflow:hidden';
    ta.parentElement.style.position = 'relative'; ta.parentElement.appendChild(box);
    let timer = null, items = [], sel = 0, tokenStart = -1, lastQ = '';
    function hide() { box.style.display = 'none'; items = []; }
    function paint() {
        box.textContent = '';
        items.forEach((u, i) => {
            const row = document.createElement('div');
            row.style.cssText = 'display:flex;align-items:center;gap:8px;padding:7px 10px;cursor:pointer;font-size:13px;color:#e5e7eb;' + (i === sel ? 'background:rgba(0,245,255,.12)' : '');
            const av = document.createElement('span');
            av.style.cssText = 'width:22px;height:22px;border-radius:50%;overflow:hidden;background:#222;display:inline-flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;flex-shrink:0';
            if (u.avatar_url) { const im = document.createElement('img'); im.src = u.avatar_url; im.style.cssText = 'width:100%;height:100%;object-fit:cover'; im.alt = ''; av.appendChild(im); } else av.textContent = (u.username || '?').charAt(0).toUpperCase();
            const nm = document.createElement('span'); nm.textContent = u.username;
            row.append(av, nm);
            row.addEventListener('mousedown', e => { e.preventDefault(); pick(i); });
            box.appendChild(row);
        });
        box.style.display = items.length ? 'block' : 'none';
        box.style.left = '0'; box.style.top = (ta.offsetTop + ta.offsetHeight + 4) + 'px';
    }
    function pick(i) {
        const u = items[i]; if (!u || tokenStart < 0) return;
        const caret = ta.selectionStart;
        ta.value = ta.value.slice(0, tokenStart) + '@' + u.username + ' ' + ta.value.slice(caret);
        const pos = tokenStart + u.username.length + 2; ta.setSelectionRange(pos, pos);
        hide(); ta.focus(); if (typeof updateCharCount === 'function') updateCharCount();
    }
    ta.addEventListener('input', () => {
        const caret = ta.selectionStart, before = ta.value.slice(0, caret);
        const m = before.match(/(?:^|\s)@([a-zA-Z0-9_.\-]{1,40})$/);
        if (!m) { hide(); return; }
        tokenStart = caret - m[1].length - 1;
        if (m[1] === lastQ && items.length) return;
        lastQ = m[1]; clearTimeout(timer);
        timer = setTimeout(async () => {
            try {
                const r = await fetch('<?= APP_URL ?>/api/mention_suggest.php?q=' + encodeURIComponent(m[1]));
                const j = await r.json(); items = j.data || []; sel = 0; paint();
            } catch (e) { hide(); }
        }, 180);
    });
    ta.addEventListener('keydown', e => {
        if (box.style.display === 'none' || !items.length) return;
        if (e.key === 'ArrowDown') { e.preventDefault(); sel = (sel + 1) % items.length; paint(); }
        else if (e.key === 'ArrowUp') { e.preventDefault(); sel = (sel - 1 + items.length) % items.length; paint(); }
        else if (e.key === 'Enter' || e.key === 'Tab') { e.preventDefault(); pick(sel); }
        else if (e.key === 'Escape') { hide(); }
    });
    ta.addEventListener('blur', () => setTimeout(hide, 150));
})();
</script>

<script>
// CDN CORS başlığı vermiyorsa (crossorigin yüzünden video açılmaz) bir kez crossorigin'siz yeniden dene
(function () {
    const v = document.getElementById('main-video');
    const src = v && v.querySelector('source');
    if (!v || !src) return;
    let retried = false;
    src.addEventListener('error', function () {
        if (retried || !v.hasAttribute('crossorigin')) return;
        retried = true;
        v.removeAttribute('crossorigin');
        v.load();
    });
})();
</script>
<script src="<?= APP_URL ?>/assets/js/player.js"></script>

<script>
// ============================================================
// Yorum & Beğeni İşlemleri
// ============================================================

// Auth durumuna göre form göster/gizle
document.addEventListener('DOMContentLoaded', () => {
    (async function() {
        if (typeof sbClient !== 'undefined') {
            const { data: { session } } = await sbClient.auth.getSession();
            if (session) {
                document.getElementById('comment-login-prompt')?.classList.add('hidden');
                document.getElementById('comment-form')?.classList.remove('hidden');
                const user  = session.user;
                const uname = user.user_metadata?.username || user.email?.split('@')[0] || 'U';
                const avatarUrl = user.user_metadata?.avatar_url;
                const el    = document.getElementById('comment-user-avatar');
                if (el) {
                    if (avatarUrl) {
                        el.outerHTML = `<img src="${avatarUrl}" id="comment-user-avatar" alt="Avatar" class="w-9 h-9 rounded-full object-cover flex-shrink-0 border border-gray-700 mt-0.5">`;
                    } else {
                        el.textContent = uname.charAt(0).toUpperCase();
                    }
                }
                checkLikeStatus(session.access_token);
                checkSubscribeStatus(session.access_token);
            }
        }
    })();
});

async function deleteComment(id) {
    const token = getAuthToken();
    try {
        const res = await fetch(`<?= APP_URL ?>/api/comments.php?id=${id}&token=${token}`, {
            method: 'DELETE',
            headers: { 'Authorization': 'Bearer ' + token }
        });
        const data = await res.json();
        if (data.success) {
            window.location.reload();
        }
    } catch(e) {}
}

async function checkLikeStatus(token) {
    try {
        const res = await fetch('<?= APP_URL ?>/api/likes.php?video_id=<?= $video['id'] ?? '' ?>&token=' + token, {
            method: 'GET',
            headers: { 'Authorization': 'Bearer ' + token }
        });
        const data = await res.json();
        if ((data.data && data.data.liked) || data.liked) setLiked(true);
    } catch(e) {}
}

async function checkSubscribeStatus(token) {
    const btn = document.getElementById('subscribe-btn');
    if (!btn) return;
    const channelId = btn.dataset.channelId;
    if (!channelId) return;
    try { if (localStorage.getItem('sub_' + channelId) === '1') applySubState(btn, true); } catch (e) {}
    try {
        // Subscriptions tablosundan direkt okuma yapmak için likes mantığına benzer bir GET endpoint'i lazım,
        // veya abone ol butonuna tıklandığında toggle olduğu için şu anlık basitçe çalışır.
        // İdealde api/channels.php'ye GET ?check_subscribe=ID eklenebilir.
        const res = await fetch(`<?= APP_URL ?>/api/channels.php?check_subscribe=${channelId}&token=${token}`, {
            headers: { 'Authorization': 'Bearer ' + token }
        });
        const resp = await res.json();
        applySubState(btn, !!((resp.data && resp.data.subscribed) || resp.subscribed));
    } catch(e) {}
}

let isLiked = false;
document.getElementById('like-btn')?.addEventListener('click', async function() {
    const token = getAuthToken();
    if (!token) { window.location.href = '<?= APP_URL ?>/auth.php'; return; }

    const method = isLiked ? 'DELETE' : 'POST';
    try {
        const res  = await fetch('<?= APP_URL ?>/api/likes.php?token=' + token, {
            method,
            headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
            body: JSON.stringify({ video_id: VIDEO_ID, token: token })
        });
        const data = await res.json();
        if (data.success) {
            isLiked = !isLiked;
            setLiked(isLiked);
            const vRes  = await fetch(`<?= APP_URL ?>/api/videos.php?id=${VIDEO_ID}`);
            const vData = await vRes.json();
            if (vData.data) document.getElementById('like-count').textContent = formatNum(vData.data.likes_count || 0);
        }
    } catch(e) {}
});

function setLiked(liked) {
    isLiked = liked;
    const btn  = document.getElementById('like-btn');
    const icon = document.getElementById('like-icon');
    if (liked) {
        icon.className = 'fa-solid fa-heart text-sm text-red-400';
        btn.style.borderColor = 'rgba(255,0,122,0.5)';
        btn.style.background  = 'rgba(255,0,122,0.1)';
    } else {
        icon.className = 'fa-regular fa-heart text-sm';
        btn.style.borderColor = 'rgba(255,255,255,0.12)';
        btn.style.background  = 'rgba(255,255,255,0.06)';
    }
}

let replyParentId = null;

function replyTo(commentId, username) {
    replyParentId = commentId;
    const input = document.getElementById('comment-input');
    input.value = `@${username} `;
    input.focus();
    document.getElementById('cancel-reply-btn').classList.remove('hidden');
    
    // Scroll to form
    document.getElementById('comment-form-area').scrollIntoView({behavior: 'smooth', block: 'center'});
}

function cancelReply() {
    replyParentId = null;
    if (window._clearGif) window._clearGif();
    document.getElementById('comment-input').value = '';
    document.getElementById('cancel-reply-btn').classList.add('hidden');
    updateCharCount();
}

async function submitComment(e) {
    e.preventDefault();
    let token = getAuthToken();
    try {
        const { data: { session } } = await sbClient.auth.getSession();
        if (session && session.access_token) token = session.access_token;
    } catch (err) {}
    if (!token) { alert('Yorum yapmak için giriş yapmalısın.'); return; }
    let content = document.getElementById('comment-input').value.trim();
    if (window._pendingGif) content = (content + ' [gif:' + window._pendingGif + ']').trim();
    if (!content) return;

    const btn = document.getElementById('comment-submit-btn');
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin text-xs"></i> Gönderiliyor';

    try {
        const payload = { video_id: VIDEO_ID, content: content, token: token };
        if (replyParentId) payload.parent_id = replyParentId;

        const res  = await fetch('<?= APP_URL ?>/api/comments.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
            body: JSON.stringify(payload)
        });
        
        let data;
        try {
            data = await res.json();
        } catch (e) {
            throw new Error(`Geçersiz JSON yanıtı. Status: ${res.status}`);
        }

        if (data.success) {
            cancelReply();
            document.getElementById('no-comments-msg')?.remove();

            const c = data.data;
            const prof = c.profiles || {};
            const isReply = !!c.parent_id;
            
            const timeAgo = 'Şimdi';
            
            const contentParsed = window.renderCT(c.content);
            
            let avatarHtml = '';
            if (prof.avatar_url) {
                avatarHtml = `<img src="${escHtml(prof.avatar_url)}" alt="Avatar" class="${isReply ? 'w-8 h-8' : 'w-10 h-10'} rounded-full object-cover flex-shrink-0 border border-gray-700">`;
            } else {
                const initial = (prof.username || 'U').charAt(0).toUpperCase();
                avatarHtml = `<div class="${isReply ? 'w-8 h-8 text-xs' : 'w-10 h-10 text-sm'} rounded-full flex-shrink-0 flex items-center justify-center font-bold" style="background:linear-gradient(135deg,#00f5ff,#bf00ff);color:#000;">${initial}</div>`;
            }

            if (c.frame && /^[a-z]+$/.test(c.frame)) {
                avatarHtml = `<span class="nvf nvf-${c.frame} ${isReply ? 'nvf-sm' : 'nvf-md'}">${avatarHtml.replace('flex-shrink-0', 'flex-shrink-0 nvf-in')}</span>`;
            }

            const commentHtml = `
            <div class="flex gap-3 comment-item" id="comment-${escHtml(c.id)}">
                ${avatarHtml}
                <div class="flex-1 min-w-0">
                    <div class="flex items-center gap-2 mb-1">
                        <span class="text-sm font-bold text-white">${escHtml(prof.username)}</span>${c.is_premium ? '<span class="inline-flex items-center gap-1 text-[10px] font-bold px-1.5 py-0.5 rounded-full" style="background:linear-gradient(135deg,#ffd76a,#ff9d00);color:#000;"><i class="fa-solid fa-crown text-[8px]"></i>Premium</span>' : ''}
                        <span class="text-xs text-gray-600">${timeAgo}</span>
                    </div>
                    <p class="text-gray-300 text-sm leading-relaxed whitespace-pre-wrap">${contentParsed}</p>
                    <button onclick="replyTo('${escHtml(isReply ? c.parent_id : c.id)}', '${escHtml(prof.username)}')" class="text-xs text-gray-500 hover:text-cyan-400 mt-2 font-semibold transition-colors">Yanıtla</button>
                </div>
            </div>`;

            if (isReply) {
                const thread = document.getElementById('thread-' + c.parent_id);
                if (thread) {
                    let repliesContainer = thread.querySelector('.ml-10.mt-4');
                    if (!repliesContainer) {
                        repliesContainer = document.createElement('div');
                        repliesContainer.className = 'ml-10 mt-4 space-y-4 border-l-2 border-gray-800 pl-4';
                        thread.appendChild(repliesContainer);
                    }
                    repliesContainer.insertAdjacentHTML('beforeend', commentHtml);
                }
            } else {
                const newThreadHtml = `<div class="comment-thread" id="thread-${escHtml(c.id)}">${commentHtml}</div>`;
                document.getElementById('comments-list').insertAdjacentHTML('afterbegin', newThreadHtml);
            }
        } else {
            alert(data.message || 'Bir hata oluştu');
        }
    } catch(err) {
        alert('Bağlantı hatası: ' + err.message);
    }

    btn.disabled = false;
    btn.innerHTML = '<i class="fa-solid fa-paper-plane text-xs"></i> Gönder';
}

function shareVideo() {
    if (navigator.share) {
        navigator.share({ title: '<?= e($video['title']) ?>', url: window.location.href });
    } else {
        navigator.clipboard.writeText(window.location.href);
        const btn = document.getElementById('share-btn');
        const orig = btn.innerHTML;
        btn.innerHTML = '<i class="fa-solid fa-check text-sm"></i><span class="hidden sm:inline">Kopyalandı!</span>';
        btn.style.color = '#00f5ff';
        setTimeout(() => { btn.innerHTML = orig; btn.style.color = ''; }, 2000);
    }
}

function escHtml(t) {
    return t.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function formatNum(n) {
    if (n >= 1e6) return (n/1e6).toFixed(1)+'M';
    if (n >= 1e3) return (n/1e3).toFixed(1)+'K';
    return String(n);
}

// ============================================================
// Özellik 15: Çift Tıklama ile İleri/Geri Sarma
// ============================================================
const _playerContainer = document.getElementById('player-container');
const _mainVideo = document.getElementById('main-video');
let _lastClickTime = 0;

if (_playerContainer && _mainVideo) {
    // Mobil ve masaüstü için çift tıklama
    _playerContainer.addEventListener('click', (e) => {
        // Kontrol paneline veya ayarlara tıklanmışsa yoksay
        if (e.target.closest('#video-controls') || e.target.closest('#big-play-btn')) return;
        
        const currentTime = new Date().getTime();
        const timeDiff = currentTime - _lastClickTime;
        
        if (timeDiff < 400 && timeDiff > 0) {
            // Çift tıklama algılandı
            const rect = _playerContainer.getBoundingClientRect();
            const clickX = e.clientX - rect.left;
            
            // Ripple efekti
            const ripple = document.createElement('div');
            ripple.className = 'absolute pointer-events-none flex items-center justify-center font-bold text-3xl text-white rounded-full bg-white/20';
            ripple.style.width = '120px';
            ripple.style.height = '120px';
            ripple.style.top = '50%';
            ripple.style.transform = 'translateY(-50%)';
            ripple.style.animation = 'glowPulse 0.5s ease-out forwards';
            ripple.style.zIndex = '50';
            
            if (clickX < rect.width / 2) {
                // Sol taraf: Geri sar
                _mainVideo.currentTime = Math.max(0, _mainVideo.currentTime - 10);
                ripple.style.left = '15%';
                ripple.innerHTML = '<i class="fa-solid fa-backward"></i><span class="text-sm ml-1">-10s</span>';
            } else {
                // Sağ taraf: İleri sar
                _mainVideo.currentTime = Math.min(_mainVideo.duration, _mainVideo.currentTime + 10);
                ripple.style.right = '15%';
                ripple.innerHTML = '<span class="text-sm mr-1">+10s</span><i class="fa-solid fa-forward"></i>';
            }
            
            _playerContainer.appendChild(ripple);
            setTimeout(() => ripple.remove(), 500);
            
            _lastClickTime = 0; // Sıfırla
        } else {
            _lastClickTime = currentTime;
        }
    });
}
</script>

<script>
// ===== Geçmiş, Sonra İzle, Premium erken erişim / indirme =====
(function () {
    const VID  = <?= json_encode($videoId) ?>;
    const BASE = <?= json_encode(APP_URL) ?>;
    const LOCKED = <?= $earlyLocked ? 'true' : 'false' ?>;
    const video = document.getElementById('main-video');
    let tok = null;
    function api(path, opt) {
        opt = opt || {};
        opt.headers = Object.assign({ 'Authorization': 'Bearer ' + tok, 'X-Access-Token': tok }, opt.headers || {});
        return fetch(BASE + '/api/' + path + (path.includes('?') ? '&' : '?') + 'token=' + encodeURIComponent(tok), opt).then(r => r.json());
    }
    function setLater(on) {
        const i = document.getElementById('later-icon'), l = document.getElementById('later-label'), b = document.getElementById('later-btn');
        if (!i) return;
        i.className = (on ? 'fa-solid' : 'fa-regular') + ' fa-clock text-sm';
        if (l) l.textContent = on ? 'Kaydedildi' : 'Sonra İzle';
        if (b) b.style.color = on ? '#00f5ff' : '';
    }
    async function init() {
        try { const { data } = await sbClient.auth.getSession(); tok = data.session ? data.session.access_token : null; } catch (e) {}
        document.getElementById('later-btn')?.addEventListener('click', async () => {
            if (!tok) { location.href = BASE + '/auth.php'; return; }
            setLater(document.getElementById('later-icon').classList.contains('fa-regular'));
            try { const r = await api('watchlater.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ video_id: VID }) });
                  if (r.success) setLater(!!r.data.saved); } catch (e) {}
        });
        if (!tok) return;
        api('watchlater.php?video_id=' + VID).then(r => { if (r.success) setLater(!!r.data.saved); }).catch(() => {});
        api('auth.php').then(async r => {
            if (!(r && r.data && r.data.is_premium)) { const t = document.getElementById('early-lock-text'); if (t && LOCKED) t.textContent += ' Premium üyeler şimdi izleyebilir.'; return; }
            const a = await api('video_access.php?id=' + VID);
            if (!a.success) return;
            const dl = document.getElementById('premium-dl-btn');
            if (dl) { dl.href = a.data.video_url; dl.setAttribute('download', (a.data.title || 'video') + '.mp4'); dl.classList.remove('hidden'); dl.classList.add('flex'); }
            if (LOCKED && video) { document.getElementById('early-lock')?.remove(); video.src = a.data.video_url; video.load(); }
        }).catch(() => {});
        if (LOCKED) return;
        try {
            const r = await api('history.php?video_id=' + VID);
            const pos = r && r.data ? r.data.position : 0;
            if (pos > 5 && video) {
                const seek = () => { if (video.currentTime < 1) { try { video.currentTime = pos; } catch (e) {} } };
                if (video.readyState >= 1) seek(); else video.addEventListener('loadedmetadata', seek, { once: true });
            }
        } catch (e) {}
        let last = 0;
        const save = () => {
            if (!video || !video.duration || !isFinite(video.duration) || video.currentTime < 2) return;
            fetch(BASE + '/api/history.php?token=' + encodeURIComponent(tok), { method: 'POST', keepalive: true,
                headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + tok, 'X-Access-Token': tok },
                body: JSON.stringify({ video_id: VID, position: video.currentTime, duration: video.duration }) }).catch(() => {});
        };
        video && video.addEventListener('timeupdate', () => { const n = Date.now(); if (n - last > 15000 && !video.paused) { last = n; save(); } });
        video && video.addEventListener('pause', save);
        document.addEventListener('visibilitychange', () => { if (document.hidden) save(); });
    }
    window.addEventListener('load', init);
})();
</script>

<script>
// ===== Puanlama, kullanıcı listeleri, otomatik oynat =====
(function () {
    const VID = <?= json_encode($videoId) ?>, BASE = <?= json_encode(APP_URL) ?>;
    let tok = null;
    function api(path, opt) {
        opt = opt || {};
        opt.headers = Object.assign({ 'Content-Type': 'application/json' }, tok ? { 'Authorization': 'Bearer ' + tok, 'X-Access-Token': tok } : {}, opt.headers || {});
        return fetch(BASE + '/api/' + path + (tok ? (path.includes('?') ? '&' : '?') + 'token=' + encodeURIComponent(tok) : ''), opt).then(r => r.json());
    }
    const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

    // Otomatik oynat (player.js bu anahtarı kontrol eder)
    const at = document.getElementById('autoplay-toggle');
    try { at.checked = localStorage.getItem('neontv_autoplay') !== '0'; } catch (e) { at.checked = true; }
    at.addEventListener('change', () => { try { localStorage.setItem('neontv_autoplay', at.checked ? '1' : '0'); } catch (e) {} });

    // Puan
    const stars = document.querySelectorAll('#rating-stars i'), rtext = document.getElementById('rating-text');
    function paint(n) { stars.forEach(s => { const on = +s.dataset.r <= n; s.className = (on ? 'fa-solid' : 'fa-regular') + ' fa-star'; }); }
    let mine = 0;
    function showRating(d) { mine = d.mine || 0; paint(mine || Math.round(d.avg)); rtext.textContent = d.count ? d.avg + ' / 5 (' + d.count + ' oy)' + (mine ? ' · senin puanın: ' + mine : '') : 'Henüz puan yok'; }
    stars.forEach(s => {
        s.addEventListener('mouseenter', () => paint(+s.dataset.r));
        s.addEventListener('mouseleave', () => paint(mine));
        s.addEventListener('click', async () => {
            if (!tok) { location.href = BASE + '/auth.php'; return; }
            try { const j = await api('ratings.php', { method: 'POST', body: JSON.stringify({ video_id: VID, rating: +s.dataset.r }) }); if (j.success) showRating(j.data); } catch (e) {}
        });
    });

    // Listeler
    const menu = document.getElementById('pl-menu'), list = document.getElementById('pl-items');
    async function loadLists() {
        const j = await api('user_playlists.php?video_id=' + VID);
        if (!j.success) { list.innerHTML = '<p class="p-2 text-xs text-gray-500">Giriş yapmalısın.</p>'; return; }
        const L = j.data.lists;
        list.innerHTML = L.length ? L.map(l => '<label class="flex items-center gap-2 px-2 py-1.5 rounded-lg hover:bg-white/5 cursor-pointer text-gray-200"><input type="checkbox" class="accent-cyan-400" data-id="' + esc(l.id) + '"' + (l.has_video ? ' checked' : '') + '><span class="truncate flex-1">' + esc(l.title) + '</span><span class="text-xs text-gray-500">' + l.count + '</span></label>').join('') : '<p class="p-2 text-xs text-gray-500">Henüz listen yok. Aşağıdan oluştur.</p>';
    }
    list.addEventListener('change', async e => {
        const id = e.target.dataset.id; if (!id) return;
        try { await api('user_playlists.php', { method: 'POST', body: JSON.stringify({ action: 'toggle', playlist_id: id, video_id: VID }) }); } catch (x) {}
    });
    document.getElementById('pl-btn').addEventListener('click', async () => {
        if (!tok) { location.href = BASE + '/auth.php'; return; }
        menu.classList.toggle('hidden'); if (!menu.classList.contains('hidden')) loadLists();
    });
    document.addEventListener('click', e => { if (!document.getElementById('pl-wrap').contains(e.target)) menu.classList.add('hidden'); });
    document.getElementById('pl-new').addEventListener('submit', async e => {
        e.preventDefault();
        const inp = document.getElementById('pl-new-title'), t = inp.value.trim(); if (!t) return;
        try {
            const j = await api('user_playlists.php', { method: 'POST', body: JSON.stringify({ action: 'create', title: t }) });
            if (j.success) { await api('user_playlists.php', { method: 'POST', body: JSON.stringify({ action: 'toggle', playlist_id: j.data.list.id, video_id: VID }) }); inp.value = ''; loadLists(); }
            else alert(j.message || 'Oluşturulamadı');
        } catch (x) {}
    });

    window.addEventListener('load', async () => {
        try { const { data } = await sbClient.auth.getSession(); tok = data.session ? data.session.access_token : null; } catch (e) {}
        try { const j = await api('ratings.php?video_id=' + VID); if (j.success) showRating(j.data); } catch (e) {}
    });
})();
</script>

<script>
// ===== Yorum sabitleme (yalnızca admin) + bildirimden/son yorumlardan gelen #comment-ID bağlantısı =====
(function () {
    document.addEventListener('click', async e => {
        const b = e.target.closest('.pin-btn'); if (!b) return;
        b.disabled = true;
        try {
            const r = await (await fetch(<?= json_encode(APP_URL) ?> + '/api/comment_pin.php', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
                body: JSON.stringify({ comment_id: b.dataset.cid, pinned: b.dataset.pin === '1', csrf_token: <?= json_encode($isAdminViewer ? generateCsrfToken() : '') ?> }) })).json();
            if (r.success) location.reload(); else { alert(r.message || 'Yapılamadı'); b.disabled = false; }
        } catch (err) { b.disabled = false; }
    });
    const st = document.createElement('style');
    st.textContent = '@keyframes cmflash{0%,60%{box-shadow:0 0 0 2px #00f5ff,0 0 24px rgba(0,245,255,.55);background:rgba(0,245,255,.12)}100%{box-shadow:0 0 0 0 transparent;background:transparent}}.cm-flash{border-radius:12px;animation:cmflash 3.6s ease-out 1}';
    document.head.appendChild(st);
    function go() {
        const h = location.hash; if (!/^#comment-[0-9a-f-]{36}$/i.test(h)) return;
        const el = document.querySelector(h); if (!el) return;
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        el.classList.remove('cm-flash'); void el.offsetWidth; el.classList.add('cm-flash');
        setTimeout(() => el.classList.remove('cm-flash'), 3800);
    }
    if (document.readyState === 'complete') setTimeout(go, 350); else window.addEventListener('load', () => setTimeout(go, 350));
    window.addEventListener('hashchange', go);
})();
</script>
<script>
// ===== Yorum: sıralama, tepkiler, düzenleme =====
(function () {
    const VID = <?= json_encode($videoId) ?>, BASE = <?= json_encode(APP_URL) ?>;
    let tok = null, myId = null;
    const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
    function api(path, opt) {
        opt = opt || {};
        opt.headers = Object.assign({ 'Content-Type': 'application/json' }, tok ? { 'Authorization': 'Bearer ' + tok, 'X-Access-Token': tok } : {}, opt.headers || {});
        return fetch(BASE + '/api/' + path + (tok ? (path.includes('?') ? '&' : '?') + 'token=' + encodeURIComponent(tok) : ''), opt).then(r => r.json());
    }

    // Sıralama
    const list = document.getElementById('comments-list');
    const orig = list ? Array.from(list.querySelectorAll(':scope > .comment-thread')) : [];
    document.getElementById('comment-sort')?.addEventListener('change', e => {
        const m = e.target.value;
        const likes = t => parseInt((t.querySelector('.clike-n') || {}).textContent || '0', 10) || 0;
        let arr = orig.slice();
        if (m === 'new') arr.sort((a, b) => b.dataset.time - a.dataset.time);
        else if (m === 'old') arr.sort((a, b) => a.dataset.time - b.dataset.time);
        else if (m === 'top') arr.sort((a, b) => likes(b) - likes(a) || b.dataset.time - a.dataset.time);
        arr.sort((a, b) => (b.dataset.apin === '1') - (a.dataset.apin === '1')).forEach(t => list.appendChild(t));
    });

    // Tepkiler
    const EMO = ['👍', '🔥', '😂', '😮', '❤️'];
    let R = { counts: {}, mine: {} };
    function renderReact(box) {
        const id = box.dataset.id, c = R.counts[id] || {}, mine = R.mine[id] || [];
        box.innerHTML = EMO.map(e => {
            const n = c[e] || 0, on = mine.includes(e);
            if (!n && !on && !box.dataset.open) return '';
            return '<button type="button" class="react-btn text-xs px-1.5 py-0.5 rounded-full" data-e="' + e + '" style="border:1px solid ' + (on ? 'rgba(0,245,255,.6)' : 'rgba(255,255,255,.12)') + ';background:' + (on ? 'rgba(0,245,255,.12)' : 'transparent') + '">' + e + (n ? ' ' + n : '') + '</button>';
        }).join('') + '<button type="button" class="react-more text-xs text-gray-600 hover:text-cyan-400 px-1" title="Tepki ekle">' + (box.dataset.open ? '–' : '＋') + '</button>';
    }
    function renderAll() { document.querySelectorAll('.creact').forEach(renderReact); }
    document.addEventListener('click', async e => {
        const box = e.target.closest('.creact'); if (!box) return;
        if (e.target.closest('.react-more')) { box.dataset.open = box.dataset.open ? '' : '1'; if (!box.dataset.open) delete box.dataset.open; renderReact(box); return; }
        const b = e.target.closest('.react-btn'); if (!b) return;
        if (!tok) { location.href = BASE + '/auth.php'; return; }
        try {
            const j = await api('comment_reactions.php', { method: 'POST', body: JSON.stringify({ comment_id: box.dataset.id, emoji: b.dataset.e }) });
            if (!j.success) return;
            const id = box.dataset.id; R.counts[id] = R.counts[id] || {}; R.counts[id][b.dataset.e] = j.data.count;
            R.mine[id] = (R.mine[id] || []).filter(x => x !== b.dataset.e); if (j.data.on) R.mine[id].push(b.dataset.e);
            renderReact(box);
        } catch (x) {}
    });

    // Düzenleme (yalnızca kendi yorumların)
    function addEditButtons() {
        if (!myId) return;
        document.querySelectorAll('.comment-item').forEach(it => {
            if (it.dataset.uid !== myId || it.querySelector('.cedit-btn')) return;
            const holder = it.querySelector('.creact'); if (!holder) return;
            const b = document.createElement('button');
            b.type = 'button'; b.className = 'cedit-btn text-xs text-gray-500 hover:text-cyan-400 mt-1 mr-3 font-semibold';
            b.innerHTML = '<i class="fa-solid fa-pen text-[10px] mr-1"></i>Düzenle';
            holder.parentNode.insertBefore(b, holder);
        });
    }
    document.addEventListener('click', e => {
        const b = e.target.closest('.cedit-btn'); if (!b) return;
        const it = b.closest('.comment-item'), p = it.querySelector('.ctext'); if (!p || it.querySelector('.cedit-area')) return;
        const raw = p.textContent;
        const wrap = document.createElement('div'); wrap.className = 'cedit-area mt-1';
        wrap.innerHTML = '<textarea maxlength="2000" rows="3" class="w-full bg-black/30 border border-gray-700 rounded-lg p-2 text-sm text-white focus:outline-none focus:border-cyan-500"></textarea>' +
            '<div class="flex gap-2 mt-1"><button type="button" class="csave text-xs font-bold px-3 py-1 rounded-lg text-black" style="background:#00f5ff">Kaydet</button><button type="button" class="ccancel text-xs text-gray-400 px-3 py-1">Vazgeç</button></div>';
        wrap.querySelector('textarea').value = raw;
        p.style.display = 'none'; p.parentNode.insertBefore(wrap, p.nextSibling);
        wrap.querySelector('.ccancel').onclick = () => { wrap.remove(); p.style.display = ''; };
        wrap.querySelector('.csave').onclick = async () => {
            const v = wrap.querySelector('textarea').value.trim(); if (!v) return;
            try {
                const j = await api('comments.php', { method: 'PATCH', body: JSON.stringify({ id: it.dataset.cid, content: v }) });
                if (!j.success) { alert(j.message || 'Kaydedilemedi'); return; }
                p.innerHTML = window.renderCT(j.data && j.data.content ? j.data.content : v);
                const ed = it.querySelector('.cedited'); if (ed) ed.textContent = '(düzenlendi)';
                wrap.remove(); p.style.display = '';
            } catch (x) { alert('Kaydedilemedi'); }
        };
    });

    window.addEventListener('load', async () => {
        try { const { data } = await sbClient.auth.getSession(); if (data.session) { tok = data.session.access_token; myId = data.session.user.id; } } catch (e) {}
        try { const j = await api('comment_reactions.php?video_id=' + VID); if (j.success) R = { counts: j.data.counts || {}, mine: j.data.mine || {} }; } catch (e) {}
        renderAll(); addEditButtons();
    });
})();
</script>

<script>
// ===== Altyazı görünüm ayarları (tarayıcıda hatırlanır) =====
(function () {
    const KEY = 'neontv_sub_style', DEF = { size: '100', color: '#ffffff', bg: '0.75' };
    let st = DEF; try { st = Object.assign({}, DEF, JSON.parse(localStorage.getItem(KEY) || '{}')); } catch (e) {}
    const tag = document.createElement('style'); tag.id = 'sub-style-dyn'; document.head.appendChild(tag);
    function apply() {
        tag.textContent = 'video::cue{font-size:' + st.size + '%;color:' + st.color + ';background-color:rgba(0,0,0,' + st.bg + ');}';
        try { localStorage.setItem(KEY, JSON.stringify(st)); } catch (e) {}
    }
    apply();
    const m = { size: 'sub-size', color: 'sub-color', bg: 'sub-bg' };
    Object.keys(m).forEach(k => { const el = document.getElementById(m[k]); if (!el) return; el.value = st[k]; el.addEventListener('change', () => { st[k] = el.value; apply(); }); });
    document.getElementById('sub-reset')?.addEventListener('click', () => { st = Object.assign({}, DEF); Object.keys(m).forEach(k => { const el = document.getElementById(m[k]); if (el) el.value = st[k]; }); apply(); });
})();
</script>

<script>
// ===== Altyazı özeti (YZ) =====
(function () {
    const b = document.getElementById('sum-btn'); if (!b) return;
    const VID = <?= json_encode($videoId) ?>, BASE = <?= json_encode(APP_URL) ?>;
    let box = null;
    function ensureBox() {
        if (box) return box;
        box = document.createElement('div');
        box.className = 'w-full mt-3 p-4 rounded-2xl text-sm text-gray-200 leading-relaxed whitespace-pre-wrap';
        box.style.cssText = 'background:rgba(191,0,255,0.07);border:1px solid rgba(191,0,255,0.25);';
        const anchor = document.getElementById('rating-box');
        if (anchor && anchor.parentNode) anchor.parentNode.parentNode.insertBefore(box, anchor.parentNode.nextSibling);
        return box;
    }
    b.addEventListener('click', async () => {
        const bx = ensureBox();
        if (bx.dataset.done) { bx.style.display = bx.style.display === 'none' ? '' : 'none'; return; }
        let tok = null; try { const { data } = await sbClient.auth.getSession(); tok = data.session ? data.session.access_token : null; } catch (e) {}
        if (!tok) { location.href = BASE + '/auth.php'; return; }
        bx.textContent = 'Özet hazırlanıyor...'; b.disabled = true;
        try {
            const r = await fetch(BASE + '/api/ai_summary.php?video_id=' + encodeURIComponent(VID) + '&token=' + encodeURIComponent(tok), { headers: { 'Authorization': 'Bearer ' + tok, 'X-Access-Token': tok } });
            const j = await r.json();
            if (j.success) { bx.innerHTML = ''; const h = document.createElement('div'); h.className = 'text-xs font-bold mb-1'; h.style.color = '#d36bff'; h.textContent = '✨ Altyazı özeti (yapay zeka · hata yapabilir)'; const t = document.createElement('div'); t.textContent = j.data.summary; bx.appendChild(h); bx.appendChild(t); bx.dataset.done = '1'; }
            else bx.textContent = j.message || 'Özet alınamadı.';
        } catch (e) { bx.textContent = 'Özet alınamadı. Lütfen tekrar dene.'; }
        b.disabled = false;
    });
})();
</script>

<script>
// ===== İzleyici ısı çizgisi (en çok izlenen anlar) =====
(function () {
    const video = document.getElementById('main-video'), pc = document.getElementById('progress-container');
    if (!video || !pc) return;
    const VID = <?= json_encode($videoId) ?>, BASE = <?= json_encode(APP_URL) ?>;
    let hits = new Array(100).fill(0), last = -1, dirty = false;
    const wrap = document.createElement('div');
    wrap.style.cssText = 'position:absolute;left:0;right:0;bottom:100%;height:26px;pointer-events:none;opacity:0;transition:opacity .2s;margin-bottom:4px';
    pc.appendChild(wrap);
    pc.addEventListener('mouseenter', () => { wrap.style.opacity = '1'; });
    pc.addEventListener('mouseleave', () => { wrap.style.opacity = '.0'; });
    fetch(BASE + '/api/heatmap.php?video_id=' + encodeURIComponent(VID)).then(r => r.json()).then(j => {
        const b = j && j.data ? j.data.buckets : []; if (!b || b.length !== 100) return;
        const s = b.map((v, i) => ((b[i - 1] ?? v) + v + (b[i + 1] ?? v)) / 3);
        let d = 'M0,26 '; s.forEach((v, i) => { d += 'L' + (i + 0.5) + ',' + (26 - v * 24).toFixed(1) + ' '; }); d += 'L100,26 Z';
        wrap.innerHTML = '<svg viewBox="0 0 100 26" preserveAspectRatio="none" style="width:100%;height:100%"><path d="' + d + '" fill="rgba(191,0,255,0.45)" stroke="rgba(211,107,255,0.9)" stroke-width="0.6" vector-effect="non-scaling-stroke"/></svg>';
        wrap.style.opacity = '.0';
    }).catch(() => {});
    video.addEventListener('timeupdate', () => {
        if (video.paused || video.seeking || !video.duration || !isFinite(video.duration)) return;
        const bk = Math.min(99, Math.floor(video.currentTime / video.duration * 100));
        if (bk !== last) { last = bk; if (hits[bk] < 3) { hits[bk]++; dirty = true; } }
    });
    video.addEventListener('play', () => { last = -1; });
    const send = () => {
        if (!dirty) return; const body = JSON.stringify({ video_id: VID, hits: hits }); hits = new Array(100).fill(0); dirty = false;
        try { fetch(BASE + '/api/heatmap.php', { method: 'POST', keepalive: true, headers: { 'Content-Type': 'application/json' }, body: body }).catch(() => {}); } catch (e) {}
    };
    video.addEventListener('pause', send); video.addEventListener('ended', send);
    document.addEventListener('visibilitychange', () => { if (document.hidden) send(); });
    window.addEventListener('pagehide', send);
})();
</script>

<script>
// ===== Yorum metni (zaman damgası/GIF/@etiket), emoji + GIF seçici, zaman damgası tıklama =====
(function () {
    const BASE = <?= json_encode(APP_URL) ?>;
    const esc = t => String(t == null ? '' : t).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
    const GIF_RE = /\[gif:(https:\/\/media\d*\.giphy\.com\/[A-Za-z0-9_\/.\-]+\.(?:gif|webp))\]/g;
    window.renderCT = function (text) {
        let s = esc(text);
        s = s.replace(/(^|[^\d:\/])(?:(\d{1,2}):)?([0-5]?\d):([0-5]\d)(?![\d:])/g, (m, pre, h, mi, se) => {
            const sec = (h ? parseInt(h, 10) * 3600 : 0) + parseInt(mi, 10) * 60 + parseInt(se, 10);
            return pre + '<a href="#t=' + sec + '" class="ts-link text-cyan-400 hover:underline font-semibold" data-t="' + sec + '">' + m.slice(pre.length) + '</a>';
        });
        s = s.replace(/@([a-zA-Z0-9_.-]+)/g, '<a href="' + BASE + '/search.php?q=%40$1" class="text-cyan-400 hover:underline font-semibold">@$1</a>');
        return s.replace(GIF_RE, '<img src="$1" alt="GIF" class="cgif" loading="lazy">');
    };
    // Zaman damgasına tıkla -> videoyu o saniyeye al
    document.addEventListener('click', e => {
        const a = e.target.closest('.ts-link'); if (!a) return; e.preventDefault();
        const v = document.getElementById('main-video'); if (!v) return;
        try { v.currentTime = parseInt(a.dataset.t, 10); v.play().catch(() => {}); } catch (x) {}
        const pc = document.getElementById('player-container'); if (pc) pc.scrollIntoView({ behavior: 'smooth', block: 'center' });
    });
    // ---- Seçici ----
    const pick = document.getElementById('cpick'); if (!pick) return;
    const input = document.getElementById('comment-input'), emo = document.getElementById('cpick-emoji'), gifBox = document.getElementById('cpick-gif');
    const chip = document.getElementById('gif-chip'), chipImg = document.getElementById('gif-chip-img');
    const EMOJIS = '😀😁😂🤣😊😍😘😎🤩🥰😏😉😜😋🙃😇🥵🔥💦🍑🍆😈👀💋❤️💜💙💚🧡💔👍👎👏🙌🙏💪😮😲😱😳🥺😭😢😤😡🤔🙄😴🤤🤯🥳🎉💯✨⭐💥👌🤝🤞'.match(/\p{Extended_Pictographic}(?:\uFE0F)?/gu) || [];
    emo.innerHTML = EMOJIS.map(x => '<button type="button" class="emo-b px-1 rounded hover:bg-white/10">' + x + '</button>').join('');
    emo.addEventListener('click', e => {
        const b = e.target.closest('.emo-b'); if (!b) return;
        const st = input.selectionStart ?? input.value.length, en = input.selectionEnd ?? st;
        input.value = input.value.slice(0, st) + b.textContent + input.value.slice(en);
        input.focus(); input.selectionStart = input.selectionEnd = st + b.textContent.length;
        input.dispatchEvent(new Event('input'));
    });
    function open(which) {
        const same = !pick.classList.contains('hidden') && ((which === 'emoji') === !emo.classList.contains('hidden'));
        if (same) { pick.classList.add('hidden'); return; }
        pick.classList.remove('hidden'); emo.classList.toggle('hidden', which !== 'emoji'); gifBox.classList.toggle('hidden', which !== 'gif');
        if (which === 'gif' && !gifBox.dataset.loaded) { gifBox.dataset.loaded = '1'; loadGifs(''); }
    }
    document.getElementById('btn-emoji').onclick = () => open('emoji');
    document.getElementById('btn-gif').onclick = () => open('gif');
    async function token() { try { const { data } = await sbClient.auth.getSession(); return data.session ? data.session.access_token : null; } catch (e) { return null; } }
    const grid = document.getElementById('cpick-gifs');
    async function loadGifs(q) {
        const t = await token(); if (!t) { grid.innerHTML = '<p class="text-xs text-gray-500 col-span-full">Giriş yapmalısın.</p>'; return; }
        grid.innerHTML = '<p class="text-xs text-gray-500 col-span-full">Yükleniyor...</p>';
        try {
            const r = await fetch(BASE + '/api/giphy.php?q=' + encodeURIComponent(q) + '&token=' + encodeURIComponent(t), { headers: { 'Authorization': 'Bearer ' + t, 'X-Access-Token': t } });
            const j = await r.json(); const items = (j.data && j.data.items) || [];
            grid.innerHTML = items.length ? items.map(g => '<button type="button" class="gif-b" data-u="' + esc(g.url) + '"><img src="' + esc(g.preview) + '" loading="lazy" alt="" class="w-full h-20 object-cover rounded-lg"></button>').join('') : '<p class="text-xs text-gray-500 col-span-full">' + esc(j.message || 'Sonuç yok') + '</p>';
        } catch (e) { grid.innerHTML = '<p class="text-xs text-gray-500 col-span-full">GIF alınamadı.</p>'; }
    }
    let qt; document.getElementById('cpick-q').addEventListener('input', e => { clearTimeout(qt); qt = setTimeout(() => loadGifs(e.target.value.trim()), 400); });
    grid.addEventListener('click', e => {
        const b = e.target.closest('.gif-b'); if (!b) return;
        window._pendingGif = b.dataset.u; chipImg.src = b.dataset.u; chip.classList.remove('hidden'); pick.classList.add('hidden');
    });
    window._clearGif = () => { window._pendingGif = null; chip.classList.add('hidden'); chipImg.removeAttribute('src'); };
    document.getElementById('gif-chip-x').onclick = window._clearGif;
})();
</script>

<?php
// SEO: VideoObject (JSON-LD)
$ld = [
    '@context' => 'https://schema.org', '@type' => 'VideoObject',
    'name' => $video['title'],
    'description' => mb_substr(trim($video['description'] ?? '') ?: $video['title'], 0, 300),
    'thumbnailUrl' => [$video['thumbnail_url'] ?? ''],
    'uploadDate' => gmdate('c', strtotime($video['created_at'] ?? 'now')),
    'contentUrl' => $video['video_url'],
    'embedUrl' => APP_URL . '/video.php?id=' . $videoId,
    'isFamilyFriendly' => false,
];
if (!empty($video['duration'])) $ld['duration'] = 'PT' . (int)$video['duration'] . 'S';
if (!$earlyLocked): ?>
<script type="application/ld+json"><?= json_encode($ld, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG) ?></script>
<?php endif; ?>

<script>
// Yorum beğenileri
(function () {
    const BASE = <?= json_encode(APP_URL) ?>, VID = <?= json_encode($videoId) ?>;
    let tok = null;
    function call(path, opt) {
        opt = opt || {};
        opt.headers = Object.assign({ 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + tok, 'X-Access-Token': tok }, opt.headers || {});
        return fetch(BASE + '/api/' + path + (path.includes('?') ? '&' : '?') + 'token=' + encodeURIComponent(tok), opt).then(r => r.json());
    }
    function paint(btn, on) { const i = btn.querySelector('i'); i.className = (on ? 'fa-solid' : 'fa-regular') + ' fa-heart mr-1'; btn.style.color = on ? '#ff5fa8' : ''; }
    document.addEventListener('click', async e => {
        const b = e.target.closest('.clike-btn'); if (!b) return;
        if (!tok) { location.href = BASE + '/auth.php'; return; }
        if (b.dataset.busy) return;
        const nEl = b.querySelector('.clike-n'), wasOn = b.querySelector('i').classList.contains('fa-solid'), n0 = parseInt(nEl.textContent, 10) || 0;
        paint(b, !wasOn); nEl.textContent = Math.max(0, n0 + (wasOn ? -1 : 1));   // anında göster
        b.dataset.busy = '1';
        try {
            const j = await call('comment_likes.php', { method: 'POST', body: JSON.stringify({ comment_id: b.dataset.id }) });
            if (j.success) { paint(b, j.data.liked); nEl.textContent = j.data.count; } else throw new Error();
        } catch (x) { paint(b, wasOn); nEl.textContent = n0; }   // hata: geri al
        delete b.dataset.busy;
    });
    window.addEventListener('load', async () => {
        try { const { data } = await sbClient.auth.getSession(); tok = data.session ? data.session.access_token : null; } catch (e) {}
        if (!tok) return;
        try { const j = await call('comment_likes.php?video_id=' + VID); if (j.success) j.data.liked.forEach(id => { const b = document.querySelector('.clike-btn[data-id="' + id + '"]'); if (b) paint(b, true); }); } catch (e) {}
    });
})();
</script>

<?php include __DIR__ . '/components/footer.php'; ?>
