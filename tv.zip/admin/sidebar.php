<?php
// ============================================================
// NeonTV - Admin Sidebar (Responsive - Mobile Drawer)
// ============================================================
$currentFile  = basename($_SERVER['PHP_SELF'], '.php');
$adminUrl     = APP_URL . '/admin';
$currentRole  = getAdminRole();
$roleLabel    = getRoleLabel($currentRole);
$roleColor    = getRoleColor($currentRole);

// Menü öğeleri: 'roles' = hangi rollerin görebileceği (boş = herkese açık)
$navItems = [
    ['file' => 'index',       'icon' => 'fa-gauge',             'label' => 'Dashboard',       'roles' => []],
    ['file' => 'channels',    'icon' => 'fa-users-rectangle',   'label' => 'Kanallar',         'roles' => []],
    ['file' => 'upload',      'icon' => 'fa-upload',            'label' => 'Video Yukle',      'roles' => ['editor', 'moderator', 'superadmin']],
    ['file' => 'upload_link', 'icon' => 'fa-link',              'label' => 'Link ile Yukle',   'roles' => ['editor', 'moderator', 'superadmin']],
    ['file' => 'videos',      'icon' => 'fa-film',              'label' => 'Videolar',         'roles' => ['editor', 'moderator', 'superadmin']],
    ['file' => 'tools',       'icon' => 'fa-toolbox',           'label' => 'Araçlar',          'roles' => ['editor', 'moderator', 'superadmin']],
    ['file' => 'activity',    'icon' => 'fa-clock-rotate-left', 'label' => 'Aktivite Logu',   'roles' => ['moderator', 'superadmin']],
    ['file' => 'playlists',   'icon' => 'fa-list-ul',           'label' => 'Oynatma Listeleri','roles' => ['editor', 'moderator', 'superadmin']],
    ['file' => 'premium_perks','icon' => 'fa-crown',            'label' => 'Erken Erişim',     'roles' => ['editor', 'moderator', 'superadmin']],
    ['file' => 'link_check',  'icon' => 'fa-link-slash',        'label' => 'Kırık Bağlantı',   'roles' => ['editor', 'moderator', 'superadmin']],
    ['file' => 'channel_posts','icon' => 'fa-bullhorn',         'label' => 'Kanal Duyuruları', 'roles' => ['editor', 'moderator', 'superadmin']],
    ['file' => 'announcement','icon' => 'fa-bullhorn',         'label' => 'Duyuru Çubuğu',    'roles' => ['editor', 'superadmin']],
    ['file' => 'requests',    'icon' => 'fa-inbox',             'label' => 'Video İstekleri',  'roles' => ['editor', 'moderator', 'superadmin']],
    ['file' => 'messages',    'icon' => 'fa-envelope',          'label' => 'Mesajlar',         'roles' => ['moderator', 'superadmin']],
];

if ($currentRole === 'superadmin') {
    $navItems[] = ['file' => 'settings',    'icon' => 'fa-sliders',         'label' => 'Ayarlar',          'roles' => ['superadmin']];
    $navItems[] = ['file' => 'meta',        'icon' => 'fa-tags',             'label' => 'Meta Etiketler',   'roles' => ['superadmin']];
    $navItems[] = ['file' => 'admins',      'icon' => 'fa-user-shield',      'label' => 'Adminler',         'roles' => ['superadmin']];
    $navItems[] = ['file' => 'security',    'icon' => 'fa-shield-halved',    'label' => 'Güvenlik & IP',  'roles' => ['superadmin']];
    $navItems[] = ['file' => 'categories',  'icon' => 'fa-list',             'label' => 'Kategoriler',      'roles' => ['superadmin']];
    $navItems[] = ['file' => 'ads',         'icon' => 'fa-rectangle-ad',     'label' => 'Reklamlar',        'roles' => ['superadmin']];
    $navItems[] = ['file' => 'ad_reports',  'icon' => 'fa-chart-line',       'label' => 'Reklam Raporu',    'roles' => ['superadmin']];
    $navItems[] = ['file' => 'error_log',   'icon' => 'fa-bug',              'label' => 'Hata Günlüğü',     'roles' => ['superadmin']];
    $navItems[] = ['file' => 'ai_usage',    'icon' => 'fa-robot',            'label' => 'NeTvYZ Kullanımı', 'roles' => ['superadmin']];
    $navItems[] = ['file' => 'stats',       'icon' => 'fa-chart-column',     'label' => 'İstatistikler',    'roles' => ['superadmin']];
    $navItems[] = ['file' => 'slow',        'icon' => 'fa-gauge-high',       'label' => 'Yavaş İstekler',   'roles' => ['superadmin']];
    $navItems[] = ['file' => 'backup',      'icon' => 'fa-database',         'label' => 'Yedekleme',        'roles' => ['superadmin']];
    $navItems[] = ['file' => 'users',       'icon' => 'fa-crown',            'label' => 'Kullanıcılar',     'roles' => ['superadmin']];
    $navItems[] = ['file' => 'app',         'icon' => 'fa-mobile-screen',    'label' => 'Uygulama',         'roles' => ['superadmin']];
}
?>

<!-- ========== MOBILE OVERLAY ========== -->
<div id="sidebar-overlay"
     onclick="closeSidebar()"
     class="fixed inset-0 z-30 hidden lg:hidden"
     style="background:rgba(0,0,0,0.6);backdrop-filter:blur(2px);"></div>

<!-- ========== SIDEBAR ========== -->
<aside id="admin-sidebar"
       class="fixed top-0 left-0 h-full z-40 w-56 flex flex-col
              -translate-x-full transition-transform duration-300 ease-in-out
              lg:static lg:translate-x-0 lg:flex"
       style="background:#0d0d1a;border-right:1px solid rgba(255,255,255,0.06);">

    <!-- Logo -->
    <div class="px-5 py-5 flex-shrink-0" style="border-bottom:1px solid rgba(255,255,255,0.06);">
        <div class="flex items-center justify-between">
            <a href="<?= $adminUrl ?>/index.php" class="flex items-center gap-2">
                <i class="fa-solid fa-shield-halved text-lg" style="color:#00f5ff;filter:drop-shadow(0 0 6px #00f5ff);"></i>
                <div>
                    <span class="text-sm font-bold" style="background:linear-gradient(135deg,#00f5ff,#bf00ff);-webkit-background-clip:text;-webkit-text-fill-color:transparent;">NeonTV</span>
                    <span class="text-xs text-gray-600 block -mt-0.5">Admin Panel</span>
                </div>
            </a>
            <!-- Mobil Kapat Butonu -->
            <button onclick="closeSidebar()" class="lg:hidden text-gray-600 hover:text-white transition-colors p-1">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>
    </div>

    <!-- Nav -->
    <nav class="flex-1 p-3 space-y-1 mt-2 overflow-y-auto">
        <?php foreach ($navItems as $item): ?>
        <?php
            // Rol filtresi: boş dizi = herkese açık; dolu dizi = sadece belirtilen roller
            $itemRoles = $item['roles'] ?? [];
            if (!empty($itemRoles) && !in_array($currentRole, $itemRoles, true)) continue;
        ?>
        <a href="<?= $adminUrl ?>/<?= $item['file'] ?>.php"
           onclick="closeSidebar()"
           class="flex items-center gap-3 px-3 py-2.5 text-sm font-medium rounded-xl transition-all duration-200
                  <?= $currentFile === $item['file'] ? 'text-cyan-400' : 'text-gray-400 hover:text-white hover:bg-white/5' ?>"
           style="<?= $currentFile === $item['file'] ? 'background:rgba(0,245,255,0.08);border-left:2px solid #00f5ff;padding-left:10px;' : '' ?>">
            <i class="fa-solid <?= $item['icon'] ?> w-4 text-center text-xs"></i>
            <?= $item['label'] ?>
        </a>
        <?php endforeach; ?>
    </nav>

    <!-- Alt Kısım -->
    <div class="p-3 space-y-1 flex-shrink-0" style="border-top:1px solid rgba(255,255,255,0.06);">

        <!-- Kullanıcı Bilgisi + Rol Badge -->
        <div class="flex items-center gap-2.5 px-3 py-2.5 mb-1 rounded-xl" style="background:rgba(255,255,255,0.03);">
            <div class="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 text-xs font-bold"
                 style="background:linear-gradient(135deg,<?= $roleColor ?>22,<?= $roleColor ?>11);color:<?= $roleColor ?>;border:1px solid <?= $roleColor ?>33;">
                <?= strtoupper(substr($_SESSION['admin_username'] ?? 'A', 0, 1)) ?>
            </div>
            <div class="min-w-0 flex-1">
                <p class="text-xs font-semibold text-white truncate"><?= e($_SESSION['admin_username'] ?? 'Admin') ?></p>
                <span class="text-[10px] font-medium px-1.5 py-0.5 rounded-full" style="background:<?= $roleColor ?>18;color:<?= $roleColor ?>;"><?= $roleLabel ?></span>
            </div>
        </div>

        <a href="<?= APP_URL ?>/index.php" target="_blank"
           class="flex items-center gap-3 px-3 py-2.5 text-sm text-gray-500 hover:text-gray-300 rounded-xl hover:bg-white/5 transition-all">
            <i class="fa-solid fa-arrow-up-right-from-square w-4 text-center text-xs"></i>
            Siteyi Gor
        </a>
        <a href="<?= $adminUrl ?>/logout.php"
           class="flex items-center gap-3 px-3 py-2.5 text-sm text-gray-500 hover:text-red-400 rounded-xl hover:bg-red-500/5 transition-all">
            <i class="fa-solid fa-right-from-bracket w-4 text-center text-xs"></i>
            Cikis Yap
        </a>
    </div>
</aside>

<script>
function openSidebar() {
    document.getElementById('admin-sidebar').classList.remove('-translate-x-full');
    document.getElementById('sidebar-overlay').classList.remove('hidden');
    document.body.style.overflow = 'hidden';
}
function closeSidebar() {
    document.getElementById('admin-sidebar').classList.add('-translate-x-full');
    document.getElementById('sidebar-overlay').classList.add('hidden');
    document.body.style.overflow = '';
}
// ESC tuşu ile kapat
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') closeSidebar();
});
</script>
