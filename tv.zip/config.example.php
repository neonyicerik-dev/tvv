<?php
// ============================================================
// NeonTV - Ana Konfigürasyon Örneği (config.example.php)
// GERÇEK ANAHTARLARI BURAYA YAZMAYIN
// Bu dosyayı config.php olarak kopyalayıp doldurun.
// ============================================================

// Supabase
define('SUPABASE_URL',         getenv('SUPABASE_URL')         ?: 'https://YOUR_PROJECT.supabase.co');
define('SUPABASE_ANON_KEY',    getenv('SUPABASE_ANON_KEY')    ?: 'YOUR_ANON_KEY');
define('SUPABASE_SERVICE_KEY', getenv('SUPABASE_SERVICE_KEY') ?: 'YOUR_SERVICE_KEY');

// Cloudinary
define('CLOUDINARY_CLOUD_NAME',    getenv('CLOUDINARY_CLOUD_NAME')    ?: 'YOUR_CLOUD_NAME');
define('CLOUDINARY_API_KEY',       getenv('CLOUDINARY_API_KEY')       ?: 'YOUR_API_KEY');
define('CLOUDINARY_API_SECRET',    getenv('CLOUDINARY_API_SECRET')    ?: 'YOUR_API_SECRET');
define('CLOUDINARY_UPLOAD_PRESET', getenv('CLOUDINARY_UPLOAD_PRESET') ?: '');

// Gemini
define('GEMINI_API_KEY',  getenv('GEMINI_API_KEY')  ?: 'YOUR_GEMINI_KEY');
define('GEMINI_MODEL',    'gemini-2.5-flash');
define('GEMINI_API_BASE', 'https://generativelanguage.googleapis.com/v1beta/models/');

// CloudConvert
define('CLOUDCONVERT_API_KEY', getenv('CLOUDCONVERT_API_KEY') ?: 'YOUR_CLOUDCONVERT_KEY');

// Admin (superadmin yedeği – admin_users DB tablosunu tercih edin)
define('ADMIN_USERNAME',      getenv('ADMIN_USERNAME')      ?: 'Admin');
// Yeni hash oluşturmak için: php -r "echo password_hash('sifreniz', PASSWORD_BCRYPT);"
define('ADMIN_PASSWORD_HASH', getenv('ADMIN_PASSWORD_HASH') ?: '$2y$12$XXXX_CHANGE_ME_XXXX');

// Uygulama
define('APP_NAME',    'NeonTV');
define('APP_TAGLINE', 'Neon Işıklı Porno Deneyimi');
define('APP_URL',     ((!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off') || strtolower((string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https' || stripos((string)($_SERVER['HTTP_CF_VISITOR'] ?? ''), '"scheme":"https"') !== false ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost'));
define('SESSION_NAME', 'neontv_admin_session');

// Upload
define('MAX_CHUNK_SIZE',      1024 * 1024);
define('MAX_VIDEO_SIZE',      500 * 1024 * 1024);
define('MAX_THUMBNAIL_SIZE',  5 * 1024 * 1024);
define('ALLOWED_VIDEO_TYPES', ['video/mp4', 'video/webm', 'video/ogg', 'video/quicktime', 'video/x-msvideo']);
define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/webp', 'image/gif']);

// Sayfalama
define('VIDEOS_PER_PAGE',   15);
define('COMMENTS_PER_PAGE', 20);

// SSL / cURL – sunucunuzda CA sorunu varsa tam yol girin
define('CA_BUNDLE_PATH', getenv('CA_BUNDLE_PATH') ?: '');

// IP Gizlilik – ÜRETİMDE MUTLAKA GÜÇLÜ BİR DEĞER KOYUN (en az 32 rastgele karakter)
define('IP_HASH_SECRET', getenv('IP_HASH_SECRET') ?: 'CHANGE_ME_TO_RANDOM_32_CHAR_STRING_HERE');

// Güvenilen Proxiler (Cloudflare + sunucunuza özgü)
define('TRUSTED_PROXIES', array_filter(explode(',', getenv('TRUSTED_PROXIES') ?: implode(',', [
    '103.21.244.0/22', '103.22.200.0/22', '103.31.4.0/22',
    '104.16.0.0/13',  '104.24.0.0/14',  '108.162.192.0/18',
    '131.0.72.0/22',  '141.101.64.0/18', '162.158.0.0/15',
    '172.64.0.0/13',  '173.245.48.0/20', '188.114.96.0/20',
    '190.93.240.0/20', '197.234.240.0/22', '198.41.128.0/17',
    '127.0.0.1',
]))));

// Reklam
define('AD_DOUBLE_PREROLL_CHANCE', (float)(getenv('AD_DOUBLE_PREROLL_CHANCE') ?: 0.15)); // %15
define('AD_MIDROLL_CHANCE',        (float)(getenv('AD_MIDROLL_CHANCE') ?: 0.50));        // %50

// YZ kota
define('AI_FREE_MONTHLY_LIMIT',    (int)(getenv('AI_FREE_MONTHLY_LIMIT') ?: 5));
define('AI_PREMIUM_MONTHLY_LIMIT', (int)(getenv('AI_PREMIUM_MONTHLY_LIMIT') ?: 50));

// Session
if (session_status() === PHP_SESSION_NONE) {
    session_name(SESSION_NAME);
    $isHttps = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on';
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_strict_mode', 1);
    ini_set('session.cookie_samesite', 'Lax');
    if ($isHttps) ini_set('session.cookie_secure', 1);
    ini_set('session.gc_maxlifetime', 7200);
    session_start();
}

error_reporting(0);
ini_set('display_errors', 0);
date_default_timezone_set('Europe/Istanbul');
