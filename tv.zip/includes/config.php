<?php
// ============================================================
// NeonTV - Ana Konfigürasyon Dosyası
// ============================================================

// İsteğe bağlı gizli ayarlar (sunucuya özel): includes/secrets.php içinde putenv('ANAHTAR=değer'); kullanılabilir.
// PHP-FPM ortam değişkenlerini temizlediğinde (clear_env) getenv() boş döner; bu dosya o durumda çözüm sağlar.
if (is_file(__DIR__ . '/secrets.php')) require_once __DIR__ . '/secrets.php';

// HTTPS algılama: doğrudan HTTPS, ters vekil (Nginx/Cloudflare Flexible vb.) başlıkları veya 443 portu
function neonIsHttps(): bool {
    if (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off') return true;
    if (strtolower((string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https') return true;
    if (strtolower((string)($_SERVER['HTTP_X_FORWARDED_SSL'] ?? '')) === 'on') return true;
    if (stripos((string)($_SERVER['HTTP_CF_VISITOR'] ?? ''), '"scheme":"https"') !== false) return true;
    if ((string)($_SERVER['SERVER_PORT'] ?? '') === '443') return true;
    return false;
}

// Supabase Konfigürasyonu
define('SUPABASE_URL', getenv('SUPABASE_URL') ?: 'https://vbfhdjgngujkevchksbn.supabase.co');
define('SUPABASE_ANON_KEY', getenv('SUPABASE_ANON_KEY') ?: 'sb_publishable_1V9jQ68dhTleArJUkDYxDA_dNyYeQSh');
define('SUPABASE_SERVICE_KEY', getenv('SUPABASE_SERVICE_KEY') ?: 'sb_secret_HSzeShLss3DtVa4awfRjsw_3bJK26yn');

// Cloudinary Konfigürasyonu
define('CLOUDINARY_CLOUD_NAME', getenv('CLOUDINARY_CLOUD_NAME') ?: 'denymthhz');
define('CLOUDINARY_API_KEY', getenv('CLOUDINARY_API_KEY') ?: '124595213858883');
define('CLOUDINARY_API_SECRET', getenv('CLOUDINARY_API_SECRET') ?: 'TlVDwNllUzNVwmI6qwQ0OJ93sXo');
define('CLOUDINARY_UPLOAD_PRESET', getenv('CLOUDINARY_UPLOAD_PRESET') ?: '');

if (defined('CLOUDINARY_CLOUD_NAME') && CLOUDINARY_CLOUD_NAME === 'YOUR_CLOUD_NAME') {
    define('CLOUDINARY_NOT_CONFIGURED', true);
}

// Google AI Studio (Gemini) Konfigürasyonu
define('GEMINI_API_KEY', getenv('GEMINI_API_KEY') ?: 'AQ.Ab8RN6IwpmGhusF8Fms1VP_Vm4VV5NkrNNHZtemzqc2a1i03QQ');
define('GIPHY_API_KEY', getenv('GIPHY_API_KEY') ?: 'i8bYBUJqUNfwrtkImZsSPzHqJhXsF2BM');
define('GEMINI_MODEL', 'gemini-2.5-flash');
define('GEMINI_API_BASE', 'https://generativelanguage.googleapis.com/v1beta/models/');

// CloudConvert API Konfigürasyonu
define('CLOUDCONVERT_API_KEY', getenv('CLOUDCONVERT_API_KEY') ?: 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiYmM0NGViZWU4YTlmODIxZWU2NWQ3NWE5OWNiMGQ1OTU1ZWI3NjljNzY2NDZhYWM3NTA5NDY0MTk1YjM1ODg3YmNhNzQ5MWIwZTZjNWRhMDkiLCJpYXQiOjE3ODIxOTUzNzkuMDcyMDE0LCJuYmYiOjE3ODIxOTUzNzkuMDcyMDE1LCJleHAiOjQ5Mzc4Njg5NzkuMDY4MDMsInN1YiI6Ijc2MDcyODA2Iiwic2NvcGVzIjpbInVzZXIucmVhZCIsInVzZXIud3JpdGUiLCJwcmVzZXQud3JpdGUiLCJ3ZWJob29rLndyaXRlIiwicHJlc2V0LnJlYWQiLCJ0YXNrLnJlYWQiLCJ0YXNrLndyaXRlIiwid2ViaG9vay5yZWFkIl19.NNt3SAhwn_UQySHg1pk9GkZ7Xvbnn_H8CNoFXP8AtSqq7AR-JZVNquXLbtz1awEl3JCK1XM5HbA2mEn0ujf6AYbreWaYJTViNWKE0IY-o9VbJFlMOyy3U4MI3xKByrth7HVJOBNLOm7ahyTxtu0XOalFrU8otSPuI9Vvz6P91ApcQcCdCRy3OaKKkH9mx1PZ-nquWFI7L4tKT6hgE1c24A5r2evHbeFy_DxT5cqBRXPgoJa7Me06E8bZ_Q5t0kLSS-GZ1If1PMG98fz1v-64NLmb_Kn4ecOE1a4GPbWq_7C75zBoXQ5c2CdiPdLmgNgfDzVM8j8YKsuIe24Bfm5roPLMDz0pvrg_-__Ux71DMSZTC5EzxbAX06RqE4OkhnSWcD1YDKn52F75OpGZK5E8EFt6kDzrZVD9nGfBv_S2KKBsL6GsOFcksxrNJW3aJGboazsj10yri-c2-jz2ADyTJhnVgR5jeFhS_HLgkGJMS98P4GfOfULFppLgc2QXT1DAuHP94zKbOb-I-9X7XIzayWuBzelpfKO7f_BLU7j78d5Ri7xHaL4SWERUxfiioGJqnLbATg6C_TlZbDK-zDVbQo76aa0UauDCZUJQq0M40Lq0n9YTqPZ-UGA-kGIhlv6jECXssrRloPPtBUFJRsAN6ySGkB8aL6JAJIxu0tyu5KA');

// Admin Konfigürasyonu (config.php yedeği – superadmin için)
define('ADMIN_USERNAME', getenv('ADMIN_USERNAME') ?: 'Admin');
define('ADMIN_PASSWORD_HASH', getenv('ADMIN_PASSWORD_HASH') ?: '$2y$12$Er1nnrbitm1MWHXV3XJG9e19WHG5SB1KWN4xioi6eKBBsfQcy.Qpq');

// Uygulama Konfigürasyonu
define('APP_NAME', 'NeonTV');
define('APP_TAGLINE', 'Neon Işıklı Porno Deneyimi');
define('APP_URL', (neonIsHttps() ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost'));
// İzinli alan adları (CORS/Origin kontrolü; ayrıca istek yapılan host her zaman izinlidir). Ortam: ALLOWED_HOSTS=a.com,b.com
define('ALLOWED_HOSTS', array_values(array_filter(array_map('trim', explode(',', getenv('ALLOWED_HOSTS') ?: 'neontvapp.dpdns.org,neontv.qd.je,neontv.zya.me')))));
define('SESSION_NAME', 'neontv_admin_session');

// Upload Konfigürasyonu
define('MAX_CHUNK_SIZE', 1024 * 1024);
define('MAX_VIDEO_SIZE', 500 * 1024 * 1024);
define('MAX_THUMBNAIL_SIZE', 5 * 1024 * 1024);
define('ALLOWED_VIDEO_TYPES', ['video/mp4', 'video/webm', 'video/ogg', 'video/quicktime', 'video/x-msvideo']);
define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/webp', 'image/gif']);

// Sayfalama
define('VIDEOS_PER_PAGE', 15);
define('COMMENTS_PER_PAGE', 20);

// ============================================================
// G2: SSL / cURL Konfigürasyonu
// ============================================================
// Sunucuda CA paketi sorunları için: ortam değişkeniyle ya da burada ayarlayın
define('CA_BUNDLE_PATH', getenv('CA_BUNDLE_PATH') ?: (file_exists(__DIR__ . '/cacert.pem') ? __DIR__ . '/cacert.pem' : ''));

// ============================================================
// G5: IP Gizlilik
// ============================================================
// HMAC-SHA256 anahtarı – ÜRETİMDE MUTLAKA DEĞİŞTİRİN ve gizli tutun
define('IP_HASH_SECRET', getenv('IP_HASH_SECRET') ?: 'neontv_change_me_in_production_00000');

// Güvenilen proxy IP'leri/CIDR aralıkları (Cloudflare + özel)
// Cloudflare IPv4 aralıkları (2024): https://www.cloudflare.com/ips-v4
define('TRUSTED_PROXIES', array_filter(explode(',', getenv('TRUSTED_PROXIES') ?: implode(',', [
    // Yerel/özel ağ (Nginx, Docker, konteyner ağ geçidi) – arkasında Cloudflare olan kurulumlar için
    '127.0.0.0/8', '10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16', '100.64.0.0/10',
    '103.21.244.0/22',
    '103.22.200.0/22',
    '103.31.4.0/22',
    '104.16.0.0/13',
    '104.24.0.0/14',
    '108.162.192.0/18',
    '131.0.72.0/22',
    '141.101.64.0/18',
    '162.158.0.0/15',
    '172.64.0.0/13',
    '173.245.48.0/20',
    '188.114.96.0/20',
    '190.93.240.0/20',
    '197.234.240.0/22',
    '198.41.128.0/17',
    '127.0.0.1',   // localhost geliştirme için
]))));

// ============================================================
// F2: Reklam Konfigürasyonu
// ============================================================
define('AD_DOUBLE_PREROLL_CHANCE', (float)(getenv('AD_DOUBLE_PREROLL_CHANCE') ?: 0.15)); // %15
define('AD_MIDROLL_CHANCE',        (float)(getenv('AD_MIDROLL_CHANCE') ?: 0.50));        // %50

// ============================================================
// F5: YZ Kota Konfigürasyonu
// ============================================================
define('AI_FREE_MONTHLY_LIMIT',    (int)(getenv('AI_FREE_MONTHLY_LIMIT') ?: 5));
define('AI_PREMIUM_MONTHLY_LIMIT', (int)(getenv('AI_PREMIUM_MONTHLY_LIMIT') ?: 50));

// ============================================================
// Session Başlatma (G4 güvenlik iyileştirmeleri)
// ============================================================
// Performans: oturum yalnızca gerekirse başlatılır (admin çerezi varsa, admin sayfaları, iletişim formu).
// Sıradan ziyaretçi ve kullanıcı API istekleri oturum kilidi beklemez, her ziyaretçi için oturum dosyası oluşmaz.
$__script = $_SERVER['SCRIPT_NAME'] ?? '';
$__needSession = isset($_COOKIE[SESSION_NAME]) || str_contains($__script, '/admin/') || basename($__script) === 'iletisim.php';
if ($__needSession && session_status() === PHP_SESSION_NONE) {
    session_name(SESSION_NAME);
    $isHttps = neonIsHttps();
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_strict_mode', 1);
    ini_set('session.cookie_samesite', 'Lax');
    if ($isHttps) {
        ini_set('session.cookie_secure', 1);
    }
    ini_set('session.gc_maxlifetime', 7200); // 2 saat
    session_start();

    // 2 saatlik boşta kalma zaman aşımı
    if (isset($_SESSION['admin_last_activity'])) {
        if (time() - $_SESSION['admin_last_activity'] > 7200) {
            // Oturumu sonlandır
            session_unset();
            session_destroy();
            session_start();
        }
    }
    if (isset($_SESSION['admin_logged_in'])) {
        $_SESSION['admin_last_activity'] = time();
    }
}

// ============================================================
// Hata Raporlama (Production'da kapalı)
// ============================================================
// Hatalar ekrana basılmaz; uyarı ve üzeri hatalar logs/app_errors.log dosyasına yazılır
error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED & ~E_STRICT);
ini_set('display_errors', 0);
require_once __DIR__ . '/error_logger.php';

// Timezone
date_default_timezone_set('Europe/Istanbul');

// Yavaş istek günlüğü (logs/slow_requests.log)
require_once __DIR__ . '/slowlog.php';
require_once __DIR__ . '/push.php';
