<?php
// ============================================================
// NeonTV - Supabase REST API Helper Sınıfı
// ============================================================
require_once __DIR__ . '/config.php';

class Supabase {
    /** İstek boyunca veritabanı çağrı sayısı/süresi (yavaş istek günlüğü için) */
    public static array $stats = ['n' => 0, 'ms' => 0.0, 'slow' => '', 'slowms' => 0];
    private string $url;
    private string $anonKey;
    private string $serviceKey;

    public function __construct() {
        $this->url        = SUPABASE_URL;
        $this->anonKey    = SUPABASE_ANON_KEY;
        $this->serviceKey = SUPABASE_SERVICE_KEY;
    }

    /** İstek boyunca tek curl tutamağı (bağlantı yeniden kullanılır); her çağrıda seçenekler sıfırlanır */
    private static function sharedHandle() {
        static $h = null;
        if ($h === null) $h = curl_init(); else curl_reset($h);
        return $h;
    }

    // --------------------------------------------------------
    // Ana HTTP İstek Metodu (G2: SSL doğrulama zorunlu)
    // --------------------------------------------------------
    private function request(
        string  $method,
        string  $endpoint,
        ?array  $data = null,
        bool    $useServiceKey = false,
        ?string $userToken = null,
        array   $extraHeaders = []
    ): array {
        $url    = $this->url . '/rest/v1/' . $endpoint;
        $apiKey = $useServiceKey ? $this->serviceKey : $this->anonKey;
        $bearer = $userToken ?? $apiKey;

        $headers = array_merge([
            'Content-Type: application/json',
            'Prefer: return=representation',
            'apikey: ' . $apiKey,
            'Authorization: Bearer ' . $bearer,
        ], $extraHeaders);

        // Aynı istek içinde bağlantıyı yeniden kullan (her sorguda yeni TLS el sıkışması yapma)
        $ch = self::sharedHandle();
        $opts = [
            CURLOPT_URL             => $url,
            CURLOPT_RETURNTRANSFER  => true,
            CURLOPT_HTTPHEADER      => $headers,
            CURLOPT_ENCODING        => '',
            CURLOPT_TCP_KEEPALIVE   => 1,
            CURLOPT_TIMEOUT         => 30,
            CURLOPT_CONNECTTIMEOUT  => 10,
            CURLOPT_SSL_VERIFYPEER  => true,
            CURLOPT_SSL_VERIFYHOST  => 2,
        ];

        // G2: Özel CA bundle yolu tanımlanmışsa kullan
        if (defined('CA_BUNDLE_PATH') && CA_BUNDLE_PATH !== '') {
            $opts[CURLOPT_CAINFO] = CA_BUNDLE_PATH;
        }

        curl_setopt_array($ch, $opts);

        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        } elseif (in_array($method, ['PATCH', 'PUT', 'DELETE'], true)) {
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
            if ($data !== null) {
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            }
        } elseif ($method === 'HEAD') {
            curl_setopt($ch, CURLOPT_NOBODY, true);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'HEAD');
        }

        $__t0 = microtime(true);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error    = curl_error($ch);
        $__ms = (microtime(true) - $__t0) * 1000;
        self::$stats['n']++; self::$stats['ms'] += $__ms;
        if ($__ms > self::$stats['slowms']) { self::$stats['slowms'] = (int)$__ms; self::$stats['slow'] = $method . ' ' . (string)strtok($endpoint, '?') . ' ' . (int)$__ms . 'ms'; }

        if ($error) {
            error_log('[Supabase] cURL error: ' . $error . ' (endpoint: ' . $endpoint . ')');
            return ['data' => null, 'status' => 0, 'error' => 'Bağlantı hatası'];
        }

        $decoded = json_decode($response, true);
        return [
            'data'   => $decoded,
            'status' => $httpCode,
            'error'  => ($httpCode >= 400) ? ($decoded['message'] ?? 'HTTP ' . $httpCode) : null,
        ];
    }

    // --------------------------------------------------------
    // SELECT
    // --------------------------------------------------------
    public function select(
        string  $table,
        string  $query = '',
        bool    $useServiceKey = false,
        ?string $userToken = null
    ): array {
        $endpoint = $table . ($query ? '?' . $query : '');
        return $this->request('GET', $endpoint, null, $useServiceKey, $userToken);
    }

    // --------------------------------------------------------
    // INSERT
    // --------------------------------------------------------
    public function insert(
        string  $table,
        array   $data,
        bool    $useServiceKey = false,
        ?string $userToken = null
    ): array {
        $res = $this->request('POST', $table, $data, $useServiceKey, $userToken);
        // Web push: yeni bildirim eklenince kullanıcıya (abonesiyse) tarayıcı bildirimi gönder
        if ($table === 'notifications' && ($res['status'] ?? 500) < 300 && !empty($data['user_id']) && function_exists('nvPushSchedule')) nvPushSchedule((string)$data['user_id']);
        return $res;
    }

    // --------------------------------------------------------
    // UPDATE
    // --------------------------------------------------------
    public function update(
        string $table,
        array  $data,
        string $condition,
        bool   $useServiceKey = false
    ): array {
        $endpoint = $table . '?' . $condition;
        return $this->request('PATCH', $endpoint, $data, $useServiceKey);
    }

    // --------------------------------------------------------
    // DELETE
    // --------------------------------------------------------
    public function delete(
        string  $table,
        string  $condition,
        bool    $useServiceKey = false,
        ?string $userToken = null
    ): array {
        $endpoint = $table . '?' . $condition;
        return $this->request('DELETE', $endpoint, null, $useServiceKey, $userToken);
    }

    // --------------------------------------------------------
    // RPC (PostgreSQL Function Call)
    // --------------------------------------------------------
    public function rpc(
        string  $function,
        array   $params = [],
        bool    $useServiceKey = false,
        ?string $userToken = null
    ): array {
        return $this->request('POST', 'rpc/' . $function, $params, $useServiceKey, $userToken);
    }

    // --------------------------------------------------------
    // Kullanıcı Token Doğrulama
    // --------------------------------------------------------
    public function verifyToken(string $token): ?array {
        $ch = self::sharedHandle();
        $opts = [
            CURLOPT_URL             => $this->url . '/auth/v1/user',
            CURLOPT_RETURNTRANSFER  => true,
            CURLOPT_HTTPHEADER      => [
                'apikey: ' . $this->anonKey,
                'Authorization: Bearer ' . $token,
            ],
            CURLOPT_TIMEOUT         => 10,
            CURLOPT_CONNECTTIMEOUT  => 5,
            CURLOPT_SSL_VERIFYPEER  => true,
            CURLOPT_SSL_VERIFYHOST  => 2,
        ];
        if (defined('CA_BUNDLE_PATH') && CA_BUNDLE_PATH !== '') {
            $opts[CURLOPT_CAINFO] = CA_BUNDLE_PATH;
        }
        curl_setopt_array($ch, $opts);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err      = curl_error($ch);
        if ($err) { error_log('[Supabase::verifyToken] ' . $err); return null; }
        return ($httpCode === 200) ? json_decode($response, true) : null;
    }

    // --------------------------------------------------------
    // Kullanıcı Kaydı
    // --------------------------------------------------------
    public function signUp(string $email, string $password, array $metadata = []): array {
        return $this->authRequest('/auth/v1/signup', [
            'email'    => $email,
            'password' => $password,
            'data'     => $metadata,
        ]);
    }

    // --------------------------------------------------------
    // Kullanıcı Girişi
    // --------------------------------------------------------
    public function signIn(string $email, string $password): array {
        return $this->authRequest('/auth/v1/token?grant_type=password', [
            'email'    => $email,
            'password' => $password,
        ]);
    }

    // --------------------------------------------------------
    // Auth işlemleri için ortak yardımcı
    // --------------------------------------------------------
    private function authRequest(string $path, array $body): array {
        $ch   = curl_init();
        $opts = [
            CURLOPT_URL             => $this->url . $path,
            CURLOPT_POST            => true,
            CURLOPT_RETURNTRANSFER  => true,
            CURLOPT_POSTFIELDS      => json_encode($body),
            CURLOPT_HTTPHEADER      => [
                'Content-Type: application/json',
                'apikey: ' . $this->anonKey,
            ],
            CURLOPT_TIMEOUT         => 15,
            CURLOPT_CONNECTTIMEOUT  => 5,
            CURLOPT_SSL_VERIFYPEER  => true,
            CURLOPT_SSL_VERIFYHOST  => 2,
        ];
        if (defined('CA_BUNDLE_PATH') && CA_BUNDLE_PATH !== '') {
            $opts[CURLOPT_CAINFO] = CA_BUNDLE_PATH;
        }
        curl_setopt_array($ch, $opts);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err      = curl_error($ch);
        curl_close($ch);
        if ($err) { error_log('[Supabase::authRequest] ' . $err); }
        return ['data' => json_decode($response, true), 'status' => $httpCode];
    }

    // --------------------------------------------------------
    // Yardımcı: Tek kayıt döndür
    // --------------------------------------------------------
    public function first(string $table, string $query = '', bool $useServiceKey = false): ?array {
        $result = $this->select($table, $query . '&limit=1', $useServiceKey);
        if ($result['status'] === 200 && !empty($result['data'])) {
            return $result['data'][0];
        }
        return null;
    }

    // --------------------------------------------------------
    // Yardımcı: Sayım döndür (count exact)
    // --------------------------------------------------------
    public function count(string $table, string $query = '', bool $useServiceKey = false): int {
        $endpoint = $table . ($query ? '?' . $query : '');
        $ch   = self::sharedHandle();
        $apiKey  = $useServiceKey ? $this->serviceKey : $this->anonKey;
        $opts = [
            CURLOPT_URL             => $this->url . '/rest/v1/' . $endpoint,
            CURLOPT_NOBODY          => true,
            CURLOPT_RETURNTRANSFER  => true,
            CURLOPT_HEADER          => true,
            CURLOPT_HTTPHEADER      => [
                'apikey: ' . $apiKey,
                'Authorization: Bearer ' . $apiKey,
                'Prefer: count=exact',
            ],
            CURLOPT_TIMEOUT         => 10,
            CURLOPT_CONNECTTIMEOUT  => 5,
            CURLOPT_SSL_VERIFYPEER  => true,
            CURLOPT_SSL_VERIFYHOST  => 2,
        ];
        if (defined('CA_BUNDLE_PATH') && CA_BUNDLE_PATH !== '') {
            $opts[CURLOPT_CAINFO] = CA_BUNDLE_PATH;
        }
        curl_setopt_array($ch, $opts);
        $response = curl_exec($ch);
        // Content-Range: 0-24/47
        if (preg_match('/Content-Range:\s*\d+-\d+\/(\d+)/i', $response, $m)) {
            return (int)$m[1];
        }
        return 0;
    }

    // --------------------------------------------------------
    // Auth Admin: Kayıtlı Kullanıcıları Listele
    // --------------------------------------------------------
    public function adminListUsers(int $page = 1, int $perPage = 100): array {
        $ch = curl_init();
        $opts = [
            CURLOPT_URL             => $this->url . '/auth/v1/admin/users?page=' . $page . '&per_page=' . $perPage,
            CURLOPT_RETURNTRANSFER  => true,
            CURLOPT_HTTPHEADER      => [
                'apikey: ' . $this->serviceKey,
                'Authorization: Bearer ' . $this->serviceKey,
            ],
            CURLOPT_TIMEOUT         => 15,
            CURLOPT_CONNECTTIMEOUT  => 5,
            CURLOPT_SSL_VERIFYPEER  => true,
            CURLOPT_SSL_VERIFYHOST  => 2,
        ];
        if (defined('CA_BUNDLE_PATH') && CA_BUNDLE_PATH !== '' && file_exists(CA_BUNDLE_PATH)) {
            $opts[CURLOPT_CAINFO] = CA_BUNDLE_PATH;
        }
        curl_setopt_array($ch, $opts);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err      = curl_error($ch);
        curl_close($ch);

        if ($err || $httpCode >= 400) {
            error_log('[Supabase::adminListUsers] ' . ($err ?: 'HTTP ' . $httpCode));
            return [];
        }

        $decoded = json_decode($response, true);
        return $decoded['users'] ?? ($decoded ?: []);
    }

    // --------------------------------------------------------
    // Auth Admin: Kullanıcıyı sil (bağlı tablolar ON DELETE CASCADE ile temizlenir)
    // --------------------------------------------------------
    public function adminDeleteUser(string $userId): bool {
        if (!preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i', $userId)) return false;
        $ch = curl_init();
        $opts = [
            CURLOPT_URL             => $this->url . '/auth/v1/admin/users/' . $userId,
            CURLOPT_CUSTOMREQUEST   => 'DELETE',
            CURLOPT_RETURNTRANSFER  => true,
            CURLOPT_HTTPHEADER      => [
                'apikey: ' . $this->serviceKey,
                'Authorization: Bearer ' . $this->serviceKey,
            ],
            CURLOPT_TIMEOUT         => 20,
            CURLOPT_CONNECTTIMEOUT  => 5,
            CURLOPT_SSL_VERIFYPEER  => true,
            CURLOPT_SSL_VERIFYHOST  => 2,
        ];
        if (defined('CA_BUNDLE_PATH') && CA_BUNDLE_PATH !== '' && file_exists(CA_BUNDLE_PATH)) {
            $opts[CURLOPT_CAINFO] = CA_BUNDLE_PATH;
        }
        curl_setopt_array($ch, $opts);
        curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err      = curl_error($ch);
        curl_close($ch);
        if ($err || $httpCode >= 400) {
            error_log('[Supabase::adminDeleteUser] ' . ($err ?: 'HTTP ' . $httpCode));
            return false;
        }
        return true;
    }
}
